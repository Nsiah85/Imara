// This file is deprecated. Please use pages/ShopPage.tsx instead.
import React from 'react';
import { Navigate } from 'react-router-dom';

const ShopPage: React.FC = () => {
  return <Navigate to="/shop" replace />;
};

export default ShopPage;