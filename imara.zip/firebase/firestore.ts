// FIX: Import members using @firebase/firestore to prevent module shadowing
import * as Firestore from 'firebase/firestore';
import app from './config.ts';
// FIX: Import User type directly from the firebase/auth SDK (using @firebase/auth to match auth.ts fix)
import type { User as FirebaseUser } from 'firebase/auth';

// FIX: Initialize db here to break circular dependency.
export const db = Firestore.getFirestore(app);

// Helper to remove undefined values that cause Firestore to throw
const sanitizeData = (obj: any): any => {
    if (obj === undefined) return null;
    if (obj === null || typeof obj !== 'object') return obj;
    if (obj instanceof Date) return obj;
    if (Array.isArray(obj)) return obj.map(sanitizeData);
    const result: any = {};
    for (const key in obj) {
        const val = sanitizeData(obj[key]);
        if (val !== undefined) {
            result[key] = val;
        }
    }
    return result;
};

// Re-exporting functions for easier use in components
export const doc = Firestore.doc;
export const serverTimestamp = Firestore.serverTimestamp;
export const collection = Firestore.collection;
export const query = Firestore.query;
export const onSnapshot = Firestore.onSnapshot;
export const orderBy = Firestore.orderBy;
export const where = Firestore.where;
export const limit = Firestore.limit;
export const Timestamp = Firestore.Timestamp;
export const getDoc = Firestore.getDoc;
export const deleteDoc = Firestore.deleteDoc;

// Wrapped setDoc to sanitize data
export const setDoc = (reference: Firestore.DocumentReference<any, any>, data: any, options?: Firestore.SetOptions) => {
    return options ? Firestore.setDoc(reference, sanitizeData(data), options) : Firestore.setDoc(reference, sanitizeData(data));
};

// Wrapped addDoc to sanitize data
export const addDoc = (reference: Firestore.CollectionReference<any, any>, data: any) => {
    return Firestore.addDoc(reference, sanitizeData(data));
};

// Wrapped updateDoc to sanitize data
export const updateDoc = (reference: Firestore.DocumentReference<any, any>, data: any) => {
    return Firestore.updateDoc(reference, sanitizeData(data));
};


/*
  Example Firestore Schemas

  // users collection
  {
    uid: "firebase-auth-uid",
    fullName: "Amina Kante",
    email: "amina@example.com",
    role: "user", // 'user', 'partner', 'admin'
    isVerified: false,
    subscriptionPlanId: "vendor_basic" | null,
    createdAt: Timestamp,
    // ... other profile fields
  }

  // toasts (Gist Posts) collection
  {
    id: "auto-generated-id",
    creatorId: "user-uid",
    creatorName: "Amina Kante",
    creatorAvatarUrl: "...",
    content: "My new post text...",
    mediaUrls: ["storage-url-1", "storage-url-2"],
    languageCode: "en",
    sentimentTag: "Positive",
    createdAt: Timestamp,
    engagement: { likes: 10, comments: 2, ... }
  }
  
  // You can follow similar patterns for `chats`, `products`, and `orders` collections.
*/


/**
 * Creates a user document in Firestore from a Firebase Auth user object.
 * @param userAuth - The user object from Firebase Authentication.
 * @param additionalInformation - Optional additional data to store.
 */
export const createUserDocumentFromAuth = async (
  userAuth: FirebaseUser,
  additionalInformation = {}
) => {
  if (!userAuth) return;

  const userDocRef = doc(db, 'users', userAuth.uid);
  const userSnapshot = await getDoc(userDocRef);

  if (!userSnapshot.exists()) {
    const { displayName, email } = userAuth;
    const createdAt = new Date();

    try {
      await setDoc(userDocRef, {
        fullName: displayName,
        email,
        createdAt: serverTimestamp(),
        role: 'user', // Default role
        ...additionalInformation,
      });
    } catch (error) {
      console.error('Error creating user document:', error);
    }
  }

  return userDocRef;
};