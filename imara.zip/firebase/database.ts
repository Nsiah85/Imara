import { getDatabase, ref, set, get, child, update, remove, onValue } from 'firebase/database';
import app from './config.ts';

export const database = getDatabase(app);

export { ref as dbRef, set as dbSet, get as dbGet, child, update as dbUpdate, remove as dbRemove, onValue };
