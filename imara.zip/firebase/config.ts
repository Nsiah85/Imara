
import { initializeApp, getApp, getApps } from 'firebase/app';
import { initializeAppCheck, ReCaptchaV3Provider } from 'firebase/app-check';

// Ensure we load from Vite's import.meta.env for client-side environments
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || 'monkix-core.firebaseapp.com',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'monkix-core',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || 'monkix-core.appspot.com',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
  databaseURL: import.meta.env.VITE_FIREBASE_DATABASE_URL || `https://${import.meta.env.VITE_FIREBASE_PROJECT_ID || 'monkix-core'}.firebaseio.com`,
};

// Initialize Firebase only once
let app;
if (!getApps().length) {
    if (firebaseConfig.apiKey) {
        app = initializeApp(firebaseConfig);
        
        if (typeof window !== 'undefined') {
            const recaptchaKey = import.meta.env.VITE_RECAPTCHA_SITE_KEY;
            
            if (recaptchaKey) {
                // Enable debug tokens for non-production domains (likelocalhost or Cloud Run preview URLs)
                if (import.meta.env.DEV || window.location.hostname.includes('run.app')) {
                    (window as any).FIREBASE_APPCHECK_DEBUG_TOKEN = true;
                }
                
                try {
                    initializeAppCheck(app, {
                        provider: new ReCaptchaV3Provider(recaptchaKey),
                        isTokenAutoRefreshEnabled: true
                    });
                } catch (error) {
                    console.warn("App Check initialization failed:", error);
                }
            }
        }
    } else {
        console.warn("Firebase API Key is missing. Check your .env.local file.");
    }
} else {
    app = getApp();
}

export default app;
