// FIX: Import members using @firebase/storage to prevent module shadowing
import * as Storage from 'firebase/storage';
import app from './config.ts';

// FIX: Initialize storage here to break circular dependency.
export const storage = Storage.getStorage(app);

// FIX: Re-export storage functions for consistency.
export const ref = Storage.ref;
export const uploadBytes = Storage.uploadBytes;
export const getDownloadURL = Storage.getDownloadURL;

/**
 * Uploads a file to Firebase Storage.
 * @param file The file to upload.
 * @param path The path in storage where the file should be saved (e.g., 'toasts/toastId').
 * @returns The download URL of the uploaded file.
 */
export const uploadFile = async (file: File, path: string): Promise<string> => {
    if (!file) {
        throw new Error("No file provided for upload.");
    }

    const storageRef = ref(storage, `${path}/${file.name}`);
    
    try {
        const snapshot = await uploadBytes(storageRef, file);
        const downloadURL = await getDownloadURL(snapshot.ref);
        return downloadURL;
    } catch (error) {
        console.error("Error uploading file:", error);
        throw new Error("File upload failed.");
    }
};