
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  sendPasswordResetEmail, 
  signOut, 
  onAuthStateChanged,
  PhoneAuthProvider,
  RecaptchaVerifier as FirebaseRecaptchaVerifier,
  User as FirebaseUser,
  RecaptchaVerifier as RecaptchaVerifierType
} from 'firebase/auth';

import app from './config.ts';

// Initialize and export auth instance.
export const auth = getAuth(app);

// Re-export the class.
export const RecaptchaVerifier = FirebaseRecaptchaVerifier;

// Re-export types.
export type User = FirebaseUser;
// export type RecaptchaVerifierType = RecaptchaVerifierType;

// Declare recaptchaVerifier on the window object.
declare global {
  interface Window {
    recaptchaVerifier: any; // Using any to avoid strict type issues with window extensions
  }
}

// --- Google Sign-In ---
const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account',
});

export const signInWithGoogle = () => signInWithPopup(auth, googleProvider);

// --- Email & Password ---
export const createAuthUserWithEmailAndPassword = (email: string, password: string) =>
  createUserWithEmailAndPassword(auth, email, password);

export const signInAuthUserWithEmailAndPassword = (email: string, password: string) =>
  signInWithEmailAndPassword(auth, email, password);

// --- Forgot Password ---
export const sendPasswordReset = (email: string) => sendPasswordResetEmail(auth, email);

// --- Phone (SMS) Sign-In ---
export const setupRecaptcha = (containerId: string) => {
    window.recaptchaVerifier = new RecaptchaVerifier(auth, containerId, {
        'size': 'invisible',
        'callback': (response: any) => {
            console.log("reCAPTCHA solved");
        }
    });
};

export const signInWithPhone = (phoneNumber: string) => {
    const appVerifier = window.recaptchaVerifier;
    const phoneProvider = new PhoneAuthProvider(auth);
    return phoneProvider.verifyPhoneNumber(phoneNumber, appVerifier);
};

// --- Sign Out ---
export const signOutUser = () => signOut(auth);

// --- Auth State Listener ---
export const onAuthStateChangedListener = (callback: (user: User | null) => void) =>
  onAuthStateChanged(auth, callback);
