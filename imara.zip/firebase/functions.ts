import { getFunctions, httpsCallable } from 'firebase/functions';
import app from './config.ts';

export const functions = getFunctions(app);

export const callFunction = async (name: string, data: any) => {
    const fn = httpsCallable(functions, name);
    const result = await fn(data);
    return result.data;
};
