
import React, { useState } from 'react';
import { mockAdCampaigns } from '../../data/mockData.ts';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';
import { ChartBarIcon, EyeIcon, PlusCircleIcon, BanknotesIcon, ArrowUpTrayIcon, TheaterIcon, HomeIcon, CheckCircleIcon } from '../icons/Icons.tsx';
import Button from '../ui/Button.tsx';
import SalesChart from '../vendor/SalesChart.tsx'; // Reusing chart component

const AdvertiserDashboard: React.FC = () => {
    const { formatCurrency } = useCurrency();
    const [campaigns, setCampaigns] = useState(mockAdCampaigns);
    const [activeTab, setActiveTab] = useState<'overview' | 'campaigns' | 'create'>('overview');

    // Create Campaign State
    const [newAd, setNewAd] = useState({
        title: '',
        placement: 'feed' as 'feed' | 'theater' | 'both',
        budget: 100,
        targetAudience: 'all',
    });

    const toggleStatus = (id: string) => {
        setCampaigns(prev => prev.map(c => 
            c.id === id ? { ...c, status: c.status === 'active' ? 'paused' : 'active' } : c
        ));
    };

    // Mock chart data for ads
    const adPerformanceData = [
        { day: 'Mon', sales: 2400 },
        { day: 'Tue', sales: 1398 },
        { day: 'Wed', sales: 9800 },
        { day: 'Thu', sales: 3908 },
        { day: 'Fri', sales: 4800 },
        { day: 'Sat', sales: 3800 },
        { day: 'Sun', sales: 4300 },
    ];

    return (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-md border border-gray-100 dark:border-gray-700">
            {/* Header */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4 border-b border-gray-100 dark:border-gray-700 pb-6">
                <div>
                    <h2 className="text-3xl font-display font-bold text-brand-navy-dark dark:text-white">Ads Manager Pro</h2>
                    <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">Reach thousands of customers across Imara's Feed and Theater.</p>
                </div>
                <div className="flex bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
                    <button onClick={() => setActiveTab('overview')} className={`px-4 py-2 rounded-md text-sm font-bold transition-all ${activeTab === 'overview' ? 'bg-white dark:bg-gray-600 text-brand-navy-dark dark:text-white shadow-sm' : 'text-gray-500'}`}>Overview</button>
                    <button onClick={() => setActiveTab('campaigns')} className={`px-4 py-2 rounded-md text-sm font-bold transition-all ${activeTab === 'campaigns' ? 'bg-white dark:bg-gray-600 text-brand-navy-dark dark:text-white shadow-sm' : 'text-gray-500'}`}>Campaigns</button>
                    <button onClick={() => setActiveTab('create')} className={`px-4 py-2 rounded-md text-sm font-bold transition-all ${activeTab === 'create' ? 'bg-brand-gold text-brand-navy-dark shadow-sm' : 'text-gray-500'}`}>+ Create</button>
                </div>
            </div>

            {activeTab === 'overview' && (
                <div className="animate-fade-in">
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                        <div className="p-6 bg-gradient-to-br from-brand-navy-dark to-brand-navy text-white rounded-2xl shadow-lg relative overflow-hidden">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full blur-2xl"></div>
                            <div className="relative z-10">
                                <div className="flex justify-between items-start mb-4">
                                    <p className="text-sm text-gray-300 uppercase tracking-wider font-bold">Total Spend</p>
                                    <div className="p-2 bg-white/10 rounded-full"><BanknotesIcon className="w-5 h-5 text-brand-gold"/></div>
                                </div>
                                <p className="text-4xl font-bold font-mono">{formatCurrency(1250)}</p>
                                <p className="text-xs text-green-400 mt-2 flex items-center gap-1"><ArrowUpTrayIcon className="w-3 h-3"/> +12% this month</p>
                            </div>
                        </div>
                        <div className="p-6 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-2xl shadow-sm">
                             <div className="flex justify-between items-start mb-4">
                                <p className="text-sm text-gray-500 dark:text-gray-300 uppercase tracking-wider font-bold">Impressions</p>
                                <div className="p-2 bg-brand-green/10 rounded-full"><EyeIcon className="w-5 h-5 text-brand-green"/></div>
                            </div>
                            <p className="text-4xl font-bold text-brand-navy-dark dark:text-white">45.2k</p>
                            <p className="text-xs text-green-600 mt-2 flex items-center gap-1"><ArrowUpTrayIcon className="w-3 h-3"/> +5.4% this week</p>
                        </div>
                        <div className="p-6 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-2xl shadow-sm">
                             <div className="flex justify-between items-start mb-4">
                                <p className="text-sm text-gray-500 dark:text-gray-300 uppercase tracking-wider font-bold">Avg. CTR</p>
                                <div className="p-2 bg-purple-100 rounded-full"><ChartBarIcon className="w-5 h-5 text-purple-600"/></div>
                            </div>
                            <p className="text-4xl font-bold text-brand-navy-dark dark:text-white">2.4%</p>
                            <p className="text-xs text-gray-400 mt-2">Industry avg: 1.9%</p>
                        </div>
                    </div>

                    <div className="mb-8 bg-white dark:bg-gray-700 border border-gray-100 dark:border-gray-600 rounded-2xl p-6 shadow-sm">
                        <h3 className="font-bold text-lg mb-6 text-brand-navy-dark dark:text-white">Performance Trend</h3>
                        <SalesChart data={adPerformanceData} />
                    </div>
                </div>
            )}

            {activeTab === 'campaigns' && (
                 <div className="overflow-x-auto animate-fade-in">
                    <table className="w-full text-sm text-left">
                        <thead className="bg-gray-50 dark:bg-gray-700 text-gray-700 dark:text-gray-300 uppercase text-xs">
                            <tr>
                                <th className="px-6 py-4 rounded-l-lg">Campaign</th>
                                <th className="px-6 py-4">Status</th>
                                <th className="px-6 py-4">Placement</th>
                                <th className="px-6 py-4">Budget</th>
                                <th className="px-6 py-4">Results</th>
                                <th className="px-6 py-4 text-center rounded-r-lg">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="space-y-2">
                            {campaigns.map(ad => (
                                <tr key={ad.id} className="border-b border-gray-100 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                                    <td className="px-6 py-4">
                                        <div className="flex items-center gap-3">
                                            <img src={ad.mediaUrl} className="w-12 h-12 rounded-lg object-cover bg-gray-200" alt=""/>
                                            <div>
                                                <p className="font-bold text-brand-navy-dark dark:text-white">{ad.title}</p>
                                                <p className="text-xs text-gray-500 truncate max-w-[150px]">{ad.content}</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${ad.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                                            {ad.status}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4">
                                         <div className="flex gap-2">
                                             <span className="p-1 bg-gray-100 dark:bg-gray-600 rounded text-gray-500 dark:text-gray-300" title="Feed"><HomeIcon className="w-4 h-4"/></span>
                                             <span className="p-1 bg-gray-100 dark:bg-gray-600 rounded text-gray-500 dark:text-gray-300" title="Theater"><TheaterIcon className="w-4 h-4"/></span>
                                         </div>
                                    </td>
                                    <td className="px-6 py-4 font-mono text-gray-700 dark:text-gray-300 font-bold">
                                        {formatCurrency(ad.budget)}
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex flex-col text-xs text-gray-600 dark:text-gray-400 gap-1">
                                            <span className="flex items-center gap-1"><EyeIcon className="w-3 h-3"/> {ad.impressions.toLocaleString()}</span>
                                            <span className="flex items-center gap-1"><ChartBarIcon className="w-3 h-3"/> {ad.clicks} clicks</span>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 text-center">
                                        <button 
                                            onClick={() => toggleStatus(ad.id)}
                                            className={`font-bold text-xs border px-4 py-2 rounded-full transition-colors ${ad.status === 'active' ? 'text-brand-green border-brand-green hover:bg-brand-green hover:text-white' : 'text-gray-500 border-gray-300 hover:bg-gray-100'}`}
                                        >
                                            {ad.status === 'active' ? 'Pause' : 'Resume'}
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}

            {activeTab === 'create' && (
                <div className="max-w-2xl mx-auto animate-fade-in">
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                         <div className="space-y-6">
                             <div>
                                 <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">Campaign Title</label>
                                 <input type="text" value={newAd.title} onChange={e => setNewAd({...newAd, title: e.target.value})} className="w-full p-3 border border-gray-300 rounded-lg bg-gray-50 focus:ring-2 focus:ring-brand-gold outline-none dark:bg-gray-700 dark:text-white" placeholder="e.g. Summer Sale Promo" />
                             </div>
                             
                             <div>
                                 <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">Placement</label>
                                 <div className="grid grid-cols-3 gap-3">
                                     {['feed', 'theater', 'both'].map(p => (
                                         <button 
                                            key={p} 
                                            onClick={() => setNewAd({...newAd, placement: p as any})}
                                            className={`p-3 rounded-lg border-2 flex flex-col items-center gap-2 transition-all ${newAd.placement === p ? 'border-brand-gold bg-brand-gold/10 text-brand-navy-dark font-bold' : 'border-gray-200 text-gray-500 hover:border-gray-300'}`}
                                        >
                                            {p === 'feed' && <HomeIcon className="w-5 h-5"/>}
                                            {p === 'theater' && <TheaterIcon className="w-5 h-5"/>}
                                            {p === 'both' && <div className="flex"><HomeIcon className="w-4 h-4"/><TheaterIcon className="w-4 h-4"/></div>}
                                            <span className="text-xs capitalize">{p}</span>
                                         </button>
                                     ))}
                                 </div>
                             </div>

                              <div>
                                 <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">Daily Budget</label>
                                 <div className="flex items-center gap-4">
                                     <input 
                                        type="range" 
                                        min="10" 
                                        max="1000" 
                                        step="10" 
                                        value={newAd.budget} 
                                        onChange={e => setNewAd({...newAd, budget: Number(e.target.value)})}
                                        className="flex-grow h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-600"
                                    />
                                    <span className="font-mono font-bold text-brand-green dark:text-brand-gold text-lg">{formatCurrency(newAd.budget)}</span>
                                 </div>
                                 <p className="text-xs text-gray-500 mt-2">Est. Reach: <span className="font-bold text-gray-700">{(newAd.budget * 45).toLocaleString()} - {(newAd.budget * 80).toLocaleString()}</span> people per day</p>
                             </div>
                         </div>

                         <div className="bg-gray-50 dark:bg-gray-700 p-6 rounded-xl border border-gray-200 dark:border-gray-600 flex flex-col justify-center items-center text-center">
                             <div className="w-16 h-16 bg-gray-200 dark:bg-gray-600 rounded-full flex items-center justify-center mb-4">
                                 <PlusCircleIcon className="w-8 h-8 text-gray-400"/>
                             </div>
                             <h4 className="font-bold text-gray-700 dark:text-white mb-2">Upload Creative</h4>
                             <p className="text-xs text-gray-500 mb-6">Image or Video (1080x1920 for Theater, 1:1 for Feed)</p>
                             <Button variant="outline">Select Media</Button>
                         </div>
                     </div>
                     
                     <div className="mt-8 pt-6 border-t border-gray-100 flex justify-end gap-4">
                         <Button variant="outline" onClick={() => setActiveTab('overview')}>Cancel</Button>
                         <Button className="px-8">Launch Campaign</Button>
                     </div>
                </div>
            )}
        </div>
    );
};

export default AdvertiserDashboard;
