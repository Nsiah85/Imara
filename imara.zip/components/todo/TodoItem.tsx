import React, { useState, useEffect } from 'react';
import type { Todo } from '../../types.ts';
import { TrashIcon } from '../icons/Icons.tsx';

interface TodoItemProps {
    todo: Todo;
    onToggle: (id: string) => void;
    onDelete: (id: string) => void;
}

const TodoItem: React.FC<TodoItemProps> = ({ todo, onToggle, onDelete }) => {
    const [isDeleting, setIsDeleting] = useState(false);
    const [isMounted, setIsMounted] = useState(false);

    useEffect(() => {
        // Trigger the mount animation
        setIsMounted(true);
    }, []);

    const handleDelete = () => {
        setIsDeleting(true);
        // Wait for animation to finish before calling parent onDelete
        setTimeout(() => onDelete(todo.id), 300);
    };

    return (
        <li
            className={`flex items-center gap-4 p-4 rounded-lg transition-all duration-300 transform ${
                isMounted ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
            } ${isDeleting ? 'opacity-0 scale-95' : ''} ${
                todo.completed ? 'bg-green-50' : 'bg-brand-off-white'
            }`}
            aria-label={`Task: ${todo.text}`}
        >
            <button
                onClick={() => onToggle(todo.id)}
                className={`flex-shrink-0 w-6 h-6 rounded-md border-2 flex items-center justify-center transition-all duration-200 ${
                    todo.completed
                        ? 'bg-brand-gold border-brand-gold'
                        : 'border-gray-300 bg-white hover:border-brand-gold'
                }`}
                aria-pressed={todo.completed}
            >
                {/* Animated checkmark */}
                <svg
                    className={`w-4 h-4 text-white transition-transform duration-200 ease-in-out ${
                        todo.completed ? 'scale-100' : 'scale-0'
                    }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                >
                    <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="3"
                        d="M5 13l4 4L19 7"
                    ></path>
                </svg>
            </button>
            <span
                className={`flex-grow text-gray-700 transition-all duration-300 relative ${
                    todo.completed ? 'text-gray-400' : 'text-brand-green-dark'
                }`}
            >
                {todo.text}
                {/* Strikethrough animation */}
                <span
                    className={`absolute top-1/2 left-0 w-full h-0.5 bg-gray-400 transition-transform duration-300 ease-in-out transform origin-left ${
                        todo.completed ? 'scale-x-100' : 'scale-x-0'
                    }`}
                ></span>
            </span>
            <button
                onClick={handleDelete}
                className="p-1 text-gray-400 hover:text-red-500 transition-colors"
                aria-label={`Delete task: ${todo.text}`}
            >
                <TrashIcon className="w-5 h-5" />
            </button>
        </li>
    );
};

export default TodoItem;
