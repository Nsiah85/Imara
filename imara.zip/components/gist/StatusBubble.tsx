
import React from 'react';
import Avatar from '../ui/Avatar.tsx';
import type { GistStatus } from '../../types.ts';
import { VerifiedBadgeIcon } from '../icons/Icons.tsx';

interface StatusBubbleProps {
  status: GistStatus;
  hasBeenViewed: boolean;
  onClick: () => void;
}

const StatusBubble: React.FC<StatusBubbleProps> = ({ status, hasBeenViewed, onClick }) => {
    // Get the latest item to show as preview
    const latestItem = status.items[status.items.length - 1];
    
    // Determine preview background
    const renderBackground = () => {
        if (latestItem.type === 'image' || latestItem.type === 'gif') {
            return <img src={latestItem.url} alt="Story Preview" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />;
        }
        if (latestItem.type === 'video') {
            return <video src={latestItem.url} className="w-full h-full object-cover" muted />;
        }
        return (
            <div style={{ backgroundColor: latestItem.backgroundColor || '#0A2342', fontFamily: latestItem.font }} className="w-full h-full flex items-center justify-center p-2 text-center">
                <p className="text-[10px] text-white line-clamp-4">{latestItem.text}</p>
            </div>
        );
    };

    return (
        <button onClick={onClick} className="relative flex-shrink-0 w-28 h-44 rounded-xl overflow-hidden group shadow-sm hover:shadow-md transition-all border border-gray-200 dark:border-gray-700">
            {/* Background Preview */}
            <div className="absolute inset-0 bg-gray-200 dark:bg-gray-800">
                {renderBackground()}
            </div>
            
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/80"></div>

            {/* Avatar Top Left */}
            <div className={`absolute top-2 left-2 p-[2px] rounded-full ${hasBeenViewed ? 'bg-gray-400' : 'bg-brand-gold'}`}>
                <div className="relative">
                    <Avatar 
                        imageUrl={status.creator.avatarUrl}
                        name={status.creator.name}
                        id={status.creator.id}
                        className="w-8 h-8 rounded-full border-2 border-brand-navy-dark"
                        textClassName="text-xs font-bold text-white"
                        hasRing={false} // We handle the ring manually here for the story border color logic
                    />
                    {status.creator.isVerified && (
                        <div className="absolute -bottom-1 -right-1 bg-white rounded-full border border-white">
                            <VerifiedBadgeIcon className="w-3 h-3 text-brand-gold" />
                        </div>
                    )}
                </div>
            </div>

            {/* Name Bottom */}
            <div className="absolute bottom-2 left-2 right-2 text-left">
                <p className="text-white text-xs font-bold truncate shadow-sm flex items-center gap-1">
                    {status.creator.name}
                    {status.creator.isVerified && <VerifiedBadgeIcon className="w-3 h-3 text-brand-gold" />}
                </p>
            </div>
        </button>
    );
};

export default StatusBubble;
