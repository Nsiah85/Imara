import React from 'react';
import type { LanguageCode } from '../../types';
import { useLanguage } from '../../contexts/LanguageContext';
import { LanguageIcon } from '../icons/Icons';

interface TranslateButtonProps {
    isTranslated: boolean;
    onToggle: () => void;
    languageCode?: LanguageCode;
}

const TranslateButton: React.FC<TranslateButtonProps> = ({ isTranslated, onToggle, languageCode }) => {
    const { languages, t } = useLanguage();
    
    const languageName = languageCode 
        ? languages.find(lang => lang.code === languageCode)?.name 
        : null;

    return (
        <button 
            onClick={onToggle}
            className="flex items-center gap-1.5 text-xs font-semibold text-white/90 hover:text-white transition-colors"
        >
            <LanguageIcon className="w-4 h-4" />
            <span>{isTranslated ? t('toast.showOriginal') : `${t('toast.translate')} ${languageName ? `from ${languageName}` : ''}`}</span>
        </button>
    );
};

export default TranslateButton;
