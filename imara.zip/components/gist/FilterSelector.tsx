
import React from 'react';

export type FilterType = 'none' | 'sepia' | 'grayscale' | 'contrast' | 'warm' | 'cool';

interface FilterSelectorProps {
    selectedFilter: FilterType;
    onSelect: (filter: FilterType) => void;
    previewUrl: string;
}

const filters: { id: FilterType; name: string; style: React.CSSProperties }[] = [
    { id: 'none', name: 'Normal', style: {} },
    { id: 'sepia', name: 'Vintage', style: { filter: 'sepia(0.8) contrast(1.2)' } },
    { id: 'grayscale', name: 'Noir', style: { filter: 'grayscale(1) contrast(1.2)' } },
    { id: 'contrast', name: 'Vibrant', style: { filter: 'contrast(1.5) saturate(1.2)' } },
    { id: 'warm', name: 'Warm', style: { filter: 'sepia(0.3) saturate(1.4)' } },
    { id: 'cool', name: 'Cool', style: { filter: 'hue-rotate(180deg) sepia(0.2)' } },
];

const FilterSelector: React.FC<FilterSelectorProps> = ({ selectedFilter, onSelect, previewUrl }) => {
    return (
        <div className="mt-4">
            <p className="text-xs font-bold text-gray-400 mb-2 uppercase tracking-wider">Filters</p>
            <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
                {filters.map((filter) => (
                    <button
                        key={filter.id}
                        onClick={() => onSelect(filter.id)}
                        className={`flex flex-col items-center gap-1 flex-shrink-0 ${selectedFilter === filter.id ? 'opacity-100' : 'opacity-60 hover:opacity-100'}`}
                    >
                        <div className={`w-16 h-16 rounded-lg overflow-hidden border-2 ${selectedFilter === filter.id ? 'border-brand-gold' : 'border-transparent'}`}>
                            <img 
                                src={previewUrl} 
                                alt={filter.name} 
                                className="w-full h-full object-cover" 
                                style={filter.style}
                            />
                        </div>
                        <span className="text-[10px] font-medium text-gray-300">{filter.name}</span>
                    </button>
                ))}
            </div>
        </div>
    );
};

export default FilterSelector;
