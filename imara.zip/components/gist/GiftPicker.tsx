
import React, { useState } from 'react';
import { mockImaraGifts } from '../../data/mockData';
import type { ImaraGift } from '../../types';
import { useCurrency } from '../../contexts/CurrencyContext';
import { GiftIcon, FireIcon, StarIcon } from '../icons/Icons';

interface GiftPickerProps {
    onSelect: (gift: ImaraGift) => void;
    userBalance: number; // In Torts
}

const GiftPicker: React.FC<GiftPickerProps> = ({ onSelect, userBalance }) => {
    const { formatCurrency } = useCurrency();
    const [activeTab, setActiveTab] = useState<'all' | 'emoji' | 'premium'>('all');

    const filteredGifts = mockImaraGifts.filter(g => {
        if (activeTab === 'all') return true;
        if (activeTab === 'emoji') return g.type === 'emoji';
        if (activeTab === 'premium') return g.type === 'premium' || g.type === 'brand';
        return true;
    });

    return (
        <div className="bg-white dark:bg-gray-900 rounded-t-xl overflow-hidden flex flex-col h-full max-h-[400px]">
            <div className="p-3 border-b dark:border-gray-700 bg-gray-50 dark:bg-gray-800 flex justify-between items-center">
                <h3 className="font-bold text-brand-navy-dark dark:text-white flex items-center gap-2">
                    <GiftIcon className="w-5 h-5 text-brand-gold"/> Send a Gift
                </h3>
                <div className="text-xs font-mono bg-brand-navy-dark text-brand-gold px-2 py-1 rounded">
                    {userBalance.toLocaleString()} Tts
                </div>
            </div>
            
            <div className="flex p-2 gap-2 overflow-x-auto scrollbar-hide border-b dark:border-gray-700">
                <button onClick={() => setActiveTab('all')} className={`px-3 py-1 rounded-full text-xs font-bold transition-colors ${activeTab === 'all' ? 'bg-brand-navy-dark text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300'}`}>All</button>
                <button onClick={() => setActiveTab('emoji')} className={`px-3 py-1 rounded-full text-xs font-bold transition-colors ${activeTab === 'emoji' ? 'bg-brand-navy-dark text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300'}`}>Emoji</button>
                <button onClick={() => setActiveTab('premium')} className={`px-3 py-1 rounded-full text-xs font-bold transition-colors ${activeTab === 'premium' ? 'bg-brand-gold text-brand-navy-dark' : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300'}`}>Premium</button>
            </div>

            <div className="grid grid-cols-4 gap-2 p-4 overflow-y-auto">
                {filteredGifts.map(gift => (
                    <button 
                        key={gift.id} 
                        onClick={() => onSelect(gift)}
                        className="flex flex-col items-center justify-center p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 border border-transparent hover:border-brand-gold transition-all group relative"
                    >
                        <div className="text-3xl mb-1 transform group-hover:scale-110 transition-transform">{gift.iconUrl}</div>
                        <p className="text-[10px] font-bold text-gray-700 dark:text-gray-300 truncate w-full text-center">{gift.name}</p>
                        <div className="flex items-center gap-1 text-[10px] text-brand-green dark:text-brand-gold font-mono mt-1">
                            {gift.cost >= 1000 ? `${(gift.cost/1000).toFixed(1)}k` : gift.cost} <span className="text-[8px] opacity-70">Tts</span>
                        </div>
                    </button>
                ))}
            </div>
            
            <div className="p-3 bg-gray-50 dark:bg-gray-800 border-t dark:border-gray-700 text-center">
                <button className="text-xs text-brand-green dark:text-brand-gold font-bold hover:underline">
                    Get more Torts
                </button>
            </div>
        </div>
    );
};

export default GiftPicker;
