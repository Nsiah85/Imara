
import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { GistStatus, GistComment } from '../../types.ts';
import { XIcon, SpeakerWaveIcon, HeartIcon, SolidHeartIcon, ChatBubbleIcon, BookmarkIcon, SolidBookmarkIcon, ArrowUpTrayIcon, PaperAirplaneIcon, CheckCircleIcon, VerifiedBadgeIcon } from '../icons/Icons.tsx';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import Avatar from '../ui/Avatar.tsx';
import { useAuth } from '../../contexts/AuthContext.tsx';

interface StatusViewerModalProps {
  statuses: GistStatus[];
  startIndex: number;
  onClose: () => void;
  onViewed: (statusId: string) => void;
}

const StatusViewerModal: React.FC<StatusViewerModalProps> = ({ statuses, startIndex, onClose, onViewed }) => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();
    
    // Create a local snapshot of statuses to prevent re-ordering jumps during viewing
    const [localStatuses] = useState(statuses);
    
    const [statusIndex, setStatusIndex] = useState(startIndex);
    const [itemIndex, setItemIndex] = useState(0);
    const [isPaused, setIsPaused] = useState(false);
    const [videoProgress, setVideoProgress] = useState(0);
    const videoRef = useRef<HTMLVideoElement>(null);
    const audioRef = useRef<HTMLAudioElement>(null);
    const timerRef = useRef<number | null>(null);

    // Interaction states
    const [isLiked, setIsLiked] = useState(false);
    const [isSaved, setIsSaved] = useState(false);
    const [showComments, setShowComments] = useState(false);
    const [newComment, setNewComment] = useState('');
    const [commentSent, setCommentSent] = useState(false);
    
    // Mock comments for status
    const [comments, setComments] = useState<GistComment[]>([
        { id: 'c1', author: { name: 'Kwame', avatarUrl: '' }, text: 'This is fire! 🔥', timestamp: '2m' },
        { id: 'c2', author: { name: 'Amina', avatarUrl: '' }, text: 'Love the vibe 😍', timestamp: '5m' },
    ]);

    const checkAuth = () => {
        if (!user) {
            navigate('/login', { state: { from: location.pathname } });
            return false;
        }
        return true;
    };

    const currentStatus = localStatuses[statusIndex];
    const currentItem = currentStatus?.items[itemIndex];

    const nextItem = useCallback(() => {
        if (!currentStatus) return;
        setVideoProgress(0); // Reset progress immediately for smooth transition
        
        if (itemIndex < currentStatus.items.length - 1) {
            setItemIndex(prev => prev + 1);
        } else {
            if (statusIndex < localStatuses.length - 1) {
                setStatusIndex(prev => prev + 1);
                setItemIndex(0);
            } else {
                onClose();
            }
        }
    }, [itemIndex, statusIndex, currentStatus, localStatuses.length, onClose]);

    const prevItem = () => {
        setVideoProgress(0);
        if (itemIndex > 0) {
            setItemIndex(prev => prev - 1);
        } else {
            if (statusIndex > 0) {
                const prevStatus = localStatuses[statusIndex - 1];
                setStatusIndex(prev => prev - 1);
                setItemIndex(prevStatus.items.length - 1);
            } else {
                if (videoRef.current) videoRef.current.currentTime = 0;
                if (audioRef.current) audioRef.current.currentTime = 0;
            }
        }
    };

    useEffect(() => {
        if (!currentStatus) return;
        onViewed(currentStatus.id);
    }, [currentStatus, onViewed]);

    useEffect(() => {
        // Cleanup and setup for new item
        if (timerRef.current) clearTimeout(timerRef.current);
        setVideoProgress(0);
        if (videoRef.current) {
            videoRef.current.pause();
            videoRef.current.currentTime = 0;
        }
        if (audioRef.current) {
            audioRef.current.pause();
            audioRef.current.currentTime = 0;
        }

        if (isPaused || !currentItem || showComments) return;

        // Start new timers/media
        if (currentItem.soundUrl && audioRef.current) {
            audioRef.current.src = currentItem.soundUrl;
            audioRef.current.play().catch(e => console.error("Audio play failed:", e));
        }

        if (currentItem.type === 'image' || currentItem.type === 'gif' || currentItem.type === 'text') {
            timerRef.current = window.setTimeout(nextItem, currentItem.duration * 1000);
        } else if (currentItem.type === 'video' && videoRef.current) {
            videoRef.current.play().catch(e => console.error("Video play failed:", e));
        }
        
        return () => {
            if (timerRef.current) clearTimeout(timerRef.current);
        };
    }, [currentItem, isPaused, nextItem, showComments, statusIndex, itemIndex]); 

    const handleVideoEnd = () => nextItem();
    
    const handleVideoTimeUpdate = () => {
        if (videoRef.current?.duration) {
            setVideoProgress((videoRef.current.currentTime / videoRef.current.duration) * 100);
        }
    };

    const handleInteractionStart = (e: React.MouseEvent | React.TouchEvent) => {
        // Prevent pausing if clicking on an interactive button or comment section
        if ((e.target as HTMLElement).closest('button') || (e.target as HTMLElement).closest('.comment-section')) return;
        setIsPaused(true);
        videoRef.current?.pause();
        audioRef.current?.pause();
    };
    
    const handleInteractionEnd = (e: React.MouseEvent | React.TouchEvent) => {
        if ((e.target as HTMLElement).closest('button') || (e.target as HTMLElement).closest('.comment-section')) return;
        if (!showComments) {
            setIsPaused(false);
            videoRef.current?.play().catch(e => console.error(e));
            audioRef.current?.play().catch(e => console.error(e));
        }
    };

    const handleLike = () => {
        if (!checkAuth()) return;
        setIsLiked(p => !p);
    };

    const handleSave = () => {
        if (!checkAuth()) return;
        setIsSaved(p => !p);
    };

    const handleShare = () => {
        if (!checkAuth()) return;
        // Implement share
    };

    const handleReply = () => {
        if (!checkAuth()) return;
        setShowComments(p => !p);
        setIsPaused(p => !p);
    };

    const handleAddComment = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newComment.trim()) return;
        if (!checkAuth()) return;
        
        // Simulate sending to inbox
        setCommentSent(true);
        setNewComment('');
        
        setTimeout(() => {
            setCommentSent(false);
            setShowComments(false);
            setIsPaused(false);
        }, 1500);
    };
    
    if (!currentStatus || !currentItem) return null;

    return (
        <div className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center" onMouseDown={handleInteractionStart} onMouseUp={handleInteractionEnd} onTouchStart={handleInteractionStart} onTouchEnd={handleInteractionEnd}>
            <audio ref={audioRef} />
            <div className="relative w-full h-full max-w-md max-h-[95vh] rounded-lg overflow-hidden bg-black">
                {/* Progress Bars */}
                <div className="absolute top-3 left-2 right-2 flex items-center gap-1 z-20">
                    {currentStatus.items.map((item, index) => (
                        <div key={item.id} className="h-1 bg-white/30 rounded-full flex-1 overflow-hidden">
                            <div
                                className="h-1 bg-white transition-all duration-100 linear"
                                style={{
                                    width: (
                                        index < itemIndex ? '100%' :
                                        index > itemIndex ? '0%' :
                                        (currentItem.type === 'video' ? `${videoProgress}%` : '0%')
                                    ),
                                    animation: (
                                        index === itemIndex && !isPaused && !showComments &&
                                        (currentItem.type === 'image' || currentItem.type === 'gif' || currentItem.type === 'text')
                                    ) ? `fill-progress ${currentItem.duration}s linear` : 'none'
                                }}
                            />
                        </div>
                    ))}
                </div>

                {/* Header */}
                <header className="absolute top-6 left-4 z-20 flex items-center gap-3">
                    <Link to={currentStatus.creator.profileLink} onClick={onClose}>
                        <Avatar 
                            imageUrl={currentStatus.creator.avatarUrl}
                            name={currentStatus.creator.name}
                            id={currentStatus.creator.id}
                            className="w-9 h-9 rounded-full border border-white/50"
                            textClassName="text-sm font-bold"
                        />
                    </Link>
                    <div className="flex items-center gap-1">
                        <Link to={currentStatus.creator.profileLink} onClick={onClose} className="text-white text-sm font-bold hover:underline shadow-black drop-shadow-md">{currentStatus.creator.name}</Link>
                        {currentStatus.creator.isVerified && <VerifiedBadgeIcon className="w-3 h-3 text-brand-gold drop-shadow-md" />}
                        {currentItem.soundUrl && <SpeakerWaveIcon className="w-4 h-4 text-white animate-pulse ml-1" />}
                    </div>
                </header>
                <button onClick={onClose} className="absolute top-6 right-4 z-20 text-white p-1 rounded-full bg-black/30"><XIcon className="w-5 h-5"/></button>
                
                {/* Content */}
                <div className="w-full h-full flex items-center justify-center">
                    {currentItem.type === 'image' && <img src={currentItem.url} alt="Status" className="w-auto h-auto max-w-full max-h-full" />}
                    {currentItem.type === 'gif' && <img src={currentItem.url} alt="Status GIF" className="w-auto h-auto max-w-full max-h-full" />}
                    {currentItem.type === 'video' && (
                        <video key={currentItem.url} ref={videoRef} src={currentItem.url} className="w-auto h-auto max-w-full max-h-full" onEnded={handleVideoEnd} onTimeUpdate={handleVideoTimeUpdate} playsInline autoPlay />
                    )}
                    {currentItem.type === 'text' && (
                        <div style={{ backgroundColor: currentItem.backgroundColor, fontFamily: currentItem.font }} className="w-full h-full flex items-center justify-center p-8 text-center">
                            <p className="text-white text-3xl font-bold" style={{ textShadow: '1px 1px 3px rgba(0,0,0,0.3)' }}>{currentItem.text}</p>
                        </div>
                    )}
                </div>
                
                {/* Interaction Overlay */}
                <div className="absolute right-3 bottom-20 z-20 flex flex-col items-center gap-5">
                    <button onClick={handleLike} className="flex flex-col items-center gap-1 text-white">
                        {isLiked ? <SolidHeartIcon className="w-8 h-8 text-brand-green" /> : <HeartIcon className="w-8 h-8 drop-shadow-md"/>}
                        <span className="text-xs font-semibold drop-shadow-md">Like</span>
                    </button>
                    <button onClick={handleReply} className="flex flex-col items-center gap-1 text-white">
                        <ChatBubbleIcon className="w-8 h-8 drop-shadow-md"/>
                        <span className="text-xs font-semibold drop-shadow-md">Reply</span>
                    </button>
                     <button onClick={handleSave} className="flex flex-col items-center gap-1 text-white">
                        {isSaved ? <SolidBookmarkIcon className="w-8 h-8 text-brand-gold"/> : <BookmarkIcon className="w-8 h-8 drop-shadow-md"/>}
                        <span className="text-xs font-semibold drop-shadow-md">Save</span>
                    </button>
                    <button onClick={handleShare} className="flex flex-col items-center gap-1 text-white">
                        <ArrowUpTrayIcon className="w-8 h-8 drop-shadow-md"/>
                        <span className="text-xs font-semibold drop-shadow-md">Share</span>
                    </button>
                </div>

                {/* Navigation Zones */}
                <div className="absolute inset-0 flex z-10 pointer-events-none">
                    <div onClick={prevItem} className="w-1/3 h-full cursor-pointer pointer-events-auto"></div>
                    <div className="w-1/3 h-full"></div>
                    <div onClick={nextItem} className="w-1/3 h-full cursor-pointer pointer-events-auto"></div>
                </div>

                {/* Comments/Reply Overlay */}
                {showComments && (
                    <div className="absolute inset-x-0 bottom-0 bg-white dark:bg-gray-900 rounded-t-xl z-30 flex flex-col comment-section animate-fade-in-up">
                        <div className="p-4 border-b dark:border-gray-700 flex justify-between items-center">
                            <h3 className="font-bold text-brand-navy-dark dark:text-white">Reply to {currentStatus.creator.name}</h3>
                            <button onClick={() => { setShowComments(false); setIsPaused(false); }}><XIcon className="w-5 h-5 text-gray-500"/></button>
                        </div>
                        
                        {commentSent ? (
                            <div className="p-8 text-center text-green-600 animate-fade-in">
                                <CheckCircleIcon className="w-10 h-10 mx-auto mb-2" />
                                <p className="font-semibold">Reply sent to inbox!</p>
                            </div>
                        ) : (
                            <form onSubmit={handleAddComment} className="p-4 flex items-center gap-2">
                                <input 
                                    type="text" 
                                    value={newComment}
                                    onChange={e => setNewComment(e.target.value)}
                                    placeholder="Send a message..." 
                                    className="flex-1 bg-gray-100 dark:bg-gray-800 rounded-full px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-brand-gold text-black dark:text-white"
                                    autoFocus
                                />
                                <button type="submit" disabled={!newComment.trim()} className="p-2 text-brand-gold disabled:opacity-50">
                                    <PaperAirplaneIcon className="w-6 h-6" />
                                </button>
                            </form>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

export default StatusViewerModal;
