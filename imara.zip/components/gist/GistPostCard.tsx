
import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import type { GistPost, Product, Cause, TravelService } from '../../types.ts';
import { useLanguage } from '../../contexts/LanguageContext.tsx';
import { HeartIcon, SolidHeartIcon, ChatBubbleIcon, ArrowUpTrayIcon, BookmarkIcon, SolidBookmarkIcon, ChartBarIcon, ChatBubbleBottomCenterTextIcon, VerifiedBadgeIcon, PlayIcon, PauseIcon, DocumentTextIcon, ShareIcon, TheaterIcon, EllipsisHorizontalIcon, XCircleIcon, EyeIcon, ShieldCheckIcon, GiftIcon, SparklesIcon } from '../icons/Icons.tsx';
import TranslateButton from './TranslateButton.tsx';
import { mockProducts, mockCauses, mockTravelServices } from '../../data/mockData.ts';
import Button from '../ui/Button.tsx';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';
import { useAuth } from '../../contexts/AuthContext.tsx';
import Avatar from '../ui/Avatar.tsx';
import ShareModal from '../modals/ShareModal.tsx';
import RemixModal from '../modals/RemixModal.tsx';
import InAppBrowser from '../ui/InAppBrowser.tsx';
import ImaraOutro from '../ui/ImaraOutro.tsx';
import { downloadMediaWithWatermark } from '../../utils/downloadHelper.ts';

// ... (Sub-components like ProductGistCard, ServiceGistCard remain unchanged, re-including them for context) ...

export const ProductGistCard: React.FC<{ product: Product, onAddToCart: (product: Product) => void }> = ({ product, onAddToCart }) => {
    const { formatCurrency } = useCurrency();
    return (
        <div className="bg-brand-green/5 dark:bg-brand-navy-dark rounded-lg overflow-hidden flex gap-3 p-3 border border-brand-green/20 shadow-sm">
            <img src={product.imageUrl} alt={product.name} loading="lazy" className="w-24 h-24 object-cover rounded-md flex-shrink-0" />
            <div className="flex flex-col justify-between flex-grow">
                <div>
                    <p className="text-[10px] text-brand-gray uppercase tracking-wider font-bold">{product.vendor}</p>
                    <div className="font-bold text-brand-green-dark dark:text-white hover:text-brand-green dark:hover:text-brand-gold text-sm line-clamp-2 transition-colors">{product.name}</div>
                </div>
                <div className="flex justify-between items-end">
                    <p className="font-bold text-brand-green dark:text-brand-gold">{formatCurrency(product.price)}</p>
                    <Button size="sm" className="!py-1 !px-3 !text-xs bg-brand-gold text-brand-navy-dark hover:bg-brand-green hover:text-white border-none" onClick={() => onAddToCart(product)} title="Add this item to your cart">Add Cart</Button>
                </div>
            </div>
        </div>
    );
};
export const ServiceGistCard: React.FC<{ service: TravelService, onBookService: (serviceId: string) => void }> = ({ service, onBookService }) => {
    const { formatCurrency } = useCurrency();
    return (
        <div className="bg-brand-green/5 dark:bg-brand-navy-dark rounded-lg overflow-hidden flex gap-3 p-3 border border-brand-green/20 shadow-sm">
            <img src={service.imageUrl} alt={service.title} loading="lazy" className="w-24 h-24 object-cover rounded-md flex-shrink-0" />
            <div className="flex flex-col justify-between flex-grow">
                <div>
                    <p className="text-[10px] text-brand-gray uppercase tracking-wider font-bold">{service.type}</p>
                    <div className="font-bold text-brand-green-dark dark:text-white hover:text-brand-green dark:hover:text-brand-gold text-sm line-clamp-2 transition-colors">{service.title}</div>
                </div>
                <div>
                    <p className="font-bold text-brand-green dark:text-brand-gold">{formatCurrency(service.price)} <span className="text-xs font-normal text-gray-500 dark:text-gray-400">/ {service.priceUnit}</span></p>
                    <Button size="sm" className="mt-1 !py-1 !px-3 !text-xs bg-brand-gold text-brand-navy-dark hover:bg-brand-green hover:text-white border-none" onClick={() => onBookService(service.id)} title="Start a booking for this service">Book Now</Button>
                </div>
            </div>
        </div>
    );
};
export const CauseGistCard: React.FC<{ cause: Cause, onDonateNow: (causeId: string) => void, onLearnMore: () => void }> = ({ cause, onDonateNow, onLearnMore }) => {
    return (
         <div className="bg-brand-green/5 dark:bg-brand-navy-dark rounded-lg overflow-hidden border border-brand-gold/30 shadow-sm">
            <img src={cause.imageUrl} alt={cause.title} loading="lazy" className="w-full h-32 object-cover" />
            <div className="p-3">
                <p className="text-[10px] text-brand-gray uppercase tracking-wider font-bold">{cause.organization}</p>
                <p className="font-bold text-brand-green-dark dark:text-white text-sm">{cause.title}</p>
                 <div className="flex gap-2 mt-2">
                    <Button size="sm" variant="primary" className="flex-1 !py-1 !text-xs" onClick={() => onDonateNow(cause.id)} title="Donate to this cause">Donate</Button>
                    <Button size="sm" variant="outline" className="flex-1 !py-1 !text-xs" onClick={onLearnMore} title="Read more about this campaign">Learn</Button>
                </div>
            </div>
        </div>
    );
};
export const PollCard: React.FC<{ options: { id: string; option: string; votes: number }[], duration?: string }> = ({ options, duration }) => {
    const [votedOption, setVotedOption] = useState<string | null>(null);
    const totalVotes = options.reduce((acc, curr) => acc + curr.votes, 0) + (votedOption ? 1 : 0);
    return (
        <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-gray-500 uppercase flex items-center gap-1"><ChartBarIcon className="w-3 h-3" title="Poll Icon"/> Poll</span>
                <span className="text-xs text-gray-400">{duration} left</span>
            </div>
            <div className="space-y-2">
                {options.map((opt) => {
                    const votes = votedOption === opt.id ? opt.votes + 1 : opt.votes;
                    const percentage = totalVotes > 0 ? Math.round((votes / totalVotes) * 100) : 0;
                    return (
                        <button key={opt.id} onClick={() => setVotedOption(opt.id)} disabled={!!votedOption} className={`relative w-full text-left p-2 rounded-md overflow-hidden border transition-all ${votedOption === opt.id ? 'border-brand-gold ring-1 ring-brand-gold' : 'border-gray-300 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700'}`} title={`Vote for ${opt.option}`}>
                            <div className="absolute top-0 left-0 bottom-0 bg-brand-green/20 transition-all duration-500" style={{ width: votedOption ? `${percentage}%` : '0%' }}></div>
                            <div className="relative flex justify-between z-10 px-2">
                                <span className="text-sm text-brand-navy-dark dark:text-white font-medium">{opt.option}</span>
                                {votedOption && <span className="text-sm text-gray-600 dark:text-gray-300">{percentage}%</span>}
                            </div>
                        </button>
                    )
                })}
            </div>
            <p className="text-xs text-gray-400 mt-2 text-right">{totalVotes} votes</p>
        </div>
    );
}
export const QnACard: React.FC<{ question: string, creatorName: string }> = ({ question, creatorName }) => (
    <div className="bg-gradient-to-br from-brand-navy to-brand-navy-dark rounded-lg p-6 text-center relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-brand-gold"></div>
        <ChatBubbleBottomCenterTextIcon className="w-8 h-8 text-white/20 mx-auto mb-2" title="Question Icon"/>
        <p className="text-xs text-brand-gold uppercase tracking-widest mb-2">Q&A</p>
        <h3 className="text-xl font-display font-bold text-white mb-4">"{question}"</h3>
        <Button size="sm" variant="secondary" className="mx-auto" title={`Answer the question from ${creatorName}`}>Answer {creatorName}</Button>
    </div>
);
export const GiftCelebrationCard: React.FC<{ giftName: string, giftIcon: string, senderName: string, recipientName: string }> = ({ giftName, giftIcon, senderName, recipientName }) => (
    <div className="bg-gradient-to-br from-brand-gold via-yellow-500 to-brand-navy-dark p-6 rounded-lg text-center text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-20"></div>
        <div className="relative z-10">
            <div className="text-5xl mb-2 animate-bounce">{giftIcon}</div>
            <h3 className="font-display font-bold text-lg mb-1">{giftName}</h3>
            <p className="text-sm opacity-90">
                <span className="font-bold">{senderName}</span> sent a gift to {recipientName}!
            </p>
        </div>
    </div>
);
export const QuoteCard: React.FC<{ text: string, author?: string, backgroundColor?: string, fontFamily?: string }> = ({ text, author, backgroundColor, fontFamily }) => (
    <div className="mb-3 rounded-lg overflow-hidden text-center p-8 text-white shadow-inner" style={{ background: backgroundColor || '#000', fontFamily: fontFamily }}>
        <p className="text-2xl font-bold">"{text}"</p>
        {author && <p className="mt-4 opacity-80">- {author}</p>}
    </div>
);

// --- Main GistPostCard ---

interface GistPostCardProps {
  post: GistPost;
  onCommentClick: () => void;
  onAddToCart: (item: Product | TravelService) => void;
  onBookService: (serviceId: string) => void;
  onDonateNow: (causeId: string) => void;
  onLearnMore: () => void;
  onTheaterMode?: () => void;
  isTheaterMode?: boolean;
  onLike?: (postId: string) => void;
  onSave?: (postId: string) => void;
  onGift?: (postId: string) => void;
  onRate?: (postId: string, rating: number) => void;
}

const formatTimeAgo = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + "y";
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + "mo";
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + "d";
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + "h";
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + "m";
    return "now";
};

const GistPostCard: React.FC<GistPostCardProps> = ({
  post,
  onCommentClick,
  onAddToCart,
  onBookService,
  onDonateNow,
  onLearnMore,
  onTheaterMode,
  isTheaterMode = false,
  onLike,
  onSave,
  onGift,
  onRate,
}) => {
    const { t } = useLanguage();
    const { user, followUser, unfollowUser, isFollowing } = useAuth();
    const navigate = useNavigate();
    const [isTranslated, setIsTranslated] = useState(false);
    // Added safety check for post.likedByMe
    const [isLiked, setIsLiked] = useState(post?.likedByMe || false);
    const [isSaved, setIsSaved] = useState(false);
    const [isShareModalOpen, setIsShareModalOpen] = useState(false);
    const [isRemixModalOpen, setIsRemixModalOpen] = useState(false);
    const [isPlaying, setIsPlaying] = useState(false);
    const [linkToOpen, setLinkToOpen] = useState<string | null>(null);
    const [showOutro, setShowOutro] = useState(false);
    const [showMoreMenu, setShowMoreMenu] = useState(false);
    
    const videoRef = useRef<HTMLVideoElement>(null);
    const audioRef = useRef<HTMLAudioElement>(null);

    // Guard against malformed post objects
    if (!post || !post.content || !post.creator) return null;

    const { content } = post;
    // Added safety check for engagement object with default values
    const engagement = post.engagement || { likes: 0, commentsCount: 0, shares: 0, saves: 0 };
    
    const isSponsored = post.isSponsored;
    const adStyles = isSponsored ? "border-2 border-brand-gold/30 bg-yellow-50/30 dark:bg-brand-navy-dark/50 dark:border-brand-gold/20 relative" : "bg-white dark:bg-gray-800 border-gray-100 dark:border-gray-700";
    const displayText = isTranslated && content.translatedText ? content.translatedText : content.text;

    const checkAuth = () => {
        if (!user) {
             navigate('/login');
             return false;
        }
        return true;
    };

    const handleProfileClick = (e: React.MouseEvent) => {
        e.preventDefault();
        if (checkAuth()) {
            navigate(post.creator.profileLink);
        }
    };

    const handleLike = () => { if (checkAuth()) { setIsLiked(!isLiked); if (onLike) onLike(post.id); } };
    const handleSave = () => { if (checkAuth()) { setIsSaved(!isSaved); if (onSave) onSave(post.id); } };
    const handleComment = () => { if (checkAuth()) onCommentClick(); };
    const handleShareClick = () => { if (checkAuth()) setIsShareModalOpen(true); };
    
    const handleReport = () => {
        if (checkAuth()) {
            alert("Report submitted for review. Thank you for keeping Imara safe.");
            setShowMoreMenu(false);
        }
    };

    const togglePlay = () => {
        if (content.videoUrl && videoRef.current) {
            if (isPlaying) videoRef.current.pause();
            else videoRef.current.play();
            setIsPlaying(!isPlaying);
        } else if (content.sound && audioRef.current) {
             if (isPlaying) audioRef.current.pause();
            else audioRef.current.play();
            setIsPlaying(!isPlaying);
        }
    };

    const handleVideoEnded = () => {
        setShowOutro(true);
        setTimeout(() => {
            setShowOutro(false);
            if(videoRef.current) {
                videoRef.current.currentTime = 0;
                setIsPlaying(false);
            }
        }, 3000);
    }

    const handleDownload = () => {
         if (!checkAuth()) return;
         const mediaUrl = content.videoUrl || content.imageUrl;
         const type = content.videoUrl ? 'video' : 'image';
         if (mediaUrl) {
             downloadMediaWithWatermark(mediaUrl, type, post.creator.name);
         }
         setShowMoreMenu(false);
    };

    const handleFollow = () => {
        if (!checkAuth()) return;
        if (isFollowing(post.creator.id)) {
            unfollowUser(post.creator.id);
        } else {
            followUser(post.creator.id);
        }
        setShowMoreMenu(false);
    };

    const renderTextWithLinks = (text: string) => {
        if (!text) return null;
        const urlRegex = /(https?:\/\/[^\s]+)/g;
        return text.split(urlRegex).map((part, i) => {
            if (part.match(urlRegex)) {
                return (
                    <button key={i} onClick={() => setLinkToOpen(part)} className="text-brand-green dark:text-brand-gold hover:text-brand-green-dark dark:hover:text-white transition-colors font-medium break-all text-left" title={`Open link: ${part}`}>{part}</button>
                );
            }
            return part;
        });
    };
    
    const showMedia = isSponsored ? (content.imageUrl || content.videoUrl) : (content.videoUrl || content.imageUrl);
    const following = user ? isFollowing(post.creator.id) : false;

    // More Menu Logic
    const MoreMenu = () => (
        <div className="absolute right-0 top-10 w-48 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-100 dark:border-gray-700 z-30 py-1 overflow-hidden">
            <button className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2" onClick={() => { alert('Marked as Interested'); setShowMoreMenu(false); }} title="Mark as interested">
                <HeartIcon className="w-4 h-4"/> Interested
            </button>
             <button className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2" onClick={() => { alert('Marked as Not Interested'); setShowMoreMenu(false); }} title="Mark as not interested">
                <XCircleIcon className="w-4 h-4"/> Not Interested
            </button>
            <button className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2" onClick={handleFollow} title={following ? "Unfollow user" : "Follow user"}>
                <VerifiedBadgeIcon className="w-4 h-4"/> {following ? 'Unfollow' : 'Follow'}
            </button>
             {(content.imageUrl || content.videoUrl) && (
                <button className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2" onClick={handleDownload} title="Download media">
                    <ArrowUpTrayIcon className="w-4 h-4 transform rotate-180"/> Download
                </button>
             )}
            <button className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2" onClick={() => { alert('Post Hidden'); setShowMoreMenu(false); }} title="Hide post from feed">
                <EyeIcon className="w-4 h-4"/> Hide
            </button>
            <button className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 flex items-center gap-2" onClick={handleReport} title="Report inappropriate content">
                <ShieldCheckIcon className="w-4 h-4" /> Report
            </button>
             <button className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2" onClick={() => { alert('Notifications On'); setShowMoreMenu(false); }} title="Notify me of future posts">
                <ChatBubbleIcon className="w-4 h-4"/> Notify me
            </button>
        </div>
    );

    return (
        <article className={`rounded-xl shadow-sm border overflow-hidden mb-6 transition-all hover:shadow-md ${adStyles}`}>
            {/* Ad Badge */}
            {isSponsored && (
                <div className="px-4 pt-2 flex justify-between items-center">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-brand-gold bg-brand-navy-dark px-2 py-0.5 rounded">Sponsored</span>
                    <button className="text-xs text-brand-green hover:underline" onClick={() => setLinkToOpen(content.adLink || '#')} title="Learn more about this advertisement">Learn More</button>
                </div>
            )}

            {/* Header */}
            <div className="p-4 flex justify-between items-start relative">
                <div className="flex gap-3 items-center w-[85%]">
                    <button onClick={handleProfileClick} className="flex-shrink-0" title={`View ${post.creator.name}'s profile`}>
                        <Avatar imageUrl={post.creator.avatarUrl} name={post.creator.name} id={post.creator.id} className="w-10 h-10 rounded-full" textClassName="text-sm font-bold text-white" />
                    </button>
                    <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                            <button onClick={handleProfileClick} className="font-bold text-brand-navy-dark dark:text-white hover:text-brand-green dark:hover:text-brand-gold text-sm transition-colors text-left truncate" title={`Go to ${post.creator.name}`}>{post.creator.name}</button>
                            {post.creator.isVerified && <VerifiedBadgeIcon className="w-4 h-4 text-brand-gold flex-shrink-0" title="Verified Creator" />}
                        </div>
                        <div className="flex items-center gap-2 flex-wrap">
                            <p className="text-[10px] text-gray-500 dark:text-gray-400">{formatTimeAgo(post.timestamp)}</p>
                            {post.isMonkixCIAssisted && (
                                <span className="text-[9px] bg-[#7E57C2]/10 text-[#7E57C2] px-2 py-0.5 rounded-full border border-[#7E57C2]/20 shadow-sm flex items-center gap-1">
                                    <SparklesIcon className="w-3 h-3" /> Assisted by Monkix CI
                                </span>
                            )}
                        </div>
                    </div>
                </div>
                <div className="flex gap-2 flex-shrink-0">
                    <button className="text-gray-400 hover:text-brand-navy-dark dark:hover:text-white" title="Enter Theater Mode" onClick={onTheaterMode}>
                        <TheaterIcon className="w-6 h-6" />
                    </button>
                    <div className="relative">
                        <button className="text-gray-400 hover:text-brand-navy-dark dark:hover:text-white p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700" onClick={() => setShowMoreMenu(!showMoreMenu)} title="More options">
                            <EllipsisHorizontalIcon className="w-6 h-6" />
                        </button>
                        {showMoreMenu && <MoreMenu />}
                    </div>
                </div>
                {showMoreMenu && <div className="fixed inset-0 z-20" onClick={() => setShowMoreMenu(false)}></div>}
            </div>

            {/* Content Body */}
            <div className="px-4 pb-2">
                {content.text && content.type !== 'quote' && content.type !== 'poll' && content.type !== 'q&a' && content.type !== 'gift_celebration' && (
                    <div className={`mb-2 ${content.backgroundColor ? 'p-6 rounded-xl text-white text-center shadow-inner my-3' : ''}`} style={content.backgroundColor ? { background: content.backgroundColor, fontFamily: content.fontFamily } : {}}>
                        <p className={`whitespace-pre-wrap text-sm leading-relaxed ${content.backgroundColor ? 'text-white font-medium text-lg' : 'text-gray-800 dark:text-gray-200'}`}>{renderTextWithLinks(displayText)}</p>
                        {content.translatedText && <div className="mt-1"><TranslateButton isTranslated={isTranslated} onToggle={() => setIsTranslated(!isTranslated)} languageCode={post.languageCode} /></div>}
                    </div>
                )}
                 {post.tags && post.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-3">
                        {post.tags.map(tag => <span key={tag} className="text-brand-green dark:text-brand-gold text-sm font-medium hover:text-brand-navy-dark dark:hover:text-white transition-colors cursor-pointer" title={`Search for tag ${tag}`}>{tag.startsWith('#') ? tag.replace('#', '%') : tag.startsWith('%') ? tag : `%${tag}`}</span>)}
                    </div>
                )}

                {showMedia && (
                    <div className="rounded-lg overflow-hidden mb-3 border border-gray-100 dark:border-gray-700 bg-gray-100 dark:bg-gray-900 cursor-pointer relative group" onClick={onTheaterMode} title="Enter immersive theater view">
                         {content.videoUrl ? (
                            <>
                                <video 
                                    ref={videoRef}
                                    src={content.videoUrl} 
                                    className="w-full h-full object-contain max-h-[500px]" 
                                    controls={false}
                                    playsInline
                                    muted={false}
                                    onEnded={handleVideoEnded}
                                />
                                {showOutro && <ImaraOutro />}
                                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                                    {!isPlaying && !showOutro && <div className="bg-black/50 rounded-full p-4 backdrop-blur-sm" title="Play Video"><PlayIcon className="w-10 h-10 text-white" /></div>}
                                </div>
                                <div className="absolute bottom-4 right-4 pointer-events-auto" onClick={(e) => { e.stopPropagation(); togglePlay(); }}>
                                     {isPlaying ? <PauseIcon className="w-6 h-6 text-white drop-shadow-md" title="Pause Video" /> : <PlayIcon className="w-6 h-6 text-white drop-shadow-md" title="Play Video" />}
                                </div>
                            </>
                         ) : (
                             <img src={content.imageUrl} alt="Post content" className="w-full h-auto object-cover max-h-[500px]" loading="lazy" title="View Full Image" />
                         )}
                         
                         {isSponsored && content.adLink && (
                             <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 pt-12">
                                 <button onClick={(e) => { e.stopPropagation(); setLinkToOpen(content.adLink || '#'); }} className="w-full bg-brand-gold text-brand-navy-dark font-bold py-2 rounded shadow-lg hover:bg-white transition-colors" title="Open advert detail">
                                     {content.adCtaText || "Learn More"}
                                 </button>
                             </div>
                         )}
                    </div>
                )}

                {content.type === 'product_card' && content.productId && <div className="mb-3">{(() => { const product = mockProducts.find(p => p.id === content.productId); return product ? <ProductGistCard product={product} onAddToCart={onAddToCart} /> : null; })()}</div>}
                {content.type === 'booking_card' && content.serviceId && <div className="mb-3">{(() => { const service = mockTravelServices.find(s => s.id === content.serviceId); return service ? <ServiceGistCard service={service} onBookService={onBookService} /> : null; })()}</div>}
                {content.type === 'donor_campaign' && content.causeId && <div className="mb-3">{(() => { const cause = mockCauses.find(c => c.id === content.causeId); return cause ? <CauseGistCard cause={cause} onDonateNow={onDonateNow} onLearnMore={onLearnMore} /> : null; })()}</div>}
                {content.type === 'quote' && <QuoteCard text={content.text || ''} author={content.quoteAuthor} backgroundColor={content.backgroundColor} fontFamily={content.fontFamily} />}
                {content.type === 'poll' && content.pollOptions && <div className="mb-3"><PollCard options={content.pollOptions} duration={content.pollDuration} /></div>}
                {content.type === 'q&a' && content.question && <div className="mb-3"><QnACard question={content.question} creatorName={post.creator.name} /></div>}
                {content.type === 'gift_celebration' && content.giftData && <div className="mb-3"><GiftCelebrationCard {...content.giftData} /></div>}
                {content.type === 'document' && (
                    <div className="mb-3 p-4 bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center gap-4 cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors" title="Download Document">
                        <div className="p-3 bg-white dark:bg-gray-800 rounded-lg text-brand-navy-dark dark:text-white"><DocumentTextIcon className="w-8 h-8" /></div>
                        <div className="flex-1 min-w-0">
                            <p className="font-bold text-brand-navy-dark dark:text-white truncate">{content.documentName || 'Document'}</p>
                            <p className="text-xs text-gray-500">PDF &middot; Click to view</p>
                        </div>
                    </div>
                )}
                {content.sound && (
                    <div className="flex items-center gap-2 mb-3 bg-gray-50 dark:bg-gray-700/50 p-2 rounded-full w-fit pr-4 border border-gray-200 dark:border-gray-600">
                        <button onClick={togglePlay} className="w-8 h-8 flex items-center justify-center bg-brand-gold text-brand-navy-dark rounded-full" title={isPlaying ? "Pause Sound" : "Play Sound"}>{isPlaying ? <PauseIcon className="w-4 h-4"/> : <PlayIcon className="w-4 h-4"/>}</button>
                        <div className="flex flex-col">
                            <span className="text-xs font-bold text-brand-navy-dark dark:text-white line-clamp-1">{content.sound.title}</span>
                            <span className="text-[10px] text-gray-500 dark:text-gray-400 line-clamp-1">{content.sound.artist}</span>
                        </div>
                        <audio ref={audioRef} src={content.sound.url} onEnded={() => setIsPlaying(false)} />
                    </div>
                )}
            </div>

            {/* Engagement Footer */}
            <div className="px-4 py-3 border-t border-gray-100 dark:border-gray-700 flex justify-between items-center text-gray-500 dark:text-gray-400 bg-gray-50/50 dark:bg-gray-800/50">
                <div className="flex gap-6">
                    <button onClick={handleLike} className={`flex items-center gap-1.5 transition-colors ${isLiked ? 'text-brand-green fill-current' : 'hover:text-brand-green'}`} title={isLiked ? "Unlike post" : "Like post"}>
                        {isLiked ? <SolidHeartIcon className="w-5 h-5" /> : <HeartIcon className="w-5 h-5" />}
                        <span className="text-sm font-medium">{engagement.likes + (isLiked && !post.likedByMe ? 1 : 0)}</span>
                    </button>
                    <button onClick={handleComment} className="flex items-center gap-1.5 hover:text-brand-green transition-colors" title="View/Post comments">
                        <ChatBubbleIcon className="w-5 h-5" />
                        <span className="text-sm font-medium">{engagement.commentsCount}</span>
                    </button>
                    <button onClick={() => onGift && onGift(post.id)} className="flex items-center gap-1.5 hover:text-brand-gold transition-colors" title="Send a Gift">
                        <GiftIcon className="w-5 h-5" />
                    </button>
                    <button onClick={handleShareClick} className="flex items-center gap-1.5 hover:text-brand-green transition-colors" title="Share this post externally">
                        <ShareIcon className="w-5 h-5" />
                    </button>
                </div>
                <button onClick={handleSave} className={`hover:text-brand-gold transition-colors ${isSaved ? 'text-brand-gold' : ''}`} title={isSaved ? "Unsave post" : "Save post to your account"}>
                    {isSaved ? <SolidBookmarkIcon className="w-5 h-5" /> : <BookmarkIcon className="w-5 h-5" />}
                </button>
            </div>

            {isShareModalOpen && <ShareModal postUrl={`${window.location.origin}/post/${post.id}`} postTitle={`Check out this post by ${post.creator.name} on Imara!`} onClose={() => setIsShareModalOpen(false)} />}
            {isRemixModalOpen && <RemixModal originalPost={post} onClose={() => setIsRemixModalOpen(false)} />}
            {linkToOpen && <InAppBrowser url={linkToOpen} onClose={() => setLinkToOpen(null)} />}
        </article>
    );
};

export default GistPostCard;
