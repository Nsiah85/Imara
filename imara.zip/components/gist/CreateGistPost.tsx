
import React from 'react';
import { useAuth } from '../../contexts/AuthContext.tsx';
import Avatar from '../ui/Avatar.tsx';
import { CameraIcon } from '../icons/Icons.tsx';

interface CreateGistPostProps {
  onOpen: (type: 'text' | 'media') => void;
}

const CreateGistPost: React.FC<CreateGistPostProps> = ({ onOpen }) => {
  const { user } = useAuth();

  if (!user) {
    return null;
  }

  return (
    <div className="bg-white dark:bg-brand-navy-dark p-4 rounded-lg shadow-md mb-4 border border-gray-100 dark:border-gray-800">
      <div className="flex items-center gap-3">
        {/* Use a ring to match the profile aesthetic requested */}
        <Avatar
          imageUrl={user.profileImageUrl}
          name={user.fullName}
          id={user.id}
          className="w-10 h-10 rounded-full flex-shrink-0"
          textClassName="text-lg font-bold text-white"
          hasRing={true} 
        />
        <button
          onClick={() => onOpen('text')}
          className="flex-grow text-left p-3 bg-gray-100 dark:bg-gray-800 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors truncate border border-transparent hover:border-brand-gold/20"
        >
          {`What's toastin', ${user.fullName.split(' ')[0]}?`}
        </button>
        <button 
            onClick={() => onOpen('media')}
            className="p-2.5 bg-brand-off-white dark:bg-gray-800 hover:bg-brand-gold/10 rounded-full text-brand-gold transition-colors flex-shrink-0 border border-transparent hover:border-brand-gold"
            title="Open Camera"
        >
            <CameraIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default CreateGistPost;
