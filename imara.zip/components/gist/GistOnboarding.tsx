
import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../contexts/LanguageContext.tsx';
import Button from '../ui/Button.tsx';
import { ImaraDiskIcon, XIcon } from '../icons/Icons.tsx';

interface GistOnboardingProps {
  onClose: () => void;
}

const GistOnboarding: React.FC<GistOnboardingProps> = ({ onClose }) => {
    const { t } = useLanguage();
    const [isVisible, setIsVisible] = useState(false);
    
    useEffect(() => {
        // Delay visibility for a smoother entrance animation
        const timer = setTimeout(() => setIsVisible(true), 100);
        return () => clearTimeout(timer);
    }, []);

    const handleClose = () => {
        setIsVisible(false);
        // Wait for animation before calling parent onClose
        setTimeout(onClose, 300);
    };

    return (
        <div 
            className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm transition-opacity duration-500 ${isVisible ? 'opacity-100' : 'opacity-0'}`}
        >
            <div 
                className={`relative w-full max-w-md bg-brand-navy-dark rounded-3xl shadow-2xl overflow-hidden border border-white/10 transition-all duration-500 transform ${isVisible ? 'scale-100 translate-y-0' : 'scale-95 translate-y-8'}`}
            >
                {/* Background Pattern & Glow Effects */}
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10 pointer-events-none"></div>
                <div className="absolute top-[-50%] left-1/2 transform -translate-x-1/2 w-64 h-64 bg-brand-green/30 rounded-full blur-[60px] pointer-events-none"></div>
                <div className="absolute bottom-[-20%] right-[-20%] w-40 h-40 bg-brand-gold/20 rounded-full blur-[50px] pointer-events-none"></div>

                {/* Close Button */}
                <button 
                    onClick={handleClose} 
                    className="absolute top-4 right-4 p-2 text-white/50 hover:text-white transition-colors z-20 rounded-full hover:bg-white/10"
                    aria-label="Close"
                >
                    <XIcon className="w-5 h-5" />
                </button>

                {/* Content */}
                <div className="relative z-10 p-8 flex flex-col items-center text-center">
                    <div className="mb-6 relative">
                        {/* Halo behind logo */}
                        <div className="absolute inset-0 bg-brand-gold blur-xl opacity-20 rounded-full animate-pulse"></div>
                        <ImaraDiskIcon className="w-24 h-24 relative z-10 drop-shadow-xl" />
                    </div>

                    <h1 className="text-3xl font-display font-extrabold text-white tracking-tight leading-tight mb-4">
                        {t('toast.onboarding.title')}
                    </h1>
                    
                    <p className="text-gray-300 text-base leading-relaxed mb-8 max-w-xs mx-auto">
                        {t('toast.onboarding.subtitle')}
                    </p>

                    <Button 
                        variant="primary" 
                        size="lg" 
                        className="w-full !bg-brand-gold !text-brand-navy-dark !font-extrabold !text-lg !py-4 shadow-gold-glow hover:scale-[1.02] active:scale-[0.98] transition-transform"
                        onClick={handleClose}
                    >
                        {t('toast.onboarding.cta')}
                    </Button>
                </div>
            </div>
        </div>
    );
};

export default GistOnboarding;
