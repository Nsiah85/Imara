
import React, { useState, useRef, useEffect } from 'react';
import { 
    XIcon, PhotoIcon, ChartBarIcon, ShoppingBagIcon, SparklesIcon, FilmIcon, 
    CameraIcon, DocumentTextIcon, GlobeIcon, CheckCircleIcon, 
    CropIcon, PaletteIcon, StickerIcon, WandIcon, ChatBubbleBottomCenterTextIcon,
    LayoutIcon, PlayIcon, StopIcon, MusicalNoteIcon
} from '../icons/Icons';
import Button from '../ui/Button';
import { useAuth } from '../../contexts/AuthContext';
import type { GistPost, Product, TravelService, Sound } from '../../types';
import { mockProducts, mockTravelServices } from '../../data/mockData';
import Avatar from '../ui/Avatar';
import { useVideoGeneration } from '../../hooks/useVideoGeneration';
import LoadingSpinner from '../ui/LoadingSpinner';
import { useCurrency } from '../../contexts/CurrencyContext';
import FilterSelector, { FilterType } from './FilterSelector';
import { GoogleGenAI } from '@google/genai';

interface ToastComposerModalProps {
  onClose: () => void;
  onPost: (post: GistPost) => void;
  initialTab?: 'media' | 'text' | 'interact' | 'commerce' | 'ai';
}

// Design System Constants
const fonts = ['Inter', 'Poppins', 'Lobster', 'Caveat', 'Playfair Display', 'Oswald'];
const backgroundColors = [
    '#0A2342', '#00A550', '#D4AF37', '#FFFFFF', '#F0F4F8', '#1e293b',
    'linear-gradient(45deg, #FFD700, #FF8C00)',
    'linear-gradient(to right, #00A550, #004d40)',
    'linear-gradient(to right, #ec4899, #8b5cf6)',
];

const ToastComposerModal: React.FC<ToastComposerModalProps> = ({ onClose, onPost, initialTab = 'media' }) => {
    const { user } = useAuth();
    const { formatCurrency } = useCurrency();
    
    // Core State
    const [activeTab, setActiveTab] = useState<string>(initialTab);
    const [subMode, setSubMode] = useState<'none' | 'crop' | 'filters' | 'text' | 'stickers'>('none');
    const [text, setText] = useState('');
    
    // Design State
    const [bgColor, setBgColor] = useState(backgroundColors[0]);
    const [font, setFont] = useState('Inter');
    const [textAlign, setTextAlign] = useState<'left' | 'center' | 'right'>('center');
    
    // Media State (Updated for multiple files)
    const [mediaFiles, setMediaFiles] = useState<File[]>([]);
    const [mediaPreviews, setMediaPreviews] = useState<string[]>([]);
    const [selectedFilter, setSelectedFilter] = useState<FilterType>('none');
    const [overlayText, setOverlayText] = useState('');
    const [hasSticker, setHasSticker] = useState(false);
    
    const fileInputRef = useRef<HTMLInputElement>(null);
    const cameraInputRef = useRef<HTMLInputElement>(null);
    
    // AI Video State
    const { videoUrl: aiVideoUrl, isLoading: isGeneratingVideo, error: videoError, generateVideo } = useVideoGeneration();
    const [videoPrompt, setVideoPrompt] = useState('');
    const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');

    // Interactive State (Polls/Q&A)
    const [interactionType, setInteractionType] = useState<'poll' | 'q&a' | 'quote'>('poll');
    const [pollOptions, setPollOptions] = useState(['', '']);
    const [pollDuration, setPollDuration] = useState('24h');
    const [questionText, setQuestionText] = useState('');
    const [quoteAuthor, setQuoteAuthor] = useState('');

    // Commerce State
    const [attachedItem, setAttachedItem] = useState<Product | TravelService | null>(null);
    const [commerceSearch, setCommerceSearch] = useState('');

    // Sound State
    const [attachedSound, setAttachedSound] = useState<Sound | null>(null);
    const [soundSearch, setSoundSearch] = useState('');
    const [soundResults, setSoundResults] = useState<Sound[]>([]);
    const [isSearchingSounds, setIsSearchingSounds] = useState(false);

    const isPartner = user?.role === 'vendor' || user?.role === 'workman' || user?.role === 'travel' || user?.role === 'admin';

    useEffect(() => {
        if (activeTab === 'sound' && soundSearch.length > 2) {
            const searchFirebaseSounds = async () => {
                setIsSearchingSounds(true);
                try {
                    const { collection, getDocs, db } = await import('../../firebase/firestore.ts');
                    const snapshot = await getDocs(collection(db, 'sounds'));
                    const results: Sound[] = [];
                    snapshot.forEach(doc => {
                        const data = doc.data() as Sound;
                        if (data.title.toLowerCase().includes(soundSearch.toLowerCase()) || data.artist.toLowerCase().includes(soundSearch.toLowerCase())) {
                            results.push(data);
                        }
                    });
                    setSoundResults(results);
                } catch (e) {
                    console.error("Failed to fetch sounds", e);
                } finally {
                    setIsSearchingSounds(false);
                }
            };
            const debounce = setTimeout(searchFirebaseSounds, 500);
            return () => clearTimeout(debounce);
        }
    }, [activeTab, soundSearch]);

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            const files: File[] = Array.from(e.target.files);
            const newPreviews = files.map(file => URL.createObjectURL(file));
            
            setMediaFiles(prev => [...prev, ...files]);
            setMediaPreviews(prev => [...prev, ...newPreviews]);
            setSubMode('none');
        }
    };

    const handleGenerateVideo = () => {
        if (videoPrompt.trim()) {
            generateVideo(videoPrompt, aspectRatio);
        }
    };
    
    const handleMagicWrite = async () => {
        if (!process.env.API_KEY) return;
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash-lite',
                contents: `Write a short, engaging caption for a social media post about: "${text || 'African lifestyle'}". Max 20 words.`,
            });
            if (response.text) setText(response.text.trim());
        } catch (error) { console.error(error); }
    };

    const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        // Auto-replace # with %
        const val = e.target.value.replace(/#/g, '%');
        setText(val);
    };

    const handleSubmit = async () => {
        if (!user) return;
        
        let content: GistPost['content'] = {
            text: text,
            type: 'standard'
        };

        let isSubmitting = true; // Use simple flag or we can skip UI loading for brevity if not requested, but let's just upload.
        // To be safe, change button text or something outside this if needed, but since we are modifying it, we just await.

        // Map active tab to content type
        switch (activeTab) {
            case 'interact':
                if (interactionType === 'poll') {
                    content.type = 'poll';
                    content.pollOptions = pollOptions.filter(o => o.trim()).map((opt, i) => ({
                        id: i.toString(),
                        option: opt,
                        votes: 0
                    }));
                    content.pollDuration = pollDuration;
                    content.backgroundColor = bgColor;
                } else if (interactionType === 'q&a') {
                    content.type = 'q&a';
                    content.question = questionText;
                    content.backgroundColor = bgColor;
                } else {
                    content.type = 'quote';
                    content.text = text; // Quote text is main text
                    content.quoteAuthor = quoteAuthor;
                    content.backgroundColor = bgColor;
                    content.fontFamily = font;
                }
                break;

            case 'commerce':
                if (attachedItem) {
                    if ('vendor' in attachedItem) {
                        content.type = 'product_card';
                        content.productId = attachedItem.id;
                    } else {
                        content.type = 'booking_card';
                        content.serviceId = attachedItem.id;
                    }
                }
                break;

            case 'ai':
                if (aiVideoUrl) {
                    content.type = 'standard';
                    content.videoUrl = aiVideoUrl;
                    content.text = text || videoPrompt;
                }
                break;

            case 'media':
                if (mediaFiles.length > 0) {
                    // Just take the first one for the simplified logic, but handle multiple visually in future
                    const mainFile = mediaFiles[0];
                    let downloadUrl = mediaPreviews[0]; // fallback
                    try {
                        const { uploadFile } = await import('../../firebase/storage.ts');
                        downloadUrl = await uploadFile(mainFile, `posts/${user.id}/${Date.now()}_${Math.random().toString(36).substring(7)}`);
                    } catch (error) {
                        console.error('Failed to upload media:', error);
                        alert('Failed to upload media. Please try again.');
                        return; // Prevent posting broken image
                    }

                    if (mainFile.type.startsWith('video')) {
                        content.videoUrl = downloadUrl;
                    } else {
                        content.imageUrl = downloadUrl;
                        content.filterName = selectedFilter;
                        content.overlayText = overlayText;
                    }
                }
                break;

            case 'text':
                content.backgroundColor = bgColor;
                content.fontFamily = font;
                break;
                
            case 'sound':
                content.type = 'standard';
                break;
        }

        if (attachedSound) {
            content.sound = attachedSound;
        }

        const creatorRole = isPartner ? 'partner' : (user.role === 'admin' ? 'admin' : 'user');

        const newPost: GistPost = {
            id: crypto.randomUUID(),
            creator: {
                id: user.id,
                name: user.fullName,
                avatarUrl: user.profileImageUrl,
                profileLink: `/user/${user.id}`,
                role: creatorRole,
                isVerified: user.isVerified
            },
            timestamp: new Date().toISOString(),
            content,
            tags: text.match(/%\w+/g) || [],
            engagement: { likes: 0, commentsCount: 0, shares: 0, saves: 0, rating: 0, ratingCount: 0 },
            comments: []
        };

        onPost(newPost);
    };

    const getFilterStyle = (filter: FilterType) => {
        switch (filter) {
            case 'sepia': return { filter: 'sepia(0.8) contrast(1.2)' };
            case 'grayscale': return { filter: 'grayscale(1) contrast(1.2)' };
            case 'contrast': return { filter: 'contrast(1.5) saturate(1.2)' };
            case 'warm': return { filter: 'sepia(0.3) saturate(1.4)' };
            case 'cool': return { filter: 'hue-rotate(180deg) sepia(0.2)' };
            default: return {};
        }
    };

    // --- Render Helpers ---

    const renderMediaTab = () => (
        <div className="mt-4">
            {mediaPreviews.length > 0 ? (
                <div className="space-y-4">
                    <div className="relative rounded-2xl overflow-hidden bg-black max-h-80 w-fit mx-auto border border-gray-200 dark:border-gray-700 group">
                        {/* Display the first selected media for editing */}
                        {mediaFiles[0]?.type.startsWith('video') 
                            ? <video src={mediaPreviews[0]} controls className="max-h-80 w-auto"/>
                            : <img src={mediaPreviews[0]} alt="Preview" className="max-h-80 w-auto" style={getFilterStyle(selectedFilter)}/>
                        }
                        
                        {/* Overlay Text Preview */}
                        {overlayText && (
                            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-white text-xl font-bold bg-black/50 px-4 py-2 rounded-lg text-center cursor-move">
                                {overlayText}
                            </div>
                        )}
                        
                        {/* Sticker Preview */}
                        {hasSticker && (
                            <div className="absolute bottom-10 right-10 text-4xl cursor-move transform hover:scale-110 transition-transform">
                                🔥
                            </div>
                        )}

                        <button onClick={() => { setMediaFiles([]); setMediaPreviews([]); }} className="absolute top-2 right-2 bg-black/50 text-white rounded-full p-1 hover:bg-red-600 transition-colors">
                            <XIcon className="w-4 h-4"/>
                        </button>
                        
                        {/* Editor Controls Overlay */}
                        {!mediaFiles[0]?.type.startsWith('video') && (
                            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-3 bg-black/60 backdrop-blur-md p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
                                <button onClick={() => setSubMode('filters')} className={`p-2 rounded-full hover:bg-white/20 ${subMode === 'filters' ? 'text-brand-gold' : 'text-white'}`} title="Filters"><SparklesIcon className="w-5 h-5"/></button>
                                <button onClick={() => setSubMode('text')} className={`p-2 rounded-full hover:bg-white/20 ${subMode === 'text' ? 'text-brand-gold' : 'text-white'}`} title="Add Text"><span className="font-bold text-lg leading-none">T</span></button>
                                <button onClick={() => setSubMode('stickers')} className={`p-2 rounded-full hover:bg-white/20 ${subMode === 'stickers' ? 'text-brand-gold' : 'text-white'}`} title="Stickers"><StickerIcon className="w-5 h-5"/></button>
                            </div>
                        )}
                    </div>

                    {/* Preview Strip for Multiple Files */}
                    {mediaPreviews.length > 1 && (
                        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide justify-center">
                            {mediaPreviews.map((src, i) => (
                                <div key={i} className="w-16 h-16 rounded-md overflow-hidden border border-gray-300">
                                    {mediaFiles[i].type.startsWith('video') ? (
                                        <video src={src} className="w-full h-full object-cover" muted />
                                    ) : (
                                        <img src={src} className="w-full h-full object-cover" alt={`Preview ${i}`} />
                                    )}
                                </div>
                            ))}
                        </div>
                    )}
                    
                    {subMode === 'filters' && !mediaFiles[0]?.type.startsWith('video') && (
                        <FilterSelector selectedFilter={selectedFilter} onSelect={setSelectedFilter} previewUrl={mediaPreviews[0]} />
                    )}

                    {subMode === 'text' && (
                        <div className="animate-fade-in p-2 bg-gray-100 dark:bg-gray-800 rounded-lg">
                            <input 
                                type="text" 
                                value={overlayText} 
                                onChange={(e) => setOverlayText(e.target.value)} 
                                placeholder="Type overlay text..." 
                                className="w-full p-2 rounded border dark:bg-gray-700 dark:text-white dark:border-gray-600"
                                autoFocus
                            />
                        </div>
                    )}
                    
                     {subMode === 'stickers' && (
                        <div className="animate-fade-in p-2 bg-gray-100 dark:bg-gray-800 rounded-lg flex gap-4 overflow-x-auto">
                            {['🔥', '✨', '🌍', '🛒', '🎉'].map(emoji => (
                                <button key={emoji} onClick={() => setHasSticker(true)} className="text-2xl hover:scale-125 transition-transform">{emoji}</button>
                            ))}
                        </div>
                    )}
                </div>
            ) : (
                <div className="grid grid-cols-2 gap-4">
                    <div 
                        onClick={() => fileInputRef.current?.click()} 
                        className="aspect-square border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 dark:hover:bg-white/5 transition-all group"
                    >
                        <div className="w-12 h-12 bg-brand-green/10 rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                            <PhotoIcon className="w-6 h-6 text-brand-green" />
                        </div>
                        <p className="text-sm font-bold text-gray-600 dark:text-gray-300">Upload Media</p>
                        <p className="text-xs text-gray-400">Multiple selection allowed</p>
                    </div>
                    <div 
                        onClick={() => cameraInputRef.current?.click()}
                        className="aspect-square border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 dark:hover:bg-white/5 transition-all group"
                    >
                        <div className="w-12 h-12 bg-brand-gold/20 rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                            <CameraIcon className="w-6 h-6 text-brand-gold" />
                        </div>
                        <p className="text-sm font-bold text-gray-600 dark:text-gray-300">Camera</p>
                        <p className="text-xs text-gray-400">Capture Now</p>
                    </div>
                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*,video/*" multiple onChange={handleFileSelect}/>
                    <input type="file" ref={cameraInputRef} className="hidden" accept="image/*,video/*" capture="environment" onChange={handleFileSelect}/>
                </div>
            )}
        </div>
    );

    const renderDesignTab = () => (
        <div className="mt-6 space-y-6">
            <div>
                <p className="text-xs font-bold text-gray-400 mb-2 uppercase tracking-wider">Background</p>
                <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
                    {backgroundColors.map((c, i) => (
                        <button 
                            key={i} 
                            onClick={() => setBgColor(c)} 
                            className={`w-10 h-10 rounded-full border-2 shadow-sm transition-transform hover:scale-110 flex-shrink-0 ${bgColor === c ? 'border-brand-gold scale-110' : 'border-transparent'}`} 
                            style={{background: c}} 
                        />
                    ))}
                </div>
            </div>
            <div>
                <p className="text-xs font-bold text-gray-400 mb-2 uppercase tracking-wider">Typography</p>
                <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
                    {fonts.map((f) => (
                        <button 
                            key={f} 
                            onClick={() => setFont(f)} 
                            className={`px-4 py-2 rounded-lg border bg-gray-100 dark:bg-gray-800 transition-all whitespace-nowrap ${font === f ? 'border-brand-gold text-brand-gold' : 'border-transparent text-gray-500'}`}
                            style={{fontFamily: f}}
                        >
                            {f}
                        </button>
                    ))}
                </div>
            </div>
             <div>
                <p className="text-xs font-bold text-gray-400 mb-2 uppercase tracking-wider">Alignment</p>
                <div className="flex gap-2 bg-gray-100 dark:bg-gray-800 w-fit p-1 rounded-lg">
                    {['left', 'center', 'right'].map((align: any) => (
                        <button 
                            key={align}
                            onClick={() => setTextAlign(align)} 
                            className={`p-2 rounded-md ${textAlign === align ? 'bg-white dark:bg-gray-700 shadow-sm text-brand-navy-dark dark:text-white' : 'text-gray-400'}`}
                        >
                            <div className={`w-4 h-0.5 bg-current mb-0.5 ${align === 'center' ? 'mx-auto' : align === 'right' ? 'ml-auto' : ''}`}></div>
                            <div className={`w-6 h-0.5 bg-current mb-0.5`}></div>
                            <div className={`w-3 h-0.5 bg-current ${align === 'center' ? 'mx-auto' : align === 'right' ? 'ml-auto' : ''}`}></div>
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );

    const renderInteractTab = () => (
        <div className="mt-4">
            <div className="flex gap-2 mb-6 p-1 bg-gray-100 dark:bg-gray-800 rounded-lg w-fit">
                <button onClick={() => setInteractionType('poll')} className={`px-4 py-1.5 rounded-md text-sm font-bold transition-colors ${interactionType === 'poll' ? 'bg-white dark:bg-brand-navy text-brand-navy-dark dark:text-white shadow-sm' : 'text-gray-500'}`}>Poll</button>
                <button onClick={() => setInteractionType('q&a')} className={`px-4 py-1.5 rounded-md text-sm font-bold transition-colors ${interactionType === 'q&a' ? 'bg-white dark:bg-brand-navy text-brand-navy-dark dark:text-white shadow-sm' : 'text-gray-500'}`}>Q&A</button>
                <button onClick={() => setInteractionType('quote')} className={`px-4 py-1.5 rounded-md text-sm font-bold transition-colors ${interactionType === 'quote' ? 'bg-white dark:bg-brand-navy text-brand-navy-dark dark:text-white shadow-sm' : 'text-gray-500'}`}>Quote</button>
            </div>

            {interactionType === 'poll' && (
                <div className="space-y-3 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-xl border border-gray-200 dark:border-gray-700">
                    {pollOptions.map((opt, idx) => (
                        <div key={idx} className="flex items-center gap-3">
                            <div className="w-6 h-6 rounded-full bg-brand-gold text-brand-navy-dark flex items-center justify-center text-xs font-bold">{idx + 1}</div>
                            <input 
                                type="text"
                                value={opt}
                                onChange={e => {
                                    const newOpts = [...pollOptions];
                                    newOpts[idx] = e.target.value;
                                    setPollOptions(newOpts);
                                }}
                                placeholder={`Option ${idx + 1}`}
                                className="flex-1 bg-white dark:bg-gray-700 border-none rounded-lg py-2 px-3 text-sm focus:ring-2 focus:ring-brand-gold"
                            />
                        </div>
                    ))}
                    {pollOptions.length < 4 && (
                        <button onClick={() => setPollOptions([...pollOptions, ''])} className="text-xs font-bold text-brand-green ml-9 hover:underline">+ Add Option</button>
                    )}
                </div>
            )}
            
            {interactionType === 'q&a' && (
                 <div className="p-6 bg-brand-navy-dark rounded-xl text-center relative overflow-hidden">
                     <div className="relative z-10">
                        <ChatBubbleBottomCenterTextIcon className="w-8 h-8 text-brand-gold mx-auto mb-2"/>
                        <input 
                            type="text" 
                            value={questionText}
                            onChange={e => setQuestionText(e.target.value)}
                            placeholder="Ask me anything..."
                            className="w-full bg-transparent text-center text-white placeholder:text-white/50 font-bold text-xl border-none focus:ring-0"
                        />
                     </div>
                 </div>
            )}

            {interactionType === 'quote' && (
                <div className="space-y-3">
                    <textarea 
                        value={text}
                        onChange={handleTextChange}
                        placeholder="Type the quote here..."
                        className="w-full p-4 bg-gray-50 dark:bg-gray-800 border-none rounded-xl text-lg font-serif italic focus:ring-2 focus:ring-brand-gold resize-none"
                        rows={3}
                    />
                    <input 
                         type="text"
                         value={quoteAuthor}
                         onChange={e => setQuoteAuthor(e.target.value)}
                         placeholder="- Author Name"
                         className="w-full p-2 bg-transparent border-b border-gray-200 dark:border-gray-700 focus:border-brand-gold focus:outline-none text-right font-medium"
                    />
                </div>
            )}
        </div>
    );

    const renderCommerceTab = () => (
         <div className="mt-4">
            {attachedItem ? (
                <div className="p-4 border-2 border-brand-gold bg-brand-gold/5 rounded-2xl flex gap-4 items-center relative">
                    <img src={attachedItem.imageUrl} className="w-16 h-16 rounded-xl object-cover" alt="" />
                    <div>
                        <p className="font-bold text-brand-navy-dark dark:text-white line-clamp-1">{'name' in attachedItem ? attachedItem.name : attachedItem.title}</p>
                        <p className="text-xs text-brand-green font-bold flex items-center gap-1"><CheckCircleIcon className="w-3 h-3"/> Metadata Extracted</p>
                        <p className="text-sm font-mono text-brand-navy-dark dark:text-white mt-1">{formatCurrency(attachedItem.price)}</p>
                    </div>
                    <button onClick={() => setAttachedItem(null)} className="absolute top-2 right-2 p-1 bg-white dark:bg-gray-800 rounded-full hover:text-red-500 shadow-sm"><XIcon className="w-4 h-4"/></button>
                </div>
            ) : (
                <div className="space-y-4">
                    <input 
                        type="text" 
                        placeholder="Search your inventory..." 
                        value={commerceSearch}
                        onChange={e => setCommerceSearch(e.target.value)}
                        className="w-full p-3 bg-gray-100 dark:bg-gray-800 rounded-xl border-none focus:ring-2 focus:ring-brand-gold text-sm"
                    />
                    <div className="grid grid-cols-2 gap-3 max-h-60 overflow-y-auto custom-scrollbar p-1">
                        {[...mockProducts, ...mockTravelServices].slice(0, 8).map(item => (
                            <div key={item.id} onClick={() => setAttachedItem(item)} className="flex items-center gap-2 p-2 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 cursor-pointer hover:border-brand-gold transition-colors group">
                                <img src={item.imageUrl} className="w-10 h-10 rounded-lg object-cover group-hover:scale-105 transition-transform" alt=""/>
                                <div className="flex-1 min-w-0">
                                    <p className="text-xs font-bold truncate dark:text-white">{'name' in item ? item.name : item.title}</p>
                                    <p className="text-[10px] text-gray-500">{formatCurrency(item.price)}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );

    const renderAITab = () => (
        <div className="mt-4 p-4 bg-purple-50 dark:bg-purple-900/20 border border-purple-100 dark:border-purple-800 rounded-2xl">
            {aiVideoUrl ? (
                <div className="relative rounded-xl overflow-hidden bg-black aspect-video shadow-lg">
                    <video src={aiVideoUrl} controls className="w-full h-full object-contain" />
                    <button onClick={() => setVideoPrompt('')} className="absolute top-2 right-2 bg-black/50 text-white p-1 rounded-full text-xs hover:bg-black">Reset</button>
                </div>
            ) : (
                <>
                    <div className="flex items-center gap-2 mb-4 text-purple-700 dark:text-purple-300">
                        <WandIcon className="w-5 h-5" />
                        <h3 className="font-bold text-sm">AI Video Generator</h3>
                    </div>
                    <textarea 
                        value={videoPrompt}
                        onChange={e => setVideoPrompt(e.target.value)}
                        placeholder="Describe your video (e.g. 'Cinematic drone shot of Accra city skyline at sunset with upbeat afrobeat audio')"
                        className="w-full p-3 bg-white dark:bg-gray-800 border border-purple-200 dark:border-purple-700 rounded-xl text-sm resize-none focus:ring-2 focus:ring-purple-500 outline-none mb-3"
                        rows={4}
                    />
                    
                    <div className="flex gap-4 mb-4">
                        <label className="flex items-center gap-2 text-xs font-bold text-gray-600 dark:text-gray-300 cursor-pointer">
                            <input type="radio" name="ratio" checked={aspectRatio === '16:9'} onChange={() => setAspectRatio('16:9')} className="text-purple-600 focus:ring-purple-500"/>
                            Landscape (16:9)
                        </label>
                         <label className="flex items-center gap-2 text-xs font-bold text-gray-600 dark:text-gray-300 cursor-pointer">
                            <input type="radio" name="ratio" checked={aspectRatio === '9:16'} onChange={() => setAspectRatio('9:16')} className="text-purple-600 focus:ring-purple-500"/>
                            Theater Mode (9:16)
                        </label>
                    </div>

                    <Button 
                        onClick={handleGenerateVideo} 
                        disabled={isGeneratingVideo || !videoPrompt.trim()} 
                        className="w-full !bg-purple-600 hover:!bg-purple-700 text-white border-none flex items-center justify-center gap-2 py-3 text-sm shadow-lg"
                    >
                        {isGeneratingVideo ? <><LoadingSpinner className="w-4 h-4"/> Generating Magic...</> : <><FilmIcon className="w-4 h-4"/> Generate Video</>}
                    </Button>
                </>
            )}
            {videoError && <p className="text-red-500 text-xs mt-2">{videoError}</p>}
        </div>
    );

    const renderSoundTab = () => (
        <div className="mt-4">
            <input 
                type="text"
                placeholder="Search tracks or artists to add..."
                value={soundSearch}
                onChange={(e) => setSoundSearch(e.target.value)}
                className="w-full p-4 pl-12 bg-gray-50 dark:bg-gray-800 border-none rounded-2xl dark:text-white"
            />
            <div className="mt-4 max-h-60 overflow-y-auto space-y-2">
                {isSearchingSounds ? (
                    <div className="p-4 text-center"><LoadingSpinner className="w-6 h-6 mx-auto" /></div>
                ) : soundResults.length > 0 ? (
                    soundResults.map(p => (
                        <div key={p.id} onClick={() => setAttachedSound(p)} className={`p-3 flex items-center justify-between rounded-xl cursor-pointer transition-colors ${attachedSound?.id === p.id ? 'bg-purple-100 dark:bg-purple-900/40 border border-purple-500' : 'bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700'}`}>
                            <div>
                                <p className="text-sm font-bold dark:text-white">{p.title}</p>
                                <p className="text-xs text-gray-500">{p.artist}</p>
                            </div>
                            <div className="flex gap-2">
                                <button className="p-2 bg-gray-200 dark:bg-gray-700 rounded-full" onClick={(e) => { e.stopPropagation(); /* Preview play logic could go here */ }}><PlayIcon className="w-4 h-4 text-brand-navy-dark dark:text-white"/></button>
                            </div>
                        </div>
                    ))
                ) : soundSearch.length > 2 ? (
                    <p className="text-sm text-gray-500 text-center py-4">No sounds found. Try another search.</p>
                ) : (
                    <p className="text-sm text-gray-500 text-center py-4">Type to search for music and sounds.</p>
                )}
            </div>
            {attachedSound && (
                <div className="mt-4 p-4 bg-brand-gold/20 rounded-xl flex items-center justify-between">
                    <div>
                        <p className="text-xs font-bold text-brand-navy-dark dark:text-white">Attached Tune</p>
                        <p className="text-sm font-bold text-brand-navy-dark dark:text-white">{attachedSound.title} by {attachedSound.artist}</p>
                    </div>
                    <button onClick={() => setAttachedSound(null)} className="text-red-500"><XIcon className="w-5 h-5"/></button>
                </div>
            )}
        </div>
    );

    const TabButton = ({ id, icon, label }: { id: string, icon: React.ReactNode, label: string }) => (
        <button 
            onClick={() => setActiveTab(id)}
            className={`flex flex-col items-center justify-center gap-1 px-3 py-2 rounded-xl min-w-[70px] transition-all ${
                activeTab === id 
                ? 'bg-brand-navy-dark dark:bg-white text-white dark:text-brand-navy-dark shadow-md transform -translate-y-1' 
                : 'text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}
        >
            {icon}
            <span className="text-[10px] font-bold">{label}</span>
        </button>
    );

    return (
        <div className="fixed inset-0 z-[100] bg-white sm:bg-black/60 sm:backdrop-blur-sm flex items-center justify-center sm:p-4 animate-fade-in">
            <div className="bg-white dark:bg-brand-navy-dark w-full h-full sm:h-auto sm:max-w-2xl sm:rounded-3xl shadow-2xl flex flex-col sm:max-h-[90vh] overflow-hidden relative">
                
                {/* Header */}
                <div className="p-4 px-6 flex justify-between items-center border-b border-gray-100 dark:border-gray-700 flex-shrink-0">
                    <div className="flex items-center gap-3">
                         {/* Corrected Avatar Usage: Ensure it uses user.profileImageUrl directly */}
                         <Avatar 
                             imageUrl={user?.profileImageUrl} 
                             name={user?.fullName || 'User'} 
                             id={user?.id} // ADDED THIS
                             className="w-10 h-10 rounded-full" 
                             hasRing 
                         />
                         <div className="flex flex-col">
                             <span className="text-sm font-bold text-brand-navy-dark dark:text-white">{user?.fullName}</span>
                             <button className="flex items-center gap-1 text-xs font-medium text-gray-500 dark:text-gray-400 hover:text-brand-gold transition-colors">
                                 Public <GlobeIcon className="w-3 h-3" />
                             </button>
                         </div>
                    </div>
                    <div className="flex items-center gap-2">
                        <Button size="sm" variant="outline" onClick={handleMagicWrite} className="!p-2 !rounded-full" title="AI Magic Write">
                            <SparklesIcon className="w-4 h-4 text-brand-gold" />
                        </Button>
                        <button onClick={onClose} className="p-2 bg-gray-100 dark:bg-gray-800 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors">
                            <XIcon className="w-5 h-5 text-gray-500 dark:text-gray-300" />
                        </button>
                    </div>
                </div>

                {/* Body - Scrollable Content */}
                <div className="flex-1 overflow-y-auto p-6 max-h-[calc(100vh-150px)] sm:max-h-none" style={{ background: (activeTab === 'text' || activeTab === 'interact') ? bgColor : undefined, textAlign: textAlign }}>
                    
                    {/* Text Input Area (Hidden for AI Video tab if generating) */}
                    {activeTab !== 'ai' && (
                         <textarea 
                            value={text}
                            onChange={handleTextChange}
                            placeholder="What's toastin'?"
                            className={`w-full bg-transparent resize-none focus:outline-none text-xl placeholder:text-gray-400 dark:placeholder:text-gray-500 leading-relaxed transition-all ${
                                activeTab === 'text' || activeTab === 'interact' ? 'text-white placeholder:text-white/50 font-bold text-2xl min-h-[150px]' : 'min-h-[100px] dark:text-white'
                            }`}
                            style={{ fontFamily: font, textAlign }}
                        />
                    )}

                    {/* Tab Contents */}
                    {activeTab === 'media' && renderMediaTab()}
                    {activeTab === 'text' && renderDesignTab()}
                    {activeTab === 'interact' && renderInteractTab()}
                    {activeTab === 'commerce' && renderCommerceTab()}
                    {activeTab === 'ai' && renderAITab()}
                    {activeTab === 'sound' && renderSoundTab()}

                    {/* Spacer for mobile bottom bar */}
                    <div className="h-24 sm:hidden"></div>
                </div>

                {/* Floating Bottom Toolbar */}
                <div className="border-t border-gray-100 dark:border-gray-700 bg-white dark:bg-brand-navy-dark p-2 sm:p-4 pb-6 sm:pb-4 z-20">
                    <div className="flex items-center justify-between gap-4">
                        <div className="flex gap-1 overflow-x-auto scrollbar-hide flex-1">
                            <TabButton id="media" icon={<PhotoIcon className="w-5 h-5"/>} label="Media" />
                            <TabButton id="text" icon={<PaletteIcon className="w-5 h-5"/>} label="Design" />
                            <TabButton id="interact" icon={<LayoutIcon className="w-5 h-5"/>} label="Interact" />
                            {isPartner && <TabButton id="commerce" icon={<ShoppingBagIcon className="w-5 h-5"/>} label="Shop" />}
                            {user?.isVerified && <TabButton id="ai" icon={<FilmIcon className="w-5 h-5"/>} label="AI Video" />}
                            <TabButton id="sound" icon={<MusicalNoteIcon className="w-5 h-5"/>} label="Tunes" />
                        </div>
                        <Button 
                            onClick={handleSubmit} 
                            disabled={(!text.trim() && mediaFiles.length === 0 && !attachedItem && !aiVideoUrl && !attachedSound) || isGeneratingVideo}
                            className="shadow-xl transform hover:scale-105 transition-transform rounded-full px-8 h-12 font-bold"
                        >
                            Toast
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ToastComposerModal;
