
import React, { useState, useMemo } from 'react';
import { FireIcon, SearchIcon } from '../icons/Icons.tsx';
import { mockGistPosts } from '../../data/mockData.ts';
import type { GistPost } from '../../types';

// Analyzes posts to find top trending tags based on engagement and merit
const analyzeTrends = (posts: GistPost[]): { title: string; score: number }[] => {
    const tagScores: { [tag: string]: number } = {};

    posts.forEach(post => {
        post.tags.forEach(tag => {
            if (tag.startsWith('%')) {
                // Scoring weighted for Merit (Comments/Shares/Saves) over raw Likes
                const score = (post.engagement.likes * 1) + 
                              (post.engagement.commentsCount * 5) + 
                              (post.engagement.shares * 8) +
                              (post.engagement.saves * 10);
                tagScores[tag] = (tagScores[tag] || 0) + score;
            }
        });
    });

    return Object.entries(tagScores)
        .sort(([, scoreA], [, scoreB]) => scoreB - scoreA)
        .map(([tag, score]) => ({ title: tag, score }));
};


interface TrendingGistsProps {
    onTrendClick: (trend: string) => void;
    activeTrend: string | null;
}

const TrendingGists: React.FC<TrendingGistsProps> = ({ onTrendClick, activeTrend }) => {
    const [searchTerm, setSearchTerm] = useState('');
    
    const trendingItems = useMemo(() => analyzeTrends(mockGistPosts), []);

    const filteredTrends = useMemo(() => {
        return trendingItems.filter(item => 
            item.title.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [trendingItems, searchTerm]);

    const handleSearchSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (searchTerm.trim()) {
            onTrendClick(searchTerm.trim());
        }
    };
    
    return (
        <div className="w-full h-full flex flex-col">
             <div className="flex items-center gap-2 mb-4 text-brand-gold">
                <FireIcon className="w-5 h-5 animate-pulse" />
                <h3 className="font-bold text-lg">Trending Tts</h3>
            </div>
            
            <form onSubmit={handleSearchSubmit} className="relative w-full mb-4">
                    <SearchIcon className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                    type="search"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    placeholder="Search trends..."
                    className="w-full bg-white/10 dark:bg-white/5 text-black dark:text-white rounded-lg py-2 pl-9 pr-4 text-sm focus:ring-1 focus:ring-brand-gold focus:outline-none"
                />
            </form>
            
            <div className="flex-grow overflow-y-auto custom-scrollbar space-y-2 pr-2">
                {filteredTrends.map((item, index) => (
                    <button 
                        key={index} 
                        onClick={() => onTrendClick(item.title)}
                        className={`w-full text-left px-4 py-3 rounded-full transition-all flex justify-between items-center group shadow-sm ${
                            activeTrend === item.title 
                                ? 'bg-brand-gold text-brand-navy-dark shadow-md' 
                                : 'bg-white/80 dark:bg-white/10 hover:bg-brand-off-white dark:hover:bg-white/20 text-gray-800 dark:text-gray-200'
                        }`}
                        title={`Filter by trend: ${item.title}`}
                    >
                        <span className="font-medium text-sm truncate">{item.title}</span>
                        <span className={`text-[10px] font-bold font-mono px-2 py-0.5 rounded-full ${activeTrend === item.title ? 'bg-brand-navy-dark text-brand-gold' : 'bg-gray-100 dark:bg-gray-800 text-brand-green'}`}>
                            {item.score > 1000 ? `${(item.score/1000).toFixed(1)}k` : item.score} Tts
                        </span>
                    </button>
                ))}
            </div>
        </div>
    );
};

export default TrendingGists;
