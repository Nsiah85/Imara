
import React, { useRef, useState } from 'react';
import type { GistStatus, UserProfile } from '../../types.ts';
import StatusBubble from './StatusBubble.tsx';
import { PlusIcon } from '../icons/Icons.tsx';

interface StatusBarProps {
  statuses: GistStatus[];
  viewedStatusIds: string[];
  currentUser: UserProfile | null;
  onViewStatus: (startIndex: number) => void;
  onAddGist: () => void;
}

const StatusBar: React.FC<StatusBarProps> = ({ statuses, viewedStatusIds, currentUser, onViewStatus, onAddGist }) => {
    const scrollContainerRef = useRef<HTMLDivElement>(null);
    const [isDragging, setIsDragging] = useState(false);
    const [startX, setStartX] = useState(0);
    const [scrollLeft, setScrollLeft] = useState(0);

    const handleMouseDown = (e: React.MouseEvent) => {
        if (!scrollContainerRef.current) return;
        setIsDragging(true);
        setStartX(e.pageX - scrollContainerRef.current.offsetLeft);
        setScrollLeft(scrollContainerRef.current.scrollLeft);
    };

    const handleMouseLeave = () => {
        setIsDragging(false);
    };

    const handleMouseUp = () => {
        setIsDragging(false);
    };

    const handleMouseMove = (e: React.MouseEvent) => {
        if (!isDragging || !scrollContainerRef.current) return;
        e.preventDefault();
        const x = e.pageX - scrollContainerRef.current.offsetLeft;
        const walk = (x - startX) * 2; // Scroll-fast
        scrollContainerRef.current.scrollLeft = scrollLeft - walk;
    };

    return (
        <div className="py-4 pl-4 sm:pl-0 w-full">
            <div 
                ref={scrollContainerRef}
                className="flex items-center gap-3 overflow-x-auto pb-2 scrollbar-hide cursor-grab active:cursor-grabbing snap-x snap-mandatory touch-pan-x"
                onMouseDown={handleMouseDown}
                onMouseLeave={handleMouseLeave}
                onMouseUp={handleMouseUp}
                onMouseMove={handleMouseMove}
            >
                {/* Current User Add Story */}
                {currentUser && (
                    <div className="relative flex-shrink-0 w-28 h-44 rounded-xl overflow-hidden cursor-pointer group shadow-md border border-gray-200 dark:border-gray-700 snap-start" onClick={onAddGist}>
                        <div className="absolute inset-0 bg-gray-200 dark:bg-gray-800">
                             {currentUser.profileImageUrl ? (
                                <img src={currentUser.profileImageUrl} alt="My Story" className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-500" />
                             ) : (
                                <div className="w-full h-full flex items-center justify-center bg-brand-navy-dark">
                                    <span className="text-brand-gold font-bold text-2xl">Me</span>
                                </div>
                             )}
                        </div>
                        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/60"></div>
                        <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 flex flex-col items-center gap-1 w-full">
                            <div className="bg-brand-gold text-brand-navy-dark rounded-full p-1 border-2 border-brand-navy-dark">
                                <PlusIcon className="w-5 h-5" />
                            </div>
                            <span className="text-white text-xs font-bold">Add Gist</span>
                        </div>
                    </div>
                )}
                
                {/* Other Users Statuses */}
                {statuses.map((status, index) => (
                    <div key={status.id} className="snap-start">
                        <StatusBubble
                            status={status}
                            hasBeenViewed={viewedStatusIds.includes(status.id)}
                            onClick={() => {
                                if (!isDragging) onViewStatus(index);
                            }}
                        />
                    </div>
                ))}
            </div>
        </div>
    );
};

export default StatusBar;
