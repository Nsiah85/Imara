
import React, { useState, useCallback, useRef, useEffect } from 'react';
import { XIcon, ArrowLeftIcon, ArrowUpTrayIcon, SparklesIcon, VideoCameraIcon, PhotoIcon, MusicNoteIcon, CameraIcon, MicrophoneIcon, StopIcon, PlayIcon, FilmIcon } from '../icons/Icons';
import Button from '../ui/Button';
import type { GistPost, GistStatus, GistStatusItem, Sound } from '../../types';
import { useAuth } from '../../contexts/AuthContext';
import { GoogleGenAI } from '@google/genai';
import LoadingSpinner from '../ui/LoadingSpinner';
import { mockSounds } from '../../data/mockData';
import { useContentSafety } from '../../hooks/useContentSafety';
import { useVideoGeneration } from '../../hooks/useVideoGeneration';

interface GistCreatorStudioProps {
  onClose: () => void;
  onPostCreated: (newPost: any) => void;
  initialStep?: 'select' | 'camera';
}

type CreatorStep = 'select' | 'camera' | 'voice' | 'video_gen' | 'edit' | 'publish';
type CameraMode = 'photo' | 'video';

const backgroundColors = ['#0A2342', '#028A7A', '#D4AF37', '#b91c1c', '#4f46e5', '#c026d3', '#000000'];
const fonts = ['Inter', 'Poppins', 'Lobster', 'Caveat', 'Playfair Display'];

const GistCreatorStudio: React.FC<GistCreatorStudioProps> = ({ onClose, onPostCreated, initialStep = 'select' }) => {
    const { user } = useAuth();
    const { checkSafety, isSafe, error: safetyError } = useContentSafety();
    const { videoUrl: aiVideoUrl, isLoading: isGeneratingVideo, error: videoError, generateVideo } = useVideoGeneration();

    const [step, setStep] = useState<CreatorStep>(initialStep);
    const [activeTab, setActiveTab] = useState<'media' | 'text' | 'voice' | 'video_gen'>('media');
    
    const [file, setFile] = useState<File | null>(null);
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);
    const [isAnimating, setIsAnimating] = useState(false);
    const [isMagicWriting, setIsMagicWriting] = useState(false);
    const [text, setText] = useState('');
    const [videoPrompt, setVideoPrompt] = useState('');
    const [bgColor, setBgColor] = useState(backgroundColors[0]);
    const [font, setFont] = useState(fonts[0]);
    
    // Camera State
    const videoRef = useRef<HTMLVideoElement>(null);
    const [stream, setStream] = useState<MediaStream | null>(null);
    const [cameraMode, setCameraMode] = useState<CameraMode>('photo');
    const [isRecordingVideo, setIsRecordingVideo] = useState(false);
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const videoChunksRef = useRef<Blob[]>([]);
    const [recordingTimer, setRecordingTimer] = useState(0);
    
    // Voice State
    const [isRecordingAudio, setIsRecordingAudio] = useState(false);
    const audioChunksRef = useRef<Blob[]>([]);

    // Sound Selection
    const [selectedSound, setSelectedSound] = useState<Sound | null>(null);
    const [showSoundPicker, setShowSoundPicker] = useState(false);

    const inputRef = useRef<HTMLInputElement>(null);
    const timerIntervalRef = useRef<number | null>(null);

    // Start camera immediately if initialStep is camera
    useEffect(() => {
        if (initialStep === 'camera') {
            handleStartCamera();
        }
    }, [initialStep]);
    
    useEffect(() => {
        if (aiVideoUrl) {
            setPreviewUrl(aiVideoUrl);
            // Treat AI video as a 'media' post for the final step
            setActiveTab('media'); 
            setStep('edit');
        }
    }, [aiVideoUrl]);

    // Cleanup streams on unmount
    useEffect(() => {
        return () => {
            stopCamera();
            if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
        };
    }, []);

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const selectedFile = e.target.files[0];
            setFile(selectedFile);
            setPreviewUrl(URL.createObjectURL(selectedFile));
            setStep('edit');
        }
    };

    const handleStartCamera = async () => {
        try {
            const mediaStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
            setStream(mediaStream);
            setStep('camera');
            setTimeout(() => {
                if (videoRef.current) {
                    videoRef.current.srcObject = mediaStream;
                    videoRef.current.play();
                }
            }, 100);
        } catch (err) {
            console.error("Error accessing camera:", err);
            alert("Could not access camera/microphone.");
            if(initialStep === 'camera') onClose();
        }
    };
    
    const startVideoRecording = () => {
        if (!stream) return;
        mediaRecorderRef.current = new MediaRecorder(stream);
        videoChunksRef.current = [];
        
        mediaRecorderRef.current.ondataavailable = (event) => {
            if (event.data.size > 0) {
                videoChunksRef.current.push(event.data);
            }
        };
        
        mediaRecorderRef.current.onstop = () => {
            const blob = new Blob(videoChunksRef.current, { type: 'video/webm' });
            const videoFile = new File([blob], "recorded_video.webm", { type: 'video/webm' });
            setFile(videoFile);
            setPreviewUrl(URL.createObjectURL(videoFile));
            stopCamera();
            setStep('edit');
        };

        mediaRecorderRef.current.start();
        setIsRecordingVideo(true);
        setRecordingTimer(0);
        timerIntervalRef.current = window.setInterval(() => {
            setRecordingTimer(prev => {
                if (prev >= 59) { // 60s limit
                    stopVideoRecording();
                    return 60;
                }
                return prev + 1;
            });
        }, 1000);
    };

    const stopVideoRecording = () => {
        if (mediaRecorderRef.current && isRecordingVideo) {
            mediaRecorderRef.current.stop();
            setIsRecordingVideo(false);
            if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
        }
    };
    
    const handleCapture = () => {
        if (cameraMode === 'video') {
            if (isRecordingVideo) {
                stopVideoRecording();
            } else {
                startVideoRecording();
            }
        } else {
            // Photo Mode
            if (videoRef.current && stream) {
                const canvas = document.createElement('canvas');
                canvas.width = videoRef.current.videoWidth;
                canvas.height = videoRef.current.videoHeight;
                const ctx = canvas.getContext('2d');
                ctx?.drawImage(videoRef.current, 0, 0);
                
                canvas.toBlob(blob => {
                    if (blob) {
                        const capturedFile = new File([blob], "camera_capture.jpg", { type: "image/jpeg" });
                        setFile(capturedFile);
                        setPreviewUrl(URL.createObjectURL(capturedFile));
                        stopCamera();
                        setStep('edit');
                    }
                }, 'image/jpeg');
            }
        }
    };
    
    const stopCamera = () => {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            setStream(null);
        }
        if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };

    // --- Voice Recording ---
    const startAudioRecording = async () => {
        try {
            const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorderRef.current = new MediaRecorder(audioStream);
            audioChunksRef.current = [];
            
            mediaRecorderRef.current.ondataavailable = (event) => {
                audioChunksRef.current.push(event.data);
            };
            
            mediaRecorderRef.current.onstop = () => {
                const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
                const audioFile = new File([blob], "voice_note.webm", { type: 'audio/webm' });
                setFile(audioFile);
                setPreviewUrl(URL.createObjectURL(audioFile));
                audioStream.getTracks().forEach(track => track.stop());
                setStep('edit');
            };

            mediaRecorderRef.current.start();
            setIsRecordingAudio(true);
            setRecordingTimer(0);
            timerIntervalRef.current = window.setInterval(() => {
                 setRecordingTimer(prev => prev + 1);
            }, 1000);
        } catch (e) {
            console.error("Mic access error", e);
            alert("Microphone access needed.");
        }
    };

    const stopAudioRecording = () => {
        if (mediaRecorderRef.current && isRecordingAudio) {
            mediaRecorderRef.current.stop();
            setIsRecordingAudio(false);
            if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
        }
    };

    const handleTextSubmit = () => {
        if (text.trim()) {
            setStep('edit');
        }
    };
    
    const handleVideoGeneration = () => {
        if (!videoPrompt.trim()) return;
        generateVideo(videoPrompt);
    };

    const handleMagicWrite = async () => {
        if (!process.env.API_KEY) return;
        setIsMagicWriting(true);
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash-lite',
                contents: `Write a short, catchy, and inspiring caption for a social media story about: "${text || 'African culture and lifestyle'}". Keep it under 15 words. Include 2 hashtags.`,
            });
            if (response.text) {
                setText(response.text.trim());
            }
        } catch (error) {
            console.error("Magic write failed:", error);
        } finally {
            setIsMagicWriting(false);
        }
    };

    const handlePost = async () => {
        if (!user) return;
        
        // Safety Check
        const contentToCheck = text || (file?.name || videoPrompt || 'media upload');
        const safetyResult = await checkSafety(contentToCheck);
        
        if (!safetyResult) {
             alert(`Post blocked by AI Safety Check: ${safetyError || 'Harmful content detected.'}`);
             return;
        }

        let newItem: GistStatusItem;

        // Logic to determine if it's AI video or File Upload
        if ((activeTab === 'media' || activeTab === 'voice' || activeTab === 'video_gen') && previewUrl) {
             let finalUrl = previewUrl;
             if (file) {
                 try {
                     const { uploadFile } = await import('../../firebase/storage.ts');
                     finalUrl = await uploadFile(file, `status/${user.id}/${Date.now()}_${Math.random().toString(36).substring(7)}`);
                 } catch (error) {
                     console.error('Failed to upload media:', error);
                     alert('Failed to upload media. Please try again.');
                     return;
                 }
             }

             // Determine if it's video or image. Audio is treated as video for player.
             const isVideo = file?.type.startsWith('video') || file?.type.startsWith('audio') || activeTab === 'voice' || activeTab === 'video_gen';
             newItem = { 
                id: crypto.randomUUID(), 
                type: isVideo ? 'video' : 'image',
                url: finalUrl, 
                duration: 5,
                soundUrl: selectedSound?.url
              };
        } else { 
             newItem = { 
                id: crypto.randomUUID(), 
                type: 'text', 
                text: text.replace(/#/g, '%'), 
                backgroundColor: bgColor, 
                font, 
                duration: 5,
                soundUrl: selectedSound?.url
              };
        }

        const creatorRole = (user.role === 'vendor' || user.role === 'workman' || user.role === 'travel') 
            ? 'partner' 
            : (user.role === 'admin' ? 'admin' : 'user');

        const newStatus: GistStatus = {
            id: crypto.randomUUID(),
            creator: {
                id: user.id,
                name: user.fullName,
                avatarUrl: user.profileImageUrl,
                profileLink: `/user/${user.id}`,
                role: creatorRole,
                isVerified: user.isVerified
            },
            items: [newItem],
            timestamp: new Date().toISOString()
        };

        onPostCreated(newStatus); 
        onClose();
    };

    const handleBack = () => {
        if (step === 'edit') {
            setStep('select');
            setFile(null);
            setPreviewUrl(null);
            setText('');
        } else if (step === 'camera') {
            stopCamera();
            setStep('select');
        } else {
            onClose();
        }
    };

    return (
        <div className="fixed inset-0 z-[100] bg-black text-white flex flex-col animate-fade-in">
            {/* Header */}
            <header className="p-4 flex items-center justify-between bg-black/50 backdrop-blur-sm absolute top-0 w-full z-20">
                <button onClick={handleBack} className="p-2 rounded-full hover:bg-white/10">
                    {step === 'select' ? <XIcon className="w-6 h-6"/> : <ArrowLeftIcon className="w-6 h-6"/>}
                </button>
                {step === 'select' && (
                    <div className="flex gap-2 bg-black/30 rounded-full p-1 border border-white/10 overflow-x-auto scrollbar-hide max-w-[70vw]">
                         <button onClick={() => setActiveTab('media')} className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all whitespace-nowrap ${activeTab === 'media' ? 'bg-white text-black' : 'text-white/70 hover:text-white'}`}>Media</button>
                        <button onClick={() => setActiveTab('text')} className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all whitespace-nowrap ${activeTab === 'text' ? 'bg-white text-black' : 'text-white/70 hover:text-white'}`}>Text</button>
                        <button onClick={() => setActiveTab('voice')} className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all whitespace-nowrap ${activeTab === 'voice' ? 'bg-white text-black' : 'text-white/70 hover:text-white'}`}>Voice</button>
                        {user?.isVerified && (
                            <button onClick={() => setActiveTab('video_gen')} className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all whitespace-nowrap ${activeTab === 'video_gen' ? 'bg-brand-gold text-brand-navy-dark' : 'text-brand-gold hover:text-white'}`}>AI Video</button>
                        )}
                    </div>
                )}
                {step === 'edit' ? (
                    <Button size="sm" onClick={handlePost} disabled={isAnimating} className="!bg-brand-gold !text-black border-none font-bold">Post</Button>
                ) : (
                    <div className="w-10"></div>
                )}
            </header>

            {/* Content Area */}
            <main className="flex-1 relative flex flex-col items-center justify-center bg-gray-900">
                {step === 'select' ? (
                    <div className="w-full h-full flex flex-col items-center justify-center p-4">
                        {activeTab === 'media' ? (
                            <div className="grid grid-cols-2 gap-4 w-full max-w-sm">
                                <div 
                                    onClick={() => inputRef.current?.click()}
                                    className="aspect-[3/4] bg-white/5 border border-white/10 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:bg-white/10 transition-all group"
                                >
                                    <div className="p-4 bg-brand-gold/20 rounded-full mb-3 group-hover:scale-110 transition-transform">
                                        <PhotoIcon className="w-8 h-8 text-brand-gold"/>
                                    </div>
                                    <p className="text-sm font-medium">Upload</p>
                                    <input type="file" ref={inputRef} className="hidden" accept="image/*,video/*" onChange={handleFileSelect} />
                                </div>
                                <div 
                                    onClick={handleStartCamera}
                                    className="aspect-[3/4] bg-white/5 border border-white/10 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:bg-white/10 transition-all group"
                                >
                                    <div className="p-4 bg-brand-green/20 rounded-full mb-3 group-hover:scale-110 transition-transform">
                                        <CameraIcon className="w-8 h-8 text-brand-green"/>
                                    </div>
                                    <p className="text-sm font-medium">Camera</p>
                                </div>
                            </div>
                        ) : activeTab === 'text' ? (
                             <div className="w-full max-w-md flex flex-col gap-4">
                                <div 
                                    className="h-96 rounded-xl flex items-center justify-center p-8 text-center relative shadow-2xl border border-white/10 transition-colors duration-500"
                                    style={{ backgroundColor: bgColor }}
                                >
                                    <textarea 
                                        value={text}
                                        onChange={e => setText(e.target.value)}
                                        placeholder="Type something..."
                                        className="bg-transparent text-white text-3xl font-bold w-full h-full text-center resize-none focus:outline-none placeholder:text-white/50 relative z-10"
                                        style={{ fontFamily: font, textShadow: '0 2px 10px rgba(0,0,0,0.3)' }}
                                    />
                                    <button 
                                        onClick={handleMagicWrite}
                                        disabled={isMagicWriting}
                                        className="absolute bottom-4 right-4 p-2 bg-black/20 hover:bg-black/40 rounded-full z-20 backdrop-blur-sm border border-white/20 transition-all hover:scale-110"
                                        title="Magic Write"
                                    >
                                        {isMagicWriting ? <LoadingSpinner className="w-5 h-5 text-white"/> : <SparklesIcon className="w-5 h-5 text-yellow-300"/>}
                                    </button>
                                </div>
                                <Button onClick={handleTextSubmit} disabled={!text.trim()} className="w-full mt-2">Next</Button>
                            </div>
                        ) : activeTab === 'video_gen' ? (
                             <div className="w-full max-w-md flex flex-col gap-4">
                                <div className="bg-white/5 border border-white/10 rounded-xl p-6 text-center">
                                    <div className="w-16 h-16 bg-brand-gold/20 rounded-full flex items-center justify-center mx-auto mb-4">
                                        <FilmIcon className="w-8 h-8 text-brand-gold" />
                                    </div>
                                    <h3 className="text-xl font-bold text-brand-gold mb-2">AI Promo Video</h3>
                                    <p className="text-sm text-gray-400 mb-6">Generate a stunning promotional video for your product or service.</p>
                                    
                                    <textarea 
                                        value={videoPrompt}
                                        onChange={e => setVideoPrompt(e.target.value)}
                                        placeholder="Describe your product (e.g., 'A luxurious hand-woven Kente scarf fluttering in the wind on a sunny beach in Ghana')..."
                                        className="w-full bg-black/30 border border-white/20 rounded-lg p-4 text-white placeholder:text-gray-500 resize-none focus:outline-none focus:border-brand-gold mb-4"
                                        rows={4}
                                    />
                                    
                                    {videoError && <p className="text-red-500 text-xs mb-4">{videoError}</p>}
                                    
                                    <Button onClick={handleVideoGeneration} disabled={!videoPrompt.trim() || isGeneratingVideo} className="w-full flex items-center justify-center gap-2">
                                        {isGeneratingVideo ? (
                                            <>
                                                <LoadingSpinner className="w-4 h-4" /> Generating...
                                            </>
                                        ) : (
                                            <>
                                                <SparklesIcon className="w-5 h-5" /> Generate Video
                                            </>
                                        )}
                                    </Button>
                                    <p className="text-[10px] text-gray-500 mt-2">Powered by Gemini Veo</p>
                                </div>
                             </div>
                        ) : (
                            // Voice Mode
                            <div className="w-full h-full flex flex-col items-center justify-center">
                                <div className="relative">
                                    {isRecordingAudio && <div className="absolute inset-0 bg-brand-gold rounded-full animate-ping opacity-75"></div>}
                                    <button
                                        onClick={isRecordingAudio ? stopAudioRecording : startAudioRecording}
                                        className={`relative z-10 p-8 rounded-full transition-all duration-300 ${isRecordingAudio ? 'bg-red-600 scale-110' : 'bg-white text-brand-navy-dark hover:bg-gray-100'}`}
                                    >
                                        {isRecordingAudio ? <StopIcon className="w-10 h-10 text-white" /> : <MicrophoneIcon className="w-10 h-10" />}
                                    </button>
                                </div>
                                <p className="mt-6 text-lg font-mono">{isRecordingAudio ? `Recording... ${recordingTimer}s` : 'Tap to Record'}</p>
                            </div>
                        )}
                    </div>
                ) : step === 'camera' ? (
                     <div className="w-full h-full bg-black relative flex flex-col">
                        <video ref={videoRef} className="w-full h-full object-cover transform scale-x-[-1]" autoPlay playsInline muted />
                        
                        <div className="absolute top-20 left-1/2 transform -translate-x-1/2 bg-black/50 px-3 py-1 rounded-full backdrop-blur-md">
                            <p className="text-white text-xs font-mono">{isRecordingVideo ? `00:${recordingTimer < 10 ? '0'+recordingTimer : recordingTimer}` : 'Ready'}</p>
                        </div>

                        <div className="absolute bottom-8 inset-x-0 flex flex-col items-center gap-4">
                            {/* Mode Switcher */}
                            <div className="flex gap-6 text-sm font-bold uppercase tracking-widest mb-2">
                                <button onClick={() => setCameraMode('photo')} className={`transition-colors ${cameraMode === 'photo' ? 'text-brand-gold' : 'text-white/50'}`}>Photo</button>
                                <button onClick={() => setCameraMode('video')} className={`transition-colors ${cameraMode === 'video' ? 'text-brand-gold' : 'text-white/50'}`}>Video</button>
                            </div>
                            
                            <button 
                                onClick={handleCapture} 
                                className={`w-20 h-20 rounded-full border-4 border-white transition-all duration-300 flex items-center justify-center ${
                                    cameraMode === 'video' && isRecordingVideo 
                                    ? 'bg-red-600 scale-110' 
                                    : 'bg-white/20 hover:bg-white/40'
                                }`}
                            >
                                {cameraMode === 'video' && isRecordingVideo && <div className="w-8 h-8 bg-white rounded-sm"></div>}
                                {cameraMode === 'video' && !isRecordingVideo && <div className="w-16 h-16 bg-red-500 rounded-full border-2 border-black"></div>}
                            </button>
                        </div>
                    </div>
                ) : (
                    // Edit/Preview Step
                    <div className="relative w-full h-full bg-black flex items-center justify-center">
                         {activeTab !== 'text' && previewUrl && (
                             file?.type.startsWith('video') || file?.type.startsWith('audio') || activeTab === 'video_gen' || activeTab === 'voice' ? (
                                <div className="w-full h-full flex flex-col items-center justify-center bg-gray-900">
                                    {/* Use video player for both video and audio files in preview for controls */}
                                    <video 
                                        src={previewUrl} 
                                        controls 
                                        autoPlay 
                                        className="max-w-full max-h-[80vh]" 
                                        poster={file?.type.startsWith('audio') ? 'https://via.placeholder.com/400x400.png?text=Audio+Record' : undefined}
                                    />
                                    {file?.type.startsWith('audio') && <p className="mt-4 text-brand-gold font-mono">Voice Note</p>}
                                </div>
                             ) : (
                                <img src={previewUrl} alt="Preview" className="max-w-full max-h-full object-contain" />
                             )
                         )}
                         
                         {activeTab === 'text' && (
                             <div className="w-full h-full flex items-center justify-center p-8 text-center relative" style={{ backgroundColor: bgColor }}>
                                <p className="text-4xl font-bold text-white break-words" style={{ fontFamily: font }}>{text.replace(/#/g, '%')}</p>
                            </div>
                         )}
                         
                         <div className="absolute right-4 top-20 flex flex-col gap-4 z-20">
                             <button onClick={() => setShowSoundPicker(true)} className="flex flex-col items-center gap-1 text-white group">
                                <div className="w-10 h-10 bg-black/40 backdrop-blur-md rounded-full flex items-center justify-center border border-white/10 group-hover:bg-brand-gold group-hover:text-black transition-colors">
                                    <MusicNoteIcon className="w-5 h-5" />
                                </div>
                                <span className="text-[10px] font-medium shadow-black drop-shadow-md">Sound</span>
                            </button>
                        </div>
                        
                        {/* Sound Picker Sheet */}
                        {showSoundPicker && (
                            <div className="absolute inset-x-0 bottom-0 top-1/3 z-30 bg-gray-900/95 backdrop-blur-xl flex flex-col animate-slide-up rounded-t-3xl shadow-[0_-10px_40px_rgba(0,0,0,0.5)]">
                                <div className="p-4 flex items-center gap-3 border-b border-white/10 relative">
                                    <SparklesIcon className="w-5 h-5 text-brand-gold"/>
                                    <h3 className="text-white font-bold flex-1">Viral Global Sounds</h3>
                                    <button onClick={() => {
                                        setShowSoundPicker(false);
                                        document.querySelectorAll('audio').forEach(a => a.pause());
                                    }} className="text-white bg-white/10 p-2 rounded-full hover:bg-white/20 transition-colors">
                                        <XIcon className="w-4 h-4"/>
                                    </button>
                                </div>
                                <div className="p-3 border-b border-white/10">
                                    <input 
                                        type="text" 
                                        placeholder="Search global sounds..." 
                                        onChange={(e) => {
                                            const value = e.target.value.toLowerCase();
                                            const items = document.querySelectorAll('.studio-sound-item');
                                            items.forEach(item => {
                                                const text = item.textContent?.toLowerCase() || '';
                                                if (text.includes(value)) {
                                                    (item as HTMLElement).style.display = 'flex';
                                                } else {
                                                    (item as HTMLElement).style.display = 'none';
                                                }
                                            });
                                        }}
                                        className="bg-black/50 border border-white/10 rounded-full px-4 py-2 text-white w-full outline-none placeholder:text-gray-500 text-sm focus:border-brand-gold transition-colors" 
                                    />
                                </div>
                                <div className="flex-1 overflow-y-auto p-2">
                                    {mockSounds.map(sound => (
                                        <div key={sound.id} className="studio-sound-item flex items-center justify-between p-3 hover:bg-white/10 rounded-xl group transition-colors">
                                            <div className="flex items-center gap-4 flex-1 cursor-pointer" onClick={() => { 
                                                setSelectedSound(sound); 
                                                setShowSoundPicker(false); 
                                                document.querySelectorAll('audio').forEach(a => a.pause());
                                            }}>
                                                <div className="w-10 h-10 bg-brand-gold/20 rounded-lg flex items-center justify-center text-brand-gold relative overflow-hidden">
                                                    <MusicNoteIcon className="w-5 h-5 absolute" />
                                                </div>
                                                <div className="flex-1">
                                                    <p className="text-white font-bold text-sm truncate max-w-[200px]">{sound.title}</p>
                                                    <p className="text-gray-400 text-xs truncate">{sound.artist}</p>
                                                </div>
                                                {selectedSound?.id === sound.id && <SparklesIcon className="w-5 h-5 text-brand-gold" />}
                                            </div>
                                            <button 
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    const audioEl = document.getElementById(`studio-audio-${sound.id}`) as HTMLAudioElement;
                                                    if (audioEl) {
                                                        if (audioEl.paused) {
                                                            document.querySelectorAll('audio').forEach(a => a.pause());
                                                            audioEl.play();
                                                        } else {
                                                            audioEl.pause();
                                                        }
                                                    }
                                                }}
                                                className="w-8 h-8 rounded-full border border-white/20 flex items-center justify-center text-white hover:bg-white/20 hover:text-brand-gold transition-colors z-10 ml-4"
                                            >
                                                <PlayIcon className="w-4 h-4" />
                                                <audio id={`studio-audio-${sound.id}`} src={sound.url} loop={false} />
                                            </button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                )}
            </main>
        </div>
    );
};

export default GistCreatorStudio;
