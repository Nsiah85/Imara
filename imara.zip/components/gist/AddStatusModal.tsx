
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { XIcon, ArrowUpTrayIcon, MicrophoneIcon, PlayIcon, TrashIcon, MusicNoteIcon, CameraIcon, SparklesIcon, ChevronDownIcon, CheckIcon, SearchIcon, CheckCircleIcon, StickerIcon, CropIcon } from '../icons/Icons';
import Button from '../ui/Button';
import { mockSounds } from '../../data/mockData';
import { useAuth } from '../../contexts/AuthContext';
import type { GistStatus, GistStatusItem } from '../../types';
import FilterSelector, { FilterType } from './FilterSelector';

interface AddStatusModalProps {
  onClose: () => void;
  onAddStatus: (status: GistStatus) => void;
}

const gradients = [
    { name: 'Midnight', value: 'linear-gradient(180deg, #0A2342 0%, #000000 100%)' },
    { name: 'Imara Gold', value: 'linear-gradient(45deg, #FFD700, #FF8C00)' },
    { name: 'Forest', value: 'linear-gradient(to bottom right, #00A550, #004d40)' },
    { name: 'Afro Punk', value: 'linear-gradient(to right, #ec4899, #8b5cf6)' },
    { name: 'Savanna', value: 'linear-gradient(120deg, #f6d365 0%, #fda085 100%)' },
    { name: 'Oceanic', value: 'linear-gradient(to top, #30cfd0 0%, #330867 100%)' },
    { name: 'Royal', value: 'linear-gradient(to top, #5f72bd 0%, #9b23ea 100%)' }
];

const fonts = ['Inter', 'Poppins', 'Lobster', 'Caveat', 'Playfair Display', 'Oswald', 'Pacifico'];

const templates = [
    { name: 'Motivation', text: 'Believe in your hustle. 💪 #MondayMotivation', bgIndex: 3 },
    { name: 'Culture', text: 'Celebrating our heritage today. 🌍✨', bgIndex: 2 },
    { name: 'Business', text: 'New stock alert! Check the shop. 🛍️', bgIndex: 1 },
    { name: 'Vibe', text: 'Current Mood 🎵', bgIndex: 5 }
];

const AddStatusModal: React.FC<AddStatusModalProps> = ({ onClose, onAddStatus }) => {
    const { user } = useAuth();
    const [mode, setMode] = useState<'media' | 'text'>('text');
    const [subMode, setSubMode] = useState<'none' | 'text' | 'stickers'>('none');
    const [file, setFile] = useState<File | null>(null);
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);
    const [selectedFilter, setSelectedFilter] = useState<FilterType>('none');
    const [isClosing, setIsClosing] = useState(false);

    // Text Status State
    const [text, setText] = useState('');
    const [overlayText, setOverlayText] = useState('');
    const [activeGradient, setActiveGradient] = useState(gradients[0].value);
    const [font, setFont] = useState(fonts[1]);
    const [showTemplates, setShowTemplates] = useState(false);
    const [hasSticker, setHasSticker] = useState(false);

    // Sound State
    const [showSoundPicker, setShowSoundPicker] = useState(false);
    const [selectedSound, setSelectedSound] = useState<{id: string, title: string, url: string} | null>(null);
    
    const fileInputRef = useRef<HTMLInputElement>(null);

    const close = useCallback(() => {
        setIsClosing(true);
        setTimeout(onClose, 300);
    }, [onClose]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => { if (e.key === 'Escape') close(); };
        document.addEventListener('keydown', handleKeyDown);
        return () => document.removeEventListener('keydown', handleKeyDown);
    }, [close]);

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            setFile(file);
            setPreviewUrl(URL.createObjectURL(file));
            setMode('media');
            setSubMode('none');
        }
    };

    const handleTemplateSelect = (template: typeof templates[0]) => {
        setText(template.text);
        setActiveGradient(gradients[template.bgIndex].value);
        setShowTemplates(false);
    };

    const handleSubmit = async () => {
        if (!user) return;

        let newItem: GistStatusItem;

        if (mode === 'media' && file && previewUrl) {
             let downloadUrl = previewUrl;
             try {
                 const { uploadFile } = await import('../../firebase/storage.ts');
                 downloadUrl = await uploadFile(file, `status/${user.id}/${Date.now()}_${Math.random().toString(36).substring(7)}`);
             } catch (error) {
                 console.error('Failed to upload status media:', error);
                 alert('Failed to upload media. Please try again.');
                 return;
             }

             const isVideo = file.type.startsWith('video');
             newItem = {
                id: crypto.randomUUID(),
                type: isVideo ? 'video' : 'image',
                url: downloadUrl,
                duration: isVideo ? 10 : 5,
                soundUrl: selectedSound?.url,
            };
        } else if (mode === 'text' && text.trim()) {
            newItem = {
                id: crypto.randomUUID(),
                type: 'text',
                text: text.trim(),
                backgroundColor: '#000',
                gradient: activeGradient,
                font: font,
                duration: 5,
                soundUrl: selectedSound?.url
            };
        } else {
            return; 
        }

        const creatorRole = (user.role === 'vendor' || user.role === 'workman' || user.role === 'travel') 
            ? 'partner' 
            : (user.role === 'admin' ? 'admin' : 'user');

        const newStatus: GistStatus = {
            id: crypto.randomUUID(),
            creator: {
                id: user.id,
                name: user.fullName,
                avatarUrl: user.profileImageUrl,
                profileLink: `/user/${user.id}`,
                role: creatorRole,
                isVerified: user.isVerified
            },
            items: [newItem],
            timestamp: new Date().toISOString()
        };

        onAddStatus(newStatus);
        close();
    };

    const modalAnimation = isClosing ? 'translate-y-full opacity-0' : 'translate-y-0 opacity-100';
    
    const getFilterStyle = (filter: FilterType) => {
        switch (filter) {
            case 'sepia': return { filter: 'sepia(0.8) contrast(1.2)' };
            case 'grayscale': return { filter: 'grayscale(1) contrast(1.2)' };
            case 'contrast': return { filter: 'contrast(1.5) saturate(1.2)' };
            case 'warm': return { filter: 'sepia(0.3) saturate(1.4)' };
            case 'cool': return { filter: 'hue-rotate(180deg) sepia(0.2)' };
            default: return {};
        }
    };

    return (
        <div className="fixed inset-0 z-[150] bg-black flex justify-center items-center overflow-hidden">
            {/* Mobile-First Container */}
            <div className={`relative w-full h-full md:w-[450px] md:h-[800px] md:max-h-[90vh] md:rounded-3xl bg-black overflow-hidden shadow-2xl transition-all duration-300 ${modalAnimation} flex flex-col`}>
                
                {/* Background Render */}
                <div 
                    className="absolute inset-0 z-0 transition-colors duration-500" 
                    style={{ background: mode === 'text' ? activeGradient : '#000' }}
                >
                    {mode === 'media' && previewUrl && (
                        file?.type.startsWith('video') 
                            ? <video src={previewUrl} className="w-full h-full object-cover" autoPlay loop muted />
                            : <img src={previewUrl} className="w-full h-full object-cover" alt="Preview" style={getFilterStyle(selectedFilter)} />
                    )}
                    
                     {/* Overlay Text Preview */}
                    {overlayText && mode === 'media' && (
                        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-white text-xl font-bold bg-black/50 px-4 py-2 rounded-lg text-center cursor-move">
                            {overlayText}
                        </div>
                    )}
                    
                     {/* Sticker Preview */}
                     {hasSticker && mode === 'media' && (
                        <div className="absolute bottom-20 right-10 text-4xl cursor-move transform hover:scale-110 transition-transform">
                            🔥
                        </div>
                    )}
                </div>

                {/* Header Controls */}
                <div className="relative z-10 flex justify-between items-start p-6 pt-8 md:pt-6">
                    <button onClick={close} className="p-2 bg-black/20 backdrop-blur-md rounded-full text-white hover:bg-white/20 transition-colors">
                        <XIcon className="w-6 h-6" />
                    </button>

                    <div className="flex flex-col gap-4">
                         <button 
                            onClick={() => { setMode(mode === 'text' ? 'media' : 'text'); setFile(null); setPreviewUrl(null); }} 
                            className="w-10 h-10 bg-black/20 backdrop-blur-md rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-colors"
                            title={mode === 'text' ? "Switch to Media" : "Switch to Text"}
                        >
                            {mode === 'text' ? <CameraIcon className="w-6 h-6" /> : <span className="font-display font-bold text-lg">Aa</span>}
                        </button>
                        <button 
                            onClick={() => setShowSoundPicker(true)} 
                            className={`w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-md transition-colors ${selectedSound ? 'bg-brand-gold text-brand-navy-dark' : 'bg-black/20 text-white hover:bg-white/20'}`}
                        >
                            <MusicNoteIcon className="w-5 h-5" />
                        </button>
                        {mode === 'text' && (
                            <button 
                                onClick={() => setShowTemplates(!showTemplates)} 
                                className={`w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-md transition-colors ${showTemplates ? 'bg-white text-black' : 'bg-black/20 text-white hover:bg-white/20'}`}
                                title="Templates"
                            >
                                <SparklesIcon className="w-5 h-5" />
                            </button>
                        )}
                        {/* Media Mode Specific Controls */}
                        {mode === 'media' && previewUrl && (
                             <>
                                <button onClick={() => setSubMode(subMode === 'text' ? 'none' : 'text')} className={`w-10 h-10 bg-black/20 backdrop-blur-md rounded-full flex items-center justify-center hover:bg-white/20 transition-colors ${subMode === 'text' ? 'text-brand-gold' : 'text-white'}`}><span className="font-bold text-lg">T</span></button>
                                <button onClick={() => setSubMode(subMode === 'stickers' ? 'none' : 'stickers')} className={`w-10 h-10 bg-black/20 backdrop-blur-md rounded-full flex items-center justify-center hover:bg-white/20 transition-colors ${subMode === 'stickers' ? 'text-brand-gold' : 'text-white'}`}><StickerIcon className="w-5 h-5"/></button>
                             </>
                        )}
                    </div>
                </div>

                {/* Main Content Input */}
                <div className="relative z-10 flex-1 flex items-center justify-center p-8 overflow-y-auto">
                    {mode === 'text' ? (
                         <textarea 
                            value={text}
                            onChange={e => setText(e.target.value)}
                            placeholder="Type something..."
                            className="w-full h-full bg-transparent text-center text-4xl font-bold text-white placeholder:text-white/50 resize-none focus:outline-none"
                            style={{ fontFamily: font, textShadow: '0 2px 10px rgba(0,0,0,0.3)' }}
                            autoFocus
                        />
                    ) : (
                        !previewUrl && (
                            <div 
                                onClick={() => fileInputRef.current?.click()}
                                className="flex flex-col items-center justify-center p-8 border-2 border-dashed border-white/30 rounded-2xl cursor-pointer hover:bg-white/10 transition-colors"
                            >
                                <ArrowUpTrayIcon className="w-12 h-12 text-white mb-4" />
                                <p className="text-white font-bold">Upload Media</p>
                            </div>
                        )
                    )}
                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*,video/*" onChange={handleFileSelect} />
                </div>
                
                {/* Submode Controls for Media */}
                 {mode === 'media' && previewUrl && subMode === 'text' && (
                    <div className="relative z-20 px-6 pb-4">
                         <input 
                            type="text" 
                            value={overlayText} 
                            onChange={(e) => setOverlayText(e.target.value)} 
                            placeholder="Add overlay text..." 
                            className="w-full p-2 rounded border bg-white/20 border-white/30 text-white placeholder:text-white/60 backdrop-blur-sm"
                            autoFocus
                        />
                    </div>
                )}
                
                {mode === 'media' && previewUrl && subMode === 'stickers' && (
                     <div className="relative z-20 px-6 pb-4 flex gap-4 overflow-x-auto">
                        {['🔥', '✨', '🌍', '🛒', '🎉'].map(emoji => (
                            <button key={emoji} onClick={() => setHasSticker(true)} className="text-3xl hover:scale-125 transition-transform">{emoji}</button>
                        ))}
                    </div>
                )}
                
                {/* Filter Selector for Images */}
                {mode === 'media' && previewUrl && !file?.type.startsWith('video') && subMode === 'none' && (
                     <div className="relative z-20 px-6 pb-4">
                        <FilterSelector selectedFilter={selectedFilter} onSelect={setSelectedFilter} previewUrl={previewUrl} />
                     </div>
                )}

                {/* Bottom Controls */}
                <div className="relative z-10 px-6 pb-8 md:pb-6 flex flex-col gap-6">
                    {mode === 'text' && (
                        <div className="space-y-4">
                            <div className="flex gap-4 overflow-x-auto scrollbar-hide justify-center">
                                {fonts.map(f => (
                                    <button key={f} onClick={() => setFont(f)} className={`w-8 h-8 rounded-full border flex items-center justify-center font-bold text-xs transition-all ${font === f ? 'bg-white text-black scale-110 border-white' : 'bg-black/40 text-white border-white/30'}`} style={{ fontFamily: f }}>Aa</button>
                                ))}
                            </div>
                            <div className="flex gap-3 overflow-x-auto scrollbar-hide justify-center">
                                {gradients.map((g, i) => (
                                    <button key={i} onClick={() => setActiveGradient(g.value)} className={`w-6 h-6 rounded-full border-2 transition-all ${activeGradient === g.value ? 'border-white scale-125' : 'border-transparent opacity-70'}`} style={{ background: g.value }} />
                                ))}
                            </div>
                        </div>
                    )}
                    
                    {/* Templates Overlay */}
                    {showTemplates && mode === 'text' && (
                        <div className="flex gap-3 overflow-x-auto scrollbar-hide">
                            {templates.map(t => (
                                <button key={t.name} onClick={() => handleTemplateSelect(t)} className="px-4 py-2 bg-white/20 backdrop-blur-md rounded-full text-white text-xs font-bold hover:bg-white/30 whitespace-nowrap border border-white/10">{t.name}</button>
                            ))}
                        </div>
                    )}

                    {/* Post Button */}
                    <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2 bg-black/30 px-3 py-1 rounded-full">
                            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                            <span className="text-[10px] text-white font-bold uppercase tracking-wider">Your Story</span>
                        </div>
                        <Button 
                            onClick={handleSubmit} 
                            disabled={(mode === 'text' && !text.trim()) || (mode === 'media' && !previewUrl)} 
                            className="!bg-brand-gold !text-brand-navy-dark rounded-full px-8 font-bold shadow-lg hover:scale-105 transition-transform disabled:opacity-50 disabled:hover:scale-100 flex items-center gap-2"
                        >
                            Share <ArrowUpTrayIcon className="w-4 h-4 transform rotate-90" />
                        </Button>
                    </div>
                </div>

                 {/* Sound Picker */}
                 {showSoundPicker && (
                    <div className="absolute inset-0 z-30 bg-gray-900/95 backdrop-blur-xl flex flex-col animate-slide-up">
                        <div className="p-4 flex items-center gap-3 border-b border-white/10">
                             <SearchIcon className="w-5 h-5 text-gray-400"/>
                             <input 
                                type="text" 
                                placeholder="Search global sounds..." 
                                onChange={(e) => {
                                    // Normally this would query an API. For now, filter mockSounds based on search.
                                    // Just adding the visual capability of searching global sounds.
                                    const value = e.target.value.toLowerCase();
                                    const items = document.querySelectorAll('.sound-item');
                                    items.forEach(item => {
                                        const text = item.textContent?.toLowerCase() || '';
                                        if (text.includes(value)) {
                                            (item as HTMLElement).style.display = 'flex';
                                        } else {
                                            (item as HTMLElement).style.display = 'none';
                                        }
                                    });
                                }}
                                className="bg-transparent text-white w-full outline-none placeholder:text-gray-500" 
                                autoFocus 
                             />
                             <button onClick={() => {
                                 setShowSoundPicker(false);
                                 // Stop any playing sound
                                 document.querySelectorAll('audio').forEach(a => a.pause());
                             }} className="text-white font-bold text-sm">Cancel</button>
                        </div>
                        <div className="flex-1 overflow-y-auto p-2">
                             <div className="text-xs text-brand-gold font-bold px-3 py-2 uppercase tracking-wider bg-black/20 sticky top-0 backdrop-blur-md z-10 flex items-center gap-2">
                                 <SparklesIcon className="w-4 h-4"/> Viral Global Sounds
                             </div>
                            {mockSounds.map(sound => (
                                <div key={sound.id} className="sound-item flex items-center justify-between p-3 hover:bg-white/10 rounded-xl group transition-colors">
                                    <div className="flex items-center gap-4 flex-1 cursor-pointer" onClick={() => { 
                                        setSelectedSound(sound); 
                                        setShowSoundPicker(false); 
                                        document.querySelectorAll('audio').forEach(a => a.pause());
                                    }}>
                                        <div className="w-10 h-10 bg-brand-gold/20 rounded-lg flex items-center justify-center text-brand-gold relative overflow-hidden">
                                            <MusicNoteIcon className="w-5 h-5 absolute" />
                                        </div>
                                        <div className="flex-1">
                                            <p className="text-white font-bold text-sm truncate max-w-[200px]">{sound.title}</p>
                                            <p className="text-gray-400 text-xs truncate">{sound.artist}</p>
                                        </div>
                                    </div>
                                    <button 
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            const audioEl = document.getElementById(`audio-${sound.id}`) as HTMLAudioElement;
                                            if (audioEl) {
                                                if (audioEl.paused) {
                                                    document.querySelectorAll('audio').forEach(a => a.pause());
                                                    audioEl.play();
                                                } else {
                                                    audioEl.pause();
                                                }
                                            }
                                        }}
                                        className="w-8 h-8 rounded-full border border-white/20 flex items-center justify-center text-white hover:bg-white/20 hover:text-brand-gold transition-colors z-10"
                                    >
                                        <PlayIcon className="w-4 h-4" />
                                        <audio id={`audio-${sound.id}`} src={sound.url} loop={false} />
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default AddStatusModal;
