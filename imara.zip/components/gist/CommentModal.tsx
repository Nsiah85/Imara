
import React, { useState, useEffect, useCallback } from 'react';
import type { GistPost, GistComment, ImaraGift } from '../../types';
import { useLanguage } from '../../contexts/LanguageContext';
import { XIcon, PaperAirplaneIcon, ChatBubbleIcon, GiftIcon } from '../icons/Icons.tsx';
import Button from '../ui/Button';
import Avatar from '../ui/Avatar.tsx';
import { useAuth } from '../../contexts/AuthContext.tsx';
import GiftPicker from './GiftPicker.tsx';
import { useMonetization } from '../../contexts/MonetizationContext.tsx';

interface CommentModalProps {
  post: GistPost;
  onClose: () => void;
  onAddComment: (postId: string, text: string) => void;
}

const CommentItem: React.FC<{ comment: GistComment; depth?: number; onReply?: (authorName: string) => void }> = ({ comment, depth = 0, onReply }) => (
    <div className={`animate-fade-in ${depth > 0 ? 'ml-8 border-l-2 border-gray-100 dark:border-gray-700 pl-3' : ''}`}>
        <div className="flex items-start gap-3">
            <Avatar 
                imageUrl={comment.author.avatarUrl}
                name={comment.author.name}
                className="w-8 h-8 rounded-full object-cover flex-shrink-0"
                textClassName="text-sm font-bold text-white"
            />
            <div className="flex-grow">
                <div className="bg-brand-off-white dark:bg-gray-700 p-3 rounded-2xl rounded-tl-none">
                    <p className="font-bold text-sm text-brand-navy-dark dark:text-white">{comment.author.name}</p>
                    <p className="text-sm text-gray-800 dark:text-gray-300 whitespace-pre-wrap">{comment.text}</p>
                </div>
                <div className="flex items-center gap-3 mt-1 pl-1">
                    <p className="text-xs text-gray-500 dark:text-gray-400">{comment.timestamp}</p>
                    {depth < 2 && onReply && (
                        <button onClick={() => onReply(comment.author.name)} className="text-xs font-semibold text-gray-500 hover:text-brand-gold dark:text-gray-400 dark:hover:text-brand-gold transition-colors">
                            Reply
                        </button>
                    )}
                </div>
            </div>
        </div>
        {comment.replies && comment.replies.length > 0 && (
            <div className="mt-3 space-y-3">
                {comment.replies.map(reply => (
                    <CommentItem key={reply.id} comment={reply} depth={depth + 1} onReply={onReply} />
                ))}
            </div>
        )}
    </div>
);


const CommentModal: React.FC<CommentModalProps> = ({ post, onClose, onAddComment }) => {
    const { t } = useLanguage();
    const { profile, redeemPoints } = useMonetization();
    const [newComment, setNewComment] = useState('');
    const [replyTo, setReplyTo] = useState<string | null>(null);
    const [showGiftPicker, setShowGiftPicker] = useState(false);
    const inputRef = React.useRef<HTMLInputElement>(null);

    const comments = post.comments;

    const close = useCallback(() => {
        setTimeout(onClose, 300);
    }, [onClose]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => { if (e.key === 'Escape') close(); };
        document.addEventListener('keydown', handleKeyDown);
        document.body.style.overflow = 'hidden';
        return () => {
            document.removeEventListener('keydown', handleKeyDown);
            document.body.style.overflow = 'auto';
        };
    }, [close]);

    const handleReply = (authorName: string) => {
        setReplyTo(authorName);
        setNewComment(`@${authorName} `);
        inputRef.current?.focus();
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (newComment.trim()) {
            onAddComment(post.id, newComment.trim());
            setNewComment('');
            setReplyTo(null);
            setShowGiftPicker(false);
        }
    };
    
    const handleGiftSelect = async (gift: ImaraGift) => {
        const success = await redeemPoints(gift.cost, 'shop');
        if (success) {
            const giftText = ` [Sent ${gift.iconUrl} ${gift.name}]`;
            onAddComment(post.id, (newComment + giftText).trim());
            setNewComment('');
            setShowGiftPicker(false);
        } else {
            alert("Insufficient Torts (Tts) to send this gift.");
        }
    };

    return (
        <div
            className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 opacity-100"
            onClick={close} role="dialog" aria-modal="true"
        >
            <div
                className="relative bg-white dark:bg-gray-800 rounded-2xl shadow-xl w-full max-w-lg h-[80vh] flex flex-col transition-all duration-300 scale-100"
                onClick={(e) => e.stopPropagation()}
            >
                <header className="p-4 border-b dark:border-gray-700 text-center relative flex-shrink-0">
                    <h2 className="text-lg font-bold text-brand-navy-dark dark:text-white">{t('toast.commentsTitle')} ({comments.length})</h2>
                    <button onClick={close} className="absolute top-1/2 -translate-y-1/2 right-4 p-2 text-gray-500 hover:text-black dark:text-gray-400 dark:hover:text-white">
                        <XIcon className="w-5 h-5" />
                    </button>
                </header>

                <main className="flex-grow p-4 overflow-y-auto space-y-6 custom-scrollbar relative">
                    {comments.length > 0 ? (
                        comments.map(comment => <CommentItem key={comment.id} comment={comment} onReply={handleReply} />)
                    ) : (
                        <div className="h-full flex flex-col items-center justify-center text-gray-500 dark:text-gray-400">
                            <ChatBubbleIcon className="w-12 h-12 mb-2 opacity-20" />
                            <p>No comments yet.</p>
                            <p className="text-sm mt-1">Start the conversation!</p>
                        </div>
                    )}
                    
                    {showGiftPicker && (
                        <div className="absolute bottom-2 left-4 right-4 z-10 bg-white dark:bg-gray-900 rounded-xl shadow-2xl border border-brand-gold">
                            <div className="flex justify-between items-center p-2 border-b dark:border-gray-700">
                                <span className="text-xs font-bold dark:text-white">Value Signals (Gifts)</span>
                                <button onClick={() => setShowGiftPicker(false)}><XIcon className="w-4 h-4"/></button>
                            </div>
                            <GiftPicker onSelect={handleGiftSelect} userBalance={profile.torts} />
                        </div>
                    )}
                </main>

                <footer className="p-4 border-t dark:border-gray-700 bg-gray-50 dark:bg-gray-900 rounded-b-2xl flex-shrink-0">
                    {replyTo && (
                        <div className="flex items-center justify-between text-xs text-gray-500 mb-2 px-2">
                            <span>Replying to <span className="font-bold">{replyTo}</span></span>
                            <button onClick={() => { setReplyTo(null); setNewComment(''); }} className="hover:text-red-500">Cancel</button>
                        </div>
                    )}
                    <form onSubmit={handleSubmit} className="flex items-center gap-3">
                        <button 
                            type="button" 
                            onClick={() => setShowGiftPicker(!showGiftPicker)} 
                            className="p-2 text-brand-gold hover:bg-brand-gold/10 rounded-full transition-colors"
                            title="Send a Gift"
                        >
                            <GiftIcon className="w-6 h-6" />
                        </button>
                        <input
                            ref={inputRef}
                            type="text"
                            value={newComment}
                            onChange={(e) => setNewComment(e.target.value)}
                            placeholder={replyTo ? "Write a reply..." : "Add a comment..."}
                            className="flex-1 p-3 border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white rounded-full focus:ring-2 focus:ring-brand-gold focus:border-brand-gold shadow-sm"
                            autoFocus={!showGiftPicker}
                        />
                        <Button type="submit" className="rounded-full !p-3" disabled={!newComment.trim()}>
                            <PaperAirplaneIcon className="w-5 h-5" />
                        </Button>
                    </form>
                </footer>
            </div>
        </div>
    );
};

export default CommentModal;
