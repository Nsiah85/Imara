
import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { GistPost, Product, TravelService, ImaraGift, AdminLiveEventSettings } from '../../types';
import { XIcon, HeartIcon, SolidHeartIcon, ChatBubbleIcon, ShareIcon, BookmarkIcon, SolidBookmarkIcon, ChartBarIcon, ChatBubbleBottomCenterTextIcon, VerifiedBadgeIcon, PlayIcon, PauseIcon, GiftIcon, RemixIcon, ArrowUpTrayIcon, HomeIcon, UserIcon, EnvelopeIcon, VideoCameraIcon, DocumentTextIcon, EllipsisVerticalIcon } from '../icons/Icons';
import Avatar from '../ui/Avatar';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import GiftPicker from './GiftPicker';
import { useMonetization } from '../../contexts/MonetizationContext';
import { PollCard, QnACard, GiftCelebrationCard } from './GistPostCard';
import Button from '../ui/Button';
import ImaraOutro from '../ui/ImaraOutro';
import { downloadMediaWithWatermark } from '../../utils/downloadHelper';

interface TheaterModalProps {
  posts: GistPost[];
  startIndex: number;
  onClose: () => void;
  onAddToCart: (item: Product | TravelService) => void;
  onBookService: (serviceId: string) => void;
  onDonateNow: (causeId: string) => void;
  onLearnMore: () => void;
}

const TheaterPost: React.FC<{
    post: GistPost;
    isActive: boolean;
    onClose: () => void;
    onAddToCart: any;
    onBookService: any;
    onDonateNow: any;
    onLearnMore: any;
    toggleLike: (id: string) => void;
    toggleSave: (id: string) => void;
    handleShare: (id: string) => void;
    handleSendGift: (gift: ImaraGift) => void;
    setShowGiftPicker: (show: boolean) => void;
    isLiked: boolean;
    isSaved: boolean;
    showControls: boolean;
    setShowControls: (show: boolean) => void;
    checkAuth: () => boolean;
}> = ({ post, isActive, onClose, toggleLike, toggleSave, handleShare, setShowGiftPicker, isLiked, isSaved, showControls, setShowControls, checkAuth }) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [showOutro, setShowOutro] = useState(false);
    const { content } = post;
    const [showMoreMenu, setShowMoreMenu] = useState(false);
    const [isExpanded, setIsExpanded] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        if (isActive) {
            const timer = setTimeout(() => {
                if (content.videoUrl && videoRef.current) {
                    videoRef.current.currentTime = 0;
                    videoRef.current.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
                }
                setShowControls(true);
            }, 300);
            return () => clearTimeout(timer);
        } else {
            if (videoRef.current) {
                videoRef.current.pause();
                setIsPlaying(false);
            }
            setShowOutro(false);
            setShowMoreMenu(false);
            setIsExpanded(false); // Reset expansion on scroll away
        }
    }, [isActive, content.videoUrl]);

    const handleVideoEnded = () => {
        setShowOutro(true);
        setTimeout(() => {
            setShowOutro(false);
            if (videoRef.current && isActive) {
                videoRef.current.currentTime = 0;
                videoRef.current.play();
                setIsPlaying(true);
            }
        }, 3000);
    };

    const togglePlay = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (content.videoUrl && videoRef.current) {
            if (isPlaying) {
                videoRef.current.pause();
                setIsPlaying(false);
                setShowControls(true);
            } else {
                videoRef.current.play();
                setIsPlaying(true);
                setShowControls(false);
            }
        } else {
            setShowControls(!showControls);
        }
    };
    
    const handleDownload = () => {
        if (!checkAuth()) return;
        const mediaUrl = content.videoUrl || content.imageUrl;
        const type = content.videoUrl ? 'video' : 'image';
        if (mediaUrl) {
            downloadMediaWithWatermark(mediaUrl, type, post.creator.name);
            setShowMoreMenu(false);
        }
    };

    const handleProfileClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (checkAuth()) {
            onClose();
            navigate(post.creator.profileLink);
        }
    }

    const renderContent = () => {
        if (content.type === 'quote') {
            return (
                <div className="w-full h-full flex items-center justify-center p-8 text-center"
                    style={{ backgroundColor: content.backgroundColor || '#000', fontFamily: content.fontFamily }}>
                     <div className="max-w-2xl transform scale-110">
                        <p className="text-3xl md:text-5xl font-bold text-white">"{content.text}"</p>
                        {content.quoteAuthor && <p className="mt-8 text-xl opacity-80 text-white">- {content.quoteAuthor}</p>}
                     </div>
                </div>
            );
        }
        if (content.type === 'poll' && content.pollOptions) {
             return (
                <div className="w-full h-full flex items-center justify-center p-4 bg-brand-navy-dark">
                    <div className="w-full max-w-md">
                         <h3 className="text-2xl font-bold text-white mb-8 text-center">{content.text}</h3>
                         <PollCard options={content.pollOptions} duration={content.pollDuration} />
                    </div>
                </div>
             );
        }
        if (content.type === 'q&a' && content.question) {
            return (
                <div className="w-full h-full flex items-center justify-center p-4 bg-black">
                    <div className="w-full max-w-md transform scale-125">
                        <QnACard question={content.question} creatorName={post.creator.name} />
                    </div>
                </div>
            );
        }
        if (content.type === 'gift_celebration' && content.giftData) {
            return (
                 <div className="w-full h-full flex items-center justify-center p-4 bg-black">
                    <GiftCelebrationCard {...content.giftData} />
                </div>
            );
        }
        if (content.type === 'document') {
            return (
                <div className="w-full h-full flex items-center justify-center p-8 bg-gray-900">
                    <div className="text-center text-white">
                        <DocumentTextIcon className="w-24 h-24 mx-auto text-brand-gold mb-4" />
                        <h3 className="text-2xl font-bold">{content.documentName || 'Document'}</h3>
                        <Button variant="outline" className="mt-4 !text-white !border-white hover:!bg-white hover:!text-black">Read Document</Button>
                    </div>
                </div>
            );
        }
        if (content.videoUrl) {
            return (
                <div className="w-full h-full relative bg-black flex items-center justify-center">
                    <video 
                        ref={videoRef}
                        src={content.videoUrl} 
                        className="max-w-full max-h-full object-contain" 
                        loop={false}
                        playsInline
                        onEnded={handleVideoEnded}
                    />
                    {showOutro && <ImaraOutro />}
                    {!isPlaying && !showOutro && (
                        <div className="absolute inset-0 flex items-center justify-center bg-black/20 pointer-events-none">
                            <PlayIcon className="w-20 h-20 text-white/80"/>
                        </div>
                    )}
                </div>
            );
        }
        if (content.imageUrl) {
            return <img src={content.imageUrl} className="w-full h-full object-contain bg-black" alt="Content" />;
        }
        if (content.text) {
            return (
                <div className="w-full h-full flex items-center justify-center p-8 text-center bg-brand-navy-dark relative">
                    <p className="text-2xl md:text-4xl text-white font-medium leading-relaxed z-10 max-w-3xl">{content.text}</p>
                </div>
            );
        }
        return <div className="w-full h-full bg-black"></div>;
    };

    const formatTextWithTags = (text: string) => {
        const words = text.split(' ');
        return words.map((word, idx) => {
             if (word.startsWith('%') || word.startsWith('#')) {
                 // Replace # with % if needed visually, but user prompt said "Hashtags should be % as Imara system not #"
                 const displayTag = word.startsWith('#') ? '%' + word.substring(1) : word;
                 return <span key={idx} className="font-bold text-brand-gold hover:text-brand-green transition-colors cursor-pointer">{displayTag} </span>;
             }
             return <span key={idx}>{word} </span>;
        });
    };

    const captionLimit = 100; // Characters
    const shouldTruncate = content.text && content.text.length > captionLimit;
    const displayText = isExpanded || !shouldTruncate ? content.text : content.text?.substring(0, captionLimit) + '...';

    return (
        <div className="h-[100dvh] w-full snap-center relative flex items-center justify-center bg-black overflow-hidden" onClick={togglePlay}>
            {renderContent()}

            {/* Post Info Overlay */}
            <div className={`absolute left-4 bottom-24 max-w-[70%] z-20 transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
                <button onClick={handleProfileClick} className="text-left flex items-center gap-1">
                    <h3 className="font-bold text-lg mb-1 shadow-black drop-shadow-md hover:underline text-white">@{post.creator.name}</h3>
                    {post.creator.isVerified && <VerifiedBadgeIcon className="w-4 h-4 text-brand-gold drop-shadow-md" />}
                </button>
                
                {content.text && (
                    <div className="text-sm text-white/90 shadow-black drop-shadow-md mb-2">
                        <p className="inline">{formatTextWithTags(displayText)}</p>
                        {shouldTruncate && (
                            <button 
                                onClick={(e) => { e.stopPropagation(); setIsExpanded(!isExpanded); }} 
                                className="text-brand-gold font-bold ml-1 hover:underline"
                            >
                                {isExpanded ? 'less' : 'more'}
                            </button>
                        )}
                    </div>
                )}
                
                <div className="flex gap-2 flex-wrap">
                    {post.tags.map(tag => <span key={tag} className="text-xs font-bold text-brand-gold hover:text-brand-green transition-colors cursor-pointer">{tag.startsWith('#') ? '%' + tag.substring(1) : tag}</span>)}
                </div>
            </div>

            {/* Sidebar Actions */}
            <div className={`absolute right-2 bottom-24 flex flex-col items-center gap-6 z-30 transition-transform duration-300 ${showControls ? 'translate-x-0' : 'translate-x-20'}`}>
                 <button onClick={handleProfileClick} title="View Profile">
                    <div className="relative mb-2">
                        <Avatar imageUrl={post.creator.avatarUrl} name={post.creator.name} className="w-12 h-12 rounded-full border-2 border-white" textClassName="text-lg font-bold"/>
                        <div className="absolute -bottom-1.5 left-1/2 transform -translate-x-1/2 bg-red-500 rounded-full w-5 h-5 flex items-center justify-center shadow-sm border-2 border-white">
                            <span className="text-white text-xs font-bold">+</span>
                        </div>
                    </div>
                </button>

                <div className="flex flex-col items-center gap-1" title="Like">
                        <button className="p-2 bg-black/20 backdrop-blur-sm rounded-full hover:bg-white/20 transition-all" onClick={(e) => { e.stopPropagation(); toggleLike(post.id); }}>
                        {isLiked ? <SolidHeartIcon className="w-8 h-8 text-brand-green drop-shadow-lg" /> : <HeartIcon className="w-8 h-8 text-white drop-shadow-lg" />}
                    </button>
                    <span className="text-[10px] font-bold shadow-black drop-shadow-md text-white">{post.engagement.likes}</span>
                </div>

                <div className="flex flex-col items-center gap-1" title="Comment">
                    <button className="p-2 bg-black/20 backdrop-blur-sm rounded-full hover:bg-white/20 transition-all" onClick={(e) => { e.stopPropagation(); if(checkAuth()) {/* open comments */} }}>
                        <ChatBubbleIcon className="w-8 h-8 text-white drop-shadow-lg" />
                    </button>
                    <span className="text-[10px] font-bold shadow-black drop-shadow-md text-white">{post.engagement.commentsCount}</span>
                </div>

                 <div className="flex flex-col items-center gap-1" title="Send Gift">
                    <button className="p-2 bg-black/20 backdrop-blur-sm rounded-full hover:bg-white/20 transition-all" onClick={(e) => { e.stopPropagation(); if(checkAuth()) setShowGiftPicker(true); }}>
                        <GiftIcon className="w-8 h-8 text-brand-gold drop-shadow-lg animate-pulse" />
                    </button>
                    <span className="text-[10px] font-bold shadow-black drop-shadow-md text-white">Gift</span>
                </div>

                <div className="relative flex flex-col items-center gap-1" title="More Options">
                    <button 
                        className={`p-2 backdrop-blur-sm rounded-full transition-all ${showMoreMenu ? 'bg-white/30' : 'bg-black/20 hover:bg-white/20'}`}
                        onClick={(e) => { e.stopPropagation(); setShowMoreMenu(!showMoreMenu); }}
                    >
                        <EllipsisVerticalIcon className="w-8 h-8 text-white drop-shadow-lg" />
                    </button>
                    <span className="text-[10px] font-bold shadow-black drop-shadow-md text-white">More</span>

                    {/* More Menu */}
                    {showMoreMenu && (
                        <div className="absolute bottom-full right-0 mb-2 flex flex-col gap-3 bg-black/80 backdrop-blur-md p-3 rounded-2xl animate-fade-in-up border border-white/10 w-14 items-center">
                            <button onClick={(e) => { e.stopPropagation(); toggleSave(post.id); setShowMoreMenu(false); }} className="p-2 hover:bg-white/20 rounded-full" title="Save">
                                    {isSaved ? <SolidBookmarkIcon className="w-6 h-6 text-brand-gold"/> : <BookmarkIcon className="w-6 h-6 text-white"/>}
                            </button>
                            <button onClick={(e) => { e.stopPropagation(); handleShare(post.id); setShowMoreMenu(false); }} className="p-2 hover:bg-white/20 rounded-full" title="Share">
                                <ShareIcon className="w-6 h-6 text-white"/>
                            </button>
                            {(content.imageUrl || content.videoUrl) && (
                                <button onClick={(e) => { e.stopPropagation(); handleDownload(); }} className="p-2 hover:bg-white/20 rounded-full" title="Download with Tag">
                                    <ArrowUpTrayIcon className="w-6 h-6 text-white transform rotate-180"/>
                                </button>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const TheaterModal: React.FC<TheaterModalProps> = ({ posts, startIndex, onClose }) => {
    const { user } = useAuth();
    const { profile, redeemPoints } = useMonetization();
    const navigate = useNavigate();
    const containerRef = useRef<HTMLDivElement>(null);
    const [activeIndex, setActiveIndex] = useState(startIndex);
    
    // UI State
    const [showControls, setShowControls] = useState(true);
    const [showGiftPicker, setShowGiftPicker] = useState(false);
    const [isLiveActive, setIsLiveActive] = useState(false);

    // Interaction State
    const [likedPosts, setLikedPosts] = useState<Set<string>>(new Set(posts.filter(p => p.likedByMe).map(p => p.id)));
    const [savedPosts, setSavedPosts] = useState<Set<string>>(new Set(user?.savedPostIds));

    // Apply Theater Mode Class to Body
    useEffect(() => {
        document.body.classList.add('theater-mode');
        return () => {
            document.body.classList.remove('theater-mode');
        };
    }, []);

    // Scroll to start index on mount
    useEffect(() => {
        if (containerRef.current) {
            const startEl = containerRef.current.children[startIndex] as HTMLElement;
            if (startEl) startEl.scrollIntoView({ behavior: 'auto' });
        }
    }, [startIndex]);

    // Detect active slide
    const handleScroll = useCallback(() => {
        if (containerRef.current) {
            const index = Math.round(containerRef.current.scrollTop / window.innerHeight);
            if (index !== activeIndex && index >= 0 && index < posts.length) {
                setActiveIndex(index);
            }
        }
    }, [activeIndex, posts.length]);

    useEffect(() => {
        const container = containerRef.current;
        if (container) {
            container.addEventListener('scroll', handleScroll);
            return () => container.removeEventListener('scroll', handleScroll);
        }
    }, [handleScroll]);

    useEffect(() => {
        try {
            const storedLiveEvent = localStorage.getItem('imara_live_event');
            if (storedLiveEvent) {
                const event: AdminLiveEventSettings = JSON.parse(storedLiveEvent);
                const endTime = new Date(event.startTime).getTime() + event.durationMinutes * 60 * 1000;
                if (event.isActive && Date.now() < endTime) {
                    setIsLiveActive(true);
                }
            }
        } catch (e) { console.error(e); }
    }, []);
    
    const checkAuth = () => {
        if (!user) {
            onClose();
            navigate('/login');
            return false;
        }
        return true;
    };

    const toggleLike = (postId: string) => {
        if (!checkAuth()) return;
        setLikedPosts(prev => {
            const newSet = new Set(prev);
            if (newSet.has(postId)) newSet.delete(postId);
            else newSet.add(postId);
            return newSet;
        });
    };

    const toggleSave = (postId: string) => {
        if (!checkAuth()) return;
        setSavedPosts(prev => {
            const newSet = new Set(prev);
            if (newSet.has(postId)) newSet.delete(postId);
            else newSet.add(postId);
            return newSet;
        });
    };
    
    const handleShare = (postId: string) => {
        if (!checkAuth()) return;
        alert("Shared!");
    };

    const handleSendGift = async (gift: ImaraGift) => {
        if (!user) return;
        const success = await redeemPoints(gift.cost, 'shop');
        if (success) {
            alert(`Sent ${gift.name}!`);
            setShowGiftPicker(false);
        } else {
            alert("Insufficient Torts.");
        }
    };

    const handleNavigate = (path: string) => {
        if (!checkAuth()) return;
        onClose();
        navigate(path);
    };

    const handleLiveClick = () => {
        if (isLiveActive) {
            handleNavigate('/live/stream_1');
        }
    };

    if (posts.length === 0) return null;

    return (
        <div className="fixed inset-0 z-[100] bg-black flex flex-col">
             {/* Collapsible Header */}
             <div className={`absolute top-0 left-0 right-0 z-40 transition-transform duration-300 ${showControls ? 'translate-y-0' : '-translate-y-full'}`}>
                <div className="bg-gradient-to-b from-black/80 to-transparent pt-safe px-4 pb-8 flex justify-center items-center gap-8 text-sm font-semibold text-white/70">
                    <button onClick={() => handleNavigate('/discover')} className="hover:text-white hover:scale-110 transition-all">Discover</button>
                    <button onClick={() => handleNavigate('/shop-hub')} className="hover:text-white hover:scale-110 transition-all">ShopHub</button>
                    
                    {/* For You Toggle - Only visible/active for authenticated users */}
                    {user ? (
                        <span className="text-white font-bold border-b-2 border-white pb-1 cursor-pointer">For You</span>
                    ) : (
                        <span className="text-white/30 cursor-not-allowed" title="Login to see personalized content">For You</span>
                    )}
                    
                    <button onClick={() => handleNavigate('/invest')} className="hover:text-white hover:scale-110 transition-all">Impact</button>
                </div>
                <button onClick={onClose} className="absolute top-6 left-4 p-2 bg-white/10 backdrop-blur-md rounded-full hover:bg-white/20">
                    <XIcon className="w-6 h-6 text-white"/>
                </button>
            </div>

            {/* Main Feed Area */}
            <div 
                ref={containerRef}
                className="flex-1 h-[100dvh] w-full overflow-y-scroll snap-y snap-mandatory scrollbar-hide"
                style={{ scrollBehavior: 'smooth' }}
            >
                {posts.map((post, index) => (
                    <TheaterPost 
                        key={post.id} 
                        post={post} 
                        isActive={index === activeIndex} 
                        onClose={onClose}
                        onAddToCart={() => {}}
                        onBookService={() => {}}
                        onDonateNow={() => {}}
                        onLearnMore={() => {}}
                        toggleLike={toggleLike}
                        toggleSave={toggleSave}
                        handleShare={handleShare}
                        handleSendGift={handleSendGift}
                        setShowGiftPicker={setShowGiftPicker}
                        isLiked={likedPosts.has(post.id)}
                        isSaved={savedPosts.has(post.id)}
                        showControls={showControls}
                        setShowControls={setShowControls}
                        checkAuth={checkAuth}
                    />
                ))}
            </div>

             {/* Collapsible Footer */}
             <div className={`absolute bottom-0 left-0 right-0 z-40 bg-brand-navy-dark/80 backdrop-blur-md border-t border-white/10 transition-transform duration-300 ${showControls ? 'translate-y-0' : 'translate-y-full'}`}>
                <div className="flex justify-around items-center py-3 pb-safe">
                    <button onClick={() => handleNavigate('/')} className="flex flex-col items-center gap-1 text-white/60 hover:text-brand-gold">
                        <HomeIcon className="w-6 h-6"/>
                        <span className="text-[10px]">Home</span>
                    </button>
                    
                    <button 
                        onClick={handleLiveClick} 
                        className={`flex flex-col items-center gap-1 transition-colors ${isLiveActive ? 'text-red-500 animate-pulse cursor-pointer' : 'text-white/20 cursor-not-allowed'}`}
                        disabled={!isLiveActive}
                    >
                        <VideoCameraIcon className="w-6 h-6"/>
                        <span className="text-[10px] font-bold">{isLiveActive ? 'LIVE' : 'Live'}</span>
                    </button>
                    
                    <button onClick={onClose} className="relative -top-5 bg-gradient-to-r from-brand-green to-brand-green-dark p-1 rounded-full shadow-lg border-4 border-brand-navy-dark transform hover:scale-105 transition-transform">
                        <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                           <div className="text-brand-navy-dark font-black text-xl">+</div>
                        </div>
                    </button>
                    
                    <button onClick={() => handleNavigate('/messages')} className="flex flex-col items-center gap-1 text-white/60 hover:text-brand-gold">
                        <EnvelopeIcon className="w-6 h-6"/>
                        <span className="text-[10px]">Chat</span>
                    </button>
                    <button onClick={() => handleNavigate('/account')} className="flex flex-col items-center gap-1 text-white/60 hover:text-brand-gold">
                        <UserIcon className="w-6 h-6"/>
                        <span className="text-[10px]">Account</span>
                    </button>
                </div>
            </div>

            {/* Gift Picker Overlay */}
            {showGiftPicker && (
                <div className="absolute bottom-0 left-0 right-0 bg-white dark:bg-gray-900 rounded-t-2xl z-50 animate-slide-up max-h-[50vh] overflow-hidden pb-safe">
                    <div className="flex justify-between items-center p-4 border-b dark:border-gray-700">
                        <h3 className="font-bold text-black dark:text-white">Send a Gift</h3>
                        <button onClick={() => setShowGiftPicker(false)} className="text-gray-500"><XIcon className="w-5 h-5"/></button>
                    </div>
                    <GiftPicker onSelect={handleSendGift} userBalance={profile.points} />
                </div>
            )}
        </div>
    );
};

export default TheaterModal;
