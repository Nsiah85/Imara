

import React from 'react';
import Button from '../ui/Button.tsx';
import { UserCircleIcon, PhotoIcon, BanknotesIcon, BookOpenIcon, ArrowRightIcon } from '../icons/Icons.tsx';

interface OnboardingStepProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  buttonText: string;
  onClick: () => void;
}

const OnboardingStep: React.FC<OnboardingStepProps> = ({ icon, title, description, buttonText, onClick }) => (
  <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm flex flex-col sm:flex-row items-start sm:items-center gap-6">
    <div className="flex-shrink-0 w-12 h-12 bg-brand-gold/10 text-brand-gold rounded-full flex items-center justify-center">
      {icon}
    </div>
    <div className="flex-grow">
      <h3 className="font-display font-bold text-lg text-brand-green-dark dark:text-white">{title}</h3>
      <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">{description}</p>
    </div>
    <Button variant="outline" onClick={onClick} className="w-full sm:w-auto mt-4 sm:mt-0">{buttonText}</Button>
  </div>
);

interface WorkmanOnboardingGuideProps {
    workmanName: string;
    onComplete: () => void;
    onGoToProfile: () => void;
    onAddPortfolio: () => void;
    onConfigurePayouts: () => void;
    onReadPolicies: () => void;
}

const WorkmanOnboardingGuide: React.FC<WorkmanOnboardingGuideProps> = ({ 
    workmanName, 
    onComplete,
    onGoToProfile,
    onAddPortfolio,
    onConfigurePayouts,
    onReadPolicies
}) => {
    const steps = [
        {
            icon: <UserCircleIcon className="w-7 h-7" />,
            title: "Complete Your Professional Profile",
            description: "Add your role, skills, and rates to attract clients.",
            buttonText: "Edit Profile",
            onClick: onGoToProfile,
        },
        {
            icon: <PhotoIcon className="w-7 h-7" />,
            title: "Showcase Your Work",
            description: "Upload images of your past projects to build your portfolio.",
            buttonText: "Add Portfolio",
            onClick: onAddPortfolio,
        },
        {
            icon: <BanknotesIcon className="w-7 h-7" />,
            title: "Set Up Payouts",
            description: "Connect your account to receive your earnings securely.",
            buttonText: "Configure Payouts",
            onClick: onConfigurePayouts,
        },
        {
            icon: <BookOpenIcon className="w-7 h-7" />,
            title: "Review Platform Policies",
            description: "Familiarize yourself with our community and service guidelines.",
            buttonText: "Read Policies",
            onClick: onReadPolicies,
        }
    ];

    return (
        <div className="bg-brand-off-white/80 dark:bg-gray-900/50 p-8 rounded-lg w-full max-w-4xl mx-auto">
            <div className="text-center">
                <h2 className="text-3xl font-display font-bold text-brand-green-dark dark:text-white">Akwaaba, {workmanName}!</h2>
                <p className="mt-2 text-gray-700 dark:text-gray-300 max-w-2xl mx-auto">Let's get your profile ready to connect with clients on the marketplace.</p>
            </div>
            
            <div className="mt-10 space-y-6">
                {steps.map(step => (
                    <OnboardingStep key={step.title} {...step} />
                ))}
            </div>

            <div className="mt-10 text-center">
                <Button size="lg" onClick={onComplete} className="flex items-center gap-2 mx-auto">
                    <span>Finish Setup</span>
                    <ArrowRightIcon className="w-5 h-5" />
                </Button>
            </div>
        </div>
    );
};

export default WorkmanOnboardingGuide;