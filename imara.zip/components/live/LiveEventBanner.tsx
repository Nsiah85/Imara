import React, { useState, useEffect } from 'react';
import type { AdminLiveEventSettings } from '../../types';

interface LiveEventBannerProps {
  event: AdminLiveEventSettings;
}

const LiveEventBanner: React.FC<LiveEventBannerProps> = ({ event }) => {
    const [timeLeft, setTimeLeft] = useState('');

    useEffect(() => {
        const calculateTimeLeft = () => {
            const endTime = new Date(event.startTime).getTime() + event.durationMinutes * 60 * 1000;
            const now = Date.now();
            const difference = endTime - now;

            if (difference > 0) {
                const hours = Math.floor((difference / (1000 * 60 * 60)) % 24);
                const minutes = Math.floor((difference / 1000 / 60) % 60);
                const seconds = Math.floor((difference / 1000) % 60);
                setTimeLeft(
                    `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`
                );
            } else {
                setTimeLeft('Event Ended');
            }
        };

        const timer = setInterval(calculateTimeLeft, 1000);
        calculateTimeLeft(); // Initial call

        return () => clearInterval(timer);
    }, [event]);

    return (
        <div className="bg-gradient-to-r from-brand-gold to-brand-emerald text-center py-2 px-4">
            <p className="text-sm font-bold text-brand-navy-dark animate-pulse">
                {event.bannerText} | Ends in: {timeLeft}
            </p>
        </div>
    );
};

export default LiveEventBanner;