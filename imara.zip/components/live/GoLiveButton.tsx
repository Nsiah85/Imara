import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';

const GoLiveButton: React.FC = () => {
    const { user } = useAuth();
    const isPartner = user && (user.role === 'admin'); // Simplified partner check for demo

    const linkTo = isPartner ? '/live/start' : '/live/event_1'; // Example stream ID

    return (
        <div className="fixed bottom-20 sm:bottom-6 right-1/2 translate-x-1/2 sm:right-24 sm:translate-x-0 z-40">
            <Link to={linkTo}>
                <button className="relative flex items-center justify-center w-36 h-12 bg-gradient-to-r from-red-500 to-orange-500 text-white font-bold rounded-full shadow-lg transform hover:scale-105 transition-transform">
                    <span className="absolute h-full w-full rounded-full bg-red-500 animate-ping opacity-75"></span>
                    <span className="relative z-10">GO LIVE</span>
                </button>
            </Link>
        </div>
    );
};

export default GoLiveButton;