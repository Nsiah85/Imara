import React, { useState, useRef, useEffect } from 'react';
import type { LiveComment } from '../../types';
import { PaperAirplaneIcon } from '../icons/Icons';
import Avatar from '../ui/Avatar';

interface LiveCommentFeedProps {
    comments: LiveComment[];
    onAddComment: (text: string) => void;
}

const LiveCommentFeed: React.FC<LiveCommentFeedProps> = ({ comments, onAddComment }) => {
    const [newComment, setNewComment] = useState('');
    const feedRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (feedRef.current) {
            feedRef.current.scrollTop = feedRef.current.scrollHeight;
        }
    }, [comments]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (newComment.trim()) {
            onAddComment(newComment.trim());
            setNewComment('');
        }
    };

    return (
        <div className="flex flex-col h-full">
            <h2 className="text-lg font-bold p-4 border-b border-white/10 flex-shrink-0">Live Chat</h2>
            <div ref={feedRef} className="flex-1 p-4 overflow-y-auto space-y-4">
                {comments.map((comment) => (
                    <div key={comment.id} className="flex items-start gap-2 text-sm">
                        <Avatar 
                            imageUrl={comment.authorAvatar}
                            name={comment.authorName}
                            id={comment.authorName} // Use name as ID for unique color
                            className="w-6 h-6 rounded-full flex-shrink-0"
                            textClassName="text-xs font-bold text-white"
                        />
                        <div>
                            <span className="font-bold text-gray-300">{comment.authorName}</span>
                            <p>{comment.text}</p>
                        </div>
                    </div>
                ))}
            </div>
            <div className="p-4 border-t border-white/10 flex-shrink-0">
                <form onSubmit={handleSubmit} className="flex items-center gap-2">
                    <input
                        type="text"
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        placeholder="Say something..."
                        className="flex-1 p-2 bg-white/10 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold"
                    />
                    <button type="submit" className="p-2 rounded-full bg-brand-gold text-brand-navy-dark" aria-label="Send comment">
                        <PaperAirplaneIcon className="w-5 h-5" />
                    </button>
                </form>
            </div>
        </div>
    );
};

export default LiveCommentFeed;