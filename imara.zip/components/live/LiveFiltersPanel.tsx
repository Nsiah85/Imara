import React from 'react';

const filtersList = [
    { name: 'None', css: { brightness: 100, contrast: 100 } },
    { name: 'Vintage', css: { brightness: 110, contrast: 90, sepia: 30 } },
    { name: 'Noir', css: { brightness: 100, contrast: 120, grayscale: 100 } },
    { name: 'Vibrant', css: { brightness: 110, contrast: 110, saturate: 130 } },
];

const overlaysList = [
    { name: 'None', url: '' },
    { name: 'Pattern 1', url: 'https://www.clipartmax.com/png/middle/2-21110_african-pattern-png.png' },
    { name: 'Pattern 2', url: 'https://www.pngkey.com/png/full/4-44223_african-patterns-png-african-patterns-transparent.png' },
];

interface LiveFiltersPanelProps {
    currentFilters: any;
    setFilters: React.Dispatch<React.SetStateAction<any>>;
}

const LiveFiltersPanel: React.FC<LiveFiltersPanelProps> = ({ currentFilters, setFilters }) => {
    
    const applyFilter = (filter: any) => {
        setFilters(prev => ({
            ...prev,
            brightness: filter.css.brightness || 100,
            contrast: filter.css.contrast || 100,
        }));
    };

    const applyOverlay = (overlayUrl: string) => {
        setFilters(prev => ({ ...prev, overlay: overlayUrl }));
    };

    return (
        <div>
            <p className="text-sm font-bold text-gray-300 mb-2">Filters & Effects</p>
            <div className="flex gap-2">
                {filtersList.map(f => (
                    <button key={f.name} onClick={() => applyFilter(f)} className="px-3 py-1 text-xs bg-white/10 rounded-full hover:bg-white/20">{f.name}</button>
                ))}
            </div>
            <div className="flex gap-2 mt-2">
                 {overlaysList.map(o => (
                    <button key={o.name} onClick={() => applyOverlay(o.url)} className={`px-3 py-1 text-xs rounded-full ${currentFilters.overlay === o.url ? 'bg-brand-gold text-brand-navy-dark' : 'bg-white/10 hover:bg-white/20'}`}>{o.name}</button>
                ))}
            </div>
        </div>
    );
};

export default LiveFiltersPanel;