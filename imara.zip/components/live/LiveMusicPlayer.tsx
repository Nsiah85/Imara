
import React, { useState, useRef } from 'react';
import { PlayIcon, PauseIcon } from '../icons/Icons';

interface Track {
    title: string;
    artist: string;
    url: string;
}

interface LiveMusicPlayerProps {
    tracks: Track[];
}

const LiveMusicPlayer: React.FC<LiveMusicPlayerProps> = ({ tracks }) => {
    const [isPlaying, setIsPlaying] = useState(false);
    const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
    const audioRef = useRef<HTMLAudioElement>(null);

    const currentTrack = tracks[currentTrackIndex];

    const togglePlayPause = () => {
        if (isPlaying) {
            audioRef.current?.pause();
        } else {
            audioRef.current?.play().catch(e => {
                if (e.name !== 'AbortError') {
                    console.error("Audio play failed", e);
                }
            });
        }
        setIsPlaying(!isPlaying);
    };

    const playNext = () => {
        const nextIndex = (currentTrackIndex + 1) % tracks.length;
        setCurrentTrackIndex(nextIndex);
        if (isPlaying) {
            // Need a slight delay to allow the new src to load
            setTimeout(() => {
                audioRef.current?.play().catch(e => {
                    if (e.name !== 'AbortError') {
                        console.error("Audio play failed", e);
                    }
                });
            }, 50);
        }
    };
    
    return (
        <div>
            <p className="text-sm font-bold text-gray-300">Background Music</p>
            <div className="flex items-center gap-3 mt-2">
                <audio ref={audioRef} src={currentTrack.url} onEnded={playNext} />
                <button onClick={togglePlayPause} className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                    {isPlaying ? <PauseIcon className="w-5 h-5" /> : <PlayIcon className="w-5 h-5" />}
                </button>
                <div className="text-sm">
                    <p className="font-semibold truncate">{currentTrack.title}</p>
                    <p className="text-xs text-gray-400 truncate">{currentTrack.artist}</p>
                </div>
            </div>
        </div>
    );
};

export default LiveMusicPlayer;
