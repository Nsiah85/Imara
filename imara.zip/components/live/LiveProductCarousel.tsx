import React, { useState } from 'react';
import type { Product } from '../../types';
import { useCurrency } from '../../contexts/CurrencyContext';
import Button from '../ui/Button';

interface LiveProductCarouselProps {
    products: Product[];
    onAddToCart: (product: Product) => void;
}

const LiveProductCarousel: React.FC<LiveProductCarouselProps> = ({ products, onAddToCart }) => {
    const { formatCurrency } = useCurrency();
    const [addedProductId, setAddedProductId] = useState<string | null>(null);

    const handleAddToCart = (product: Product) => {
        onAddToCart(product);
        setAddedProductId(product.id);
        setTimeout(() => setAddedProductId(null), 2000);
    };

    return (
        <div className="bg-black/50 backdrop-blur-md p-3 rounded-lg">
            <h3 className="text-sm font-bold mb-2 text-brand-gold-light">Featured Products</h3>
            <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
                {products.map(product => (
                    <div key={product.id} className="bg-white/10 rounded-lg p-2 w-36 flex-shrink-0 flex flex-col">
                        <img src={product.imageUrl} alt={product.name} className="w-full h-20 object-cover rounded-md" />
                        <div className="mt-2 flex-grow">
                            <p className="text-xs font-semibold truncate">{product.name}</p>
                            <p className="text-xs text-gray-300">{formatCurrency(product.price)}</p>
                        </div>
                        <Button 
                            size="sm" 
                            variant="primary"
                            className="mt-2 w-full !text-xs !py-1"
                            onClick={() => handleAddToCart(product)}
                            disabled={addedProductId === product.id}
                        >
                            {addedProductId === product.id ? 'Added!' : 'Add to Cart'}
                        </Button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default LiveProductCarousel;