import React, { useState } from 'react';

const gifts = ['❤️', '🔥', '✨', '💎', '👑', '🎉'];

interface FloatingGift {
    id: number;
    emoji: string;
    style: React.CSSProperties;
}

const EmojiGiftTray: React.FC = () => {
    const [floatingGifts, setFloatingGifts] = useState<FloatingGift[]>([]);

    const sendGift = (emoji: string) => {
        const newGift: FloatingGift = {
            id: Date.now() + Math.random(),
            emoji,
            style: {
                left: `${Math.random() * 80 + 10}%`,
                animation: `float-up ${Math.random() * 2 + 3}s linear forwards`,
            }
        };
        setFloatingGifts(prev => [...prev, newGift]);

        // Clean up old gifts
        setTimeout(() => {
            setFloatingGifts(prev => prev.filter(g => g.id !== newGift.id));
        }, 5000);
    };

    return (
        <>
            <style>{`
                @keyframes float-up {
                    0% { bottom: 5%; opacity: 1; transform: scale(1); }
                    100% { bottom: 90%; opacity: 0; transform: scale(1.5); }
                }
            `}</style>

            <div className="absolute bottom-20 right-4 flex flex-col gap-3 z-20">
                {gifts.map(emoji => (
                    <button
                        key={emoji}
                        onClick={() => sendGift(emoji)}
                        className="w-12 h-12 rounded-full bg-black/50 text-3xl flex items-center justify-center transition-transform hover:scale-110"
                    >
                        {emoji}
                    </button>
                ))}
            </div>

            <div className="absolute inset-0 pointer-events-none overflow-hidden">
                {floatingGifts.map(gift => (
                    <div
                        key={gift.id}
                        className="absolute text-4xl"
                        style={gift.style}
                    >
                        {gift.emoji}
                    </div>
                ))}
            </div>
        </>
    );
};

export default EmojiGiftTray;