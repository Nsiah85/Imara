
import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import type { Conversation, DirectConversation, GroupConversation } from '../../types.ts';
import { SearchIcon, PlusCircleIcon, EllipsisHorizontalIcon, LockClosedIcon, UserGroupIcon } from '../icons/Icons.tsx';
import Avatar from '../ui/Avatar.tsx';

interface ConversationListProps {
    conversations: Conversation[];
    activeConversationId?: string;
    onNewMessage: () => void;
    onCreateGroup: () => void;
    onDeleteConversation: (id: string) => void;
}

const ConversationList: React.FC<ConversationListProps> = ({ conversations, activeConversationId, onNewMessage, onCreateGroup, onDeleteConversation }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [openMenuId, setOpenMenuId] = useState<string | null>(null);

    const filteredConversations = useMemo(() => {
        let sorted = [...conversations];
        
        // Sort by Pinned first, then by timestamp (mock logic assumes array order is roughly chronological or fixed)
        sorted.sort((a, b) => {
            if (a.isPinned && !b.isPinned) return -1;
            if (!a.isPinned && b.isPinned) return 1;
            return 0;
        });

        if (!searchTerm) return sorted;
        const lowerTerm = searchTerm.toLowerCase();
        return sorted.filter(conv => {
            const name = conv.type === 'direct' ? conv.participant.name : conv.groupName;
            const matchesName = name.toLowerCase().includes(lowerTerm);
            const matchesMessage = conv.messages.some(msg => msg.content.type === 'text' && msg.content.text.toLowerCase().includes(lowerTerm));
            return matchesName || matchesMessage;
        });
    }, [conversations, searchTerm]);

    // Active Users / Contacts for top scroll
    // Prioritize Monkix AI and System accounts in the bubbles if they exist
    const activeContacts = conversations.map(c => c.type === 'direct' ? c.participant : null).filter(Boolean).slice(0, 8);

    const getMessagePreview = (conversation: Conversation) => {
        if (conversation.messages.length === 0) return "No messages yet.";
        const lastMessage = conversation.messages[conversation.messages.length - 1];
        const prefix = lastMessage.senderId === 'currentUser' ? 'You: ' : '';
        
        switch (lastMessage.content.type) {
            case 'text': return `${prefix}${lastMessage.content.text}`;
            case 'image': return `${prefix}Sent an image`;
            case 'voice': return `${prefix}Sent a voice message`;
            default: return `${prefix}Sent an attachment`;
        }
    };
    
    const handleAction = (e: React.MouseEvent, action: string, id: string) => {
        e.preventDefault();
        e.stopPropagation();
        setOpenMenuId(null);
        
        if (action === 'delete') {
            onDeleteConversation(id);
        } else {
            console.log(`Action ${action} triggered for ${id}`);
        }
    };

    return (
        <div className="flex flex-col h-full bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700" onClick={() => setOpenMenuId(null)}>
            {/* Horizontal Scroll for Active Contacts */}
            <div className="p-4 pb-2 border-b border-gray-100 dark:border-gray-700">
                 <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">My Contacts</div>
                <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-2 items-start">
                    <button onClick={onNewMessage} className="flex flex-col items-center gap-1.5 min-w-[64px] group">
                         <div className="w-14 h-14 rounded-full bg-gray-50 dark:bg-gray-700 flex items-center justify-center text-gray-400 group-hover:text-brand-gold group-hover:bg-brand-off-white transition-all border-2 border-dashed border-gray-300 dark:border-gray-600 group-hover:border-brand-gold">
                             <PlusCircleIcon className="w-6 h-6" />
                         </div>
                         <span className="text-xs font-medium text-gray-600 dark:text-gray-300 group-hover:text-brand-gold transition-colors">Direct</span>
                    </button>
                    <button onClick={onCreateGroup} className="flex flex-col items-center gap-1.5 min-w-[64px] group">
                         <div className="w-14 h-14 rounded-full bg-gray-50 dark:bg-gray-700 flex items-center justify-center text-gray-400 group-hover:text-brand-gold group-hover:bg-brand-off-white transition-all border-2 border-dashed border-gray-300 dark:border-gray-600 group-hover:border-brand-gold">
                             <UserGroupIcon className="w-6 h-6" />
                         </div>
                         <span className="text-xs font-medium text-gray-600 dark:text-gray-300 group-hover:text-brand-gold transition-colors">Group</span>
                    </button>
                    {activeContacts.map((user, i) => (
                        <div key={i} className="flex flex-col items-center gap-1.5 min-w-[64px] cursor-pointer hover:opacity-80 transition-opacity group">
                            <div className="relative">
                                {/* Pass ID here so Avatar component renders Monkix/Imara Logo for system accounts */}
                                <Avatar 
                                    imageUrl={user?.avatarUrl} 
                                    name={user?.name || 'User'} 
                                    id={user?.id}
                                    className="w-14 h-14 rounded-full border-2 border-brand-green p-0.5 bg-white dark:bg-gray-800 group-hover:border-brand-gold transition-colors"
                                    hasRing={true} 
                                />
                                {user?.isOnline && <span className="absolute bottom-1 right-1 w-3.5 h-3.5 bg-green-500 border-2 border-white rounded-full"></span>}
                            </div>
                            <span className="text-xs font-medium text-gray-600 dark:text-gray-300 truncate w-16 text-center">{user?.name.split(' ')[0]}</span>
                        </div>
                    ))}
                </div>
            </div>

            {/* Search */}
            <div className="px-4 py-4">
                <div className="relative group">
                    <SearchIcon className="w-5 h-5 text-gray-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none group-focus-within:text-brand-gold transition-colors" />
                    <input 
                        type="text" 
                        placeholder="Search gossip..."
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        className="w-full bg-gray-100 dark:bg-gray-700/50 border-transparent border-2 rounded-2xl py-3 pl-12 pr-4 focus:ring-0 focus:border-brand-gold text-sm transition-all placeholder:text-gray-500 dark:text-white"
                    />
                </div>
            </div>
            
            {/* Chat List */}
            <div className="flex-grow overflow-y-auto custom-scrollbar px-2 space-y-1">
                <div className="px-3 py-2 text-xs font-bold text-gray-400 uppercase tracking-wider">Recent Gossip</div>

                {filteredConversations.length > 0 ? (
                    filteredConversations.map(conv => {
                        const isDirect = conv.type === 'direct';
                        const participant = isDirect ? (conv as DirectConversation).participant : null;
                        const group = !isDirect ? (conv as GroupConversation) : null;
                        const name = isDirect ? participant!.name : group!.groupName;
                        const avatar = isDirect ? participant!.avatarUrl : group!.groupAvatarUrl;
                        const entityId = isDirect ? participant!.id : group!.id;
                        
                        const isActive = activeConversationId === conv.id;
                        // STABLE UNREAD COUNT: Use the actual data, do not randomize
                        const unreadCount = isActive ? 0 : (conv.isUnread ? 1 : 0);

                        return (
                            <div key={conv.id} className="relative group/item">
                                <Link
                                    to={`/messages/${conv.id}`}
                                    className={`relative flex items-center gap-4 p-3 mx-1 rounded-2xl transition-all duration-200 ${
                                        isActive 
                                        ? 'bg-brand-navy-dark text-white shadow-lg' 
                                        : 'hover:bg-gray-100 dark:hover:bg-gray-700/50 bg-transparent text-gray-800 dark:text-gray-100'
                                    }`}
                                >
                                    <div className="relative flex-shrink-0">
                                        <Avatar 
                                            imageUrl={avatar}
                                            name={name}
                                            id={entityId}
                                            className={`w-12 h-12 rounded-full ${isActive ? 'border-2 border-brand-gold' : 'border-2 border-transparent'}`}
                                            textClassName="text-sm font-bold"
                                            hasRing={true}
                                        />
                                        {participant?.isOnline && (
                                            <span className={`absolute bottom-0 right-0 block h-3.5 w-3.5 rounded-full bg-green-500 ring-2 ${isActive ? 'ring-brand-navy-dark' : 'ring-white'}`} />
                                        )}
                                    </div>
                                    
                                    <div className="flex-grow overflow-hidden min-w-0">
                                        <div className="flex justify-between items-center mb-1">
                                            <div className="flex items-center gap-1">
                                                {conv.isLocked && <LockClosedIcon className="w-3 h-3 text-gray-400" />}
                                                <h2 className={`font-bold text-sm truncate ${isActive ? 'text-white' : 'text-brand-navy-dark dark:text-white'}`}>{name}</h2>
                                            </div>
                                            <div className="flex items-center gap-1">
                                                {conv.isPinned && <span className="text-[10px] bg-brand-gold/20 text-brand-gold px-1 rounded">PIN</span>}
                                                <span className={`text-[10px] font-medium ${isActive ? 'text-gray-300' : 'text-gray-400'}`}>
                                                    {conv.messages.length > 0 ? conv.messages[conv.messages.length - 1].timestamp : ''}
                                                </span>
                                            </div>
                                        </div>
                                        <div className="flex justify-between items-center">
                                            <p className={`text-xs truncate pr-2 ${isActive ? 'text-gray-300' : 'text-gray-500 dark:text-gray-400'} ${conv.isUnread && !isActive ? 'font-bold text-brand-navy-dark dark:text-white' : ''}`}>
                                                {getMessagePreview(conv)}
                                            </p>
                                            {unreadCount > 0 && (
                                                <span className={`flex-shrink-0 min-w-[20px] h-5 flex items-center justify-center rounded-full text-[10px] font-bold px-1 ${isActive ? 'bg-brand-gold text-brand-navy-dark' : 'bg-brand-green text-white'}`}>
                                                    {unreadCount}
                                                </span>
                                            )}
                                        </div>
                                    </div>
                                    
                                    {/* Action Menu Button */}
                                    <button 
                                        onClick={(e) => { e.preventDefault(); setOpenMenuId(openMenuId === conv.id ? null : conv.id); }}
                                        className={`absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-full hover:bg-gray-200 dark:hover:bg-gray-600 opacity-0 group-hover/item:opacity-100 transition-opacity ${isActive ? 'text-white hover:text-brand-navy-dark' : 'text-gray-500'}`}
                                    >
                                        <EllipsisHorizontalIcon className="w-5 h-5" />
                                    </button>
                                </Link>
                                
                                {/* Context Menu */}
                                {openMenuId === conv.id && (
                                    <div className="absolute right-0 top-10 z-20 w-40 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-100 dark:border-gray-700 py-1 overflow-hidden animate-fade-in-down">
                                        <button onClick={(e) => handleAction(e, 'pin', conv.id)} className="w-full text-left px-4 py-2 text-xs hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-white">Pin to Top</button>
                                        <button onClick={(e) => handleAction(e, 'hide', conv.id)} className="w-full text-left px-4 py-2 text-xs hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-white">Hide Gossip</button>
                                        <button onClick={(e) => handleAction(e, 'archive', conv.id)} className="w-full text-left px-4 py-2 text-xs hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-white">Archive</button>
                                        <button onClick={(e) => handleAction(e, 'lock', conv.id)} className="w-full text-left px-4 py-2 text-xs hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-white">Lock Chat</button>
                                        <button onClick={(e) => handleAction(e, 'delete', conv.id)} className="w-full text-left px-4 py-2 text-xs hover:bg-red-50 text-red-600">Delete</button>
                                    </div>
                                )}
                            </div>
                        );
                    })
                ) : (
                    <div className="text-center text-gray-400 py-10">
                        <p>No gossip found.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ConversationList;
