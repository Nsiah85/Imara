import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import type { Conversation, MessageContent } from '../../types.ts';
import { 
    PaperAirplaneIcon, ArrowLeftIcon, PhoneIcon, VideoCameraIcon, 
    PaperclipIcon, MicrophoneIcon, FaceSmileIcon, EllipsisVerticalIcon, 
    TrashIcon, LockClosedIcon, StopIcon, XIcon 
} from '../icons/Icons.tsx';
import ChatMessage from './ChatMessage.tsx';
import Avatar from '../ui/Avatar.tsx';
import { ChatSettings } from '../modals/ChatSettingsModal.tsx';

interface ChatViewProps {
    conversation: Conversation;
    onSendMessage: (content: MessageContent) => void;
    isTyping: boolean;
    onInitiateCall: (type: 'voice' | 'video') => void;
    settings?: ChatSettings;
}

const ChatView: React.FC<ChatViewProps> = ({ conversation, onSendMessage, isTyping, onInitiateCall, settings }) => {
    const navigate = useNavigate();
    const [inputText, setInputText] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const [showMenu, setShowMenu] = useState(false);
    const [isCleared, setIsCleared] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    // Voice Recorder State
    const [isRecording, setIsRecording] = useState(false);
    const [recordingTime, setRecordingTime] = useState(0);
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioChunksRef = useRef<Blob[]>([]);
    // FIX: Changed NodeJS.Timeout to number for browser compatibility as the NodeJS namespace is not available.
    const timerRef = useRef<number | null>(null);

    const isGroupChat = conversation.type === 'group';
    const participant = conversation.type === 'direct' ? conversation.participant : null;
    const name = isGroupChat ? conversation.groupName : participant!.name;
    const entityId = isGroupChat ? conversation.id : participant!.id;
    const avatarUrl = isGroupChat ? conversation.groupAvatarUrl : participant!.avatarUrl;

    const isSystemChat = entityId === 'system_toast_feed' || entityId === 'toast_feed_notifications';

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [conversation.messages, isTyping, isCleared]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (inputText.trim()) {
            onSendMessage({ type: 'text', text: inputText });
            setInputText('');
        }
    };

    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            const mediaRecorder = new MediaRecorder(stream);
            mediaRecorderRef.current = mediaRecorder;
            audioChunksRef.current = [];

            mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) {
                    audioChunksRef.current.push(event.data);
                }
            };

            mediaRecorder.onstop = () => {
                const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
                const audioUrl = URL.createObjectURL(audioBlob);
                onSendMessage({ type: 'voice', audioUrl, duration: recordingTime });
                stream.getTracks().forEach(track => track.stop());
                setRecordingTime(0);
            };

            mediaRecorder.start();
            setIsRecording(true);
            setRecordingTime(0);
            // FIX: Use window.setInterval which returns a number in the browser environment.
            timerRef.current = window.setInterval(() => {
                setRecordingTime(prev => prev + 1);
            }, 1000);
        } catch (err) {
            console.error("Mic access denied", err);
            alert("Could not access microphone. Please check permissions.");
        }
    };

    const stopRecording = () => {
        if (mediaRecorderRef.current && isRecording) {
            mediaRecorderRef.current.stop();
            setIsRecording(false);
            if (timerRef.current) clearInterval(timerRef.current);
        }
    };

    const cancelRecording = () => {
        if (mediaRecorderRef.current && isRecording) {
            mediaRecorderRef.current.onstop = null; // Prevent sending
            mediaRecorderRef.current.stop();
            setIsRecording(false);
            if (timerRef.current) clearInterval(timerRef.current);
            setRecordingTime(0);
            // Clean up tracks
            mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
        }
    };

    const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            const files = Array.from(e.target.files) as File[];
            try {
                const { uploadFile } = await import('../../firebase/storage.ts');
                for (const file of files) {
                    const isImage = file.type.startsWith('image/');
                    const url = await uploadFile(file, `chats/${conversation.id}/${Date.now()}`);
                    
                    if (isImage) {
                        onSendMessage({ type: 'image', imageUrl: url });
                    } else {
                         onSendMessage({ 
                             type: 'document', 
                             fileUrl: url, 
                             fileName: file.name, 
                             fileSize: `${(file.size / 1024).toFixed(1)} KB` 
                        });
                    }
                }
            } catch (err) {
                console.error("Failed to upload attachment", err);
            }
        }
    };
    
    const handleBack = (e: React.MouseEvent) => {
        e.preventDefault();
        navigate('/messages'); 
    };

    const handleClearChat = () => {
        setIsCleared(true);
        setShowMenu(false);
        setTimeout(() => setIsCleared(false), 4000); 
    };

    const formatTime = (seconds: number) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    };

    const backgroundStyle = settings?.wallpaper.startsWith('url') 
        ? { backgroundImage: settings.wallpaper } 
        : { backgroundColor: settings?.wallpaper };

    return (
        <div className="flex flex-col h-full relative w-full" style={backgroundStyle}>
            <header className="flex items-center justify-between px-4 md:px-6 py-3 bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700 shadow-sm flex-shrink-0 z-20 rounded-b-3xl mx-2 mt-2">
                <div className="flex items-center gap-3">
                    <button onClick={handleBack} className="md:hidden text-gray-500 hover:text-brand-navy-dark p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors" title="Back to Gossip List">
                        <ArrowLeftIcon className="w-5 h-5" />
                    </button>
                    
                    <div className="flex items-center gap-3 cursor-pointer p-1 rounded-full hover:bg-gray-50 dark:hover:bg-gray-700 transition-all pr-4" onClick={() => !isSystemChat && navigate(isGroupChat ? '#' : participant?.profileLink || '#')} title="View Profile">
                        <div className="relative">
                            <Avatar 
                                imageUrl={avatarUrl} 
                                name={name} 
                                id={entityId} 
                                className="w-10 h-10 md:w-11 md:h-11 rounded-full border-2 border-white dark:border-gray-800 shadow-sm" 
                                textClassName="text-sm font-bold text-white"
                                hasRing={true} 
                            />
                             {participant?.isOnline && <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white dark:border-gray-800 rounded-full"></span>}
                        </div>

                        <div className="flex flex-col justify-center">
                            <h2 className="font-bold text-brand-navy-dark dark:text-white text-base leading-tight truncate max-w-[150px] md:max-w-xs flex items-center gap-1">
                                {name}
                                {participant?.role && <span className="text-[10px] bg-gray-100 dark:bg-gray-600 px-1.5 rounded text-gray-500 dark:text-gray-300 font-normal hidden sm:inline-block">{participant.role}</span>}
                            </h2>
                            <p className="text-xs text-brand-green dark:text-brand-gold font-medium">{participant?.isOnline ? 'Active now' : 'Seen recently'}</p>
                        </div>
                    </div>
                </div>

                <div className="flex items-center gap-1 sm:gap-2 text-gray-400 relative bg-gray-50 dark:bg-gray-700/50 p-1 rounded-full">
                    {!isSystemChat && (
                        <>
                            <button onClick={() => onInitiateCall('voice')} className="p-2 rounded-full hover:bg-white dark:hover:bg-gray-600 hover:text-brand-green shadow-sm transition-all" title="Start Voice Call"><PhoneIcon className="w-5 h-5" /></button>
                            <button onClick={() => onInitiateCall('video')} className="p-2 rounded-full hover:bg-white dark:hover:bg-gray-600 hover:text-brand-green shadow-sm transition-all" title="Start Video Call"><VideoCameraIcon className="w-5 h-5" /></button>
                            <div className="w-px h-6 bg-gray-200 dark:bg-gray-600 mx-1"></div>
                        </>
                    )}
                    <button onClick={() => setShowMenu(!showMenu)} className="p-2 rounded-full hover:bg-white dark:hover:bg-gray-600 hover:text-brand-navy-dark shadow-sm transition-all" title="Conversation Options"><EllipsisVerticalIcon className="w-5 h-5" /></button>
                    
                    {showMenu && (
                        <div className="absolute top-full right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-100 dark:border-gray-700 z-50 py-1 animate-fade-in-up overflow-hidden">
                            {!isSystemChat && (
                                <>
                                    <button onClick={() => navigate(participant?.profileLink || '#')} className="w-full text-left px-4 py-3 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors font-medium" title="View detail profile">
                                        View Profile
                                    </button>
                                    <div className="h-px bg-gray-100 dark:bg-gray-700 my-1"></div>
                                </>
                            )}
                            <button onClick={handleClearChat} className="w-full text-left px-4 py-3 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 flex items-center gap-2 transition-colors font-medium" title="Delete all messages">
                                <TrashIcon className="w-4 h-4" /> Clear Chat
                            </button>
                        </div>
                    )}
                </div>
            </header>

            <div className="flex-1 px-4 md:px-8 py-6 overflow-y-auto space-y-6 z-10 scrollbar-thin scrollbar-thumb-gray-200 dark:scrollbar-thumb-gray-700">
                {isCleared ? (
                     <div className="h-full flex flex-col items-center justify-center text-gray-400">
                         <div className="p-4 bg-white dark:bg-gray-800 rounded-full shadow-sm mb-2">
                            <TrashIcon className="w-8 h-8 text-gray-300"/>
                         </div>
                         <p>Gossip history cleared.</p>
                     </div>
                ) : (
                    <>
                        {conversation.messages.map((msg, idx) => {
                            const isCurrentUser = msg.senderId === 'currentUser';
                            return (
                                <div key={msg.id} className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'}`}>
                                    <ChatMessage 
                                        message={msg} 
                                        isCurrentUser={isCurrentUser} 
                                        bubbleStyle={settings?.bubbleColor}
                                    />
                                </div>
                            );
                        })}
                        <div ref={messagesEndRef} />
                    </>
                )}
            </div>

            <footer className="p-4 md:p-6 bg-white dark:bg-gray-800 border-t border-gray-100 dark:border-gray-700 z-20">
                {isSystemChat ? (
                    <div className="flex justify-center items-center w-full py-2">
                        <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-700 px-4 py-2 rounded-full">
                            <LockClosedIcon className="w-4 h-4" />
                            <span>This is a system broadcast. Replies are disabled.</span>
                        </div>
                    </div>
                ) : isRecording ? (
                    <div className="flex items-center gap-4 max-w-5xl mx-auto bg-red-50 dark:bg-red-900/20 p-3 rounded-2xl animate-pulse border border-red-200 dark:border-red-900/50">
                        <div className="flex items-center gap-3 px-4">
                            <div className="w-3 h-3 bg-red-600 rounded-full animate-ping"></div>
                            <span className="font-mono text-red-600 dark:text-red-400 font-black text-lg">{formatTime(recordingTime)}</span>
                        </div>
                        <div className="flex-1 text-red-700 dark:text-red-300 text-sm font-bold uppercase tracking-wider">Recording Voice Note...</div>
                        <button onClick={cancelRecording} className="p-2 text-gray-400 hover:text-red-600 transition-colors" title="Cancel Recording">
                            <XIcon className="w-6 h-6" />
                        </button>
                        <button onClick={stopRecording} className="p-4 bg-red-600 text-white rounded-full shadow-lg hover:bg-red-700 transition-all transform scale-110" title="Stop and Send">
                            <StopIcon className="w-6 h-6" />
                        </button>
                    </div>
                ) : (
                    <div className="flex items-center gap-2 md:gap-4 max-w-5xl mx-auto">
                        <button onClick={() => fileInputRef.current?.click()} className="text-gray-400 hover:text-brand-navy-dark transition-colors p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full" title="Attach Files">
                            <PaperclipIcon className="w-6 h-6" />
                        </button>
                        <input type="file" ref={fileInputRef} className="hidden" multiple onChange={handleFileSelect} />
                        
                        <div className="flex-grow relative">
                            <input
                                type="text"
                                value={inputText}
                                onChange={(e) => setInputText(e.target.value)}
                                placeholder="Whisper something..."
                                className="w-full py-3 md:py-4 pl-6 pr-12 bg-gray-100 dark:bg-gray-700 rounded-full border-none focus:ring-2 focus:ring-brand-gold text-sm text-brand-navy-dark dark:text-white font-medium placeholder:text-gray-400 transition-shadow"
                                onKeyDown={(e) => e.key === 'Enter' && handleSubmit(e)}
                            />
                            <button className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-brand-gold transition-colors" title="Add Emoji">
                                <FaceSmileIcon className="w-6 h-6" />
                            </button>
                        </div>
                        
                        {inputText ? (
                            <button onClick={handleSubmit} className="p-3 bg-brand-navy-dark hover:bg-brand-green text-white rounded-full shadow-lg transition-all transform hover:scale-105" title="Send Message">
                                <PaperAirplaneIcon className="w-5 h-5 md:w-6 md:h-6" />
                            </button>
                        ) : (
                            <button onClick={startRecording} className="p-3 bg-brand-green hover:bg-brand-green-dark text-white rounded-full shadow-lg transition-all hover:scale-105" title="Hold to Record Voice Note">
                                <MicrophoneIcon className="w-5 h-5 md:w-6 md:h-6" />
                            </button>
                        )}
                    </div>
                )}
            </footer>
        </div>
    );
};

export default ChatView;