import React from 'react';

interface EmojiPickerProps {
  onSelect: (emoji: string) => void;
}

const emojis = [
  '😊', '😂', '❤️', '👍', '🙏', '🔥', '🎉', '🌟', '👋', '😎', '😢', '🤔',
  '🙌', '💯', '✨', '🌍', '🤝', '💼', '🛒', '✈️', '🏨', '🚗', '🍲', '🏆'
];

const EmojiPicker: React.FC<EmojiPickerProps> = ({ onSelect }) => {
  return (
    <div className="absolute bottom-full right-0 mb-2 w-64 bg-white rounded-lg shadow-xl border p-2 z-10 animate-fade-in-up">
      <div className="grid grid-cols-6 gap-1">
        {emojis.map(emoji => (
          <button
            key={emoji}
            onClick={() => onSelect(emoji)}
            className="text-2xl rounded-md p-1 hover:bg-gray-200 transition-colors"
            aria-label={`Select emoji ${emoji}`}
          >
            {emoji}
          </button>
        ))}
      </div>
    </div>
  );
};

export default EmojiPicker;
