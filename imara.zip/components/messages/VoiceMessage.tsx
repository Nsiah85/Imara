import React, { useState, useRef, useEffect } from 'react';
import { PlayIcon, PauseIcon } from '../icons/Icons.tsx';

interface VoiceMessageProps {
  audioUrl: string;
}

const VoiceMessage: React.FC<VoiceMessageProps> = ({ audioUrl }) => {
    const [isPlaying, setIsPlaying] = useState(false);
    const [progress, setProgress] = useState(0);
    const [duration, setDuration] = useState(0);
    const audioRef = useRef<HTMLAudioElement>(null);

    useEffect(() => {
        const audio = audioRef.current;
        if (!audio) return;

        const setAudioData = () => {
            setDuration(audio.duration);
        };

        const updateProgress = () => {
            setProgress((audio.currentTime / audio.duration) * 100);
        };
        
        const handleEnded = () => {
            setIsPlaying(false);
            setProgress(0);
        }

        audio.addEventListener('loadedmetadata', setAudioData);
        audio.addEventListener('timeupdate', updateProgress);
        audio.addEventListener('ended', handleEnded);

        return () => {
            audio.removeEventListener('loadedmetadata', setAudioData);
            audio.removeEventListener('timeupdate', updateProgress);
            audio.removeEventListener('ended', handleEnded);
        };
    }, []);

    const togglePlay = () => {
        if (audioRef.current) {
            if (isPlaying) {
                audioRef.current.pause();
            } else {
                audioRef.current.play();
            }
            setIsPlaying(!isPlaying);
        }
    };
    
    const formatTime = (time: number) => {
        if (isNaN(time) || time === 0) return '0:00';
        const minutes = Math.floor(time / 60);
        const seconds = Math.floor(time % 60);
        return `${minutes}:${seconds.toString().padStart(2, '0')}`;
    };

    return (
        <div className="flex items-center gap-3 w-64">
            <audio ref={audioRef} src={audioUrl} preload="metadata" />
            <button onClick={togglePlay} className="flex-shrink-0 w-8 h-8 rounded-full bg-brand-gold text-brand-navy-dark flex items-center justify-center">
                {isPlaying ? <PauseIcon className="w-5 h-5" /> : <PlayIcon className="w-5 h-5" />}
            </button>
            <div className="flex-grow flex items-center gap-2">
                 <div className="w-full bg-black/10 rounded-full h-1.5">
                    <div 
                        className="bg-brand-navy-dark h-1.5 rounded-full" 
                        style={{ width: `${progress}%` }}
                    ></div>
                </div>
                <span className="text-xs font-mono text-gray-700">{formatTime(duration)}</span>
            </div>
        </div>
    );
};

export default VoiceMessage;
