
import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext.tsx';
import Avatar from '../ui/Avatar.tsx';
import { PhoneIcon, AtSymbolIcon, InformationCircleIcon, Cog6ToothIcon, UserGroupIcon, UsersIcon, ArrowUpTrayIcon } from '../icons/Icons.tsx';
import Button from '../ui/Button.tsx';
import { Link } from 'react-router-dom';
import ChatSettingsModal, { ChatSettings } from '../modals/ChatSettingsModal.tsx';
import ContactsModal from '../modals/ContactsModal.tsx';
import GroupInfoModal from '../modals/GroupInfoModal.tsx';

interface ChatProfileSidebarProps {
    onSettingsChange?: (settings: ChatSettings) => void;
    currentSettings?: ChatSettings;
}

const ChatProfileSidebar: React.FC<ChatProfileSidebarProps> = ({ onSettingsChange, currentSettings }) => {
    const { user } = useAuth();
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);
    const [isContactsOpen, setIsContactsOpen] = useState(false);
    const [isGroupsOpen, setIsGroupsOpen] = useState(false);
    
    // Local fallback if not provided
    const [localSettings, setLocalSettings] = useState<ChatSettings>({ wallpaper: 'default', bubbleColor: 'bg-brand-gold text-brand-navy-dark' });
    const settings = currentSettings || localSettings;

    if (!user) return null;

    const menuItems = [
        { icon: <UsersIcon className="w-5 h-5" />, label: "Contacts", action: () => setIsContactsOpen(true) },
        { icon: <UserGroupIcon className="w-5 h-5" />, label: "Groups & Teams", action: () => setIsGroupsOpen(true) },
        { icon: <Cog6ToothIcon className="w-5 h-5" />, label: "Settings", action: () => setIsSettingsOpen(true) },
    ];

    const handleSaveSettings = (newSettings: ChatSettings) => {
        if (onSettingsChange) {
            onSettingsChange(newSettings);
        } else {
            setLocalSettings(newSettings);
        }
    };

    return (
        <div className="h-full w-full bg-brand-navy-dark text-white flex flex-col overflow-y-auto scrollbar-hide relative">
            {/* User Header */}
            <div className="p-8 flex flex-col items-center border-b border-white/10">
                <div className="relative mb-4">
                    <Avatar 
                        imageUrl={user.profileImageUrl} 
                        name={user.fullName} 
                        id={user.id} 
                        className="w-24 h-24 rounded-full border-4 border-brand-gold shadow-lg"
                        textClassName="text-2xl font-bold"
                    />
                </div>
                <h2 className="text-xl font-display font-bold text-white">{user.fullName}</h2>
                <p className="text-sm text-gray-400 mt-1">{user.role === 'user' ? 'Product Enthusiast' : 'Verified Partner'}</p>
            </div>

            {/* Details List */}
            <div className="p-6 space-y-6">
                <div className="flex items-center gap-4 group">
                    <div className="p-2 bg-white/5 rounded-full group-hover:bg-white/10 transition-colors"><PhoneIcon className="w-5 h-5 text-gray-400 group-hover:text-brand-gold" /></div>
                    <div className="flex-grow">
                        <p className="text-xs text-gray-400 uppercase tracking-wider mb-1">Phone</p>
                        <div className="flex justify-between items-center">
                            <input 
                                type="text"
                                defaultValue="+233 55 123 4567"
                                className="font-medium bg-transparent border-b border-transparent hover:border-white/20 focus:border-brand-gold outline-none w-full"
                                onChange={(e) => {
                                    // Normally save to user profile
                                }}
                            />
                        </div>
                    </div>
                </div>
                <div className="flex items-center gap-4 group">
                    <div className="p-2 bg-white/5 rounded-full group-hover:bg-white/10 transition-colors"><AtSymbolIcon className="w-5 h-5 text-gray-400 group-hover:text-brand-gold" /></div>
                    <div>
                        <p className="text-xs text-gray-400 uppercase tracking-wider mb-1">Username</p>
                        <p className="font-medium">@{user.fullName.replace(/\s+/g, '').toLowerCase()}</p>
                    </div>
                </div>
                <div className="flex items-center gap-4 group">
                    <div className="p-2 bg-white/5 rounded-full group-hover:bg-white/10 transition-colors"><InformationCircleIcon className="w-5 h-5 text-gray-400 group-hover:text-brand-gold" /></div>
                    <div>
                        <p className="text-xs text-gray-400 uppercase tracking-wider mb-1">Status</p>
                        <p className="font-medium">Shopping on Imara 🛒</p>
                    </div>
                </div>
            </div>

            <div className="w-full h-px bg-white/10 my-2"></div>

            {/* Menu */}
            <div className="p-4 space-y-2">
                {menuItems.map((item, index) => (
                    <button key={index} onClick={item.action} className="w-full flex items-center gap-4 p-3 rounded-xl hover:bg-white/10 transition-colors text-left group">
                        <span className="text-gray-400 group-hover:text-white transition-colors">{item.icon}</span>
                        <span className="font-medium">{item.label}</span>
                    </button>
                ))}
                
                <Link to="/upgrade" className="w-full flex items-center gap-4 p-3 rounded-xl hover:bg-white/10 transition-colors text-left group">
                    <span className="text-brand-gold group-hover:scale-110 transition-transform"><ArrowUpTrayIcon className="w-5 h-5" /></span>
                    <span className="font-bold text-brand-gold">Upgrade Plan</span>
                </Link>
            </div>

            {/* Premium Card */}
            <div className="mt-auto p-6">
                <div className="bg-gradient-to-br from-brand-navy to-black p-5 rounded-2xl border border-white/10 relative overflow-hidden group shadow-lg">
                     <div className="absolute top-0 right-0 w-20 h-20 bg-brand-gold/20 rounded-full blur-xl group-hover:bg-brand-gold/30 transition-all"></div>
                     <h3 className="font-bold text-lg text-white mb-1 relative z-10">Imara Premium</h3>
                     <p className="text-xs text-gray-400 mb-4 relative z-10">Experience enhanced features and improved accessibility.</p>
                     <Link to="/upgrade">
                        <Button className="w-full !bg-brand-gold !text-brand-navy-dark !font-bold !py-2 hover:!bg-white transition-colors">Upgrade Now</Button>
                     </Link>
                </div>
            </div>
            
            {/* Modals - Rendered conditionally */}
            {isSettingsOpen && <ChatSettingsModal onClose={() => setIsSettingsOpen(false)} onSave={handleSaveSettings} currentSettings={settings} />}
            {isContactsOpen && <ContactsModal onClose={() => setIsContactsOpen(false)} />}
            {isGroupsOpen && <GroupInfoModal onClose={() => setIsGroupsOpen(false)} />}
        </div>
    );
};

export default ChatProfileSidebar;
