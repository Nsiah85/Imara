
import React from 'react';
import { Link } from 'react-router-dom';
import type { DirectMessage } from '../../types.ts';
import { DocumentTextIcon, BriefcaseIcon, CheckIcon } from '../icons/Icons.tsx';
import Button from '../ui/Button.tsx';
import VoiceMessage from './VoiceMessage.tsx';

interface ChatMessageProps {
  message: DirectMessage;
  isCurrentUser: boolean;
  bubbleStyle?: string;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message, isCurrentUser, bubbleStyle }) => {

    const renderContent = () => {
        switch (message.content.type) {
            case 'text':
                return <p className="whitespace-pre-wrap leading-relaxed font-medium text-sm md:text-base">{message.content.text}</p>;
            case 'image':
                return <img src={message.content.imageUrl} alt="Upload" className="rounded-2xl max-h-64 object-cover border border-white/10" />;
            case 'voice':
                return <VoiceMessage audioUrl={message.content.audioUrl} />;
            case 'document':
                return (
                    <div className="flex items-center gap-3 p-2 bg-white/10 rounded-xl border border-white/10">
                        <div className="p-2 bg-white/20 rounded-lg"><DocumentTextIcon className="w-6 h-6 text-white" /></div>
                        <div>
                            <p className="font-bold text-sm truncate max-w-[150px] text-white">{message.content.fileName}</p>
                            <p className="text-[10px] text-white/70">{message.content.fileSize} • PDF</p>
                        </div>
                    </div>
                );
            case 'test_invite':
                 return (
                    <div className="p-2">
                        <p className="font-bold mb-2 flex items-center gap-2 text-sm"><BriefcaseIcon className="w-4 h-4"/> Interview Invite</p>
                        <p className="text-xs mb-3 opacity-90">Skill assessment: {message.content.jobTitle}.</p>
                        <Link to={`/pre-interview-test/${message.content.testAttemptId}`}>
                            <Button size="sm" className="w-full bg-white text-brand-navy-dark hover:bg-gray-100 border-none text-xs font-bold shadow-sm">Start Test</Button>
                        </Link>
                    </div>
                 );
            default: return null;
        }
    };

    // Determine bubble classes
    // If user provided custom style (e.g. "bg-blue-500 text-white"), use it for sent messages
    // Otherwise default to navy
    const defaultSentStyle = 'bg-brand-navy-dark text-white';
    const appliedSentStyle = bubbleStyle && bubbleStyle !== 'default' ? bubbleStyle : defaultSentStyle;

    const bubbleClass = isCurrentUser 
        ? `${appliedSentStyle} rounded-2xl rounded-tr-sm shadow-md` 
        : `bg-white dark:bg-gray-800 text-gray-800 dark:text-white rounded-2xl rounded-tl-sm shadow-sm border border-gray-100 dark:border-gray-700`;

    return (
        <div className={`flex flex-col ${isCurrentUser ? 'items-end' : 'items-start'} max-w-[85%] md:max-w-[70%]`}>
             <div className={`p-3 md:p-4 ${bubbleClass}`}>
                {renderContent()}
            </div>
            
            <div className={`flex items-center gap-1 mt-1 px-1 text-[10px] text-gray-400 font-medium select-none`}>
                <span>{message.timestamp}</span>
                {isCurrentUser && (
                    <div className="flex -space-x-1 ml-1">
                         <CheckIcon className="w-3 h-3 text-brand-green" />
                         <CheckIcon className="w-3 h-3 text-brand-green" />
                    </div>
                )}
            </div>
        </div>
    );
};

export default ChatMessage;
