
import React, { useState, useEffect } from 'react';
import type { SubscriptionPlan } from '../../types.ts';
import { mockVendorSubscriptionPlans, mockWorkmanSubscriptionPlans } from '../../data/mockData.ts';
import Button from '../ui/Button.tsx';
import { EditIcon, PlusCircleIcon } from '../icons/Icons.tsx';
import SubscriptionCard from '../subscriptions/SubscriptionCard.tsx';
import SubscriptionEditModal from '../modals/SubscriptionEditModal.tsx';

const AdminSubscriptionManager: React.FC = () => {
    const [vendorPlans, setVendorPlans] = useState<SubscriptionPlan[]>([]);
    const [workmanPlans, setWorkmanPlans] = useState<SubscriptionPlan[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingPlan, setEditingPlan] = useState<Partial<SubscriptionPlan> | null>(null);

    useEffect(() => {
        try {
            const storedVPlans = localStorage.getItem('vendor_plans');
            setVendorPlans(storedVPlans ? JSON.parse(storedVPlans) : mockVendorSubscriptionPlans);
            
            const storedWPlans = localStorage.getItem('workman_plans');
            setWorkmanPlans(storedWPlans ? JSON.parse(storedWPlans) : mockWorkmanSubscriptionPlans);
        } catch (error) {
            console.error("Failed to load plans from localStorage", error);
            setVendorPlans(mockVendorSubscriptionPlans);
            setWorkmanPlans(mockWorkmanSubscriptionPlans);
        }
    }, []);

    const handleSaveToLocalStorage = (plans: SubscriptionPlan[], key: string) => {
        try {
            localStorage.setItem(key, JSON.stringify(plans));
        } catch (error) {
            console.error("Failed to save plans to localStorage", error);
        }
    };

    const handleOpenModal = (plan: Partial<SubscriptionPlan> | null) => {
        setEditingPlan(plan);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingPlan(null);
    };

    const handleSavePlan = (plan: SubscriptionPlan) => {
        if (plan.type === 'vendor') {
            const newPlans = editingPlan?.id
                ? vendorPlans.map(p => p.id === plan.id ? plan : p)
                : [...vendorPlans, { ...plan, id: crypto.randomUUID() }];
            setVendorPlans(newPlans);
            handleSaveToLocalStorage(newPlans, 'vendor_plans');
        } else {
             const newPlans = editingPlan?.id
                ? workmanPlans.map(p => p.id === plan.id ? plan : p)
                : [...workmanPlans, { ...plan, id: crypto.randomUUID() }];
            setWorkmanPlans(newPlans);
            handleSaveToLocalStorage(newPlans, 'workman_plans');
        }
        handleCloseModal();
    };

    // Helper to delete a plan
    const handleDeletePlan = (id: string, type: 'vendor' | 'workman') => {
         if (window.confirm("Are you sure you want to delete this subscription plan? This could affect active users.")) {
             if (type === 'vendor') {
                 const updated = vendorPlans.filter(p => p.id !== id);
                 setVendorPlans(updated);
                 handleSaveToLocalStorage(updated, 'vendor_plans');
             } else {
                 const updated = workmanPlans.filter(p => p.id !== id);
                 setWorkmanPlans(updated);
                 handleSaveToLocalStorage(updated, 'workman_plans');
             }
         }
    }

    return (
        <>
            <div className="space-y-8">
                <div className="bg-white p-6 rounded-lg shadow-md">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-xl font-display font-semibold text-brand-green-dark">Vendor Plans</h3>
                        <Button size="sm" variant="outline" className="flex items-center gap-2" onClick={() => handleOpenModal({ type: 'vendor' })}>
                           <PlusCircleIcon className="w-5 h-5" /> Add New
                        </Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {vendorPlans.map(plan => (
                             <div key={plan.id} className="relative">
                                <SubscriptionCard plan={plan} />
                                <div className="absolute top-4 right-4 flex gap-2">
                                    <button onClick={() => handleOpenModal(plan)} className="p-2 bg-white rounded-full shadow hover:bg-gray-100" aria-label={`Edit ${plan.name} plan`}>
                                        <EditIcon className="w-4 h-4 text-gray-600" />
                                    </button>
                                    {/* Assuming delete functionality might be needed in future, keeping UI consistent */}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-md">
                     <div className="flex justify-between items-center mb-4">
                        <h3 className="text-xl font-display font-semibold text-brand-green-dark">Workman Plans</h3>
                        <Button size="sm" variant="outline" className="flex items-center gap-2" onClick={() => handleOpenModal({ type: 'workman' })}>
                           <PlusCircleIcon className="w-5 h-5" /> Add New
                        </Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {workmanPlans.map(plan => (
                            <div key={plan.id} className="relative">
                                <SubscriptionCard plan={plan} />
                                <div className="absolute top-4 right-4 flex gap-2">
                                     <button onClick={() => handleOpenModal(plan)} className="p-2 bg-white rounded-full shadow hover:bg-gray-100" aria-label={`Edit ${plan.name} plan`}>
                                        <EditIcon className="w-4 h-4 text-gray-600" />
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
            {isModalOpen && (
                <SubscriptionEditModal
                    plan={editingPlan}
                    onClose={handleCloseModal}
                    onSave={handleSavePlan}
                />
            )}
        </>
    );
};

export default AdminSubscriptionManager;
