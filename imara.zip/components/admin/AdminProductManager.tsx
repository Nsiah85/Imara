import React, { useState, useEffect } from 'react';
import type { Product } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { EditIcon, TrashIcon, PlusCircleIcon } from '../icons/Icons.tsx';
import AddProductModal from './AddProductModal.tsx';
import { db, collection, onSnapshot, setDoc, doc, deleteDoc, updateDoc } from '../../firebase/firestore.ts';

const AdminProductManager: React.FC = () => {
    const [products, setProducts] = useState<Product[]>([]);
    const [showAddModal, setShowAddModal] = useState(false);

    useEffect(() => {
        const unsubscribe = onSnapshot(collection(db, 'products'), (snapshot) => {
            const loadedProducts = snapshot.docs.map(doc => doc.data() as Product);
            setProducts(loadedProducts);
        }, (error) => {
            console.error("Failed to load products", error);
        });
        return () => unsubscribe();
    }, []);

    const handleDelete = async (id: string) => {
        if (window.confirm("Are you sure you want to delete this product?")) {
            await deleteDoc(doc(db, 'products', id));
        }
    };

    const handleAdd = async (newProduct: Product) => {
        await setDoc(doc(db, 'products', newProduct.id), newProduct);
        setShowAddModal(false);
    };

    const toggleVerification = async (id: string) => {
        const product = products.find(p => p.id === id);
        if (product) {
            await updateDoc(doc(db, 'products', id), { isVerified: !product.isVerified });
        }
    };

    return (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-[40px] border border-gray-100 dark:border-gray-700 shadow-sm animate-fade-in mt-10">
            <h3 className="text-2xl font-display font-black text-brand-navy-dark dark:text-white uppercase mb-6 tracking-tight flex items-center justify-between">
                <span>Products Management ({products.length})</span>
                <Button size="sm" onClick={() => setShowAddModal(true)} className="flex items-center gap-2"><PlusCircleIcon className="w-4 h-4"/> Add Product</Button>
            </h3>
            
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-500">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-900 dark:text-gray-400">
                        <tr>
                            <th scope="col" className="px-6 py-3">Product Name</th>
                            <th scope="col" className="px-6 py-3">Vendor</th>
                            <th scope="col" className="px-6 py-3">Price</th>
                            <th scope="col" className="px-6 py-3">Verified</th>
                            <th scope="col" className="px-6 py-3 text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {products.map(p => (
                            <tr key={p.id} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                                <td className="px-6 py-4 font-bold text-gray-900 dark:text-white">{p.name}</td>
                                <td className="px-6 py-4">{p.vendor}</td>
                                <td className="px-6 py-4">{p.price.toFixed(2)}</td>
                                <td className="px-6 py-4">
                                    <button onClick={() => toggleVerification(p.id)} className={`px-2 py-1 rounded text-xs font-bold uppercase ${p.isVerified ? 'bg-brand-gold/20 text-brand-gold' : 'bg-gray-100 text-gray-600'}`}>
                                        {p.isVerified ? 'Verified' : 'Pending'}
                                    </button>
                                </td>
                                <td className="px-6 py-4 flex justify-center gap-2">
                                    <Button size="sm" variant="outline" className="p-2 hover:bg-red-500 hover:text-white" onClick={() => handleDelete(p.id)} title="Remove"><TrashIcon className="w-4 h-4" /></Button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            {showAddModal && <AddProductModal onClose={() => setShowAddModal(false)} onAdd={handleAdd} />}
        </div>
    );
};

export default AdminProductManager;
