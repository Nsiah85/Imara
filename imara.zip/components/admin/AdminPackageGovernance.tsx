
import React, { useState, useEffect } from 'react';
import Button from '../ui/Button.tsx';
import { SparklesIcon, PhotoIcon, CheckCircleIcon, ClockIcon, BoltIcon } from '../icons/Icons.tsx';
import { useDataSync } from '../../contexts/DataSyncContext.tsx';

const STORAGE_KEY = 'imara_package_governance';

interface PackageVitals {
    imageQuality: 'Standard' | 'Ultra';
    maxPostsPerMonth: number;
    profileEditCooldown: number; // in hours
    autoVerification: boolean;
    uploadRangeLimit: number;
}

const AdminPackageGovernance: React.FC = () => {
    const { saveData, getData } = useDataSync();
    const [vitals, setVitals] = useState<PackageVitals>({
        imageQuality: 'Ultra',
        maxPostsPerMonth: 20,
        profileEditCooldown: 48,
        autoVerification: false,
        uploadRangeLimit: 10,
    });
    const [isSaving, setIsSaving] = useState(false);
    const [isSaved, setIsSaved] = useState(false);

    useEffect(() => {
        const stored = getData('system/governance');
        if (stored) {
            setVitals(stored);
        } else {
             // Fallback
             const ls = localStorage.getItem(STORAGE_KEY);
             if (ls) setVitals(JSON.parse(ls));
        }
    }, [getData]);

    const handleSave = () => {
        setIsSaving(true);
        saveData('system/governance', 'config', vitals);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(vitals));
        
        setTimeout(() => {
            setIsSaving(false);
            setIsSaved(true);
            setTimeout(() => setIsSaved(false), 2000);
        }, 800);
    };

    const inputClass = "w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-brand-gold outline-none dark:bg-gray-800 dark:border-gray-700 dark:text-white";

    return (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-[40px] shadow-sm border border-gray-100 dark:border-gray-700 h-full flex flex-col">
            <h3 className="text-xl font-display font-black text-brand-navy-dark dark:text-white mb-6 flex items-center gap-2">
                <SparklesIcon className="w-6 h-6 text-brand-gold"/> Package Vitals & IQ
            </h3>
            
            <div className="space-y-5 flex-grow">
                <div>
                    <label className="block text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-2 ml-1">AI Image Priority (IQ)</label>
                    <div className="grid grid-cols-2 gap-3">
                        <button 
                            onClick={() => setVitals({...vitals, imageQuality: 'Standard'})}
                            className={`p-4 rounded-2xl border-2 flex flex-col items-center gap-2 transition-all ${vitals.imageQuality === 'Standard' ? 'border-brand-navy bg-gray-50 dark:bg-gray-900' : 'border-gray-100 dark:border-gray-700 text-gray-400'}`}
                        >
                            <BoltIcon className="w-5 h-5"/>
                            <span className="text-xs font-bold">Standard (Flash)</span>
                        </button>
                        <button 
                            onClick={() => setVitals({...vitals, imageQuality: 'Ultra'})}
                            className={`p-4 rounded-2xl border-2 flex flex-col items-center gap-2 transition-all ${vitals.imageQuality === 'Ultra' ? 'border-brand-gold bg-brand-gold/5' : 'border-gray-100 dark:border-gray-700 text-gray-400'}`}
                        >
                            <SparklesIcon className="w-5 h-5"/>
                            <span className="text-xs font-bold text-brand-gold">Ultra (Pro)</span>
                        </button>
                    </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 ml-1">Post Max / Mo</label>
                        <input type="number" value={vitals.maxPostsPerMonth} onChange={e => setVitals({...vitals, maxPostsPerMonth: parseInt(e.target.value)})} className={inputClass} />
                    </div>
                    <div>
                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 ml-1">Upload Range</label>
                        <input type="number" value={vitals.uploadRangeLimit} onChange={e => setVitals({...vitals, uploadRangeLimit: parseInt(e.target.value)})} className={inputClass} />
                    </div>
                </div>

                <div className="grid grid-cols-1 gap-4">
                    <div>
                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 ml-1">Edit Cooldown (Hrs)</label>
                        <div className="relative">
                            <input type="number" value={vitals.profileEditCooldown} onChange={e => setVitals({...vitals, profileEditCooldown: parseInt(e.target.value)})} className={inputClass} />
                            <ClockIcon className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-300" />
                        </div>
                    </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl">
                    <div>
                        <p className="text-xs font-bold text-brand-navy-dark dark:text-white">Auto-Verification</p>
                        <p className="text-[10px] text-gray-400">Instantly verify new Partner applications</p>
                    </div>
                    <button 
                        onClick={() => setVitals({...vitals, autoVerification: !vitals.autoVerification})}
                        className={`w-12 h-6 rounded-full transition-all relative ${vitals.autoVerification ? 'bg-brand-green' : 'bg-gray-300'}`}
                    >
                        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${vitals.autoVerification ? 'left-7' : 'left-1'}`}></div>
                    </button>
                </div>
            </div>

            <div className="pt-8 border-t border-gray-50 dark:border-gray-700 flex items-center justify-between">
                <Button onClick={handleSave} className="!rounded-2xl !px-10" disabled={isSaving}>
                     {isSaving ? 'Governing...' : isSaved ? <span className="flex items-center gap-2"><CheckCircleIcon className="w-4 h-4"/> Calibrated</span> : "Govern Vitals"}
                </Button>
            </div>
        </div>
    );
};

export default AdminPackageGovernance;
