
import React, { useState } from 'react';
import type { BrandProfile } from '../../types';
import Button from '../ui/Button.tsx';
import Avatar from '../ui/Avatar.tsx';
import { EditIcon, TrashIcon, PlusIcon, VerifiedBadgeIcon } from '../icons/Icons.tsx';

const BRAND_PROFILES_STORAGE_KEY = 'imara_brand_profiles';

interface AdminBrandProfileManagerProps {
    profiles: BrandProfile[];
    setProfiles: React.Dispatch<React.SetStateAction<BrandProfile[]>>;
}

const AdminBrandProfileManager: React.FC<AdminBrandProfileManagerProps> = ({ profiles, setProfiles }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [currentProfile, setCurrentProfile] = useState<Partial<BrandProfile>>({});

    const handleSaveToLocalStorage = (updatedProfiles: BrandProfile[]) => {
        try {
            localStorage.setItem(BRAND_PROFILES_STORAGE_KEY, JSON.stringify(updatedProfiles));
        } catch (error) {
            console.error("Failed to save brand profiles", error);
        }
    };

    const handleEdit = (profile: BrandProfile) => {
        setCurrentProfile(profile);
        setIsEditing(true);
    };

    const handleAddNew = () => {
        setCurrentProfile({
            role: 'admin',
            isVerified: true,
            name: '',
            bio: '',
            avatarUrl: '',
            coverImageUrl: ''
        });
        setIsEditing(true);
    };

    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        if (!currentProfile.name) return;

        const newProfile: BrandProfile = {
            id: currentProfile.id || `imara_${currentProfile.name.toLowerCase().replace(/\s+/g, '_')}`,
            name: currentProfile.name,
            avatarUrl: currentProfile.avatarUrl || `https://picsum.photos/seed/${currentProfile.name}/200`,
            coverImageUrl: currentProfile.coverImageUrl || `https://picsum.photos/seed/${currentProfile.name}_cover/800/300`,
            profileLink: `/user/${currentProfile.id || `imara_${currentProfile.name.toLowerCase().replace(/\s+/g, '_')}`}`,
            role: 'admin',
            isVerified: true,
            bio: currentProfile.bio
        };

        let updatedProfiles;
        if (currentProfile.id) {
            updatedProfiles = profiles.map(p => p.id === currentProfile.id ? newProfile : p);
        } else {
            updatedProfiles = [...profiles, newProfile];
        }

        setProfiles(updatedProfiles);
        handleSaveToLocalStorage(updatedProfiles);
        setIsEditing(false);
    };
    
    const handleDeleteProfile = (id: string) => {
        if (window.confirm("Are you sure you want to delete this profile?")) {
            const updatedProfiles = profiles.filter(p => p.id !== id);
            setProfiles(updatedProfiles);
            handleSaveToLocalStorage(updatedProfiles);
        }
    };

    if (isEditing) {
        return (
            <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-display font-semibold text-brand-navy-dark mb-4">{currentProfile.id ? 'Edit' : 'Create'} Brand Profile</h3>
                <form onSubmit={handleSave} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Profile Name</label>
                        <input type="text" value={currentProfile.name || ''} onChange={e => setCurrentProfile({...currentProfile, name: e.target.value})} className="mt-1 w-full p-2 border rounded-md" required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Bio / Tagline</label>
                        <textarea value={currentProfile.bio || ''} onChange={e => setCurrentProfile({...currentProfile, bio: e.target.value})} className="mt-1 w-full p-2 border rounded-md" rows={3} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Avatar URL</label>
                            <input type="text" value={currentProfile.avatarUrl || ''} onChange={e => setCurrentProfile({...currentProfile, avatarUrl: e.target.value})} className="mt-1 w-full p-2 border rounded-md" placeholder="https://..." />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Cover Image URL</label>
                            <input type="text" value={currentProfile.coverImageUrl || ''} onChange={e => setCurrentProfile({...currentProfile, coverImageUrl: e.target.value})} className="mt-1 w-full p-2 border rounded-md" placeholder="https://..." />
                        </div>
                    </div>
                    <div className="flex justify-end gap-2 mt-4">
                        <Button type="button" variant="outline" onClick={() => setIsEditing(false)}>Cancel</Button>
                        <Button type="submit">Save Profile</Button>
                    </div>
                </form>
            </div>
        )
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h3 className="text-xl font-display font-semibold text-brand-navy-dark">Manage Brand Profiles</h3>
                <Button size="sm" onClick={handleAddNew} className="flex items-center gap-2"><PlusIcon className="w-4 h-4"/> Add New</Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {profiles.map(profile => (
                    <div key={profile.id} className="bg-white rounded-lg shadow overflow-hidden group border border-gray-200">
                        <div className="h-24 bg-gray-200 relative">
                            <img src={profile.coverImageUrl || `https://picsum.photos/seed/${profile.id}/400/150`} alt="Cover" className="w-full h-full object-cover" />
                            <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button onClick={() => handleEdit(profile)} className="p-1.5 bg-white rounded-full shadow hover:text-brand-gold"><EditIcon className="w-4 h-4"/></button>
                                <button onClick={() => handleDeleteProfile(profile.id)} className="p-1.5 bg-white rounded-full shadow hover:text-red-500"><TrashIcon className="w-4 h-4"/></button>
                            </div>
                        </div>
                        <div className="px-4 pb-4">
                            <div className="relative -mt-8 mb-2">
                                <Avatar imageUrl={profile.avatarUrl} name={profile.name} className="w-16 h-16 rounded-full border-4 border-white shadow-sm" />
                            </div>
                            <div className="flex items-center gap-1 mb-1">
                                <h4 className="font-bold text-brand-navy-dark">{profile.name}</h4>
                                <VerifiedBadgeIcon className="w-4 h-4 text-brand-gold" />
                            </div>
                            <p className="text-xs text-gray-500 line-clamp-2 min-h-[2.5em]">{profile.bio || "No bio set."}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default AdminBrandProfileManager;
