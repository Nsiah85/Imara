
import React, { useState, useEffect, useMemo } from 'react';
import type { Partner } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { EditIcon, TrashIcon, VerifiedBadgeIcon, PlusCircleIcon } from '../icons/Icons.tsx';
import AddPartnerModal from './AddPartnerModal.tsx';
import { db, collection, onSnapshot, setDoc, doc, updateDoc } from '../../firebase/firestore.ts';

const AdminPartnerManager: React.FC = () => {
    const [partners, setPartners] = useState<Partner[]>([]);
    const [filter, setFilter] = useState<'all' | 'vendor' | 'workman' | 'travel'>('all');
    const [showAddModal, setShowAddModal] = useState(false);

    useEffect(() => {
        const unsubscribe = onSnapshot(collection(db, 'users'), (snapshot) => {
            const allUsers = snapshot.docs.map(doc => doc.data() as any);
            const loadedPartners = allUsers.filter(u => ['vendor', 'workman', 'travel'].includes(u.role)) as Partner[];
            setPartners(loadedPartners);
        }, (error) => {
            console.error("Failed to load partners", error);
        });
        return () => unsubscribe();
    }, []);

    const filteredPartners = useMemo(() => {
        if (filter === 'all') return partners;
        return partners.filter(p => p.role === filter);
    }, [partners, filter]);
    
    const handleRemove = async (partnerId: string) => {
        if (window.confirm("Are you sure you want to remove this partner? This action is critical.")) {
             await updateDoc(doc(db, 'users', partnerId), { accountFlagged: true });
        }
    };

    const handleToggleVerification = async (partnerId: string) => {
        const p = partners.find(p => p.id === partnerId);
        if (p) {
             await updateDoc(doc(db, 'users', partnerId), { isVerified: !p.isVerified });
        }
    };

    const handleAdd = async (newPartner: Partner) => {
        await setDoc(doc(db, 'users', newPartner.id), newPartner);
        setShowAddModal(false);
    };

    const handleEdit = (partnerId: string) => {
        const pName = window.prompt("Enter new name:", partners.find(p => p.id === partnerId)?.name);
        if (pName) {
            savePartners(partners.map(p => p.id === partnerId ? { ...p, name: pName, brandName: pName } : p));
        }
    };

    const getPlanName = (planId?: string) => {
        if (!planId) return <span className="text-gray-400">N/A</span>;
        const isPro = planId.includes('_pro');
        const planType = isPro ? 'Pro' : 'Basic';
        const color = isPro ? 'text-brand-gold font-semibold' : 'text-gray-600';
        return <span className={color}>{planType}</span>;
    };

    return (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-display font-semibold text-brand-navy-dark dark:text-white">Partner Management ({filteredPartners.length})</h3>
                <Button size="sm" onClick={handleAdd} className="flex items-center gap-2"><PlusCircleIcon className="w-4 h-4"/> Add Partner</Button>
            </div>
            <div className="flex flex-wrap gap-2 mb-4">
                <Button variant={filter === 'all' ? 'primary' : 'outline'} size="sm" onClick={() => setFilter('all')}>All</Button>
                <Button variant={filter === 'vendor' ? 'primary' : 'outline'} size="sm" onClick={() => setFilter('vendor')}>Vendors</Button>
                <Button variant={filter === 'workman' ? 'primary' : 'outline'} size="sm" onClick={() => setFilter('workman')}>Workers</Button>
                <Button variant={filter === 'travel' ? 'primary' : 'outline'} size="sm" onClick={() => setFilter('travel')}>Travel</Button>
            </div>
            
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-500">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-900 dark:text-gray-400">
                        <tr>
                            <th scope="col" className="px-6 py-3">Name / Brand</th>
                            <th scope="col" className="px-6 py-3">Role</th>
                            <th scope="col" className="px-6 py-3">Email</th>
                            <th scope="col" className="px-6 py-3">Subscription</th>
                            <th scope="col" className="px-6 py-3">Verified</th>
                            <th scope="col" className="px-6 py-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredPartners.map(partner => (
                            <tr key={partner.id} className="bg-white border-b hover:bg-gray-50 dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700">
                                <td className="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                                    {partner.role === 'workman' ? partner.name : partner.brandName}
                                </td>
                                <td className="px-6 py-4 capitalize">{partner.role}</td>
                                <td className="px-6 py-4">{partner.email}</td>
                                <td className="px-6 py-4">
                                    {getPlanName(partner.subscriptionPlanId)}
                                </td>
                                <td className="px-6 py-4">
                                    {partner.isVerified ? 
                                        <span className="flex items-center gap-1 text-brand-gold"><VerifiedBadgeIcon className="w-5 h-5"/> Yes</span> : 
                                        <span className="text-gray-400">No</span>
                                    }
                                </td>
                                <td className="px-6 py-4 flex items-center gap-2">
                                    <button 
                                        className={`p-2 text-gray-500 rounded-md hover:bg-gray-200 dark:hover:bg-gray-600 ${partner.isVerified ? 'text-brand-gold' : 'text-gray-400'}`} 
                                        onClick={() => handleToggleVerification(partner.id)}
                                        title={partner.isVerified ? "Unverify Partner" : "Verify Partner"}
                                    >
                                        <VerifiedBadgeIcon className="w-5 h-5" />
                                    </button>
                                    <button className="p-2 text-gray-500 hover:text-brand-gold rounded-md hover:bg-gray-200 dark:hover:bg-gray-600" onClick={() => handleEdit(partner.id)} title="Edit partner details"><EditIcon className="w-5 h-5" /></button>
                                    <button className="p-2 text-gray-500 hover:text-red-500 rounded-md hover:bg-gray-200 dark:hover:bg-gray-600" onClick={() => handleRemove(partner.id)} title="Remove partner"><TrashIcon className="w-5 h-5" /></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                 {filteredPartners.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                        No partners found for this filter.
                    </div>
                )}
            </div>
            {showAddModal && <AddPartnerModal onClose={() => setShowAddModal(false)} onAdd={handleAdd} />}
        </div>
    );
};

export default AdminPartnerManager;
