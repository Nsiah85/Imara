
import React, { useState, useEffect } from 'react';
import Button from '../ui/Button.tsx';
import { TruckIcon, GlobeIcon, CheckCircleIcon, PlusIcon, TrashIcon } from '../icons/Icons.tsx';
import { useDataSync } from '../../contexts/DataSyncContext.tsx';

interface DeliveryRegion {
    id: string;
    name: string;
    price: number;
}

const STORAGE_KEY = 'imara_delivery_config';

const AdminDeliverySettings: React.FC = () => {
    const { saveData, getData } = useDataSync();
    const [settings, setSettings] = useState({
        baseRate: 15,
        commission: 5,
        regions: [
            { id: '1', name: 'Greater Accra', price: 20 },
            { id: '2', name: 'Kumasi / Ashanti', price: 35 },
            { id: '3', name: 'Lagos (Island)', price: 40 },
            { id: '4', name: 'Lagos (Mainland)', price: 30 }
        ] as DeliveryRegion[]
    });
    const [isSaving, setIsSaving] = useState(false);
    const [isSaved, setIsSaved] = useState(false);
    const [newRegionName, setNewRegionName] = useState('');

    useEffect(() => {
        const stored = getData('system/delivery');
        if (stored) {
            setSettings(stored);
        } else {
             const ls = localStorage.getItem(STORAGE_KEY);
             if (ls) setSettings(JSON.parse(ls));
        }
    }, [getData]);

    const handleSave = () => {
        setIsSaving(true);
        saveData('system/delivery', 'config', settings);
        
        setTimeout(() => {
            setIsSaving(false);
            setIsSaved(true);
            setTimeout(() => setIsSaved(false), 2000);
        }, 800);
    };

    const updateRegionPrice = (index: number, val: number) => {
        const newRegions = [...settings.regions];
        newRegions[index].price = val;
        setSettings({...settings, regions: newRegions});
    };

    const addRegion = () => {
        if (!newRegionName.trim()) return;
        const newRegion = { id: crypto.randomUUID(), name: newRegionName, price: settings.baseRate };
        setSettings(prev => ({ ...prev, regions: [...prev.regions, newRegion] }));
        setNewRegionName('');
    };

    const removeRegion = (id: string) => {
        setSettings(prev => ({ ...prev, regions: prev.regions.filter(r => r.id !== id) }));
    };

    return (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-[40px] shadow-sm border border-gray-100 dark:border-gray-700 h-full">
            <h3 className="text-xl font-display font-black text-brand-navy-dark dark:text-white mb-6 flex items-center gap-2">
                <TruckIcon className="w-6 h-6 text-brand-gold"/> Delivery & Fulfillment
            </h3>

            <div className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                    <div>
                        <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Base Rate ($)</label>
                        <input 
                            type="number" 
                            value={settings.baseRate}
                            onChange={e => setSettings({...settings, baseRate: Number(e.target.value)})}
                            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl font-bold text-brand-navy-dark outline-none focus:border-brand-gold dark:bg-gray-900 dark:border-gray-700 dark:text-white"
                        />
                    </div>
                     <div>
                        <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Platform Fee (%)</label>
                        <input 
                            type="number" 
                            value={settings.commission}
                            onChange={e => setSettings({...settings, commission: Number(e.target.value)})}
                            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl font-bold text-brand-navy-dark outline-none focus:border-brand-gold dark:bg-gray-900 dark:border-gray-700 dark:text-white"
                        />
                    </div>
                </div>

                <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-3">Regional Pricing</label>
                    
                    <div className="flex gap-2 mb-4">
                        <input 
                            type="text" 
                            value={newRegionName} 
                            onChange={e => setNewRegionName(e.target.value)} 
                            placeholder="New Region Name..." 
                            className="flex-1 p-2 bg-gray-50 border border-gray-200 rounded-xl text-sm dark:bg-gray-900 dark:border-gray-700 dark:text-white"
                        />
                        <button onClick={addRegion} className="p-2 bg-brand-navy-dark text-white rounded-xl"><PlusIcon className="w-5 h-5"/></button>
                    </div>

                    <div className="space-y-3 max-h-60 overflow-y-auto pr-2 custom-scrollbar">
                        {settings.regions.map((region, idx) => (
                            <div key={region.id} className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-700">
                                <div className="flex items-center gap-2">
                                    <GlobeIcon className="w-4 h-4 text-gray-400"/>
                                    <span className="font-bold text-sm text-gray-700 dark:text-gray-300">{region.name}</span>
                                </div>
                                <div className="flex items-center gap-3">
                                    <div className="flex items-center gap-1">
                                        <span className="text-xs text-gray-400">$</span>
                                        <input 
                                            type="number" 
                                            value={region.price} 
                                            onChange={e => updateRegionPrice(idx, Number(e.target.value))}
                                            className="w-16 p-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded text-right font-mono text-sm dark:text-white"
                                        />
                                    </div>
                                    <button onClick={() => removeRegion(region.id)} className="text-red-400 hover:text-red-600"><TrashIcon className="w-4 h-4"/></button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="pt-4 border-t border-gray-100 dark:border-gray-700 flex justify-end">
                     <Button onClick={handleSave} className="!rounded-2xl min-w-[140px]" disabled={isSaving}>
                        {isSaving ? 'Updating...' : isSaved ? <span className="flex items-center gap-2"><CheckCircleIcon className="w-4 h-4"/> Saved</span> : "Update Rates"}
                    </Button>
                </div>
            </div>
        </div>
    );
};

export default AdminDeliverySettings;
