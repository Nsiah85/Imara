
import React, { useState, useEffect } from 'react';
import Button from '../ui/Button.tsx';
import { Cog6ToothIcon, CheckCircleIcon, LockClosedIcon, ShieldCheckIcon, WhatsAppIcon, CreditCardIcon, EyeIcon } from '../icons/Icons.tsx';
import { useDataSync } from '../../contexts/DataSyncContext.tsx';

const STORAGE_KEY = 'imara_system_config';

interface PlatformConfig {
    mode: 'demo' | 'public';
    paystack: {
        publicKey: string;
        secretKey: string;
        webhookUrl: string;
    };
    whatsapp: {
        businessNumber: string;
        autoGreeting: string;
    };
    delivery: {
        baseRate: number;
        commissionPercentage: number;
    };
}

const AdminPlatformConfig: React.FC = () => {
    const { saveData, getData } = useDataSync();
    const [config, setConfig] = useState<PlatformConfig>({
        mode: 'demo',
        paystack: { publicKey: '', secretKey: '', webhookUrl: '' },
        whatsapp: { businessNumber: '', autoGreeting: 'Akwaaba! How can we help?' },
        delivery: { baseRate: 15, commissionPercentage: 5 }
    });
    const [isSaving, setIsSaving] = useState(false);
    const [isSaved, setIsSaved] = useState(false);
    const [showSecrets, setShowSecrets] = useState(false);

    useEffect(() => {
        const stored = getData('system/platform');
        if (stored) {
            setConfig(stored);
        } else {
             const ls = localStorage.getItem(STORAGE_KEY);
             if (ls) setConfig(JSON.parse(ls));
        }
    }, [getData]);

    const handleSave = () => {
        setIsSaving(true);
        
        saveData('system/platform', 'config', config);
        
        // Audit log simulation
        const logs = JSON.parse(localStorage.getItem('imara_audit_logs') || '[]');
        logs.push({
            id: crypto.randomUUID(),
            action: 'Updated Platform Config',
            timestamp: new Date().toISOString(),
            metadata: { mode: config.mode }
        });
        localStorage.setItem('imara_audit_logs', JSON.stringify(logs));

        setTimeout(() => {
            setIsSaving(false);
            setIsSaved(true);
            setTimeout(() => setIsSaved(false), 2000);
        }, 800);
    };

    const handleModeToggle = (mode: 'demo' | 'public') => {
        if (mode === 'public' && config.mode !== 'public') {
            if (window.confirm("WARNING: You are about to switch to PUBLIC LIVE mode. Real payments will be processed. Are you sure?")) {
                 setConfig({...config, mode: 'public'});
            }
        } else {
            setConfig({...config, mode: 'demo'});
        }
    };

    const inputClass = "w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl p-3 text-sm focus:ring-2 focus:ring-brand-gold outline-none dark:text-white transition-all";

    return (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-[40px] shadow-sm border border-gray-100 dark:border-gray-700 space-y-8">
            <h3 className="text-xl font-display font-black text-brand-navy-dark dark:text-white flex items-center gap-2">
                <Cog6ToothIcon className="w-6 h-6 text-brand-gold"/> Platform Control
            </h3>

            {/* Platform Mode */}
            <div className="bg-gray-50 dark:bg-gray-900 p-6 rounded-3xl border border-gray-100 dark:border-gray-700">
                <div className="flex justify-between items-center mb-4">
                    <h4 className="font-bold text-brand-navy-dark dark:text-white">Environment Mode</h4>
                    <span className={`px-3 py-1 rounded-full text-xs font-black uppercase ${config.mode === 'public' ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                        {config.mode === 'public' ? 'Live Production' : 'Demo / Sandbox'}
                    </span>
                </div>
                <div className="flex gap-4">
                    <button 
                        onClick={() => handleModeToggle('demo')}
                        className={`flex-1 p-4 rounded-xl border-2 transition-all ${config.mode === 'demo' ? 'border-brand-green bg-brand-green/5' : 'border-transparent bg-white dark:bg-gray-800'}`}
                    >
                        <p className="font-bold text-brand-green">Demo Mode</p>
                        <p className="text-xs text-gray-500">Test payments, mock data.</p>
                    </button>
                    <button 
                        onClick={() => handleModeToggle('public')}
                        className={`flex-1 p-4 rounded-xl border-2 transition-all ${config.mode === 'public' ? 'border-red-500 bg-red-50' : 'border-transparent bg-white dark:bg-gray-800'}`}
                    >
                        <p className="font-bold text-red-600">Public Mode</p>
                        <p className="text-xs text-gray-500">Real money, live users.</p>
                    </button>
                </div>
            </div>

            {/* Paystack Config */}
            <div className="space-y-4">
                <h4 className="font-bold text-brand-navy-dark dark:text-white flex items-center gap-2">
                    <CreditCardIcon className="w-5 h-5 text-gray-400"/> Payment Gateway (Paystack)
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="text-xs font-bold text-gray-500 uppercase">Public Key</label>
                        <input 
                            type="text" 
                            value={config.paystack.publicKey}
                            onChange={e => setConfig({...config, paystack: {...config.paystack, publicKey: e.target.value}})}
                            className={inputClass}
                            placeholder="pk_test_..."
                        />
                    </div>
                    <div className="relative">
                        <label className="text-xs font-bold text-gray-500 uppercase">Secret Key</label>
                        <input 
                            type={showSecrets ? "text" : "password"} 
                            value={config.paystack.secretKey}
                            onChange={e => setConfig({...config, paystack: {...config.paystack, secretKey: e.target.value}})}
                            className={inputClass}
                            placeholder="sk_test_..."
                        />
                        <button 
                            type="button"
                            onClick={() => setShowSecrets(!showSecrets)} 
                            className="absolute right-3 top-7 p-1 text-gray-400 hover:text-brand-gold transition-colors"
                        >
                            {showSecrets ? <LockClosedIcon className="w-4 h-4"/> : <EyeIcon className="w-4 h-4"/>}
                        </button>
                    </div>
                    <div className="md:col-span-2">
                        <label className="text-xs font-bold text-gray-500 uppercase">Webhook URL</label>
                        <input 
                            type="text" 
                            value={config.paystack.webhookUrl}
                            onChange={e => setConfig({...config, paystack: {...config.paystack, webhookUrl: e.target.value}})}
                            className={inputClass}
                        />
                    </div>
                </div>
            </div>

            {/* WhatsApp Config */}
             <div className="space-y-4">
                <h4 className="font-bold text-brand-navy-dark dark:text-white flex items-center gap-2">
                    <WhatsAppIcon className="w-5 h-5 text-green-500"/> WhatsApp Business
                </h4>
                <div className="grid grid-cols-1 gap-4">
                    <div>
                        <label className="text-xs font-bold text-gray-500 uppercase">Business Number</label>
                        <input 
                            type="text" 
                            value={config.whatsapp.businessNumber}
                            onChange={e => setConfig({...config, whatsapp: {...config.whatsapp, businessNumber: e.target.value}})}
                            className={inputClass}
                            placeholder="+233..."
                        />
                    </div>
                </div>
            </div>

            <div className="pt-4 border-t border-gray-100 dark:border-gray-700 flex justify-end">
                 <Button onClick={handleSave} className="!rounded-2xl shadow-xl min-w-[180px]" disabled={isSaving}>
                    {isSaving ? 'Processing...' : isSaved ? <span className="flex items-center gap-2"><CheckCircleIcon className="w-4 h-4"/> Configuration Saved</span> : "Update Configuration"}
                </Button>
            </div>
        </div>
    );
};

export default AdminPlatformConfig;
