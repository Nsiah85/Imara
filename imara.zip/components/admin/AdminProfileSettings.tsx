

import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext.tsx';
import Button from '../ui/Button.tsx';
import type { UserProfile } from '../../types.ts';

const AdminProfileSettings: React.FC = () => {
    const { user } = useAuth();
    const [profile, setProfile] = useState<Partial<UserProfile>>({});
    const [isSaved, setIsSaved] = useState(false);

    useEffect(() => {
        if (user) {
            setProfile({
                fullName: user.fullName,
                email: user.email,
            });
        }
    }, [user]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setProfile(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // In a real app, you would save this to the backend and update the AuthContext
        console.log("Saving admin profile:", profile);
        setIsSaved(true);
        setTimeout(() => setIsSaved(false), 3000);
    };
    
    const inputClass = "mt-1 block w-full bg-brand-off-white/80 border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent";

    if (!user) {
        return null;
    }

    return (
        <div className="bg-white p-6 rounded-lg shadow-md max-w-2xl">
            <h3 className="text-xl font-display font-semibold text-brand-green-dark mb-1">Admin Profile</h3>
            <p className="text-gray-500 mb-6 text-sm">Manage your administrator account details.</p>

            <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label htmlFor="fullName" className="block text-sm font-medium text-gray-700">Full Name</label>
                        <input
                            type="text"
                            name="fullName"
                            id="fullName"
                            value={profile.fullName || ''}
                            onChange={handleChange}
                            className={inputClass}
                        />
                    </div>
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email Address</label>
                        <input
                            type="email"
                            name="email"
                            id="email"
                            value={profile.email || ''}
                            onChange={handleChange}
                            className={inputClass}
                        />
                    </div>
                </div>
                 <div>
                    <label className="block text-sm font-medium text-gray-700">Change Password</label>
                    <input
                        type="password"
                        name="password"
                        id="password"
                        className={inputClass}
                        placeholder="Enter new password"
                    />
                </div>
                <div className="flex items-center gap-4">
                    <Button type="submit">Save Changes</Button>
                    {isSaved && <p className="text-sm text-green-600 animate-fade-in">Profile saved successfully!</p>}
                </div>
            </form>
        </div>
    );
};

export default AdminProfileSettings;