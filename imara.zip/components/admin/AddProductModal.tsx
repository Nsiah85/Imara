import React, { useState } from 'react';
import type { Product } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { XIcon } from '../icons/Icons.tsx';

interface AddProductModalProps {
    onClose: () => void;
    onAdd: (product: Product) => void;
}

const AddProductModal: React.FC<AddProductModalProps> = ({ onClose, onAdd }) => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [price, setPrice] = useState(0);
    const [category, setCategory] = useState('');
    const [vendor, setVendor] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const newProduct: Product = {
            id: crypto.randomUUID(),
            name,
            description,
            price,
            discountPrice: undefined,
            category,
            vendor,
            rating: 0,
            reviewsCount: 0,
            imageUrl: '',
            stock: 10,
        };
        onAdd(newProduct);
    };

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
            <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 max-w-md w-full relative shadow-2xl">
                <button onClick={onClose} className="absolute top-4 right-4 p-2 text-gray-500 hover:text-gray-900 dark:hover:text-white transition-colors cursor-pointer">
                    <XIcon className="w-5 h-5" />
                </button>
                <h3 className="text-2xl font-bold mb-6 text-brand-navy-dark dark:text-white">Add New Product</h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium mb-1 dark:text-gray-300">Product Name</label>
                        <input type="text" required value={name} onChange={e => setName(e.target.value)} className="w-full p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 dark:text-white focus:ring-2 focus:ring-brand-gold outline-none" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1 dark:text-gray-300">Description</label>
                        <textarea required value={description} onChange={e => setDescription(e.target.value)} className="w-full p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 dark:text-white focus:ring-2 focus:ring-brand-gold outline-none" rows={3}></textarea>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium mb-1 dark:text-gray-300">Price (Tts)</label>
                            <input type="number" required value={price} onChange={e => setPrice(Number(e.target.value))} className="w-full p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 dark:text-white focus:ring-2 focus:ring-brand-gold outline-none" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1 dark:text-gray-300">Category</label>
                            <input type="text" required value={category} onChange={e => setCategory(e.target.value)} className="w-full p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 dark:text-white focus:ring-2 focus:ring-brand-gold outline-none" />
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1 dark:text-gray-300">Vendor / Brand</label>
                        <input type="text" required value={vendor} onChange={e => setVendor(e.target.value)} className="w-full p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 dark:text-white focus:ring-2 focus:ring-brand-gold outline-none" />
                    </div>
                    <div className="pt-4">
                        <Button type="submit" className="w-full justify-center">Create Product</Button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddProductModal;
