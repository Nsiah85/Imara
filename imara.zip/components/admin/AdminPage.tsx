
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import type { PartnerApplication, Partner, UserProfile } from '../../types.ts';
import ApplicationReviewModal from '../modals/ApplicationReviewModal.tsx';
import AdminContentManager from './AdminContentManager.tsx';
import AdminSubscriptionManager from './AdminSubscriptionManager.tsx';
import AdminPartnerManager from './AdminPartnerManager.tsx';
import { mockVendors, mockProfessionals, mockTravelPartners, mockUsers } from '../../data/mockData.ts';
import FundsFlowCard from './FundsFlowCard.tsx';
import AdminProfileSettings from './AdminProfileSettings.tsx';
import AdminGiftCardManager from './AdminGiftCardManager.tsx';
import AdminEdwasoMarketManager from './AdminEdwasoMarketManager.tsx';
import SocialMediaManager from './SocialMediaManager.tsx';
import AdminLiveEventManager from './AdminLiveEventManager.tsx';
import AdminWhatsAppManager from './AdminWhatsAppManager.tsx';
import AdminPaymentGatewayManager from './AdminPaymentGatewayManager.tsx';
import AdminPackageGovernance from './AdminPackageGovernance.tsx';
import AdminGiftManager from './AdminGiftManager.tsx';
import GlobalUIConfig from './GlobalUIConfig.tsx';
import AdminOrderManager from './AdminOrderManager.tsx';
import AdminDeliverySettings from './AdminDeliverySettings.tsx';
import AdminPlatformConfig from './AdminPlatformConfig.tsx';
import Button from '../ui/Button.tsx';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';
import { useAuth } from '../../contexts/AuthContext.tsx';
import Avatar from '../ui/Avatar.tsx';
import LoadingSpinner from '../ui/LoadingSpinner.tsx';
import { 
    EyeIcon, ChartBarIcon, UsersIcon, 
    Cog6ToothIcon, VideoCameraIcon, 
    ShoppingBagIcon, Bars3Icon, 
    ArrowLeftIcon, SparklesIcon, BoltIcon, 
    ShieldCheckIcon, ExclamationTriangleIcon,
    HandCoinIcon, CheckCircleIcon
} from '../icons/Icons.tsx';

type AdminTab = 'command_center' | 'citizenship' | 'moderation' | 'market_ops' | 'impact_studio' | 'live_manager' | 'governance';

const CommandCenterOverview: React.FC = () => {
    return (
        <div className="space-y-10 animate-fade-in">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <FundsFlowCard title="Active Imarans" amount={186000.00} period="Live" change="+45" changeType="positive" />
                <FundsFlowCard title="Trade Volume" amount={127500.00} period="Today" change="+12%" changeType="positive" />
                <FundsFlowCard title="Security Score" amount={1470.00} period="Health" change="Optimal" changeType="positive" />
                <FundsFlowCard title="Market Reach" amount={1380.00} period="Index" change="+3" changeType="positive" />
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                    <AdminPlatformConfig />
                </div>
                <div className="space-y-8">
                     <div className="bg-white dark:bg-gray-800 p-8 rounded-[40px] border border-gray-100 dark:border-gray-700 flex flex-col justify-between shadow-sm">
                        <div>
                            <SparklesIcon className="w-12 h-12 text-brand-gold mb-4" />
                            <h4 className="text-2xl font-display font-black text-brand-navy-dark dark:text-white leading-tight uppercase tracking-tighter">Command Pulse <br/>Active</h4>
                            <p className="text-sm text-gray-500 dark:text-gray-400 mt-4 leading-relaxed font-medium">Platform performance is at 99.9%. All regional hubs connected.</p>
                        </div>
                        <Button className="w-full mt-8 !rounded-2xl" variant="outline">Analyze Logs</Button>
                    </div>
                </div>
            </div>
        </div>
    );
};

const AdminPage: React.FC = () => {
    const [activeTab, setActiveTab] = useState<AdminTab>('command_center');
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);
    const { user, isLoading } = useAuth();
    const { formatCurrency } = useCurrency();
    const navigate = useNavigate();
    const [applications, setApplications] = useState<PartnerApplication[]>([]);
    const [selectedApplication, setSelectedApplication] = useState<PartnerApplication | null>(null);
    const [partners, setPartners] = useState<Partner[]>([]);
    const [citizens, setCitizens] = useState<UserProfile[]>([]);

    useEffect(() => {
        if (!user && !isLoading) return;
        
        try {
            const storedApps = localStorage.getItem('imara_partner_applications');
            const parsedApps: PartnerApplication[] = storedApps ? JSON.parse(storedApps) : [];
            setApplications(parsedApps.filter((app) => app.status === 'pending'));

            const storedPartners = localStorage.getItem('partners');
            const approvedPartners: Partner[] = storedPartners ? JSON.parse(storedPartners) : [];
            const allPartners = [...mockVendors, ...mockProfessionals, ...mockTravelPartners, ...approvedPartners];
            setPartners(Array.from(new Map(allPartners.map(p => [p.id, p])).values()));

            const storedUsers = localStorage.getItem('imara_all_users');
            setCitizens(storedUsers ? JSON.parse(storedUsers) : mockUsers);
        } catch (error) {
            setPartners([...mockVendors, ...mockProfessionals, ...mockTravelPartners]);
        }
    }, [user, isLoading]);

    const handleApplicationDecision = (appId: string, decision: 'approved' | 'rejected') => {
        setApplications(prev => prev.filter(app => app.id !== appId));
        setSelectedApplication(null);
    };

    const NavItem = ({ id, icon, label }: { id: AdminTab; icon: React.ReactNode; label: string }) => (
        <button 
            onClick={() => setActiveTab(id)}
            className={`flex items-center gap-3 w-full p-4 rounded-2xl transition-all duration-300 ${activeTab === id ? 'bg-brand-gold text-brand-navy-dark shadow-xl scale-105' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
        >
            <div className="flex-shrink-0">{icon}</div>
            {isSidebarOpen && <span className="text-sm font-black uppercase tracking-widest whitespace-nowrap">{label.replace('_', ' ')}</span>}
        </button>
    );

    const renderTabContent = () => {
        switch (activeTab) {
            case 'command_center':
                return <CommandCenterOverview />;
            case 'citizenship':
                return (
                    <div className="space-y-10 animate-fade-in">
                        <div className="bg-white dark:bg-gray-800 p-8 rounded-[40px] border border-gray-100 dark:border-gray-700 shadow-sm">
                             <div className="flex justify-between items-center mb-8">
                                <h3 className="text-2xl font-display font-black text-brand-navy-dark dark:text-white uppercase tracking-tight">Citizen Directory</h3>
                                <div className="flex gap-2">
                                    <Button size="sm" variant="outline">Export CSV</Button>
                                    <Button size="sm">Audit All</Button>
                                </div>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                {citizens.slice(0, 6).map(c => (
                                    <div key={c.id} className="p-4 bg-gray-50 dark:bg-gray-900/50 rounded-2xl border border-gray-100 dark:border-gray-800 flex items-center gap-4 group hover:border-brand-gold transition-colors cursor-pointer shadow-sm">
                                        <Avatar imageUrl={c.profileImageUrl} name={c.fullName} className="w-12 h-12" />
                                        <div className="flex-grow min-w-0">
                                            <p className="font-bold text-sm text-brand-navy-dark dark:text-white truncate">{c.fullName}</p>
                                            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mt-0.5">{c.role} &middot; Trust {c.trustScore || 0}%</p>
                                        </div>
                                        <button className="p-2 opacity-0 group-hover:opacity-100 transition-opacity"><Cog6ToothIcon className="w-4 h-4 text-gray-400"/></button>
                                    </div>
                                ))}
                            </div>
                            <Button className="mt-8" variant="outline">Manage All Citizens</Button>
                        </div>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                             <AdminSubscriptionManager />
                             <AdminGiftManager />
                        </div>
                    </div>
                );
            case 'moderation':
                return (
                    <div className="space-y-8 animate-fade-in">
                        <div className="bg-brand-navy-dark p-10 rounded-[40px] text-white relative overflow-hidden">
                            <div className="relative z-10">
                                <h2 className="text-3xl font-display font-black mb-4 uppercase tracking-tighter">Safety Shield</h2>
                                <p className="text-gray-400 max-w-xl mb-6 font-medium">Monitoring 1.2k active Toasts. 98.4% precision on localized dialect flagging across all integrated African regions.</p>
                            </div>
                        </div>
                         <div className="bg-white dark:bg-gray-800 p-8 rounded-[40px] border border-gray-100 dark:border-gray-700 shadow-sm">
                            <h3 className="text-xl font-display font-black text-brand-navy-dark dark:text-white mb-6 uppercase tracking-tight">Partner Application Queue</h3>
                             {applications.length > 0 ? (
                                <ul className="space-y-4">
                                    {applications.map(app => (
                                        <li key={app.id} className="flex items-center justify-between p-5 bg-gray-50 dark:bg-gray-900 rounded-[32px] group hover:bg-gray-100 dark:hover:bg-black transition-all border border-transparent hover:border-brand-gold/30">
                                            <div>
                                                <p className="font-bold text-brand-navy-dark dark:text-white text-lg">{app.fullName}</p>
                                                <p className="text-xs text-gray-500 font-black uppercase tracking-widest mt-1">{app.brandName || app.industry} &middot; {app.role}</p>
                                            </div>
                                            <Button size="sm" onClick={() => setSelectedApplication(app)} className="!rounded-xl px-6">Review Portal</Button>
                                        </li>
                                    ))}
                                </ul>
                            ) : (
                                <div className="text-center py-20 text-gray-400">
                                    <CheckCircleIcon className="w-16 h-16 mx-auto mb-4 opacity-10"/>
                                    <p className="font-black uppercase tracking-[0.2em]">Queue Fully Audited</p>
                                </div>
                            )}
                        </div>
                    </div>
                );
            case 'market_ops':
                return (
                    <div className="space-y-8 animate-fade-in">
                        <AdminOrderManager />
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                             <AdminDeliverySettings />
                             <AdminEdwasoMarketManager />
                        </div>
                        <AdminPartnerManager partners={partners} onEditPartner={() => {}} onToggleVerification={() => {}} />
                    </div>
                );
            case 'governance':
                return (
                    <div className="space-y-10 animate-fade-in">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <AdminPackageGovernance />
                            <AdminPaymentGatewayManager />
                        </div>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <AdminWhatsAppManager />
                            <div className="space-y-8">
                                <AdminProfileSettings />
                                <SocialMediaManager />
                            </div>
                        </div>
                        <AdminGiftCardManager />
                    </div>
                );
             case 'impact_studio':
                return <AdminContentManager />;
            case 'live_manager':
                return <AdminLiveEventManager />;
            default:
                return <CommandCenterOverview />;
        }
    };

    if (isLoading) return <div className="h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-950"><LoadingSpinner /></div>;
    if (!user || user.role !== 'admin') return <div className="h-screen flex flex-col items-center justify-center p-8 bg-gray-50 text-center dark:bg-gray-900"><ExclamationTriangleIcon className="w-20 h-20 text-red-600 mb-4"/><h1 className="text-3xl font-black text-brand-navy-dark dark:text-white mb-4 uppercase">Restricted Access</h1><p className="text-gray-500 mb-8">Access to this sector is reserved for Platform Overseers only.</p><Button onClick={() => navigate('/')}>Return to Access</Button></div>;

    return (
        <div className="min-h-screen bg-[#F8FAFC] dark:bg-gray-950 flex font-sans">
            {/* Sidebar */}
            <aside className={`bg-brand-navy-dark text-white flex-shrink-0 transition-all duration-500 ${isSidebarOpen ? 'w-80' : 'w-24'} fixed h-full z-50 hidden lg:flex flex-col`}>
                 <div className="p-8 flex justify-between items-center border-b border-white/5">
                     {isSidebarOpen && (
                         <div className="flex items-center gap-3">
                            <ShieldCheckIcon className="w-8 h-8 text-brand-gold"/>
                            <div className="font-display font-black text-2xl tracking-tighter">IMARA<span className="text-brand-gold">.OPS</span></div>
                         </div>
                     )}
                     <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 rounded-xl bg-white/5 hover:bg-white/10">
                        {isSidebarOpen ? <ArrowLeftIcon className="w-4 h-4"/> : <Bars3Icon className="w-6 h-6"/>}
                     </button>
                 </div>
                 
                 <nav className="p-6 flex-grow space-y-2">
                     <NavItem id="command_center" icon={<ChartBarIcon className="w-6 h-6"/>} label="Command Center" />
                     <NavItem id="citizenship" icon={<UsersIcon className="w-6 h-6"/>} label="Citizenship" />
                     <NavItem id="moderation" icon={<ShieldCheckIcon className="w-6 h-6"/>} label="Safety Core" />
                     <NavItem id="market_ops" icon={<ShoppingBagIcon className="w-6 h-6"/>} label="Market Ops" />
                     <NavItem id="impact_studio" icon={<HandCoinIcon className="w-6 h-6"/>} label="Impact Hub" />
                     <NavItem id="live_manager" icon={<VideoCameraIcon className="w-6 h-6"/>} label="Live Desk" />
                     
                     <div className="my-10 border-t border-white/5 pt-10">
                        <NavItem id="governance" icon={<Cog6ToothIcon className="w-6 h-6"/>} label="Governance" />
                     </div>
                 </nav>

                 <div className="p-6 border-t border-white/5 bg-black/20">
                     <div className="flex items-center gap-4">
                         <Avatar name={user.fullName} id={user.id} imageUrl={user.profileImageUrl} className="w-12 h-12 rounded-2xl border-2 border-brand-gold" />
                         {isSidebarOpen && (
                             <div className="min-w-0">
                                 <p className="text-sm font-black text-white truncate">{user.fullName}</p>
                                 <p className="text-[10px] text-brand-gold font-bold uppercase tracking-widest">Platform Overseer</p>
                             </div>
                         )}
                     </div>
                 </div>
            </aside>

            {/* Main Content */}
            <main className={`flex-1 transition-all duration-500 ${isSidebarOpen ? 'lg:ml-80' : 'lg:ml-24'} p-4 md:p-10 mb-20 lg:mb-0`}>
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 gap-6">
                    <div className="animate-fade-in">
                        <h1 className="text-4xl md:text-5xl font-display font-black text-brand-navy-dark dark:text-white capitalize tracking-tighter">{activeTab.replace('_', ' ')}</h1>
                        <p className="text-gray-400 dark:text-gray-500 font-bold uppercase tracking-[0.2em] text-[10px] mt-1 flex items-center gap-2">
                             <div className="w-2 h-2 rounded-full bg-brand-green animate-pulse"></div> Authenticated: {user.fullName} &middot; Imara Platform Governance
                        </p>
                    </div>
                    <div className="flex gap-3">
                        <Button variant="outline" className="!rounded-2xl !px-8 flex items-center gap-2 !border-brand-green !text-brand-green hover:!bg-brand-green hover:!text-white transition-all shadow-sm"><EyeIcon className="w-4 h-4"/> System View</Button>
                        <Button className="!rounded-2xl !px-8 !bg-brand-navy-dark !border-none flex items-center gap-2 shadow-xl hover:scale-105 transition-transform"><BoltIcon className="w-4 h-4 text-brand-gold"/> Quick Action</Button>
                    </div>
                </div>

                <div className="max-w-7xl mx-auto pb-10">
                    {renderTabContent()}
                </div>
            </main>

            {/* Mobile Nav */}
            <div className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-white/80 dark:bg-gray-950/80 backdrop-blur-xl border-t border-gray-100 dark:border-gray-800 p-3 flex justify-around shadow-2xl safe-bottom">
                 <button onClick={() => setActiveTab('command_center')} className={`p-4 rounded-2xl transition-all ${activeTab === 'command_center' ? 'bg-brand-gold text-brand-navy-dark shadow-lg scale-110' : 'text-gray-400 hover:text-brand-navy-dark'}`}><ChartBarIcon className="w-6 h-6"/></button>
                 <button onClick={() => setActiveTab('citizenship')} className={`p-4 rounded-2xl transition-all ${activeTab === 'citizenship' ? 'bg-brand-gold text-brand-navy-dark shadow-lg scale-110' : 'text-gray-400 hover:text-brand-navy-dark'}`}><UsersIcon className="w-6 h-6"/></button>
                 <button onClick={() => setActiveTab('market_ops')} className={`p-4 rounded-2xl transition-all ${activeTab === 'market_ops' ? 'bg-brand-gold text-brand-navy-dark shadow-lg scale-110' : 'text-gray-400 hover:text-brand-navy-dark'}`}><ShoppingBagIcon className="w-6 h-6"/></button>
                 <button onClick={() => setActiveTab('governance')} className={`p-4 rounded-2xl transition-all ${activeTab === 'governance' ? 'bg-brand-gold text-brand-navy-dark shadow-lg scale-110' : 'text-gray-400 hover:text-brand-navy-dark'}`}><Cog6ToothIcon className="w-6 h-6"/></button>
            </div>

            {selectedApplication && (
                <ApplicationReviewModal
                    application={selectedApplication}
                    onClose={() => setSelectedApplication(null)}
                    onApprove={() => handleApplicationDecision(selectedApplication.id, 'approved')}
                    onReject={() => handleApplicationDecision(selectedApplication.id, 'rejected')}
                />
            )}
        </div>
    );
};

export default AdminPage;
