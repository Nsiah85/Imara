
import React, { useState, useEffect } from 'react';
import type { EdwasoMarket } from '../../types.ts';
import { mockEdwasoMarkets } from '../../data/mockData.ts';
import Button from '../ui/Button.tsx';
import { EditIcon, TrashIcon, PlusCircleIcon } from '../icons/Icons.tsx';
import EdwasoMarketEditModal from '../modals/EdwasoMarketEditModal.tsx';

const STORAGE_KEY = 'edwaso_markets';

const AdminEdwasoMarketManager: React.FC = () => {
    const [markets, setMarkets] = useState<EdwasoMarket[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingMarket, setEditingMarket] = useState<Partial<EdwasoMarket> | null>(null);

    useEffect(() => {
        try {
            const storedMarkets = localStorage.getItem(STORAGE_KEY);
            const initialMarkets = storedMarkets ? JSON.parse(storedMarkets) : mockEdwasoMarkets;
            setMarkets(initialMarkets);
        } catch (error) {
            console.error("Failed to load markets from localStorage", error);
            setMarkets(mockEdwasoMarkets);
        }
    }, []);

    const handleSaveToLocalStorage = (updatedMarkets: EdwasoMarket[]) => {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedMarkets));
        } catch (error) {
            console.error("Failed to save markets", error);
        }
    };

    const handleOpenModal = (market: Partial<EdwasoMarket> | null) => {
        setEditingMarket(market);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingMarket(null);
    };

    const handleSaveMarket = (marketData: EdwasoMarket) => {
        const newMarkets = editingMarket?.id
            ? markets.map(m => m.id === marketData.id ? marketData : m)
            : [...markets, { ...marketData, id: crypto.randomUUID() }];
        setMarkets(newMarkets);
        handleSaveToLocalStorage(newMarkets);
        handleCloseModal();
    };

    const handleDelete = (id: string) => {
        if (window.confirm("Are you sure you want to delete this market? This cannot be undone.")) {
            const updated = markets.filter(m => m.id !== id);
            setMarkets(updated);
            handleSaveToLocalStorage(updated);
        }
    };

    return (
        <>
            <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-display font-semibold text-brand-navy-dark">Edwaso Market Management</h3>
                    <Button size="sm" variant="primary" className="flex items-center gap-2" onClick={() => handleOpenModal({})}>
                        <PlusCircleIcon className="w-5 h-5" /> Add New Market
                    </Button>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3">Market Name</th>
                                <th scope="col" className="px-6 py-3">Country</th>
                                <th scope="col" className="px-6 py-3">Region</th>
                                <th scope="col" className="px-6 py-3">Market ID</th>
                                <th scope="col" className="px-6 py-3 text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {markets.map(market => (
                                <tr key={market.id} className="bg-white border-b hover:bg-gray-50">
                                    <td className="px-6 py-4 font-medium text-gray-900">{market.name}</td>
                                    <td className="px-6 py-4">{market.country}</td>
                                    <td className="px-6 py-4">{market.region}</td>
                                    <td className="px-6 py-4 font-mono text-xs">{market.id}</td>
                                    <td className="px-6 py-4 flex justify-center gap-2">
                                        <Button size="sm" variant="outline" className="p-2" onClick={() => handleOpenModal(market)} aria-label={`Edit ${market.name}`}><EditIcon className="w-4 h-4" /></Button>
                                        <Button size="sm" variant="outline" className="p-2 hover:bg-red-500 hover:text-white" onClick={() => handleDelete(market.id)} aria-label={`Delete ${market.name}`}><TrashIcon className="w-4 h-4" /></Button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            {isModalOpen && (
                <EdwasoMarketEditModal market={editingMarket} onClose={handleCloseModal} onSave={handleSaveMarket} />
            )}
        </>
    );
};

export default AdminEdwasoMarketManager;
