
import React, { useState, useEffect } from 'react';
import type { AdminLiveEventSettings } from '../../types';
import Button from '../ui/Button';
import { useDataSync } from '../../contexts/DataSyncContext.tsx';

const STORAGE_KEY = 'imara_live_event';

const AdminLiveEventManager: React.FC = () => {
    const { saveData, getData } = useDataSync();
    const [settings, setSettings] = useState<AdminLiveEventSettings>({
        isActive: false,
        eventName: 'Imara Market Festival',
        bannerText: 'LIVE NOW: Join the celebration!',
        startTime: '',
        durationMinutes: 60,
    });
    const [isSaved, setIsSaved] = useState(false);

    useEffect(() => {
        try {
            const storedSettings = getData('system/live');
            let parsed;
            if (storedSettings) {
                parsed = storedSettings;
            } else {
                 const ls = localStorage.getItem(STORAGE_KEY);
                 if (ls) parsed = JSON.parse(ls);
            }

            if (parsed) {
                // Check if the event is expired
                const endTime = new Date(parsed.startTime).getTime() + parsed.durationMinutes * 60 * 1000;
                if (parsed.isActive && Date.now() < endTime) {
                    setSettings(parsed);
                }
            }
        } catch (error) {
            console.error("Failed to load live event settings", error);
        }
    }, [getData]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value, type } = e.target;
        if (type === 'checkbox') {
            const { checked } = e.target as HTMLInputElement;
            setSettings(prev => ({ ...prev, [name]: checked }));
        } else {
             setSettings(prev => ({ ...prev, [name]: name === 'durationMinutes' ? Number(value) : value }));
        }
    };

    const handleSave = () => {
        const settingsToSave = {
            ...settings,
            startTime: settings.isActive ? new Date().toISOString() : '',
        };
        saveData('system/live', 'config', settingsToSave);
        setIsSaved(true);
        setTimeout(() => setIsSaved(false), 3000);
    };
    
    const handleDeactivate = () => {
        const deactivatedSettings = { ...settings, isActive: false };
        setSettings(deactivatedSettings);
        saveData('system/live', 'config', deactivatedSettings);
    };

    const inputClass = "mt-1 block w-full bg-brand-off-white/80 border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent";

    return (
        <div className="bg-white p-6 rounded-lg shadow-md max-w-2xl">
            <h3 className="text-xl font-display font-semibold text-brand-navy-dark mb-4">Live Event Manager</h3>
            
            {/* Status Preview */}
            <div className={`mb-6 p-4 rounded-lg border ${settings.isActive ? 'bg-brand-gold/10 border-brand-gold' : 'bg-gray-100 border-gray-200'}`}>
                <div className="flex justify-between items-center">
                    <div>
                        <p className="font-bold text-brand-navy-dark">{settings.isActive ? 'EVENT LIVE' : 'EVENT OFFLINE'}</p>
                        {settings.isActive && <p className="text-sm text-gray-600">Started at: {new Date(settings.startTime).toLocaleTimeString()}</p>}
                    </div>
                    <div className={`w-3 h-3 rounded-full ${settings.isActive ? 'bg-red-500 animate-pulse' : 'bg-gray-400'}`}></div>
                </div>
            </div>

            <div className="space-y-6">
                <div className="flex items-center justify-between p-4 rounded-md bg-brand-navy-dark text-white">
                    <p className="font-semibold">Activate Event?</p>
                    <label className="flex items-center cursor-pointer">
                        <div className="relative">
                            <input type="checkbox" name="isActive" checked={settings.isActive} onChange={handleChange} className="sr-only" />
                            <div className={`block w-14 h-8 rounded-full transition-colors ${settings.isActive ? 'bg-brand-gold' : 'bg-gray-600'}`}></div>
                            <div className={`dot absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition-transform ${settings.isActive ? 'translate-x-6' : ''}`}></div>
                        </div>
                    </label>
                </div>
                
                 <div>
                    <label htmlFor="eventName" className="block text-sm font-medium text-gray-700">Event Name</label>
                    <input type="text" name="eventName" id="eventName" value={settings.eventName} onChange={handleChange} className={inputClass} />
                </div>
                 <div>
                    <label htmlFor="bannerText" className="block text-sm font-medium text-gray-700">Banner Text</label>
                    <input type="text" name="bannerText" id="bannerText" value={settings.bannerText} onChange={handleChange} className={inputClass} />
                </div>
                 <div>
                    <label htmlFor="durationMinutes" className="block text-sm font-medium text-gray-700">Duration (minutes)</label>
                    <input type="number" name="durationMinutes" id="durationMinutes" value={settings.durationMinutes} onChange={handleChange} className={inputClass} />
                </div>
                
                <div className="flex items-center gap-4 pt-4">
                    <Button onClick={handleSave}>Save & {settings.isActive ? 'Go Live' : 'Update Settings'}</Button>
                    {settings.isActive && <Button variant="outline" onClick={handleDeactivate} className="!border-red-500 !text-red-500 hover:!bg-red-500 hover:!text-white">End Event Now</Button>}
                    {isSaved && <p className="text-sm text-green-600 animate-fade-in">Settings saved successfully!</p>}
                </div>
            </div>
        </div>
    );
};

export default AdminLiveEventManager;
