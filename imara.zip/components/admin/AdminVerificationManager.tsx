
import React from 'react';
import type { Partner } from '../../types';
import Button from '../ui/Button.tsx';
import Avatar from '../ui/Avatar.tsx';

interface AdminVerificationManagerProps {
    partners: Partner[];
    onVerifyPartner: (partnerId: string) => void;
}

const AdminVerificationManager: React.FC<AdminVerificationManagerProps> = ({ partners, onVerifyPartner }) => {
    
    const unverifiedPartners = partners.filter(p => !p.isVerified);

    return (
        <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-display font-semibold text-brand-navy-dark mb-4">Verification Queue ({unverifiedPartners.length})</h3>
            <p className="text-sm text-gray-500 mb-6">Partners who have completed onboarding appear here. Review their profile and grant verification status.</p>
            {unverifiedPartners.length > 0 ? (
                <div className="space-y-4">
                    {unverifiedPartners.map(partner => (
                         <div key={partner.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                            <div className="flex items-center gap-4">
                                <Avatar
                                    imageUrl={partner.role === 'workman' ? partner.profileImageUrl : partner.brandLogoUrl}
                                    name={partner.role === 'workman' ? partner.name : partner.brandName}
                                    id={partner.id}
                                    className="w-12 h-12 rounded-full"
                                    textClassName="text-lg font-bold"
                                />
                                <div>
                                    <p className="font-semibold text-brand-navy-dark">{partner.role === 'workman' ? partner.name : partner.brandName}</p>
                                    <p className="text-sm text-gray-500 capitalize">{partner.role} &middot; {partner.country}</p>
                                </div>
                            </div>
                            <Button size="sm" onClick={() => onVerifyPartner(partner.id)}>Verify</Button>
                        </div>
                    ))}
                </div>
            ) : (
                <p className="text-center text-gray-500 py-8">No partners are currently awaiting verification.</p>
            )}
        </div>
    );
};

export default AdminVerificationManager;
