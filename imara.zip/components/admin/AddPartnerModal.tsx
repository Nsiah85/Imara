import React, { useState } from 'react';
import type { Partner } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { XIcon } from '../icons/Icons.tsx';

interface AddPartnerModalProps {
    onClose: () => void;
    onAdd: (partner: Partner) => void;
}

const AddPartnerModal: React.FC<AddPartnerModalProps> = ({ onClose, onAdd }) => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [role, setRole] = useState<'vendor' | 'workman' | 'travel'>('vendor');
    const [brandName, setBrandName] = useState('');
    const [industry, setIndustry] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const newPartner: Partner = {
            id: crypto.randomUUID(),
            name,
            email,
            role,
            brandName,
            industry,
            isVerified: true, // Auto-verify or leave false
            subscriptionPlanId: 'premium',
            rating: 5,
            reviewsCount: 0,
        };
        onAdd(newPartner);
    };

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
            <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 max-w-md w-full relative shadow-2xl">
                <button onClick={onClose} className="absolute top-4 right-4 p-2 text-gray-500 hover:text-gray-900 dark:hover:text-white transition-colors cursor-pointer">
                    <XIcon className="w-5 h-5" />
                </button>
                <h3 className="text-2xl font-bold mb-6 text-brand-navy-dark dark:text-white">Add New Partner</h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium mb-1 dark:text-gray-300">Contact Name</label>
                        <input type="text" required value={name} onChange={e => setName(e.target.value)} className="w-full p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 dark:text-white focus:ring-2 focus:ring-brand-gold outline-none" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1 dark:text-gray-300">Email Address</label>
                        <input type="email" required value={email} onChange={e => setEmail(e.target.value)} className="w-full p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 dark:text-white focus:ring-2 focus:ring-brand-gold outline-none" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1 dark:text-gray-300">Partner Type</label>
                        <select value={role} onChange={e => setRole(e.target.value as any)} className="w-full p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 dark:text-white focus:ring-2 focus:ring-brand-gold outline-none">
                            <option value="vendor">Vendor / Brand</option>
                            <option value="workman">Professional / Artisan</option>
                            <option value="travel">Travel Partner</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1 dark:text-gray-300">Brand / Business Name</label>
                        <input type="text" required value={brandName} onChange={e => setBrandName(e.target.value)} className="w-full p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 dark:text-white focus:ring-2 focus:ring-brand-gold outline-none" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1 dark:text-gray-300">Industry</label>
                        <input type="text" required value={industry} onChange={e => setIndustry(e.target.value)} className="w-full p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 dark:text-white focus:ring-2 focus:ring-brand-gold outline-none" />
                    </div>
                    <div className="pt-4">
                        <Button type="submit" className="w-full justify-center">Create Partner</Button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddPartnerModal;
