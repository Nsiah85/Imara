

import React, { useState, useEffect } from 'react';
import Button from '../ui/Button.tsx';
import type { SocialMediaLinks } from '../../types.ts';
import { FacebookIcon, TwitterXIcon, InstagramIcon, TikTokIcon } from '../icons/Icons.tsx';

const STORAGE_KEY = 'imara_social_media_links';

const SocialMediaManager: React.FC = () => {
    const [links, setLinks] = useState<SocialMediaLinks>({
        facebook: '',
        x: '',
        instagram: '',
        tiktok: ''
    });
    const [isSaved, setIsSaved] = useState(false);

    useEffect(() => {
        try {
            const storedLinks = localStorage.getItem(STORAGE_KEY);
            if (storedLinks) {
                setLinks(JSON.parse(storedLinks));
            }
        } catch (error) {
            console.error("Failed to load social media links", error);
        }
    }, []);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setLinks(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(links));
            setIsSaved(true);
            setTimeout(() => setIsSaved(false), 3000);
        } catch (error) {
            console.error("Failed to save social media links", error);
        }
    };
    
    const inputClass = "block w-full bg-brand-off-white/80 border border-gray-300 rounded-md shadow-sm py-2 px-3 pl-10 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent";

    const socialFields = [
        { name: 'facebook', placeholder: 'https://facebook.com/imara', icon: <FacebookIcon className="w-5 h-5 text-gray-400" /> },
        { name: 'x', placeholder: 'https://x.com/imara', icon: <TwitterXIcon className="w-5 h-5 text-gray-400" /> },
        { name: 'instagram', placeholder: 'https://instagram.com/imara', icon: <InstagramIcon className="w-5 h-5 text-gray-400" /> },
        { name: 'tiktok', placeholder: 'https://tiktok.com/@imara', icon: <TikTokIcon className="w-5 h-5 text-gray-400" /> },
    ];

    return (
        <div className="bg-white p-6 rounded-lg shadow-md max-w-2xl">
            <h3 className="text-xl font-display font-semibold text-brand-green-dark mb-1">Social Media Links</h3>
            <p className="text-gray-500 mb-6 text-sm">Manage the social media links displayed in the website footer.</p>

            <form onSubmit={handleSubmit} className="space-y-6">
                {socialFields.map(field => (
                    <div key={field.name}>
                        <label htmlFor={field.name} className="block text-sm font-medium text-gray-700 capitalize">{field.name}</label>
                        <div className="relative mt-1">
                            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                {field.icon}
                            </div>
                            <input
                                type="url"
                                name={field.name}
                                id={field.name}
                                value={links[field.name as keyof SocialMediaLinks] || ''}
                                onChange={handleChange}
                                className={inputClass}
                                placeholder={field.placeholder}
                            />
                        </div>
                    </div>
                ))}
                
                <div className="flex items-center gap-4">
                    <Button type="submit">Save Links</Button>
                    {isSaved && <p className="text-sm text-green-600 animate-fade-in">Links saved successfully!</p>}
                </div>
            </form>
        </div>
    );
};

export default SocialMediaManager;