import React, { useState, useEffect } from 'react';
import type { UserProfile } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { EditIcon, TrashIcon, SparklesIcon, ShieldCheckIcon, PlusCircleIcon } from '../icons/Icons.tsx';
import Avatar from '../ui/Avatar.tsx';
import AddCitizenModal from './AddCitizenModal.tsx';
import { db, collection, onSnapshot, setDoc, doc, updateDoc } from '../../firebase/firestore.ts';

const AdminCitizenManager: React.FC = () => {
    const [citizens, setCitizens] = useState<UserProfile[]>([]);
    const [showAddModal, setShowAddModal] = useState(false);

    useEffect(() => {
        const unsubscribe = onSnapshot(collection(db, 'users'), (snapshot) => {
            const users = snapshot.docs.map(doc => doc.data() as UserProfile);
            setCitizens(users);
        }, (error) => {
            console.error("Failed to load citizens", error);
        });
        return () => unsubscribe();
    }, []);

    const handleDelete = async (id: string) => {
        if (window.confirm("Are you sure you want to ban/remove this citizen? (Note: deletion should be done via admin cloud function, simulating UI remove for now)")) {
             // In a real app we'd delete auth user too. For now just updating flag.
             await updateDoc(doc(db, 'users', id), { accountFlagged: true });
        }
    };

    const toggleRole = async (citizen: UserProfile) => {
        const newRole = citizen.role === 'admin' ? 'user' : 'admin';
        await updateDoc(doc(db, 'users', citizen.id), { role: newRole });
    };

    const handleAddClick = () => setShowAddModal(true);

    const handleAdd = async (newCitizen: UserProfile) => {
        await setDoc(doc(db, 'users', newCitizen.id), newCitizen);
        setShowAddModal(false);
    };

    return (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-[40px] border border-gray-100 dark:border-gray-700 shadow-sm animate-fade-in relative">
            <h3 className="text-2xl font-display font-black text-brand-navy-dark dark:text-white uppercase mb-6 tracking-tight flex items-center justify-between">
                <span>Citizens Management ({citizens.length})</span>
                <Button size="sm" onClick={handleAddClick} className="flex items-center gap-2"><PlusCircleIcon className="w-4 h-4"/> Add Citizen</Button>
            </h3>
            
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-500">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-900 dark:text-gray-400">
                        <tr>
                            <th scope="col" className="px-6 py-3">Citizen</th>
                            <th scope="col" className="px-6 py-3">Role</th>
                            <th scope="col" className="px-6 py-3">Location</th>
                            <th scope="col" className="px-6 py-3 text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {citizens.map(c => (
                            <tr key={c.id} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                                <td className="px-6 py-4 flex items-center gap-4">
                                    <Avatar imageUrl={c.profileImageUrl} name={c.fullName} className="w-10 h-10" />
                                    <div>
                                        <p className="font-bold text-brand-navy-dark dark:text-white">{c.fullName}</p>
                                        <p className="text-xs text-gray-500">{c.email}</p>
                                    </div>
                                </td>
                                <td className="px-6 py-4">
                                    <span className={`px-2 py-1 rounded text-xs font-bold uppercase ${c.role === 'admin' ? 'bg-brand-gold/20 text-brand-gold' : 'bg-gray-100 text-gray-600'}`}>
                                        {c.role}
                                    </span>
                                </td>
                                <td className="px-6 py-4">
                                    {c.country} {c.region && `- ${c.region}`}
                                </td>
                                <td className="px-6 py-4 flex justify-center gap-2">
                                    <Button size="sm" variant="outline" className="p-2" onClick={() => toggleRole(c)} title="Toggle Admin Role"><ShieldCheckIcon className="w-4 h-4" /></Button>
                                    <Button size="sm" variant="outline" className="p-2 hover:bg-red-500 hover:text-white" onClick={() => handleDelete(c.id)} title="Remove"><TrashIcon className="w-4 h-4" /></Button>
                                </td>
                            </tr>
                        ))}
                        {citizens.length === 0 && (
                            <tr>
                                <td colSpan={4} className="px-6 py-4 text-center text-gray-500">No citizens found.</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
            
            {showAddModal && (
                <AddCitizenModal 
                    onClose={() => setShowAddModal(false)} 
                    onAdd={handleAdd} 
                />
            )}
        </div>
    );
};

export default AdminCitizenManager;
