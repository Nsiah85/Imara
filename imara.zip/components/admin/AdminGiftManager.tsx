
import React, { useState, useEffect } from 'react';
import type { ImaraGift } from '../../types';
import { mockImaraGifts } from '../../data/mockData';
import Button from '../ui/Button.tsx';
import { EditIcon, TrashIcon, PlusCircleIcon, PhotoIcon } from '../icons/Icons.tsx';
import { useDataSync } from '../../contexts/DataSyncContext.tsx';

const STORAGE_KEY = 'imara_gifts_v2';

const AdminGiftManager: React.FC = () => {
    const { saveData, getData } = useDataSync();
    const [gifts, setGifts] = useState<ImaraGift[]>([]);
    const [isEditing, setIsEditing] = useState(false);
    const [currentGift, setCurrentGift] = useState<Partial<ImaraGift>>({});

    useEffect(() => {
        const storedGifts = getData('gifts');
        if (storedGifts && Array.isArray(storedGifts) && storedGifts.length > 0) {
             setGifts(storedGifts);
        } else {
             // Fallback to mocks if DB empty
             setGifts(mockImaraGifts);
             // We don't autosave here to keep DB clean until edit
        }
    }, [getData]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!currentGift.name || !currentGift.cost) return;
        
        const newGift: ImaraGift = {
            id: currentGift.id || `gift_${Date.now()}`,
            name: currentGift.name,
            cost: Number(currentGift.cost),
            iconUrl: currentGift.iconUrl || '🎁',
            type: currentGift.type || 'premium'
        };

        if (currentGift.id) {
            saveData('gifts', newGift.id, newGift, 'update');
            setGifts(prev => prev.map(g => g.id === newGift.id ? newGift : g));
        } else {
            saveData('gifts', newGift.id, newGift, 'create');
            setGifts(prev => [...prev, newGift]);
        }
        setIsEditing(false);
    };

    const handleDelete = (id: string) => {
        if (window.confirm('Delete this gift?')) {
            saveData('gifts', id, {}, 'delete');
            setGifts(prev => prev.filter(g => g.id !== id));
        }
    };

    const handleIconUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setCurrentGift({...currentGift, iconUrl: reader.result as string});
            };
            reader.readAsDataURL(file);
        }
    };

    return (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-[40px] shadow-sm border border-gray-100 dark:border-gray-700 h-full">
            <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-display font-black text-brand-navy-dark dark:text-white uppercase tracking-tight">Gift Essentials</h3>
                <Button size="sm" onClick={() => { setCurrentGift({ cost: 5000, type: 'premium' }); setIsEditing(true); }}>
                    <PlusCircleIcon className="w-5 h-5 mr-2"/> Add
                </Button>
            </div>

            {isEditing ? (
                <form onSubmit={handleSubmit} className="bg-gray-50 dark:bg-gray-900 p-4 rounded-2xl mb-6 border border-gray-100 dark:border-gray-800 animate-fade-in">
                    <div className="grid grid-cols-2 gap-4 mb-4">
                        <div className="col-span-2">
                            <label className="block text-[10px] font-black text-gray-400 uppercase mb-1">Name</label>
                            <input type="text" className="w-full p-2 bg-white dark:bg-gray-800 border rounded-lg text-sm" value={currentGift.name || ''} onChange={e => setCurrentGift({...currentGift, name: e.target.value})} required />
                        </div>
                        <div className="col-span-2">
                            <label className="block text-[10px] font-black text-gray-400 uppercase mb-1">Icon Image (PNG/SVG)</label>
                            <div className="relative">
                                <input 
                                    type="file" 
                                    accept="image/png, image/jpeg, image/svg+xml"
                                    onChange={handleIconUpload}
                                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                />
                                <div className="bg-white dark:bg-gray-800 border rounded-lg p-2 text-sm flex items-center justify-center gap-2 text-gray-500">
                                    <PhotoIcon className="w-4 h-4" /> Upload Image
                                </div>
                            </div>
                        </div>
                        <div>
                            <label className="block text-[10px] font-black text-gray-400 uppercase mb-1">Cost (Tts)</label>
                            <input type="number" className="w-full p-2 bg-white dark:bg-gray-800 border rounded-lg text-sm" value={currentGift.cost || ''} onChange={e => setCurrentGift({...currentGift, cost: Number(e.target.value)})} required />
                        </div>
                        <div>
                            <label className="block text-[10px] font-black text-gray-400 uppercase mb-1">Type</label>
                            <select className="w-full p-2 bg-white dark:bg-gray-800 border rounded-lg text-sm" value={currentGift.type} onChange={e => setCurrentGift({...currentGift, type: e.target.value as any})}>
                                <option value="emoji">Emoji</option>
                                <option value="premium">Premium</option>
                                <option value="brand">Brand</option>
                            </select>
                        </div>
                    </div>
                    <div className="flex justify-end gap-2">
                        <Button type="button" variant="outline" size="sm" onClick={() => setIsEditing(false)}>Cancel</Button>
                        <Button type="submit" size="sm">Save</Button>
                    </div>
                </form>
            ) : null}

            <div className="grid grid-cols-3 gap-3">
                {gifts.map(gift => (
                    <div key={gift.id} className="p-3 bg-gray-50 dark:bg-gray-900/50 rounded-2xl border border-gray-100 dark:border-gray-800 text-center relative group">
                        <div className="flex justify-center mb-1 h-8 w-8 mx-auto">
                            {gift.iconUrl.startsWith('data:') || gift.iconUrl.startsWith('http') ? (
                                <img src={gift.iconUrl} alt={gift.name} className="w-full h-full object-contain" />
                            ) : (
                                <span className="text-3xl">{gift.iconUrl}</span>
                            )}
                        </div>
                        <p className="font-bold text-[10px] truncate mt-2">{gift.name}</p>
                        <p className="text-[10px] text-brand-green font-mono">{gift.cost} Tts</p>
                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity rounded-2xl flex items-center justify-center gap-2">
                             <button onClick={() => { setCurrentGift(gift); setIsEditing(true); }} className="p-1.5 bg-white rounded-full text-brand-navy-dark"><EditIcon className="w-3 h-3"/></button>
                             <button onClick={() => handleDelete(gift.id)} className="p-1.5 bg-white rounded-full text-red-600"><TrashIcon className="w-3 h-3"/></button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default AdminGiftManager;
