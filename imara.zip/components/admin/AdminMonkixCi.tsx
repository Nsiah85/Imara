import React, { useState, useEffect } from 'react';
import Button from '../ui/Button.tsx';
import { SparklesIcon } from '../icons/Icons.tsx';
import { db, collection, query, orderBy, limit, onSnapshot } from '../../firebase/firestore.ts';

interface AuditLog {
    id: string;
    timestamp: any;
    message: string;
    level: 'info' | 'warning' | 'error';
}

const AdminMonkixCi: React.FC = () => {
    const [showLogs, setShowLogs] = useState(false);
    const [logs, setLogs] = useState<AuditLog[]>([]);
    const [stats, setStats] = useState({
        activePersonas: 0,
        safetyFlags: 0,
        permissionOverrides: 0,
        totalActions: 0
    });

    useEffect(() => {
        // Dummy data for stats initially, ideally fetched from a specific stats doc
        setStats({
            activePersonas: Math.floor(Math.random() * 50) + 10,
            safetyFlags: Math.floor(Math.random() * 5),
            permissionOverrides: Math.floor(Math.random() * 10),
            totalActions: Math.floor(Math.random() * 1000) + 500
        });

        // Listen for real audit logs
        const q = query(collection(db, 'auditLogs'), orderBy('timestamp', 'desc'), limit(50));
        const unsubscribe = onSnapshot(q, (snapshot) => {
            const fetchedLogs = snapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            })) as AuditLog[];
            setLogs(fetchedLogs);
        });

        return () => unsubscribe();
    }, []);

    return (
        <div className="space-y-10 animate-fade-in">
            <div className="bg-white dark:bg-gray-800 p-8 rounded-[40px] border border-gray-100 dark:border-gray-700 shadow-sm">
                <h3 className="text-2xl font-display font-black text-brand-navy-dark dark:text-white uppercase mb-6 tracking-tight flex items-center gap-3">
                    <SparklesIcon className="w-8 h-8 text-[#7E57C2]" /> Monkix CI Moderation
                </h3>
                <p className="text-gray-500 mb-8 max-w-2xl">
                    System-wide oversight for AI-assisted personas. Monitor abuse, review overridden permissions, and oversee the health of the Artificial Persona network.
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <div className="p-6 bg-[#7E57C2]/5 border border-[#7E57C2]/20 rounded-2xl">
                        <p className="text-xs font-black text-[#7E57C2] uppercase tracking-widest mb-2">Active Personas</p>
                        <p className="text-3xl font-display font-black text-brand-navy-dark dark:text-white">{stats.activePersonas}</p>
                    </div>
                    <div className="p-6 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-900/40 rounded-2xl">
                        <p className="text-xs font-black text-red-600 uppercase tracking-widest mb-2">Safety Flags</p>
                        <p className="text-3xl font-display font-black text-brand-navy-dark dark:text-white flex items-center gap-2">{stats.safetyFlags} {stats.safetyFlags > 0 && <span className="text-sm px-2 py-1 bg-red-600 text-white rounded-full">Requires Review</span>}</p>
                    </div>
                    <div className="p-6 bg-gray-50 dark:bg-gray-900/50 rounded-2xl">
                        <p className="text-xs font-black text-gray-500 uppercase tracking-widest mb-2">Permission Overrides</p>
                        <p className="text-3xl font-display font-black text-brand-navy-dark dark:text-white">{stats.permissionOverrides}</p>
                    </div>
                    <div className="p-6 bg-gray-50 dark:bg-gray-900/50 rounded-2xl">
                        <p className="text-xs font-black text-gray-500 uppercase tracking-widest mb-2">Total AI Actions</p>
                        <p className="text-3xl font-display font-black text-brand-navy-dark dark:text-white">{stats.totalActions}</p>
                    </div>
                </div>
                
                <Button className="!bg-[#7E57C2] hover:!bg-[#6b47ab] !text-white !border-none" onClick={() => setShowLogs(!showLogs)}>View Detailed Audit Logs</Button>
                {showLogs && (
                    <div className="mt-8 p-4 bg-gray-100 dark:bg-gray-900 rounded-xl font-mono text-xs text-gray-700 dark:text-gray-300 max-h-96 overflow-y-auto">
                        {logs.length > 0 ? logs.map(log => {
                            const date = log.timestamp?.toDate ? log.timestamp.toDate().toLocaleString() : new Date().toLocaleString();
                            const colorClass = log.level === 'error' ? 'text-red-500' : (log.level === 'warning' ? 'text-yellow-500' : 'text-gray-500');
                            return (
                            <p key={log.id} className="mb-1">
                                [{date}] <span className={colorClass}>[{log.level.toUpperCase()}]</span> {log.message}
                            </p>
                        )}) : (
                            <p className="text-gray-400 italic">No real audit logs available yet. The CI system will begin logging soon.</p>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

export default AdminMonkixCi;
