import React, { useState, useMemo } from 'react';
import type { JobApplicant, JobListing } from '../../types.ts';
import { mockJobListings } from '../../data/mockData.ts';
import Button from '../ui/Button.tsx';
import SendTestInviteModal from '../modals/SendTestInviteModal.tsx';
import Avatar from '../ui/Avatar.tsx';

interface JobApplicantsManagerProps {
    applicants: JobApplicant[];
    setApplicants: React.Dispatch<React.SetStateAction<JobApplicant[]>>;
}

const statusStyles: { [key in JobApplicant['status']]: string } = {
    applied: 'bg-blue-100 text-blue-800',
    test_invited: 'bg-yellow-100 text-yellow-800',
    test_completed: 'bg-purple-100 text-purple-800',
    test_passed: 'bg-green-100 text-green-800',
    test_failed: 'bg-red-100 text-red-800',
    interviewing: 'bg-indigo-100 text-indigo-800',
    hired: 'bg-emerald-100 text-emerald-800',
    rejected: 'bg-gray-100 text-gray-800',
};

const JobApplicantsManager: React.FC<JobApplicantsManagerProps> = ({ applicants, setApplicants }) => {
    const [selectedApplicant, setSelectedApplicant] = useState<JobApplicant | null>(null);
    const [selectedJob, setSelectedJob] = useState<JobListing | null>(null);

    const applicantsByJob = useMemo(() => {
        return applicants.reduce((acc, applicant) => {
            const job = mockJobListings.find(j => j.id === applicant.jobListingId);
            if (job) {
                if (!acc[job.id]) {
                    acc[job.id] = { job, applicants: [] };
                }
                acc[job.id].applicants.push(applicant);
            }
            return acc;
        }, {} as Record<string, { job: JobListing; applicants: JobApplicant[] }>);
    }, [applicants]);
    
    const handleOpenTestModal = (applicant: JobApplicant, job: JobListing) => {
        setSelectedApplicant(applicant);
        setSelectedJob(job);
    };

    const handleCloseTestModal = () => {
        setSelectedApplicant(null);
        setSelectedJob(null);
    };
    
    const handleInviteSent = (applicantId: string) => {
        const updatedApplicants = applicants.map(app => 
            app.id === applicantId ? { ...app, status: 'test_invited' as const } : app
        );
        setApplicants(updatedApplicants);
        localStorage.setItem('imara_job_applicants', JSON.stringify(updatedApplicants));
    };

    return (
        <>
            <div className="space-y-8">
                {Object.values(applicantsByJob).map(({ job, applicants }) => (
                    <div key={job.id} className="bg-white p-6 rounded-lg shadow-md">
                        <h3 className="text-xl font-display font-semibold text-brand-navy-dark">{job.title}</h3>
                        <p className="text-sm text-gray-500">{job.companyName} - {job.location}</p>
                        <div className="mt-4 overflow-x-auto">
                            <table className="w-full text-sm text-left text-gray-500">
                                <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                                    <tr>
                                        <th scope="col" className="px-4 py-3">Applicant</th>
                                        <th scope="col" className="px-4 py-3">Applied</th>
                                        <th scope="col" className="px-4 py-3">Status</th>
                                        <th scope="col" className="px-4 py-3 text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {applicants.map(applicant => (
                                        <tr key={applicant.id} className="bg-white border-b hover:bg-gray-50">
                                            <td className="px-4 py-3 font-medium text-gray-900 flex items-center gap-3">
                                                <Avatar 
                                                    imageUrl={applicant.professionalAvatar}
                                                    name={applicant.professionalName}
                                                    id={applicant.professionalId}
                                                    className="w-8 h-8 rounded-full"
                                                    textClassName="text-sm font-bold text-white"
                                                />
                                                {applicant.professionalName}
                                            </td>
                                            <td className="px-4 py-3">{new Date(applicant.appliedDate).toLocaleDateString()}</td>
                                            <td className="px-4 py-3">
                                                <span className={`px-2 py-1 text-xs font-medium rounded-full ${statusStyles[applicant.status]}`}>
                                                    {applicant.status.replace('_', ' ').toUpperCase()}
                                                </span>
                                            </td>
                                            <td className="px-4 py-3 text-center">
                                                {applicant.status === 'applied' && (
                                                    <Button size="sm" onClick={() => handleOpenTestModal(applicant, job)}>Send Test</Button>
                                                )}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                ))}
            </div>
            {selectedApplicant && selectedJob && (
                <SendTestInviteModal
                    applicant={selectedApplicant}
                    job={selectedJob}
                    onClose={handleCloseTestModal}
                    onInviteSent={handleInviteSent}
                />
            )}
        </>
    );
};

export default JobApplicantsManager;