
import React, { useState, useEffect } from 'react';
import Button from '../ui/Button.tsx';
import { PhotoIcon, CheckCircleIcon, Cog6ToothIcon, GlobeIcon } from '../icons/Icons.tsx';
import { uploadFile } from '../../firebase/storage.ts';
import { doc, getDoc, setDoc, db } from '../../firebase/firestore.ts';

const GlobalUIConfig: React.FC = () => {
    const [config, setConfig] = useState({
        shopHubHeroUrl: "https://picsum.photos/seed/market-vibe/1600/600",
        maintenanceMode: false,
        accentColor: '#FFD700'
    });
    const [isSaved, setIsSaved] = useState(false);
    const [isUploading, setIsUploading] = useState(false);

    useEffect(() => {
        const fetchConfig = async () => {
            try {
                const snapshot = await getDoc(doc(db, 'system', 'config'));
                if (snapshot.exists()) {
                    setConfig(snapshot.data() as any);
                }
            } catch (e) {
                console.error(e);
            }
        };
        fetchConfig();
    }, []);

    const handleSave = async () => {
        setIsSaved(true);
        try {
            await setDoc(doc(db, 'system', 'config'), config, { merge: true });
            setTimeout(() => setIsSaved(false), 2000);
            window.dispatchEvent(new CustomEvent('imara_config_update'));
        } catch (e) {
            console.error(e);
            setIsSaved(false);
        }
    };

    const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setIsUploading(true);
            try {
                const url = await uploadFile(file, `system/hero_${Date.now()}`);
                setConfig({...config, shopHubHeroUrl: url});
            } catch (e) {
                console.error("Failed to upload image", e);
            } finally {
                setIsUploading(false);
            }
        }
    };

    return (
        <div className="bg-white p-8 rounded-[40px] shadow-sm border border-gray-100 h-full">
             <h3 className="text-xl font-display font-black text-brand-navy-dark mb-6 flex items-center gap-2">
                <Cog6ToothIcon className="w-6 h-6 text-brand-gold"/> Platform Architecture
            </h3>
            
            <div className="space-y-8">
                <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">ShopHub Master Visual</label>
                    <div className="flex gap-4 items-center">
                        <div className="relative flex-1">
                            <input 
                                type="file" 
                                accept="image/png, image/jpeg, image/svg+xml"
                                onChange={handleImageUpload}
                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
                                title="Upload Hero Image"
                                disabled={isUploading}
                            />
                            <div className={`bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm flex items-center justify-center gap-2 font-bold text-gray-500 ${isUploading ? 'opacity-50' : 'hover:border-brand-gold'}`}>
                                <PhotoIcon className="w-5 h-5" /> {isUploading ? 'Uploading...' : 'Click to upload PNG/JPG/SVG'}
                            </div>
                        </div>
                        <div className="w-20 h-14 rounded-xl overflow-hidden border border-gray-100 bg-gray-50 shadow-inner">
                            <img src={config.shopHubHeroUrl} className="w-full h-full object-cover" alt="Preview" />
                        </div>
                    </div>
                    <p className="mt-2 text-[10px] text-gray-400 font-bold uppercase tracking-wider">Cinematic standard: 2400x1200px recommended.</p>
                </div>

                <div className="grid grid-cols-2 gap-6">
                    <div>
                         <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Platform Status</label>
                         <button 
                            onClick={() => setConfig({...config, maintenanceMode: !config.maintenanceMode})}
                            className={`w-full flex items-center justify-between p-4 rounded-2xl border-2 transition-all ${config.maintenanceMode ? 'border-red-600 bg-red-50 text-red-700' : 'border-brand-green/30 bg-green-50/30 text-brand-green'}`}
                         >
                            <span className="text-xs font-black uppercase">{config.maintenanceMode ? 'Down for Ops' : 'Operational'}</span>
                            <div className={`w-3 h-3 rounded-full ${config.maintenanceMode ? 'bg-red-600' : 'bg-brand-green animate-pulse'}`}></div>
                         </button>
                    </div>
                    <div>
                         <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">System Accent</label>
                         <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-2xl border border-gray-100">
                             <div className="w-6 h-6 rounded-full shadow-sm" style={{backgroundColor: config.accentColor}}></div>
                             <span className="text-xs font-mono font-bold">{config.accentColor}</span>
                         </div>
                    </div>
                </div>

                <div className="pt-6 border-t border-gray-50 flex items-center justify-between">
                    <Button onClick={handleSave} className="!rounded-2xl shadow-xl">Apply System Changes</Button>
                    {isSaved && <span className="text-brand-green text-xs font-black uppercase flex items-center gap-1 animate-fade-in"><CheckCircleIcon className="w-4 h-4"/> Sync Complete</span>}
                </div>
            </div>
        </div>
    );
};

export default GlobalUIConfig;
