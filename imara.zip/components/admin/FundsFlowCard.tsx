
import React from 'react';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';

interface FundsFlowCardProps {
    title: string;
    amount: number;
    period: string;
    change: string;
    changeType: 'positive' | 'negative';
}

const FundsFlowCard: React.FC<FundsFlowCardProps> = ({ title, amount, period, change, changeType }) => {
    const { currency } = useCurrency();
    const changeColor = changeType === 'positive' ? 'text-brand-green' : 'text-red-600';

    return (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 hover:shadow-lg transition-all duration-300">
            <p className="text-xs font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-1">{title}</p>
            <p className="text-[28px] font-display font-black text-brand-green leading-tight">
                {currency} {amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
            <div className="mt-3 flex items-center gap-2">
                <span className={`text-xs font-black ${changeColor} px-2 py-0.5 bg-gray-50 dark:bg-gray-900 rounded-full`}>
                    {change}
                </span>
                <span className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider">{period}</span>
            </div>
        </div>
    );
};

export default FundsFlowCard;
