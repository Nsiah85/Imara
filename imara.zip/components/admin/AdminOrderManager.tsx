
import React, { useState, useEffect } from 'react';
import { UserOrder, OrderStatus } from '../../types.ts';
import { mockUserOrders } from '../../data/mockData.ts';
import Button from '../ui/Button.tsx';
import { CheckCircleIcon, TruckIcon, XIcon, SearchIcon, ClipboardListIcon, ArrowRightIcon } from '../icons/Icons.tsx';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';
import { useDataSync } from '../../contexts/DataSyncContext.tsx';

const ORDER_LIFECYCLE: OrderStatus[] = ['pending', 'paid', 'processing', 'shipped', 'delivered'];

const AdminOrderManager: React.FC = () => {
    const { saveData, getData } = useDataSync();
    const [orders, setOrders] = useState<UserOrder[]>([]);
    const [filter, setFilter] = useState<OrderStatus | 'all'>('all');
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedOrder, setSelectedOrder] = useState<UserOrder | null>(null);
    const { formatCurrency } = useCurrency();

    useEffect(() => {
        // Load data from persistence first
        const storedOrders = getData('orders');
        if (storedOrders && Array.isArray(storedOrders) && storedOrders.length > 0) {
            setOrders(storedOrders);
        } else {
            // Initialize with mocks if empty for demo purposes
            const initializedOrders = mockUserOrders.map(o => ({
                ...o,
                status: o.status || 'paid'
            }));
            setOrders(initializedOrders);
        }
    }, [getData]);

    const updateStatus = (orderId: string, newStatus: OrderStatus, trackingCode?: string) => {
        const updatedOrders = orders.map(o => 
            o.id === orderId ? { ...o, status: newStatus, trackingCode } : o
        );
        setOrders(updatedOrders);
        
        // Sync using new engine
        // We find the full object to update
        const orderToSync = updatedOrders.find(o => o.id === orderId);
        if (orderToSync) {
            saveData('orders', orderId, orderToSync, 'update');
        }
    };

    const handleRefund = (orderId: string) => {
        if(window.confirm("Are you sure you want to refund this order? This cannot be undone.")) {
            updateStatus(orderId, 'refunded');
            setSelectedOrder(null);
        }
    };

    const filteredOrders = orders.filter(order => {
        const matchesFilter = filter === 'all' || order.status === filter;
        const matchesSearch = order.orderId.toLowerCase().includes(searchTerm.toLowerCase());
        return matchesFilter && matchesSearch;
    });

    const getStatusColor = (status: string) => {
        switch(status) {
            case 'pending': return 'bg-yellow-100 text-yellow-800';
            case 'paid': return 'bg-blue-100 text-blue-800';
            case 'processing': return 'bg-indigo-100 text-indigo-800';
            case 'shipped': return 'bg-purple-100 text-purple-800';
            case 'delivered': return 'bg-green-100 text-green-800';
            case 'disputed': return 'bg-red-100 text-red-800';
            case 'refunded': return 'bg-gray-200 text-gray-800 line-through';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    return (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-[40px] shadow-sm border border-gray-100 dark:border-gray-700 h-full">
            <h3 className="text-xl font-display font-black text-brand-navy-dark dark:text-white mb-6 flex items-center gap-2">
                <ClipboardListIcon className="w-6 h-6 text-brand-gold"/> Order Operations
            </h3>

            {/* Controls */}
            <div className="flex flex-col md:flex-row gap-4 mb-6">
                <div className="relative flex-grow">
                    <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400"/>
                    <input 
                        type="text" 
                        placeholder="Search Order ID..." 
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        className="w-full pl-10 p-3 bg-gray-50 dark:bg-gray-900 border-none rounded-xl text-sm focus:ring-2 focus:ring-brand-gold dark:text-white"
                    />
                </div>
                <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0 scrollbar-hide">
                    {['all', ...ORDER_LIFECYCLE, 'disputed', 'refunded'].map(s => (
                        <button 
                            key={s}
                            onClick={() => setFilter(s as any)}
                            className={`px-4 py-2 rounded-full text-xs font-bold uppercase whitespace-nowrap transition-colors ${filter === s ? 'bg-brand-navy-dark text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300'}`}
                        >
                            {s}
                        </button>
                    ))}
                </div>
            </div>

            {/* Order List */}
            <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                    <thead className="bg-gray-50 dark:bg-gray-900 text-xs uppercase text-gray-500 font-black">
                        <tr>
                            <th className="p-4 rounded-l-xl">Order ID</th>
                            <th className="p-4">Date</th>
                            <th className="p-4">Total</th>
                            <th className="p-4">Status</th>
                            <th className="p-4 rounded-r-xl">Action</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                        {filteredOrders.map(order => (
                            <tr key={order.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                                <td className="p-4 font-mono font-bold text-brand-navy-dark dark:text-white">{order.orderId}</td>
                                <td className="p-4 text-gray-500">{order.date}</td>
                                <td className="p-4 font-bold text-brand-green">{formatCurrency(order.total)}</td>
                                <td className="p-4">
                                    <span className={`px-2 py-1 rounded text-[10px] font-black uppercase ${getStatusColor(order.status || 'pending')}`}>
                                        {order.status}
                                    </span>
                                </td>
                                <td className="p-4">
                                    <Button size="sm" variant="outline" onClick={() => setSelectedOrder(order)}>Manage</Button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Management Modal */}
            {selectedOrder && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={() => setSelectedOrder(null)}>
                    <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 max-w-2xl w-full shadow-2xl overflow-y-auto max-h-[90vh]" onClick={e => e.stopPropagation()}>
                        <div className="flex justify-between items-center mb-6">
                            <h4 className="text-xl font-bold text-brand-navy-dark dark:text-white">Order {selectedOrder.orderId}</h4>
                            <button onClick={() => setSelectedOrder(null)}><XIcon className="w-6 h-6 text-gray-400"/></button>
                        </div>
                        
                        {/* Status Pipeline Visualizer */}
                        <div className="mb-8">
                             <p className="text-xs font-bold text-gray-400 uppercase mb-3">Order Lifecycle</p>
                             <div className="flex items-center justify-between w-full relative">
                                 {/* Connector Line */}
                                 <div className="absolute top-1/2 left-0 w-full h-1 bg-gray-100 dark:bg-gray-700 -z-10"></div>
                                 
                                 {ORDER_LIFECYCLE.map((step, idx) => {
                                     const currentIdx = ORDER_LIFECYCLE.indexOf(selectedOrder.status as OrderStatus);
                                     const isCompleted = currentIdx >= idx;
                                     const isCurrent = currentIdx === idx;
                                     
                                     return (
                                         <div key={step} className="flex flex-col items-center gap-2">
                                             <div className={`w-4 h-4 rounded-full border-2 transition-all ${isCompleted ? 'bg-brand-green border-brand-green' : 'bg-white border-gray-300'}`}>
                                                 {isCurrent && <div className="w-full h-full rounded-full bg-brand-green animate-ping opacity-50"></div>}
                                             </div>
                                             <span className={`text-[9px] font-bold uppercase ${isCompleted ? 'text-brand-green' : 'text-gray-400'}`}>{step}</span>
                                         </div>
                                     )
                                 })}
                             </div>
                        </div>

                        <div className="space-y-4 mb-8">
                            <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-xl">
                                {selectedOrder.items.map(item => (
                                    <div key={item.id} className="flex justify-between text-xs mb-2 text-gray-600 dark:text-gray-300">
                                        <span>{item.quantity}x {item.name}</span>
                                        <span>{formatCurrency(item.price)}</span>
                                    </div>
                                ))}
                                <div className="border-t border-gray-200 mt-2 pt-2 flex justify-between font-bold text-brand-navy-dark dark:text-white">
                                    <span>Total</span>
                                    <span>{formatCurrency(selectedOrder.total)}</span>
                                </div>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3 mb-4">
                            {/* Next Action Logic */}
                            {selectedOrder.status === 'paid' && (
                                <Button onClick={() => updateStatus(selectedOrder.id, 'processing')} className="flex items-center justify-center gap-2 w-full col-span-2">
                                    Start Processing <ArrowRightIcon className="w-4 h-4"/>
                                </Button>
                            )}
                            {selectedOrder.status === 'processing' && (
                                <Button onClick={() => updateStatus(selectedOrder.id, 'shipped', `TRK-${Date.now()}`)} className="flex items-center justify-center gap-2 w-full col-span-2">
                                    <TruckIcon className="w-4 h-4"/> Dispatch Order
                                </Button>
                            )}
                             {selectedOrder.status === 'shipped' && (
                                <Button onClick={() => updateStatus(selectedOrder.id, 'delivered')} className="!bg-green-600 hover:!bg-green-700 flex items-center justify-center gap-2 w-full col-span-2">
                                    <CheckCircleIcon className="w-4 h-4"/> Mark Delivered
                                </Button>
                            )}
                        </div>
                        
                        <div className="border-t border-gray-100 dark:border-gray-700 pt-4">
                             <p className="text-xs font-bold text-red-400 uppercase mb-2">Danger Zone</p>
                             <Button 
                                    onClick={() => handleRefund(selectedOrder.id)} 
                                    variant="outline"
                                    className="w-full !border-red-200 !text-red-600 hover:!bg-red-50"
                                    disabled={selectedOrder.status === 'refunded'}
                            >
                                Process Full Refund
                            </Button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default AdminOrderManager;
