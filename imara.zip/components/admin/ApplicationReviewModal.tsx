
import React, { useState, useEffect, useCallback } from 'react';
import type { PartnerApplication, EdwasoMarket } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { XIcon, GlobeIcon, BriefcaseIcon, UserCircleIcon, DocumentTextIcon } from '../icons/Icons.tsx';
import { mockEdwasoMarkets } from '../../data/mockData.ts';

interface ApplicationReviewModalProps {
  application: PartnerApplication;
  onClose: () => void;
  onApprove: () => void;
  onReject: () => void;
}

const DetailItem: React.FC<{ label: string; value?: string | React.ReactNode; icon?: React.ReactNode }> = ({ label, value, icon }) => {
    if (!value) return null;
    return (
        <div className="mb-4">
            <div className="flex items-center gap-2 text-gray-500 mb-1">
                {icon}
                <p className="text-sm font-medium uppercase tracking-wider">{label}</p>
            </div>
            <div className="text-brand-navy-dark font-semibold text-lg break-words">{value}</div>
        </div>
    );
};


const ApplicationReviewModal: React.FC<ApplicationReviewModalProps> = ({ application, onClose, onApprove, onReject }) => {
  const [isClosing, setIsClosing] = useState(false);
  const [marketName, setMarketName] = useState('');

  useEffect(() => {
    if (application.marketId) {
        try {
            const storedMarkets = localStorage.getItem('edwaso_markets');
            const markets: EdwasoMarket[] = storedMarkets ? JSON.parse(storedMarkets) : mockEdwasoMarkets;
            const market = markets.find(m => m.id === application.marketId);
            if (market) {
                setMarketName(market.name);
            }
        } catch (e) {
            console.error(e);
        }
    }
  }, [application.marketId]);

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';

  return (
    <div
      className={`fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close} role="dialog" aria-modal="true" aria-labelledby="review-title"
    >
      <div
        className={`relative bg-white rounded-lg shadow-xl w-full max-w-3xl max-h-[90vh] flex flex-col transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b bg-gray-50">
          <h2 id="review-title" className="text-2xl font-display font-bold text-brand-navy-dark">Review Partner Application</h2>
          <p className="text-sm text-gray-500">Applicant ID: {application.id}</p>
        </div>
        
        <div className="p-8 space-y-8 overflow-y-auto">
            
            {/* Images Section */}
            {(application.companyLogoUrl || application.coverImageUrl) && (
                <div className="mb-6">
                    {application.coverImageUrl && (
                        <img src={application.coverImageUrl} alt="Cover" className="w-full h-32 object-cover rounded-lg mb-[-40px] border border-gray-200" />
                    )}
                    {application.companyLogoUrl && (
                        <img src={application.companyLogoUrl} alt="Logo" className="w-24 h-24 rounded-full border-4 border-white shadow-md relative z-10 ml-4 bg-white object-cover" />
                    )}
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                    <h3 className="text-brand-green-dark font-bold mb-4 border-b pb-2">Contact Information</h3>
                    <DetailItem label="Full Name" value={application.fullName} icon={<UserCircleIcon className="w-4 h-4"/>} />
                    <DetailItem label="Email Address" value={application.email} />
                    <DetailItem label="Location" value={application.country} icon={<GlobeIcon className="w-4 h-4"/>} />
                </div>
                
                <div>
                    <h3 className="text-brand-green-dark font-bold mb-4 border-b pb-2">Business Profile</h3>
                    <DetailItem label="Role Type" value={application.role.toUpperCase()} icon={<BriefcaseIcon className="w-4 h-4"/>} />
                    {(application.role === 'vendor' || application.role === 'travel') && (
                        <DetailItem label="Brand Name" value={application.brandName} />
                    )}
                    
                    {/* Specific Vendor Fields */}
                    {application.role === 'vendor' && (
                        <>
                            <DetailItem label="Vendor Category" value={application.vendorType} />
                            {marketName && <DetailItem label="Edwaso Market" value={marketName} />}
                        </>
                    )}

                    {/* Specific Workman Fields */}
                    {application.role === 'workman' && (
                        <>
                            <DetailItem label="Industry" value={application.industry} />
                            <DetailItem label="Top Skills" value={application.skills} />
                        </>
                    )}

                    {/* Specific Travel Fields */}
                    {application.role === 'travel' && (
                        <DetailItem 
                            label="Services Offered" 
                            value={
                                <div className="flex flex-wrap gap-2 mt-1">
                                    {application.serviceTypes?.map(st => <span key={st} className="text-xs bg-gray-200 text-gray-800 px-2 py-1 rounded-full border border-gray-300">{st}</span>)}
                                </div>
                            } 
                        />
                    )}
                </div>
            </div>

            {/* Story / Bio */}
            {application.story && (
                 <div className="bg-brand-off-white/50 p-4 rounded-lg border border-gray-200">
                    <div className="flex items-center gap-2 mb-2 text-gray-500">
                        <DocumentTextIcon className="w-5 h-5" />
                        <p className="font-bold uppercase text-xs tracking-wider">Brand Story / Bio</p>
                    </div>
                    <p className="text-gray-800 leading-relaxed whitespace-pre-wrap">{application.story}</p>
                </div>
            )}
            
            {/* Licensing / Compliance Placeholder */}
            <div className="mt-6 p-4 border border-yellow-200 bg-yellow-50 rounded-lg">
                <h4 className="text-yellow-800 font-bold text-sm mb-2">Compliance Check</h4>
                <p className="text-sm text-yellow-700">Verify that the submitted details match required licenses for {application.country} operations.</p>
            </div>

        </div>
        
        <div className="p-6 bg-gray-50 rounded-b-lg flex justify-between items-center border-t mt-auto">
          <Button type="button" variant="outline" onClick={close}>Cancel Review</Button>
          <div className="flex gap-4">
            <Button type="button" className="!bg-red-600 hover:!bg-red-700 text-white border-none" onClick={onReject}>Reject Application</Button>
            <Button type="button" className="!bg-green-600 hover:!bg-green-700 text-white border-none" onClick={onApprove}>Approve & Onboard</Button>
          </div>
        </div>
        
        <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 transition-colors z-10" aria-label="Close modal">
          <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default ApplicationReviewModal;
