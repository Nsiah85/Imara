

import React, { useState, useEffect } from 'react';
import Button from '../ui/Button.tsx';

interface PayoutDetails {
    momoNumber: string;
    paystackId: string;
}

const PayoutSettings: React.FC = () => {
    const [settings, setSettings] = useState<PayoutDetails>({
        momoNumber: '',
        paystackId: ''
    });
    const [isSaved, setIsSaved] = useState(false);

    useEffect(() => {
        try {
            const storedSettings = localStorage.getItem('payout_settings');
            if (storedSettings) {
                setSettings(JSON.parse(storedSettings));
            } else {
                // Pre-fill with user-provided details if no settings are stored
                setSettings({
                    momoNumber: '+233247423660',
                    paystackId: '1580277'
                });
            }
        } catch (error) {
            console.error("Failed to load payout settings", error);
        }
    }, []);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSettings(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        try {
            localStorage.setItem('payout_settings', JSON.stringify(settings));
            setIsSaved(true);
            setTimeout(() => setIsSaved(false), 3000); // Hide message after 3 seconds
        } catch (error) {
            console.error("Failed to save payout settings", error);
        }
    };
    
    const inputClass = "mt-1 block w-full bg-brand-off-white/80 border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent";

    return (
        <div className="bg-white p-6 rounded-lg shadow-md max-w-2xl">
            <h3 className="text-xl font-display font-semibold text-brand-green-dark mb-1">Payout Settings</h3>
            <p className="text-gray-500 mb-6 text-sm">Configure where you receive commissions, donations, and fees.</p>

            <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                    <label htmlFor="momoNumber" className="block text-sm font-medium text-gray-700">Mobile Money (Momo) Number</label>
                    <input
                        type="text"
                        name="momoNumber"
                        id="momoNumber"
                        value={settings.momoNumber}
                        onChange={handleChange}
                        className={inputClass}
                        placeholder="+233..."
                    />
                </div>
                <div>
                    <label htmlFor="paystackId" className="block text-sm font-medium text-gray-700">Paystack Account/Subaccount ID</label>
                    <input
                        type="text"
                        name="paystackId"
                        id="paystackId"
                        value={settings.paystackId}
                        onChange={handleChange}
                        className={inputClass}
                        placeholder="e.g., ACCT_xxxx or 1580277"
                    />
                </div>
                <div className="flex items-center gap-4">
                    <Button type="submit">Save Settings</Button>
                    {isSaved && <p className="text-sm text-green-600 animate-fade-in">Settings saved successfully!</p>}
                </div>
            </form>
        </div>
    );
};

export default PayoutSettings;