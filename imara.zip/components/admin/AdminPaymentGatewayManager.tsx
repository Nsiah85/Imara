
import React, { useState, useEffect } from 'react';
import Button from '../ui/Button.tsx';
import { CreditCardIcon, CheckCircleIcon, LockClosedIcon, ShieldCheckIcon, EyeIcon } from '../icons/Icons.tsx';
import { useDataSync } from '../../contexts/DataSyncContext.tsx';

const STORAGE_KEY = 'imara_payment_gateway_config';

interface GatewayConfig {
    paystackPublicKey: string;
    paystackSecretKey: string;
    webhookUrl: string;
    callbackUrl: string;
    isLive: boolean;
    isEnabled: boolean;
}

const AdminPaymentGatewayManager: React.FC = () => {
    const { saveData, getData } = useDataSync();
    const [config, setConfig] = useState<GatewayConfig>({
        paystackPublicKey: '',
        paystackSecretKey: '',
        webhookUrl: 'https://api.imara.com/webhooks/paystack',
        callbackUrl: 'https://imara.app/checkout/success',
        isLive: false,
        isEnabled: true,
    });
    const [isSaved, setIsSaved] = useState(false);
    const [showSecrets, setShowSecrets] = useState(false);

    useEffect(() => {
        const stored = getData('system/payments');
        if (stored) {
            setConfig(stored);
        } else {
             // Fallback to legacy key check just in case
             const ls = localStorage.getItem(STORAGE_KEY);
             if (ls) setConfig(JSON.parse(ls));
        }
    }, [getData]);

    const handleSave = () => {
        // Use DataSync to persist
        saveData('system/payments', 'config', config);
        
        setIsSaved(true);
        setTimeout(() => setIsSaved(false), 2000);
    };

    const inputClass = "w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-brand-gold outline-none dark:bg-gray-800 dark:border-gray-700 dark:text-white";

    return (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-[40px] shadow-sm border border-gray-100 dark:border-gray-700 h-full flex flex-col">
            <h3 className="text-xl font-display font-black text-brand-navy-dark dark:text-white mb-6 flex items-center gap-2">
                <CreditCardIcon className="w-6 h-6 text-brand-navy-dark dark:text-white"/> Paystack Gateway
            </h3>
            
            <div className="space-y-5 flex-grow">
                 <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-700">
                    <span className="text-sm font-bold text-gray-700 dark:text-gray-200">Enable Payments</span>
                    <button 
                        onClick={() => setConfig({...config, isEnabled: !config.isEnabled})}
                        className={`w-12 h-6 rounded-full transition-all relative ${config.isEnabled ? 'bg-brand-green' : 'bg-gray-300'}`}
                    >
                        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${config.isEnabled ? 'left-7' : 'left-1'}`}></div>
                    </button>
                </div>

                <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Environment Mode</label>
                    <button 
                        onClick={() => setConfig({...config, isLive: !config.isLive})}
                        className={`w-full flex items-center justify-between p-4 rounded-2xl border-2 transition-all ${config.isLive ? 'border-brand-green bg-green-50/50' : 'border-brand-gold bg-yellow-50/50'}`}
                    >
                        <span className={`text-xs font-black uppercase ${config.isLive ? 'text-brand-green' : 'text-brand-gold'}`}>{config.isLive ? 'Live Production' : 'Sandbox / Testing'}</span>
                        <div className={`w-2.5 h-2.5 rounded-full ${config.isLive ? 'bg-brand-green' : 'bg-brand-gold'} animate-pulse`}></div>
                    </button>
                </div>

                <div className="grid grid-cols-1 gap-4">
                    <div>
                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 ml-1">Public Key</label>
                        <input type="text" value={config.paystackPublicKey} onChange={e => setConfig({...config, paystackPublicKey: e.target.value})} className={inputClass} placeholder="pk_test_..." />
                    </div>
                    <div>
                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 ml-1">Secret Key</label>
                        <div className="relative">
                            <input 
                                type={showSecrets ? "text" : "password"} 
                                value={config.paystackSecretKey} 
                                onChange={e => setConfig({...config, paystackSecretKey: e.target.value})} 
                                className={inputClass} 
                                placeholder="sk_test_..." 
                            />
                            <button 
                                type="button"
                                onClick={() => setShowSecrets(!showSecrets)}
                                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-brand-gold"
                            >
                                {showSecrets ? <LockClosedIcon className="w-4 h-4"/> : <EyeIcon className="w-4 h-4"/>}
                            </button>
                        </div>
                    </div>
                </div>

                <div className="pt-2">
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 ml-1">Webhook URL</label>
                    <div className="flex gap-2">
                        <input type="text" value={config.webhookUrl} readOnly className={`${inputClass} bg-gray-100 dark:bg-gray-900 cursor-not-allowed`} />
                        <Button size="sm" variant="outline" onClick={() => navigator.clipboard.writeText(config.webhookUrl)}>Copy</Button>
                    </div>
                </div>
            </div>

            <div className="pt-8 border-t border-gray-50 dark:border-gray-700 flex items-center justify-between">
                <Button onClick={handleSave} className="!rounded-2xl !px-10" disabled={!config.isEnabled}>
                    Secure Sync
                </Button>
                {isSaved && <span className="text-brand-green text-xs font-black uppercase flex items-center gap-1 animate-fade-in"><CheckCircleIcon className="w-4 h-4"/> Encrypted</span>}
            </div>
        </div>
    );
};

export default AdminPaymentGatewayManager;
