
import React, { useState, useEffect } from 'react';
import type { Cause, Investment } from '../../types.ts';
import { mockCauses, mockInvestments } from '../../data/mockData.ts';
import Button from '../ui/Button.tsx';
import { TrashIcon, EditIcon, PlusCircleIcon, SparklesIcon, HeartIcon, BanknotesIcon } from '../icons/Icons.tsx';
import ContentEditModal from '../modals/ContentEditModal.tsx';

const AdminContentManager: React.FC = () => {
    const [causes, setCauses] = useState<Cause[]>([]);
    const [investments, setInvestments] = useState<Investment[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingItem, setEditingItem] = useState<Partial<Cause | Investment> | null>(null);
    const [modalType, setModalType] = useState<'cause' | 'investment'>('cause');

    useEffect(() => {
        try {
            const storedCauses = localStorage.getItem('causes');
            setCauses(storedCauses ? JSON.parse(storedCauses) : mockCauses);
            
            const storedInvestments = localStorage.getItem('investments');
            setInvestments(storedInvestments ? JSON.parse(storedInvestments) : mockInvestments);
        } catch (error) {
            console.error("Failed to load content from localStorage", error);
        }
    }, []);

    const handleSaveToLocalStorage = <T extends Cause | Investment>(items: T[], key: string) => {
        localStorage.setItem(key, JSON.stringify(items));
    };

    const handleOpenModal = (item: Partial<Cause | Investment> | null, type: 'cause' | 'investment') => {
        setEditingItem(item);
        setModalType(type);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingItem(null);
    };

    const handleSaveContent = (content: Cause | Investment) => {
        if (modalType === 'cause') {
            const newCauses = editingItem?.id
                ? causes.map(c => c.id === content.id ? content as Cause : c)
                : [...causes, { ...content as Cause, id: crypto.randomUUID() }];
            setCauses(newCauses);
            handleSaveToLocalStorage(newCauses, 'causes');
        } else {
            let newInvestments: Investment[];
            if (editingItem?.id) {
                newInvestments = investments.map(i => i.id === content.id ? content as Investment : i);
            } else {
                newInvestments = [...investments, { ...content as Investment, id: crypto.randomUUID(), raised: (content as Investment).raised || 0 }];
            }
            setInvestments(newInvestments);
            handleSaveToLocalStorage(newInvestments, 'investments');
        }
        handleCloseModal();
    };

    const handleDelete = (id: string, type: 'cause' | 'investment') => {
        if (window.confirm("Are you sure you want to delete this item? This action cannot be undone.")) {
            if (type === 'cause') {
                const updated = causes.filter(c => c.id !== id);
                setCauses(updated);
                handleSaveToLocalStorage(updated, 'causes');
            } else {
                const updated = investments.filter(i => i.id !== id);
                setInvestments(updated);
                handleSaveToLocalStorage(updated, 'investments');
            }
        }
    };

    const renderList = <T extends { id: string; title: string }>(items: T[], type: 'cause' | 'investment', title: string) => (
        <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h3 className="text-xl font-display font-black text-brand-navy-dark uppercase tracking-widest">{title}</h3>
                    <p className="text-xs text-gray-400 font-bold uppercase mt-1">Manage programs & platform impact</p>
                </div>
                 <Button size="sm" variant="primary" className="flex items-center gap-2 !px-6" onClick={() => handleOpenModal(null, type)}>
                    <PlusCircleIcon className="w-5 h-5" /> New {type}
                </Button>
            </div>
            <div className="space-y-3">
                {items.map(item => {
                    const isFeatured = 'isTopPriority' in item ? (item as any).isTopPriority : (item as any).isFeatured;
                    return (
                        <div key={item.id} className="flex items-center justify-between p-4 bg-gray-50 border border-gray-100 rounded-2xl group hover:border-brand-gold transition-colors">
                            <div className="flex items-center gap-3">
                                {isFeatured ? <SparklesIcon className="w-5 h-5 text-brand-gold" /> : (type === 'cause' ? <HeartIcon className="w-5 h-5 text-gray-300" /> : <BanknotesIcon className="w-5 h-5 text-gray-300" />)}
                                <div>
                                    <p className="font-black text-brand-navy-dark">{item.title}</p>
                                    <div className="flex items-center gap-2 mt-0.5">
                                        {isFeatured && <span className="text-[9px] font-black bg-brand-gold text-brand-navy-dark px-1.5 py-0.5 rounded uppercase tracking-widest">Featured</span>}
                                        <span className="text-[10px] text-gray-400 font-mono">#{item.id.slice(0, 8)}</span>
                                    </div>
                                </div>
                            </div>
                            <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button className="p-2 bg-white rounded-full text-gray-400 hover:text-brand-gold shadow-sm" onClick={() => handleOpenModal(item, type)} aria-label="Edit"><EditIcon className="w-4 h-4" /></button>
                                <button className="p-2 bg-white rounded-full text-gray-400 hover:text-red-500 shadow-sm" onClick={() => handleDelete(item.id, type)} aria-label="Delete"><TrashIcon className="w-4 h-4" /></button>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );

    return (
        <>
            <div className="space-y-8 animate-fade-in">
                {renderList(investments, 'investment', 'Investment Opportunities')}
                {renderList(causes, 'cause', 'Donation Causes')}
            </div>
            {isModalOpen && (
                <ContentEditModal
                    item={editingItem}
                    type={modalType}
                    onClose={handleCloseModal}
                    onSave={handleSaveContent}
                />
            )}
        </>
    );
};

export default AdminContentManager;
