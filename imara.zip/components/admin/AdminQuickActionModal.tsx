import React, { useState } from 'react';
import { XIcon, UserIcon, StorefrontIcon, ShoppingBagIcon, MapPinIcon } from '../icons/Icons.tsx';
import Button from '../ui/Button.tsx';
import { useDataSync } from '../../contexts/DataSyncContext.tsx';
import { db, collection, addDoc, serverTimestamp } from '../../firebase/firestore.ts';

interface AdminQuickActionModalProps {
    onClose: () => void;
}

const AdminQuickActionModal: React.FC<AdminQuickActionModalProps> = ({ onClose }) => {
    const [activeTab, setActiveTab] = useState<'partner' | 'product' | 'market' | 'citizen'>('partner');
    const [submitting, setSubmitting] = useState(false);
    // Generic form data, would be structured more explicitly in a real deep app
    const [formData, setFormData] = useState<any>({});

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            let collName = '';
            let dataPayload = { ...formData, createdAt: serverTimestamp() };
            
            switch (activeTab) {
                case 'partner': 
                    collName = 'partner_applications'; 
                    dataPayload.status = 'approved'; 
                    break;
                case 'product': 
                    collName = 'products'; 
                    dataPayload.isVerified = true;
                    break;
                case 'market': 
                    collName = 'markets'; 
                    break;
                case 'citizen': 
                    collName = 'users'; 
                    dataPayload.role = 'user';
                    break;
            }

            await addDoc(collection(db, collName), dataPayload);
            alert(`New ${activeTab} added successfully!`);
            onClose();
        } catch (error) {
            console.error(error);
            alert("Error adding entity");
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
             <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
             <div className="relative bg-white dark:bg-brand-navy-dark w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden animate-slide-up border border-gray-100 dark:border-gray-800">
                <div className="p-6 border-b border-gray-100 dark:border-gray-800 flex justify-between items-center">
                    <h2 className="text-2xl font-display font-bold text-brand-navy-dark dark:text-white">Admin Quick Add</h2>
                    <button onClick={onClose} className="p-2 bg-gray-100 dark:bg-gray-800 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors">
                        <XIcon className="w-5 h-5 text-gray-500 dark:text-gray-400" />
                    </button>
                </div>

                <div className="flex bg-gray-100 dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800">
                     <button onClick={() => setActiveTab('partner')} className={`flex-1 py-3 text-sm font-bold flex items-center justify-center gap-2 transition-all ${activeTab === 'partner' ? 'bg-white dark:bg-brand-navy-dark border-b-2 border-brand-gold text-brand-gold' : 'text-gray-500'}`}>
                        <StorefrontIcon className="w-4 h-4"/> Partner
                     </button>
                     <button onClick={() => setActiveTab('product')} className={`flex-1 py-3 text-sm font-bold flex items-center justify-center gap-2 transition-all ${activeTab === 'product' ? 'bg-white dark:bg-brand-navy-dark border-b-2 border-brand-gold text-brand-gold' : 'text-gray-500'}`}>
                        <ShoppingBagIcon className="w-4 h-4"/> Product
                     </button>
                     <button onClick={() => setActiveTab('market')} className={`flex-1 py-3 text-sm font-bold flex items-center justify-center gap-2 transition-all ${activeTab === 'market' ? 'bg-white dark:bg-brand-navy-dark border-b-2 border-brand-gold text-brand-gold' : 'text-gray-500'}`}>
                        <MapPinIcon className="w-4 h-4"/> Market
                     </button>
                     <button onClick={() => setActiveTab('citizen')} className={`flex-1 py-3 text-sm font-bold flex items-center justify-center gap-2 transition-all ${activeTab === 'citizen' ? 'bg-white dark:bg-brand-navy-dark border-b-2 border-brand-gold text-brand-gold' : 'text-gray-500'}`}>
                        <UserIcon className="w-4 h-4"/> Citizen
                     </button>
                </div>

                <div className="p-6">
                    <form onSubmit={handleSubmit} className="space-y-4">
                         {activeTab === 'partner' && (
                             <>
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">Brand Name</label>
                                    <input type="text" required onChange={(e) => setFormData({...formData, brandName: e.target.value})} className="mt-1 w-full bg-gray-50 dark:bg-gray-800 border-none rounded-lg p-3 dark:text-white" />
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">Email</label>
                                    <input type="email" required onChange={(e) => setFormData({...formData, email: e.target.value})} className="mt-1 w-full bg-gray-50 dark:bg-gray-800 border-none rounded-lg p-3 dark:text-white" />
                                </div>
                             </>
                         )}
                         {activeTab === 'product' && (
                             <>
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">Product Name</label>
                                    <input type="text" required onChange={(e) => setFormData({...formData, name: e.target.value})} className="mt-1 w-full bg-gray-50 dark:bg-gray-800 border-none rounded-lg p-3 dark:text-white" />
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">Price</label>
                                    <input type="number" required onChange={(e) => setFormData({...formData, price: Number(e.target.value)})} className="mt-1 w-full bg-gray-50 dark:bg-gray-800 border-none rounded-lg p-3 dark:text-white" />
                                </div>
                             </>
                         )}
                         {activeTab === 'market' && (
                             <>
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">Market Name</label>
                                    <input type="text" required onChange={(e) => setFormData({...formData, name: e.target.value})} className="mt-1 w-full bg-gray-50 dark:bg-gray-800 border-none rounded-lg p-3 dark:text-white" />
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">Region</label>
                                    <input type="text" required onChange={(e) => setFormData({...formData, region: e.target.value})} className="mt-1 w-full bg-gray-50 dark:bg-gray-800 border-none rounded-lg p-3 dark:text-white" />
                                </div>
                             </>
                         )}
                         {activeTab === 'citizen' && (
                             <>
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">Full Name</label>
                                    <input type="text" required onChange={(e) => setFormData({...formData, fullName: e.target.value})} className="mt-1 w-full bg-gray-50 dark:bg-gray-800 border-none rounded-lg p-3 dark:text-white" />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                     <div>
                                        <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">Phone</label>
                                        <input type="text" onChange={(e) => setFormData({...formData, phone: e.target.value})} className="mt-1 w-full bg-gray-50 dark:bg-gray-800 border-none rounded-lg p-3 dark:text-white" />
                                     </div>
                                     <div>
                                        <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">Trust Score</label>
                                        <input type="number" defaultValue="50" onChange={(e) => setFormData({...formData, trustScore: Number(e.target.value)})} className="mt-1 w-full bg-gray-50 dark:bg-gray-800 border-none rounded-lg p-3 dark:text-white" />
                                     </div>
                                </div>
                             </>
                         )}
                         
                         <div className="pt-4 flex justify-end">
                             <Button type="submit" disabled={submitting}>
                                 {submitting ? 'Adding...' : `Add ${activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}`}
                             </Button>
                         </div>
                    </form>
                </div>
             </div>
        </div>
    );
};

export default AdminQuickActionModal;
