
import React, { useState, useEffect } from 'react';
import Button from '../ui/Button.tsx';
import { ChatBubbleLeftIcon, CheckCircleIcon, SparklesIcon } from '../icons/Icons.tsx';
import { db, doc, onSnapshot, setDoc } from '../../firebase/firestore.ts';

interface GossipPulseConfig {
    webhookUrl: string;
    isConnected: boolean;
    botName: string;
    notifyOnOrder: boolean;
    notifyOnNewUser: boolean;
    notifyOnReport: boolean;
}

const AdminGossipPulseManager: React.FC = () => {
    const [config, setConfig] = useState<GossipPulseConfig>({
        webhookUrl: 'https://imara.test/gossip-pulse-webhook',
        isConnected: false,
        botName: 'Imara Gossip Pulse System',
        notifyOnOrder: true,
        notifyOnNewUser: false,
        notifyOnReport: true,
    });
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        const unsubscribe = onSnapshot(doc(db, 'system', 'gossipPulse'), (snapshot) => {
            if (snapshot.exists()) {
                setConfig(snapshot.data() as GossipPulseConfig);
            }
        });
        return () => unsubscribe();
    }, []);

    const saveConfigToFirestore = async (newConfig: GossipPulseConfig) => {
        await setDoc(doc(db, 'system', 'gossipPulse'), newConfig);
    };

    const handleConnect = async () => {
        setIsSaving(true);
        try {
            const newConfig = { ...config, isConnected: !config.isConnected };
            await saveConfigToFirestore(newConfig);
        } finally {
            setIsSaving(false);
        }
    };

    const handleToggle = (key: keyof GossipPulseConfig) => {
        const newConfig = { ...config, [key]: !config[key] };
        saveConfigToFirestore(newConfig);
    }

    return (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-[40px] shadow-sm border border-gray-100 dark:border-gray-700 animate-fade-in h-full">
            <h3 className="text-xl font-display font-black text-brand-navy-dark dark:text-white mb-6 flex items-center gap-2">
                <SparklesIcon className="w-6 h-6 text-brand-gold" /> Gossip Pulse Management
            </h3>
            
            <div className="p-6 border border-gray-100 dark:border-gray-700 rounded-3xl mb-8 bg-gray-50/50 dark:bg-gray-900/50">
                <div className="flex justify-between items-center">
                    <div>
                        <p className="text-xs font-black text-gray-400 uppercase tracking-widest">Master Connection</p>
                        <div className="flex items-center gap-2 mt-1">
                            <div className={`w-2.5 h-2.5 rounded-full ${config.isConnected ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`}></div>
                            <span className="text-sm font-bold text-gray-700 dark:text-gray-300">{config.isConnected ? 'Overseer Online' : 'Command Port Closed'}</span>
                        </div>
                    </div>
                    <Button onClick={handleConnect} disabled={isSaving} variant={config.isConnected ? 'outline' : 'primary'} className={config.isConnected ? '!border-red-500 !text-red-500 !rounded-2xl' : '!bg-[#25D366] !text-white border-none !rounded-2xl shadow-xl'}>
                        {isSaving ? 'Processing...' : config.isConnected ? 'Disconnect' : 'Connect Business Account'}
                    </Button>
                </div>
            </div>

            <div className="space-y-5">
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-4">Command Notifications</p>
                
                {[
                    { key: 'notifyOnOrder', label: 'Order Intel', desc: 'Real-time order details to Gossip Pulse' },
                    { key: 'notifyOnNewUser', label: 'Citizenship Alert', desc: 'Notify on every new user registration' },
                    { key: 'notifyOnReport', label: 'Safety Triggers', desc: 'Instant alerts on reported content' },
                ].map((item) => (
                    <div key={item.key} className="flex items-center justify-between group">
                        <div>
                            <p className="text-sm font-bold text-brand-navy-dark dark:text-white">{item.label}</p>
                            <p className="text-xs text-gray-400">{item.desc}</p>
                        </div>
                        <button 
                            disabled={!config.isConnected}
                            onClick={() => handleToggle(item.key as any)}
                            className={`w-12 h-6 rounded-full transition-all relative ${config[item.key as keyof WhatsAppConfig] ? 'bg-brand-green' : 'bg-gray-200 dark:bg-gray-700'} ${!config.isConnected && 'opacity-30 cursor-not-allowed'}`}
                        >
                            <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${config[item.key as keyof WhatsAppConfig] ? 'left-7' : 'left-1'}`}></div>
                        </button>
                    </div>
                ))}
            </div>
            
            {config.isConnected && (
                <div className="mt-8 p-4 bg-brand-green/10 border border-brand-green/20 rounded-2xl flex items-center gap-3 text-brand-green-dark dark:text-brand-green text-xs font-bold animate-fade-in">
                    <BoltIcon className="w-5 h-5" />
                    <p>Port open. Master Admin receiving telemetry at {config.phoneNumber}.</p>
                </div>
            )}
        </div>
    );
};

export default AdminWhatsAppManager;
