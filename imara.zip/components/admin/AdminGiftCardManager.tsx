
import React, { useState, useEffect } from 'react';
import type { GiftCard } from '../../types.ts';
import { mockGiftCards } from '../../data/mockData.ts';
import Button from '../ui/Button.tsx';
import { EditIcon, TrashIcon, PlusCircleIcon, CheckCircleIcon, XCircleIcon } from '../icons/Icons.tsx';
import GiftCardEditModal from '../modals/GiftCardEditModal.tsx';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';

const STORAGE_KEY = 'imara_admin_gift_cards';

const AdminGiftCardManager: React.FC = () => {
    const [cards, setCards] = useState<GiftCard[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingCard, setEditingCard] = useState<Partial<GiftCard> | null>(null);
    const { formatCurrency } = useCurrency();

    useEffect(() => {
        try {
            const storedCards = localStorage.getItem(STORAGE_KEY);
            const initialCards = storedCards ? JSON.parse(storedCards) : mockGiftCards;
            setCards(initialCards);
        } catch (error) {
            console.error("Failed to load cards from localStorage", error);
            setCards(mockGiftCards);
        }
    }, []);

    const handleSaveToLocalStorage = (updatedCards: GiftCard[]) => {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedCards));
        } catch (error) {
            console.error("Failed to save cards", error);
        }
    };

    const handleOpenModal = (card: Partial<GiftCard> | null) => {
        setEditingCard(card);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingCard(null);
    };

    const handleSaveCard = (cardData: GiftCard) => {
        const newCards = editingCard?.code
            ? cards.map(c => c.code === cardData.code ? cardData : c)
            : [...cards, cardData];
        setCards(newCards);
        handleSaveToLocalStorage(newCards);
        handleCloseModal();
    };

    const handleDelete = (code: string) => {
        if (window.confirm(`Are you sure you want to delete the coupon "${code}"? This action cannot be undone.`)) {
            const updated = cards.filter(c => c.code !== code);
            setCards(updated);
            handleSaveToLocalStorage(updated);
        }
    };

    const getCardValue = (card: GiftCard) => {
        return card.type === 'fixed' ? formatCurrency(card.value) : `${card.value}%`;
    };

    return (
        <>
            <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-display font-semibold text-brand-green-dark">Gift Card / Coupon Manager</h3>
                    <Button size="sm" variant="primary" className="flex items-center gap-2" onClick={() => handleOpenModal({})}>
                        <PlusCircleIcon className="w-5 h-5" /> Add New Card
                    </Button>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3">Code</th>
                                <th scope="col" className="px-6 py-3">Description</th>
                                <th scope="col" className="px-6 py-3">Value</th>
                                <th scope="col" className="px-6 py-3">Expiry</th>
                                <th scope="col" className="px-6 py-3">Status</th>
                                <th scope="col" className="px-6 py-3 text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {cards.map(card => (
                                <tr key={card.code} className="bg-white border-b hover:bg-gray-50">
                                    <td className="px-6 py-4 font-mono font-medium text-gray-900">{card.code}</td>
                                    <td className="px-6 py-4">{card.description}</td>
                                    <td className="px-6 py-4 font-semibold">{getCardValue(card)}</td>
                                    <td className="px-6 py-4">{new Date(card.expiryDate).toLocaleDateString()}</td>
                                    <td className="px-6 py-4">
                                        {card.isActive ? 
                                            <span className="flex items-center gap-1 text-green-600"><CheckCircleIcon className="w-4 h-4"/> Active</span> : 
                                            <span className="flex items-center gap-1 text-red-600"><XCircleIcon className="w-4 h-4"/> Inactive</span>
                                        }
                                    </td>
                                    <td className="px-6 py-4 flex justify-center gap-2">
                                        <Button size="sm" variant="outline" className="p-2" onClick={() => handleOpenModal(card)} aria-label={`Edit ${card.code}`}><EditIcon className="w-4 h-4" /></Button>
                                        <Button size="sm" variant="outline" className="p-2 hover:bg-red-500 hover:text-white" onClick={() => handleDelete(card.code)} aria-label={`Delete ${card.code}`}><TrashIcon className="w-4 h-4" /></Button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            {isModalOpen && (
                <GiftCardEditModal card={editingCard} onClose={handleCloseModal} onSave={handleSaveCard} />
            )}
        </>
    );
};

export default AdminGiftCardManager;
