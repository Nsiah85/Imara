
import React from 'react';
import { Link } from 'react-router-dom';
import type { CartItem } from '../../types.ts';
import { useCart } from '../../contexts/CartContext.tsx';
import { MinusIcon, PlusIcon, TrashIcon } from '../icons/Icons.tsx';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';

const CartItemRow: React.FC<{ item: CartItem }> = ({ item }) => {
    const { updateQuantity, removeFromCart } = useCart();
    const { formatCurrency } = useCurrency();

    return (
        <li className="py-4 px-4 sm:px-6">
            <div className="flex flex-col sm:flex-row bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-4 gap-6 hover:shadow-md transition-shadow">
                <div className="flex-shrink-0 w-full sm:w-32 h-32 bg-gray-100 dark:bg-gray-700 rounded-xl overflow-hidden relative">
                    <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                </div>
                
                <div className="flex-1 flex flex-col justify-between">
                    <div>
                        <div className="flex justify-between items-start">
                             <div>
                                <Link to={`/product/${item.id}`} className="font-display font-bold text-lg text-brand-navy-dark dark:text-white hover:text-brand-green transition-colors">
                                    {item.name}
                                </Link>
                                <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wider mt-1">by {item.vendor}</p>
                            </div>
                            <p className="font-bold text-lg text-brand-green dark:text-brand-gold">{formatCurrency(item.price * item.quantity)}</p>
                        </div>
                    </div>

                    <div className="flex items-center justify-between mt-4 sm:mt-0">
                        <div className="flex items-center gap-3">
                            <button 
                                onClick={() => updateQuantity(item.id, item.quantity - 1)} 
                                className="w-8 h-8 flex items-center justify-center bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 rounded-full text-gray-600 dark:text-gray-300 transition-colors disabled:opacity-50"
                                disabled={item.quantity <= 1}
                                aria-label="Decrease quantity"
                            >
                                <MinusIcon className="w-4 h-4" />
                            </button>
                            <span className="font-bold text-lg text-brand-navy-dark dark:text-white w-8 text-center">{item.quantity}</span>
                            <button 
                                onClick={() => updateQuantity(item.id, item.quantity + 1)} 
                                className="w-8 h-8 flex items-center justify-center bg-brand-navy-dark hover:bg-brand-navy text-white rounded-full shadow-sm transition-colors"
                                aria-label="Increase quantity"
                            >
                                <PlusIcon className="w-4 h-4" />
                            </button>
                        </div>

                        <button 
                            onClick={() => removeFromCart(item.id)} 
                            className="p-2 text-gray-400 hover:text-red-500 transition-colors rounded-full hover:bg-red-50 dark:hover:bg-red-900/20"
                            title="Remove Item"
                        >
                            <TrashIcon className="w-5 h-5" />
                        </button>
                    </div>
                </div>
            </div>
        </li>
    );
};

export default CartItemRow;
