import React from 'react';
import { useCall } from '../../contexts/CallContext';
import { PhoneIcon, MicrophoneIcon, VideoCameraIcon, XIcon, ArrowUpTrayIcon } from '../icons/Icons';
import Avatar from '../ui/Avatar';
import Badge from '../ui/Badge';

const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
    const secs = (seconds % 60).toString().padStart(2, '0');
    return `${mins}:${secs}`;
};

const CallOverlay: React.FC = () => {
    const { isActive, isMinimized, participant, type, status, duration, isMuted, isCameraOff, endCall, toggleMinimize, toggleMute, toggleCamera, maximize } = useCall();

    if (!isActive || !participant) return null;

    // Minimized State (PIP)
    if (isMinimized) {
        return (
            <div className="fixed bottom-24 right-4 z-[100] w-48 bg-brand-navy-dark rounded-lg shadow-2xl border border-brand-gold overflow-hidden animate-fade-in-up cursor-pointer" onClick={maximize}>
                <div className="relative h-32 bg-black/50">
                    <Avatar 
                        imageUrl={participant.avatarUrl}
                        name={participant.name}
                        className="w-full h-full object-cover opacity-60"
                    />
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <p className="text-white font-bold text-sm truncate px-2">{participant.name}</p>
                        <p className="text-brand-gold text-xs font-mono">{formatDuration(duration)}</p>
                    </div>
                    <div className="absolute bottom-2 right-2 flex gap-2" onClick={e => e.stopPropagation()}>
                        <button onClick={toggleMute} className={`p-1 rounded-full ${isMuted ? 'bg-white text-red-500' : 'bg-white/20 text-white'}`}>
                            <MicrophoneIcon className="w-3 h-3" />
                        </button>
                        <button onClick={endCall} className="p-1 rounded-full bg-red-600 text-white">
                            <PhoneIcon className="w-3 h-3 transform rotate-[135deg]" />
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    // Full Screen State
    return (
        <div className="fixed inset-0 z-[100] bg-brand-navy-dark flex flex-col items-center justify-center p-4">
            <div className="absolute top-4 right-4">
                <button onClick={toggleMinimize} className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white" aria-label="Minimize call">
                    <ArrowUpTrayIcon className="w-6 h-6 transform rotate-180" /> {/* Using arrow as down icon */}
                </button>
            </div>

            <div className="flex flex-col items-center max-w-sm w-full animate-fade-in">
                <div className="relative">
                    <Avatar 
                        imageUrl={participant.avatarUrl}
                        name={participant.name}
                        id={participant.id}
                        className="w-40 h-40 rounded-full object-cover border-4 border-brand-gold shadow-[0_0_30px_rgba(255,215,0,0.3)]"
                        textClassName="text-6xl font-bold text-white"
                    />
                    {status === 'connected' && (
                        <div className="absolute -bottom-2 inset-x-0 flex justify-center">
                            <Badge className="bg-green-500 text-white border-none shadow-lg">Live</Badge>
                        </div>
                    )}
                </div>

                <h2 className="mt-8 text-3xl font-display font-bold text-white text-center">{participant.name}</h2>
                <p className="text-brand-gold/80 text-lg mt-2 font-mono">
                    {status === 'ringing' ? 'Ringing...' : formatDuration(duration)}
                </p>
                <p className="text-white/50 text-sm mt-1 capitalize">{type} Call via Imara</p>

                <div className="mt-12 flex items-center gap-6">
                    <button 
                        onClick={toggleMute}
                        className={`p-4 rounded-full transition-all duration-300 ${isMuted ? 'bg-white text-brand-navy-dark' : 'bg-white/10 text-white hover:bg-white/20'}`}
                    >
                        <MicrophoneIcon className="w-8 h-8" />
                    </button>

                    <button 
                        onClick={endCall}
                        className="p-5 rounded-full bg-red-600 text-white shadow-lg hover:bg-red-700 hover:scale-110 transition-all duration-300"
                    >
                        <PhoneIcon className="w-10 h-10 transform rotate-[135deg]" />
                    </button>

                    {type === 'video' && (
                        <button 
                            onClick={toggleCamera}
                            className={`p-4 rounded-full transition-all duration-300 ${isCameraOff ? 'bg-white text-brand-navy-dark' : 'bg-white/10 text-white hover:bg-white/20'}`}
                        >
                            <VideoCameraIcon className="w-8 h-8" />
                        </button>
                    )}
                </div>
                <p className="mt-8 text-white/30 text-xs">Minimize to browse the app while talking</p>
            </div>
        </div>
    );
};

export default CallOverlay;