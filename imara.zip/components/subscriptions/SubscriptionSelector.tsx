

import React from 'react';
import type { SubscriptionPlan } from '../../types.ts';
import SubscriptionCard from './SubscriptionCard.tsx';
import Button from '../ui/Button.tsx';

interface SubscriptionSelectorProps {
    plans: SubscriptionPlan[];
    onPlanSelected: (planId: string) => void;
}

const SubscriptionSelector: React.FC<SubscriptionSelectorProps> = ({ plans, onPlanSelected }) => {
    return (
        <div className="w-full text-center">
            <h2 className="text-3xl font-display font-bold text-brand-green-dark">Congratulations! You're Approved!</h2>
            <p className="mt-2 text-gray-600 max-w-xl mx-auto">Just one more step. Choose a subscription plan below to unlock your partner benefits and start selling or offering your services.</p>
            
            <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
                {plans.map(plan => (
                    <SubscriptionCard 
                        key={plan.id}
                        plan={plan}
                        onSelect={() => onPlanSelected(plan.id)}
                    />
                ))}
            </div>
        </div>
    );
};

export default SubscriptionSelector;