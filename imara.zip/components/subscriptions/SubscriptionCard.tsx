

import React from 'react';
import type { SubscriptionPlan } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { CheckIcon } from '../icons/Icons.tsx';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';

interface SubscriptionCardProps {
    plan: SubscriptionPlan;
    onSelect?: () => void;
}

const SubscriptionCard: React.FC<SubscriptionCardProps> = ({ plan, onSelect }) => {
    const { formatCurrency } = useCurrency();
    const isFree = plan.price === 0;

    return (
        <div className={`flex flex-col p-8 rounded-xl border-2 ${plan.isFeatured ? 'border-brand-gold bg-brand-gold/5' : 'border-gray-200 bg-white'}`}>
            {plan.isFeatured && (
                <div className="text-center mb-4">
                    <span className="px-3 py-1 text-xs font-semibold tracking-wider uppercase rounded-full bg-brand-gold text-brand-green-dark">Most Popular</span>
                </div>
            )}
            <h3 className="text-2xl font-display font-bold text-brand-green-dark text-center">{plan.name}</h3>
            <div className="mt-4 text-center">
                {isFree ? (
                     <span className="text-5xl font-display font-extrabold text-brand-green-dark">Free</span>
                ) : (
                    <>
                        <span className="text-5xl font-display font-extrabold text-brand-green-dark">{formatCurrency(plan.price, {minimumFractionDigits: 0})}</span>
                        <span className="text-brand-gray">/ {plan.billingCycle}</span>
                    </>
                )}
            </div>
            <ul className="mt-8 space-y-4 text-left flex-grow">
                {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                        <CheckIcon className="w-5 h-5 text-brand-green flex-shrink-0 mr-3 mt-1" />
                        <span className="text-gray-600">{feature}</span>
                    </li>
                ))}
            </ul>
            {onSelect && (
                 <div className="mt-8">
                    <Button 
                        onClick={onSelect}
                        variant={plan.isFeatured ? 'primary' : 'outline'}
                        size="lg" 
                        className="w-full"
                    >
                        Choose {plan.name}
                    </Button>
                </div>
            )}
        </div>
    );
};

export default SubscriptionCard;