import React from 'react';
import { CheckCircleIcon } from '../icons/Icons.tsx';

interface StepIndicatorProps {
  steps: string[];
  currentStep: number;
}

const StepIndicator: React.FC<StepIndicatorProps> = ({ steps, currentStep }) => {
  return (
    <nav aria-label="Progress">
      <ol role="list" className="flex items-center">
        {steps.map((step, stepIdx) => (
          <li key={step} className={`relative ${stepIdx !== steps.length - 1 ? 'pr-8 sm:pr-20' : ''}`}>
            {stepIdx < currentStep ? (
              <>
                <div className="absolute inset-0 flex items-center" aria-hidden="true">
                  <div className="h-0.5 w-full bg-brand-gold" />
                </div>
                <div className="relative flex h-8 w-8 items-center justify-center rounded-full bg-brand-gold">
                   <CheckCircleIcon className="h-5 w-5 text-white" aria-hidden="true" />
                </div>
                <span className="absolute mt-2 text-sm font-medium text-brand-green-dark">{step}</span>
              </>
            ) : stepIdx === currentStep ? (
              <>
                <div className="absolute inset-0 flex items-center" aria-hidden="true">
                  <div className="h-0.5 w-full bg-gray-200" />
                </div>
                <div className="relative flex h-8 w-8 items-center justify-center rounded-full border-2 border-brand-gold bg-white">
                  <span className="h-2.5 w-2.5 rounded-full bg-brand-gold" />
                </div>
                 <span className="absolute mt-2 text-sm font-medium text-brand-gold">{step}</span>
              </>
            ) : (
              <>
                <div className="absolute inset-0 flex items-center" aria-hidden="true">
                  <div className="h-0.5 w-full bg-gray-200" />
                </div>
                <div className="relative flex h-8 w-8 items-center justify-center rounded-full border-2 border-gray-300 bg-white" />
                <span className="absolute mt-2 text-sm font-medium text-gray-500">{step}</span>
              </>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
};

export default StepIndicator;