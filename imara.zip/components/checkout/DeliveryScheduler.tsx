import React, { useState } from 'react';
import type { DeliveryDetails } from '../../types';
import Button from '../ui/Button';
import { useLanguage } from '../../contexts/LanguageContext';

interface DeliverySchedulerProps {
  onSubmit: (data: DeliveryDetails) => void;
  onBack: () => void;
}

const timeSlots = ["9am - 12pm", "1pm - 4pm", "5pm - 8pm"];

const DeliveryScheduler: React.FC<DeliverySchedulerProps> = ({ onSubmit, onBack }) => {
    const [date, setDate] = useState('');
    const [timeSlot, setTimeSlot] = useState(timeSlots[0]);
    const [error, setError] = useState('');
    const { t } = useLanguage();

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!date) {
            setError('Please select a delivery date.');
            return;
        }
        setError('');
        onSubmit({ date, timeSlot });
    };

    const getMinDate = () => {
        const today = new Date();
        today.setDate(today.getDate() + 1); // Delivery starts from tomorrow
        return today.toISOString().split('T')[0];
    };

    const inputClass = "mt-1 block w-full bg-brand-green-dark text-brand-gold-light border border-brand-green rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent placeholder:text-gray-400";

    return (
        <div className="bg-white p-8 rounded-lg shadow-md animate-fade-in">
            <h2 className="text-2xl font-display font-semibold text-brand-green-dark mb-6">{t('checkout.delivery.title')}</h2>
            <p className="text-sm text-gray-600 mb-6">{t('checkout.delivery.subtitle')}</p>
            <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                    <label htmlFor="deliveryDate" className="block text-sm font-medium text-gray-700">{t('checkout.delivery.dateLabel')}</label>
                    <input 
                        type="date" 
                        name="deliveryDate" 
                        id="deliveryDate" 
                        value={date} 
                        onChange={(e) => setDate(e.target.value)} 
                        required 
                        min={getMinDate()}
                        className={inputClass}
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700">{t('checkout.delivery.timeLabel')}</label>
                    <div className="mt-2 grid grid-cols-1 sm:grid-cols-3 gap-3">
                        {timeSlots.map(slot => (
                            <label key={slot} className={`relative block cursor-pointer rounded-lg border p-3 text-center transition-all ${timeSlot === slot ? 'border-brand-gold ring-2 ring-brand-gold' : 'border-gray-300'}`}>
                                <input
                                    type="radio"
                                    name="timeSlot"
                                    value={slot}
                                    checked={timeSlot === slot}
                                    onChange={() => setTimeSlot(slot)}
                                    className="sr-only"
                                />
                                <span className="text-sm font-medium text-brand-green-dark">{slot}</span>
                            </label>
                        ))}
                    </div>
                </div>
                {error && <p className="text-sm text-red-600">{error}</p>}
                <div className="pt-4 flex flex-col-reverse sm:flex-row gap-4 justify-between">
                    <Button type="button" variant="outline" onClick={onBack} className="w-full sm:w-auto">{t('general.back')}</Button>
                    <Button type="submit" size="lg" className="w-full sm:w-auto">{t('checkout.delivery.button')}</Button>
                </div>
            </form>
        </div>
    );
};

export default DeliveryScheduler;