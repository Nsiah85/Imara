
import React from 'react';
import type { CartItem, ShippingAddress, ShippingMethod, GiftCard, DeliveryDetails } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';
import { useLanguage } from '../../contexts/LanguageContext.tsx';
import { TicketIcon } from '../icons/Icons.tsx';

interface OrderReviewProps {
  shippingDetails: ShippingAddress;
  shippingMethod: ShippingMethod;
  deliveryDetails: DeliveryDetails | null;
  cartItems: CartItem[];
  subtotal: number;
  shippingCost: number;
  total: number;
  onPlaceOrder: () => void;
  onBack: () => void;
  appliedCoupon: GiftCard | null;
  discount: number;
  onApplyCoupon: () => void;
  onRemoveCoupon: () => void;
  couponError: string | null;
  couponCode: string;
  setCouponCode: (code: string) => void;
}

const OrderReview: React.FC<OrderReviewProps> = ({
  shippingDetails,
  shippingMethod,
  deliveryDetails,
  cartItems,
  subtotal,
  shippingCost,
  total,
  onPlaceOrder,
  onBack,
  appliedCoupon,
  discount,
  onApplyCoupon,
  onRemoveCoupon,
  couponError,
  couponCode,
  setCouponCode,
}) => {
  const { formatCurrency } = useCurrency();
  const { t } = useLanguage();
  
  return (
    <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-md">
      <h2 className="text-2xl font-display font-semibold text-brand-green-dark dark:text-white mb-6">{t('checkout.review.title')}</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Shipping & Payment Details */}
        <div>
          <div className="mb-6">
            <h3 className="text-lg font-display font-semibold text-brand-green dark:text-brand-gold mb-2">{t('checkout.review.shippingTo')}</h3>
            <div className="text-gray-600 dark:text-gray-300 text-sm">
              <p className="font-medium text-gray-800 dark:text-gray-100">{shippingDetails.fullName}</p>
              <p>{shippingDetails.addressLine1}</p>
              <p>{shippingDetails.city}, {shippingDetails.postalCode}</p>
              <p>{shippingDetails.country}</p>
              <p>{shippingDetails.email}</p>
            </div>
          </div>
          {deliveryDetails && (
              <div className="mb-6">
                  <h3 className="text-lg font-display font-semibold text-brand-green dark:text-brand-gold mb-2">{t('checkout.review.deliveryTitle')}</h3>
                  <div className="text-gray-600 dark:text-gray-300 text-sm">
                      <p><span className="font-medium text-gray-800 dark:text-gray-100">{t('checkout.review.deliveryDate')}:</span> {new Date(deliveryDetails.date).toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                      <p><span className="font-medium text-gray-800 dark:text-gray-100">{t('checkout.review.deliveryTime')}:</span> {deliveryDetails.timeSlot}</p>
                  </div>
              </div>
          )}
          <div>
            <h3 className="text-lg font-display font-semibold text-brand-green dark:text-brand-gold mb-2">{t('checkout.review.paymentMethod')}</h3>
            <p className="text-gray-600 dark:text-gray-300 text-sm">Credit Card ending in 1234</p>
            {deliveryDetails && <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">(Or Payment on Delivery)</p>}
          </div>
        </div>
        
        {/* Order Summary */}
        <div>
          <h3 className="text-lg font-display font-semibold text-brand-green dark:text-brand-gold mb-4">{t('checkout.review.orderSummary')}</h3>
          <ul className="space-y-4 mb-4">
            {cartItems.map(item => (
              <li key={item.id} className="flex items-center gap-4 text-sm">
                <img src={item.imageUrl} alt={item.name} className="w-16 h-16 rounded-md object-cover"/>
                <div className="flex-grow">
                  <p className="font-semibold text-gray-800 dark:text-gray-100">{item.name}</p>
                  <p className="text-gray-500 dark:text-gray-400">Qty: {item.quantity}</p>
                </div>
                <p className="font-semibold text-gray-800 dark:text-gray-100">{formatCurrency(item.price * item.quantity)}</p>
              </li>
            ))}
          </ul>
          
          {/* Coupon Section */}
          <div className="border-t dark:border-gray-700 pt-4 mb-4">
            {!appliedCoupon ? (
              <div>
                <label htmlFor="coupon-code" className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1 mb-1">
                    <TicketIcon className="w-4 h-4 text-brand-gold" />
                    Gift card or discount code
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    id="coupon-code"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                    placeholder="Enter code"
                    className="block w-full rounded-md border border-gray-300 dark:bg-gray-700 dark:border-gray-600 shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent sm:text-sm"
                  />
                  <Button type="button" variant="outline" onClick={onApplyCoupon} disabled={!couponCode}>Apply</Button>
                </div>
                {couponError && <p className="mt-1 text-sm text-red-600">{couponError}</p>}
              </div>
            ) : (
              <div className="bg-green-50 dark:bg-green-900/50 text-green-800 dark:text-green-200 p-3 rounded-md border border-green-200 dark:border-green-700">
                <div className="flex justify-between items-center text-sm">
                  <p className="flex items-center gap-2"><TicketIcon className="w-4 h-4"/> <span className="font-bold">{appliedCoupon.code}</span> applied!</p>
                  <button onClick={onRemoveCoupon} className="font-semibold hover:underline text-xs">Remove</button>
                </div>
                <p className="text-xs mt-1">{appliedCoupon.description}</p>
              </div>
            )}
          </div>
          
          <div className="border-t dark:border-gray-700 pt-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <p className="text-gray-600 dark:text-gray-300">Subtotal</p>
              <p className="font-medium text-gray-800 dark:text-gray-100">{formatCurrency(subtotal)}</p>
            </div>
            <div className="flex justify-between">
              <p className="text-gray-600 dark:text-gray-300">{shippingMethod.name}</p>
              <p className="font-medium text-gray-800 dark:text-gray-100">{formatCurrency(shippingCost)}</p>
            </div>
            {discount > 0 && (
                <div className="flex justify-between text-green-600 dark:text-green-400 font-medium">
                    <p>Discount ({appliedCoupon?.code})</p>
                    <p>-{formatCurrency(discount)}</p>
                </div>
            )}
            <div className="flex justify-between text-xl font-bold border-t dark:border-gray-700 pt-3 mt-2">
              <p className="text-brand-green-dark dark:text-white">Total</p>
              <p className="text-brand-green-dark dark:text-white">{formatCurrency(total)}</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-8 pt-6 border-t dark:border-gray-700 flex flex-col-reverse sm:flex-row gap-4 justify-between">
        <Button type="button" variant="outline" onClick={onBack} className="w-full sm:w-auto">{t('general.back')}</Button>
        <Button type="button" size="lg" onClick={onPlaceOrder} className="w-full sm:w-auto">{t('checkout.review.button')}</Button>
      </div>
    </div>
  );
};

export default OrderReview;
