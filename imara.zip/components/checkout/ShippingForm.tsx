import React, { useState } from 'react';
import type { ShippingAddress } from '../../types.ts';
import Button from '../ui/Button.tsx';

interface ShippingFormProps {
  onSubmit: (data: ShippingAddress) => void;
}

const ShippingForm: React.FC<ShippingFormProps> = ({ onSubmit }) => {
    const [formData, setFormData] = useState<ShippingAddress>({
        fullName: '',
        addressLine1: '',
        city: '',
        country: '',
        postalCode: '',
        email: '',
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit(formData);
    };

    const inputClass = "mt-1 block w-full bg-white dark:bg-brand-navy-dark text-gray-900 dark:text-white border-gray-300 dark:border-brand-green rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-green dark:focus:ring-brand-gold focus:border-transparent placeholder:text-gray-500 dark:placeholder:text-gray-400";

    return (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-md">
            <h2 className="text-2xl font-display font-semibold text-brand-green-dark dark:text-white mb-6">Shipping Information</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
                 <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Email Address</label>
                    <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} required className={inputClass}/>
                </div>
                <div>
                    <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Full Name</label>
                    <input type="text" name="fullName" id="fullName" value={formData.fullName} onChange={handleChange} required className={inputClass}/>
                </div>
                <div>
                    <label htmlFor="addressLine1" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Address</label>
                    <input type="text" name="addressLine1" id="addressLine1" value={formData.addressLine1} onChange={handleChange} required className={inputClass}/>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                     <div>
                        <label htmlFor="city" className="block text-sm font-medium text-gray-700 dark:text-gray-300">City</label>
                        <input type="text" name="city" id="city" value={formData.city} onChange={handleChange} required className={inputClass}/>
                    </div>
                     <div>
                        <label htmlFor="country" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Country</label>
                        <input type="text" name="country" id="country" value={formData.country} onChange={handleChange} required className={inputClass}/>
                    </div>
                     <div>
                        <label htmlFor="postalCode" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Postal Code</label>
                        <input type="text" name="postalCode" id="postalCode" value={formData.postalCode} onChange={handleChange} required className={inputClass}/>
                    </div>
                </div>
                <div className="pt-4">
                    <Button type="submit" size="lg" className="w-full">Continue to Shipping Method</Button>
                </div>
            </form>
        </div>
    );
};

export default ShippingForm;