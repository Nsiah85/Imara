
import React from 'react';
import Button from '../ui/Button.tsx';
import { ShieldCheckIcon, LockClosedIcon, BanknotesIcon } from '../icons/Icons.tsx';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';
import { useAuth } from '../../contexts/AuthContext.tsx';
import { usePayment } from '../../hooks/usePayment.ts';

interface PaymentGatewayProps {
  onSubmit: (ref: string) => void;
  onBack: () => void;
  totalAmount: number;
}

const PaymentGateway: React.FC<PaymentGatewayProps> = ({ onSubmit, onBack, totalAmount }) => {
    const { user } = useAuth();
    const { currency } = useCurrency();
    const { initializePayment, isProcessing } = usePayment();

    const handlePaystackStart = () => {
        initializePayment({
            amount: totalAmount,
            email: user?.email || 'guest@imara.com',
            metadata: {
                type: 'order',
                description: `Imara Marketplace Purchase`,
            },
            onSuccess: (ref) => onSubmit(ref),
        });
    };

    return (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-[32px] shadow-xl border border-gray-100 dark:border-gray-700 animate-fade-in">
            <div className="flex items-center gap-3 mb-8">
                <div className="p-3 bg-brand-gold/10 rounded-2xl">
                    <ShieldCheckIcon className="w-8 h-8 text-brand-gold" />
                </div>
                <div>
                    <h2 className="text-2xl font-display font-black text-brand-navy-dark dark:text-white uppercase tracking-tight">Secure Payment</h2>
                    <p className="text-[10px] text-gray-500 font-black uppercase tracking-[0.2em]">Verified African Gateway</p>
                </div>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-900/50 p-6 rounded-2xl mb-8 space-y-4 border border-dashed border-gray-200 dark:border-gray-700">
                <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-500 font-bold uppercase">Payable Total</span>
                    <span className="text-2xl font-display font-black text-brand-navy-dark dark:text-white">${totalAmount.toFixed(2)}</span>
                </div>
                <div className="flex items-center gap-3 text-xs text-gray-600 dark:text-gray-400">
                    <BanknotesIcon className="w-5 h-5 text-brand-green"/>
                    <span>Supports MTN MoMo, Telecel Cash, and global cards.</span>
                </div>
            </div>

            <div className="space-y-4">
                <Button 
                    onClick={handlePaystackStart} 
                    disabled={isProcessing}
                    className="w-full py-5 text-lg font-black uppercase tracking-widest shadow-gold-glow flex justify-center items-center gap-3"
                >
                    {isProcessing ? (
                        <div className="w-6 h-6 border-3 border-brand-navy-dark border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                        <>Pay with Paystack &rarr;</>
                    )}
                </Button>
                
                <button 
                    onClick={onBack}
                    className="w-full py-3 text-xs font-black text-gray-400 uppercase tracking-widest hover:text-brand-navy-dark dark:hover:text-white transition-colors"
                >
                    Return to Review
                </button>
            </div>

            <div className="mt-8 flex justify-center items-center gap-2 grayscale opacity-50">
                <LockClosedIcon className="w-3 h-3"/>
                <p className="text-[9px] font-bold uppercase tracking-widest text-gray-400">256-bit SSL Encrypted Transaction</p>
            </div>
        </div>
    );
};

export default PaymentGateway;
