import React from 'react';
import type { ShippingMethod } from '../../types';
import { useCurrency } from '../../contexts/CurrencyContext';
import Button from '../ui/Button';

interface ShippingMethodSelectorProps {
  methods: ShippingMethod[];
  selectedMethod: ShippingMethod;
  onSelect: (method: ShippingMethod) => void;
  onSubmit: () => void;
  onBack: () => void;
}

const ShippingMethodSelector: React.FC<ShippingMethodSelectorProps> = ({ methods, selectedMethod, onSelect, onSubmit, onBack }) => {
    const { formatCurrency } = useCurrency();

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit();
    };

    return (
        <div className="bg-white p-8 rounded-lg shadow-md">
            <h2 className="text-2xl font-display font-semibold text-brand-green-dark mb-6">Choose a Shipping Method</h2>
            <form onSubmit={handleSubmit}>
                <fieldset>
                    <legend className="sr-only">Shipping method</legend>
                    <div className="space-y-4">
                        {methods.map((method) => (
                            <label
                                key={method.id}
                                htmlFor={method.id}
                                className={`relative block cursor-pointer rounded-lg border bg-white p-4 shadow-sm focus-within:outline-none focus-within:ring-2 focus-within:ring-brand-gold transition-all ${
                                    selectedMethod.id === method.id ? 'border-brand-gold ring-2 ring-brand-gold' : 'border-gray-300'
                                }`}
                            >
                                <input
                                    type="radio"
                                    name="shipping-method"
                                    id={method.id}
                                    value={method.id}
                                    className="sr-only"
                                    checked={selectedMethod.id === method.id}
                                    onChange={() => onSelect(method)}
                                    aria-describedby={`${method.id}-description`}
                                />
                                <div className="flex justify-between">
                                    <span className="flex flex-col">
                                        <span className="block text-sm font-medium text-brand-green-dark">{method.name}</span>
                                        <span id={`${method.id}-description`} className="mt-1 flex items-center text-sm text-gray-500">
                                            {method.estimatedDelivery}
                                        </span>
                                    </span>
                                    <span className="text-sm font-semibold text-brand-green-dark">{formatCurrency(method.price)}</span>
                                </div>
                            </label>
                        ))}
                    </div>
                </fieldset>
                 <div className="mt-8 pt-6 border-t flex flex-col-reverse sm:flex-row gap-4 justify-between">
                    <Button type="button" variant="outline" onClick={onBack} className="w-full sm:w-auto">Back to Shipping</Button>
                    <Button type="submit" size="lg" className="w-full sm:w-auto">Continue to Payment</Button>
                </div>
            </form>
        </div>
    );
};

export default ShippingMethodSelector;