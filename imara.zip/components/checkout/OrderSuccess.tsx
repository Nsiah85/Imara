import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../ui/Button.tsx';
import { CheckCircleIcon } from '../icons/Icons.tsx';

interface OrderSuccessProps {
  orderNumber: string;
}

const OrderSuccess: React.FC<OrderSuccessProps> = ({ orderNumber }) => {
  return (
    <div className="bg-white p-8 md:p-12 rounded-lg shadow-md text-center">
        <CheckCircleIcon className="w-16 h-16 text-brand-gold mx-auto" />
        <h1 className="text-3xl font-display font-bold text-brand-green-dark mt-4">Thank You for Your Order!</h1>
        <p className="mt-2 text-gray-600">Your order has been placed successfully.</p>
        
        <div className="mt-6 text-sm text-gray-500">
            <span>Order Number: </span>
            <span className="font-medium text-gray-800">{orderNumber}</span>
        </div>
        
        <p className="mt-4 max-w-md mx-auto text-sm text-gray-500">
            You will receive an email confirmation shortly with your order details and tracking information.
        </p>

        <div className="mt-8">
            <Link to="/shop">
                <Button size="lg" variant="primary">Continue Shopping</Button>
            </Link>
        </div>
    </div>
  );
};

export default OrderSuccess;