
import React, { useState } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { UserIcon, SearchIcon, ChatDotsIcon, ShoppingBagIcon, ImaraDiskIcon, ShieldCheckIcon } from '../icons/Icons.tsx';
import { useCart } from '../../contexts/CartContext.tsx';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';
import { useAuth } from '../../contexts/AuthContext.tsx';
import { useLanguage } from '../../contexts/LanguageContext.tsx';
import SearchModal from '../modals/SearchModal.tsx';

const Logo: React.FC<{ className?: string; isKidz?: boolean }> = ({ className, isKidz }) => (
  <div className={`flex items-center gap-2 ${className}`}>
    <ImaraDiskIcon className="w-8 h-8 sm:w-9 sm:h-9" />
    <div className="font-display font-extrabold text-2xl sm:text-3xl tracking-tight text-brand-navy-dark dark:text-white">
        {isKidz ? 'Imara Kidz' : 'Imara'}
    </div>
  </div>
);

const CurrencySelector: React.FC<{ className?: string }> = ({ className = '' }) => {
    const { currency, setCurrency, supportedCurrencies } = useCurrency();

    return (
        <div className={`relative group ${className}`} title="Switch Display Currency">
            <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="bg-transparent font-bold text-xs sm:text-sm border-none focus:ring-0 cursor-pointer text-gray-600 hover:text-brand-green dark:text-gray-300 dark:hover:text-brand-gold py-1 transition-colors appearance-none"
                aria-label="Select currency"
            >
                {supportedCurrencies.map(c => (
                     <option key={c} value={c} className="text-brand-navy-dark bg-white">{c}</option>
                ))}
            </select>
        </div>
    );
};

const Header: React.FC = () => {
  const { totalItems } = useCart();
  const { user, unreadGossipCount } = useAuth();
  const { t } = useLanguage();
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const handleGistClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    if (location.pathname === '/') {
      window.dispatchEvent(new CustomEvent('refresh-toast-feed'));
    } else {
      navigate('/');
    }
  };

  const navLinkClass = ({ isActive }: { isActive: boolean }): string =>
    `relative px-1 py-2 text-sm font-medium transition-all duration-200 flex items-center gap-2 
     ${isActive 
        ? 'text-brand-green dark:text-brand-gold glow-active' 
        : 'text-gray-500 hover:text-brand-green dark:text-gray-400 dark:hover:text-brand-gold glow-hover'
     }`;

  const userLink = user ? "/account" : "/login";
  const messagesLink = "/messages";

  const isKidzMode = React.useMemo(() => {
    if (!user?.dateOfBirth) return false;
    const dob = new Date(user.dateOfBirth);
    const ageDifMs = Date.now() - dob.getTime();
    const ageDate = new Date(ageDifMs);
    const age = Math.abs(ageDate.getUTCFullYear() - 1970);
    return age < 16;
  }, [user]);

  return (
    <>
      <header className="sticky top-0 bg-white dark:bg-brand-navy-dark border-b border-gray-100 dark:border-gray-800 z-50 transition-colors duration-300">
        {/* Mobile Header */}
        <div className="sm:hidden container mx-auto px-4 py-3 flex justify-between items-center h-16">
          <a href="/" onClick={handleGistClick} aria-label="Imara Home" title="Go to Toast Home">
            <Logo isKidz={isKidzMode} />
          </a>
          <div className="flex items-center space-x-3">
            {user?.role === 'admin' && (
                <NavLink to="/admin" className="text-brand-gold p-1" title="Command Center">
                    <ShieldCheckIcon className="w-6 h-6" />
                </NavLink>
            )}
            <CurrencySelector className="pr-1" />
            <button onClick={() => setIsSearchOpen(true)} className="text-gray-600 hover:text-brand-green dark:text-gray-300 dark:hover:text-brand-gold p-1" aria-label="Search" title="Search Marketplace">
              <SearchIcon className="w-6 h-6" />
            </button>
             
             <NavLink to="/cart" className="relative text-gray-600 hover:text-brand-green dark:text-gray-300 dark:hover:text-brand-gold" aria-label="Shopping Cart" title="View Shopping Cart">
              <ShoppingBagIcon className="w-6 h-6" />
              {totalItems > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-brand-gold text-brand-navy-dark text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </NavLink>
          </div>
        </div>

        {/* Desktop Header */}
        <div className="hidden sm:flex container mx-auto px-6 justify-between items-center h-20">
          <div className="flex items-center gap-6">
              <a href="/" onClick={handleGistClick} title="Imara Home">
                <Logo isKidz={isKidzMode} />
              </a>
          </div>

          <nav className="hidden md:flex items-center space-x-8 lg:space-x-12">
            <a href="/" onClick={handleGistClick} className={navLinkClass({ isActive: location.pathname === '/' })} title="Go to Toast Feed">{t('nav.home')}</a>
            <NavLink to="/shop-hub" className={navLinkClass} title="Browse All Marketplaces">{t('nav.shopHub')}</NavLink>
            <NavLink to="/find-talent" className={navLinkClass} title="Find Professionals & Talents">{t('nav.findTalent')}</NavLink>
            <NavLink to="/invest" className={navLinkClass} title="Support Community Causes & Impact">{t('nav.invest')}</NavLink>
          </nav>

          <div className="flex items-center space-x-6">
            {user?.role === 'admin' && (
                <NavLink to="/admin" className="text-gray-500 hover:text-brand-gold transition-colors glow-hover flex items-center gap-1" title="Command Center">
                    <ShieldCheckIcon className="w-5 h-5" />
                    <span className="text-xs font-bold uppercase hidden lg:inline">Admin</span>
                </NavLink>
            )}

            <button onClick={() => setIsSearchOpen(true)} className="text-gray-500 hover:text-brand-green dark:text-gray-400 dark:hover:text-brand-gold transition-colors glow-hover" aria-label="Search" title="Open Global Search">
              <SearchIcon className="w-5 h-5" />
            </button>
            
            <div className="h-6 w-px bg-gray-200 dark:bg-gray-700"></div>

            <CurrencySelector />

             <NavLink to={messagesLink} className="relative text-gray-500 hover:text-brand-green dark:text-gray-400 dark:hover:text-brand-gold transition-colors glow-hover hidden md:flex" aria-label="Gossip" title="Messages & Gossip">
              <ChatDotsIcon className="w-5 h-5" />
              {unreadGossipCount > 0 && (
                 <span className="absolute -top-1.5 -right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-brand-green text-[10px] font-bold text-white dark:bg-brand-gold dark:text-brand-navy-dark shadow-sm">
                    {unreadGossipCount > 9 ? '9+' : unreadGossipCount}
                </span>
              )}
            </NavLink>

            <NavLink to="/cart" className="relative text-gray-500 hover:text-brand-green dark:text-gray-400 dark:hover:text-brand-gold transition-colors glow-hover" aria-label="Shopping Cart" title="Review your Shopping Cart">
              <ShoppingBagIcon className="w-5 h-5" />
              {totalItems > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-brand-gold text-brand-navy-dark text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center shadow-sm">
                  {totalItems}
                </span>
              )}
            </NavLink>

            <NavLink to={userLink} className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-brand-green hover:text-white dark:hover:bg-brand-gold dark:hover:text-brand-navy-dark transition-all" aria-label={user ? "My Account" : "Login"} title={user ? "Manage your Profile & Account" : "Login or Signup to Imara"}>
              {user && user.profileImageUrl ? (
                 <img src={user.profileImageUrl} alt="Profile" className="w-full h-full rounded-full object-cover border border-gray-200" />
              ) : (
                 <UserIcon className="w-5 h-5" />
              )}
            </NavLink>
          </div>
        </div>
      </header>
      {isSearchOpen && <SearchModal onClose={() => setIsSearchOpen(false)} />}
    </>
  );
};

export default Header;
