import React from 'react';
import { useLocation } from 'react-router-dom';
import Header from './Header.tsx';
import MobileNav from './MobileNav.tsx';
import Footer from './Footer.tsx';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  const isMessagesPage = location.pathname.startsWith('/messages');
  const isHubPage = ['/shop-hub', '/find-talent', '/invest'].includes(location.pathname);
  
  const showHeader = !isMessagesPage && !isHubPage;
  const showFooter = true; // Show footer everywhere unless specifically requested not to

  return (
    <div className="min-h-screen font-sans text-gray-800 dark:text-gray-200 flex flex-col">
      {/* Hide Global Header on Chat Page and Hub Pages for immersive experience */}
      {showHeader && <Header />}
      
      {/* Adjusted bottom padding to accommodate MobileNav up to md breakpoint */}
      <main className={`flex-grow ${showHeader ? 'pt-14 sm:pt-16' : ''} ${!isMessagesPage ? 'pb-24 md:pb-8' : ''} adjust-padding-on-landscape-mobile`}>
        {children}
      </main>
      
      {showFooter && <Footer />}
      
      {/* Mobile Nav remains visible unless in Theater mode or Messages page */}
      {!isMessagesPage && <MobileNav />}
    </div>
  );
};

export default Layout;