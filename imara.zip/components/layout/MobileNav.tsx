
import React from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { HomeIcon, UserIcon, ChatDotsIcon, StorefrontIcon, AcademicCapUserIcon, HandCoinIcon, Cog6ToothIcon, ShieldCheckIcon } from '../icons/Icons.tsx';
import { useLanguage } from '../../contexts/LanguageContext.tsx';
import { useAuth } from '../../contexts/AuthContext.tsx';

const MobileNav: React.FC = () => {
    const { t } = useLanguage();
    const { user, unreadGossipCount } = useAuth();
    const location = useLocation();
    const navigate = useNavigate();

    const navLinkClass = ({ isActive }: { isActive: boolean }): string =>
    `flex flex-col items-center justify-center space-y-1 transition-all duration-300 w-full h-full group relative ${
      isActive 
      ? 'text-brand-gold' 
      : 'text-gray-400 hover:text-white'
    }`;
    
    const handleGistClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
        e.preventDefault();
        if (location.pathname === '/') {
          window.dispatchEvent(new CustomEvent('refresh-toast-feed'));
        } else {
          navigate('/');
        }
    };
    
    const accountLink = user ? "/account" : "/login";
    const isAdmin = user?.role === 'admin';

  return (
    <nav className="mobile-nav md:hidden fixed bottom-0 left-0 right-0 bg-brand-navy-dark border-t border-white/5 shadow-[0_-10px_25px_-5px_rgba(0,0,0,0.3)] z-50 h-16 sm:h-20 transition-all">
      <div className={`grid ${isAdmin ? 'grid-cols-7' : 'grid-cols-6'} h-full w-full max-w-lg mx-auto`}>
        <a href="/" onClick={handleGistClick} className={navLinkClass({ isActive: location.pathname === '/' })} title="Toast Feed">
            <HomeIcon className="w-6 h-6 sm:w-7 sm:h-7" />
            <span className="text-[9px] font-black uppercase tracking-tighter sm:text-xs">Toast</span>
        </a>
        <NavLink to="/shop-hub" className={navLinkClass} title="ShopHub">
            <StorefrontIcon className="w-6 h-6 sm:w-7 sm:h-7" />
            <span className="text-[9px] font-black uppercase tracking-tighter sm:text-xs">Shop</span>
        </NavLink>
        <NavLink to="/find-talent" className={navLinkClass} title="AfroTalents">
            <AcademicCapUserIcon className="w-6 h-6 sm:w-7 sm:h-7" />
            <span className="text-[9px] font-black uppercase tracking-tighter sm:text-xs">Talent</span>
        </NavLink>
        <NavLink to="/messages" className={navLinkClass} title="Gossip">
            <div className="relative">
                <ChatDotsIcon className="w-6 h-6 sm:w-7 sm:h-7" />
                {unreadGossipCount > 0 && (
                    <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-brand-green text-[10px] font-bold text-white shadow-sm">
                        {unreadGossipCount > 9 ? '9+' : unreadGossipCount}
                    </span>
                )}
            </div>
            <span className="text-[9px] font-black uppercase tracking-tighter sm:text-xs">Gossip</span>
        </NavLink>
        <NavLink to="/invest" className={navLinkClass} title="Impact Hub">
            <HandCoinIcon className="w-6 h-6 sm:w-7 sm:h-7" />
            <span className="text-[9px] font-black uppercase tracking-tighter sm:text-xs">Impact</span>
        </NavLink>
        <NavLink to={accountLink} className={navLinkClass} title="My Account">
            <UserIcon className="w-6 h-6 sm:w-7 sm:h-7" />
            <span className="text-[9px] font-black uppercase tracking-tighter sm:text-xs">Profile</span>
        </NavLink>
        {isAdmin && (
            <NavLink to="/admin" className={navLinkClass} title="Command Center">
                <ShieldCheckIcon className="w-6 h-6 sm:w-7 sm:h-7 text-brand-gold" />
                <span className="text-[9px] font-black uppercase tracking-tighter sm:text-xs text-brand-gold">OPS</span>
            </NavLink>
        )}
      </div>
    </nav>
  );
};

export default MobileNav;
