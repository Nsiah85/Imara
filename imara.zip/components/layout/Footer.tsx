
import React from 'react';

const Footer: React.FC = () => {
    return (
        <footer className="text-center py-4 pb-20 md:pb-4 bg-gray-100 dark:bg-brand-navy-dark text-sm text-gray-500 dark:text-brand-gray relative z-10">
            <p>Made by Monkix &copy; {new Date().getFullYear()}</p>
        </footer>
    );
};

export default Footer;
