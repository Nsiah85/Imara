
import React from 'react';
import { Link } from 'react-router-dom';
import type { Professional } from '../../types.ts';
import { useIntersectionObserver } from '../../hooks/useIntersectionObserver.ts';
import { VerifiedBadgeIcon, GlobeIcon, StarIcon } from '../icons/Icons.tsx';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';
import Avatar from '../ui/Avatar.tsx';

interface ProfessionalCardProps {
    professional: Professional;
    animationDelay?: number;
    compact?: boolean;
}

const ProfessionalCard: React.FC<ProfessionalCardProps> = ({ professional, animationDelay = 75, compact = false }) => {
    const [cardRef, isVisible] = useIntersectionObserver<HTMLDivElement>({ threshold: 0.1 });
    const { formatCurrency } = useCurrency();
    
    const getWageText = (wageRange: [number, number], wageType: string) => {
        const typeText = wageType === 'hourly' ? '/hr' : wageType === 'daily' ? '/day' : '/proj';
        const formattedRange = wageRange.map(w => formatCurrency(w, { minimumFractionDigits: 0 }));
        if (wageRange[0] === wageRange[1]) return `${formattedRange[0]}${typeText}`;
        return `${formattedRange[0]}-${formattedRange[1]}${typeText}`;
    };

    return (
        <Link 
            to={`/workman/${professional.storeSlug}`}
            ref={cardRef}
            className={`block bg-white dark:bg-gray-800 rounded-3xl shadow-sm hover:shadow-xl transition-all duration-300 ease-out transform hover:-translate-y-1 border-2 border-transparent hover:border-brand-gold overflow-hidden group ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
            style={{ transitionDelay: `${animationDelay}ms` }}
        >
            {/* Banner Area */}
            <div className="h-24 bg-gradient-to-r from-brand-navy-dark to-brand-green/80 relative">
                 <div className="absolute top-2 right-2 flex gap-1">
                     {professional.subscriptionPlanId?.includes('pro') && (
                         <span className="bg-brand-gold text-brand-navy-dark text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm">PRO</span>
                     )}
                     <span className="bg-white/90 text-brand-navy-dark text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm flex items-center gap-1">
                        <StarIcon className="w-3 h-3 text-brand-gold" /> 4.9
                     </span>
                 </div>
            </div>

            <div className="px-5 pb-5 relative flex flex-col h-[calc(100%-6rem)]">
                {/* Floating Avatar */}
                <div className="-mt-10 mb-3 flex justify-between items-end">
                    <Avatar 
                        imageUrl={professional.profileImageUrl} 
                        name={professional.name} 
                        className="w-20 h-20 rounded-full border-4 border-white dark:border-gray-800 shadow-md bg-white"
                    />
                </div>

                <div className="flex-grow">
                    <div className="flex items-center gap-1 mb-0.5">
                        <h3 className="font-display font-bold text-lg text-brand-navy-dark dark:text-white truncate">{professional.name}</h3>
                        {professional.isVerified && <VerifiedBadgeIcon className="w-4 h-4 text-brand-gold" />}
                    </div>
                    <p className="text-sm text-gray-500 font-medium mb-2">{professional.professionalRole}</p>
                    
                    <div className="flex items-center gap-1 text-xs text-gray-400 mb-4">
                        <GlobeIcon className="w-3 h-3" />
                        {professional.location}
                    </div>

                    <div className="flex flex-wrap gap-1 mb-4">
                        {professional.skills.slice(0, 3).map(skill => (
                            <span key={skill} className="text-[10px] bg-brand-off-white dark:bg-gray-700 text-brand-navy-dark dark:text-gray-300 px-2 py-1 rounded-md font-semibold">{skill}</span>
                        ))}
                        {professional.skills.length > 3 && <span className="text-[10px] text-gray-400 px-1 py-1">+{professional.skills.length - 3}</span>}
                    </div>
                </div>

                <div className="pt-4 border-t border-gray-100 dark:border-gray-700 mt-auto flex justify-between items-center">
                     <span className="font-bold text-brand-green dark:text-brand-gold">{getWageText(professional.wageRange, professional.wageType)}</span>
                     <span className="text-xs font-bold text-brand-navy-dark group-hover:translate-x-1 transition-transform">View Profile &rarr;</span>
                </div>
            </div>
        </Link>
    );
};

export default ProfessionalCard;
