import React from 'react';
import { Link } from 'react-router-dom';
import type { Professional } from '../../types';
import { useCurrency } from '../../contexts/CurrencyContext';
import Button from '../ui/Button';
import Badge from '../ui/Badge';
import { ShieldCheckIcon, GlobeIcon, DollarSignIcon, BriefcaseIcon } from '../icons/Icons';

interface ProfessionalListCardProps {
  professional: Professional;
}

const ProfessionalListCard: React.FC<ProfessionalListCardProps> = ({ professional }) => {
  const { formatCurrency } = useCurrency();
  const isPro = professional.subscriptionPlanId?.includes('_pro');

  const getWageText = (wageRange: [number, number], wageType: string) => {
    const typeText = wageType === 'hourly' ? 'hr' : wageType === 'daily' ? 'day' : 'project';
    const formattedRange = wageRange.map(w => formatCurrency(w, { minimumFractionDigits: 0 }));
    if (wageRange[0] === wageRange[1]) return `${formattedRange[0]} / ${typeText}`;
    return `${formattedRange[0]} - ${formattedRange[1]} / ${typeText}`;
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden flex flex-col sm:flex-row group transition-all duration-300 hover:shadow-md">
      <div className="relative sm:w-1/4 flex-shrink-0">
        <img
          src={professional.profileImageUrl}
          alt={professional.name}
          className="w-full h-48 sm:h-full object-cover"
        />
        {isPro && (
          <div className="absolute top-3 right-3">
            <Badge className="bg-brand-gold text-brand-green-dark" icon={<ShieldCheckIcon className="w-4 h-4" />}>
              PRO
            </Badge>
          </div>
        )}
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <div>
          <h3 className="font-display font-semibold text-xl text-brand-green-dark dark:text-white">{professional.name}</h3>
          <p className="text-md text-brand-green dark:text-brand-gold-light">{professional.professionalRole}</p>
        </div>

        <div className="flex flex-wrap gap-x-4 gap-y-2 mt-2 text-sm text-gray-600 dark:text-gray-400">
            <div className="flex items-center gap-1.5"><GlobeIcon className="w-4 h-4" /><span>{professional.location}</span></div>
            <div className="flex items-center gap-1.5"><BriefcaseIcon className="w-4 h-4" /><span>{professional.industry}</span></div>
        </div>

        <p className="text-gray-600 dark:text-gray-300 mt-3 text-sm flex-grow">
          <strong>Skills:</strong> {professional.skills.slice(0, 4).join(', ')}{professional.skills.length > 4 ? '...' : ''}
        </p>

        <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-1.5 text-md font-semibold text-brand-green dark:text-brand-gold-light">
            <DollarSignIcon className="w-5 h-5" />
            <span>{getWageText(professional.wageRange, professional.wageType)}</span>
          </div>
          <Link to={`/workman/${professional.storeSlug}`}>
            <Button variant="secondary">
                View Profile & Book
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ProfessionalListCard;
