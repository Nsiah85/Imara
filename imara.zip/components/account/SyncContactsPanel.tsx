import React, { useState, useEffect } from 'react';
import Button from '../ui/Button.tsx';
import { useAuth } from '../../contexts/AuthContext.tsx';
import { UsersIcon, CheckCircleIcon, PlusIcon } from '../icons/Icons.tsx';

/**
 * A panel that lets users sync their mobile device contacts
 * using the Contact Picker API or mock flow, to find friends on Imara.
 */
const SyncContactsPanel: React.FC = () => {
    const { user } = useAuth();
    const [isSyncing, setIsSyncing] = useState(false);
    const [contacts, setContacts] = useState<any[]>([]);
    const [synced, setSynced] = useState(false);

    useEffect(() => {
        // Load mock contacts if already synced
        if (localStorage.getItem('imara_contacts_synced')) {
            setSynced(true);
            setContacts([
                { id: '1', name: 'Alice Doe', isRegistered: true },
                { id: '2', name: 'Bob Smith', isRegistered: false },
                { id: '3', name: 'Charlie Young', isRegistered: true }
            ]);
        }
    }, []);

    const handleSyncContacts = async () => {
        setIsSyncing(true);
        try {
            const props = ['name', 'email', 'tel', 'address', 'icon'];
            const opts = { multiple: true };
            
            if ('contacts' in navigator && 'ContactsManager' in window) {
                // @ts-ignore
                const deviceContacts = await navigator.contacts.select(props, opts);
                console.log("Device contacts:", deviceContacts);
                // Map the device contacts here
                setContacts(deviceContacts.map((c: any, i: number) => ({
                    id: String(i),
                    name: c.name?.[0] || 'Unknown',
                    isRegistered: Math.random() > 0.5
                })));
            } else {
                // Feature not supported, use mock data
                await new Promise(resolve => setTimeout(resolve, 1500));
                setContacts([
                    { id: '1', name: 'Alice Doe', isRegistered: true },
                    { id: '2', name: 'Bob Smith', isRegistered: false },
                    { id: '3', name: 'Charlie Young', isRegistered: true }
                ]);
            }
            setSynced(true);
            localStorage.setItem('imara_contacts_synced', 'true');
        } catch (ex) {
            console.error("Error syncing contacts", ex);
        } finally {
            setIsSyncing(false);
        }
    };

    const handleInvite = (name: string) => {
        alert(`Invite sent to ${name}!`);
    };

    if (!synced) {
        return (
            <div className="bg-white p-8 rounded-[40px] shadow-sm border border-gray-100 flex flex-col items-center justify-center text-center animate-fade-in">
                <div className="w-20 h-20 bg-brand-gold/10 rounded-full flex items-center justify-center mb-6">
                    <UsersIcon className="w-10 h-10 text-brand-gold" />
                </div>
                <h3 className="text-2xl font-display font-black text-brand-navy-dark mb-4">Find Your Friends</h3>
                <p className="text-gray-500 max-w-sm mb-8">
                    Sync your device contacts to see who is already on Imara, and invite the rest to join the community.
                </p>
                <Button onClick={handleSyncContacts} disabled={isSyncing} className="shadow-lg">
                    {isSyncing ? 'Syncing Contacts...' : 'Sync Phone Contacts'}
                </Button>
            </div>
        );
    }

    return (
        <div className="bg-white p-8 rounded-[40px] shadow-sm border border-gray-100 animate-fade-in">
            <div className="flex items-center justify-between mb-8">
                <div>
                    <h3 className="text-xl font-display font-black text-brand-navy-dark flex items-center gap-2">
                        <UsersIcon className="w-6 h-6 text-brand-gold" /> Phone Contacts
                    </h3>
                    <p className="text-sm text-gray-500 mt-1">We found {contacts.length} people from your address book.</p>
                </div>
                <div className="bg-green-50 p-2 rounded-xl text-green-700 flex items-center gap-2 text-xs font-bold">
                    <CheckCircleIcon className="w-4 h-4"/> Synced
                </div>
            </div>

            <div className="space-y-4">
                {contacts.map((c) => (
                    <div key={c.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-gray-50 rounded-2xl border border-gray-100">
                        <div className="flex items-center gap-4 mb-4 sm:mb-0">
                            <div className="w-12 h-12 bg-white border border-gray-200 rounded-full flex items-center justify-center font-bold text-gray-400">
                                {c.name.charAt(0)}
                            </div>
                            <div>
                                <p className="font-bold text-sm text-brand-navy-dark">{c.name}</p>
                                <p className="text-xs text-gray-500">{c.isRegistered ? 'Already on Imara' : 'Not on Imara yet'}</p>
                            </div>
                        </div>
                        {c.isRegistered ? (
                            <Button variant="outline" size="sm" className="!text-xs">View Profile</Button>
                        ) : (
                            <Button size="sm" variant="secondary" onClick={() => handleInvite(c.name)} className="!text-xs flex items-center gap-1">
                                <PlusIcon className="w-3 h-3" /> Send Invite
                            </Button>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default SyncContactsPanel;
