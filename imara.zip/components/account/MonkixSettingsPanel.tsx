import React, { useState, useEffect } from 'react';
import { UserProfile, MonkixCISettings } from '../../types.ts';
import ToggleSwitch from '../ui/ToggleSwitch.tsx';
import Button from '../ui/Button.tsx';
import { SparklesIcon, ShieldCheckIcon, ChartBarIcon, WandIcon } from '../icons/Icons.tsx';

interface MonkixSettingsPanelProps {
    user: UserProfile;
    onUpdate: (key: keyof UserProfile, value: any) => void;
}

const defaultMonkixSettings: MonkixCISettings = {
    enabled: false,
    mode: 'observation',
    permissions: {
        autoPost: false,
        autoEngage: false,
        suggestPosts: true,
        maintainPresence: false,
    },
    allowedTopics: [],
    restrictedActions: [],
    visibility: 'private',
    consentGiven: false,
};

const MonkixSettingsPanel: React.FC<MonkixSettingsPanelProps> = ({ user, onUpdate }) => {
    const [settings, setSettings] = useState<MonkixCISettings>(user.monkixSettings || defaultMonkixSettings);
    const [showConsent, setShowConsent] = useState(false);
    const [saving, setSaving] = useState(false);

    const handleSave = async (newSettings: MonkixCISettings) => {
        setSaving(true);
        // Persist to user profile
        onUpdate('monkixSettings', newSettings);
        
        // In a real app we'd also hit Firestore `monkix_ci_settings` or `users` endpoint
        try {
            const { setDoc, doc } = await import('firebase/firestore');
            const { db } = await import('../../firebase/firestore.ts');
            await setDoc(doc(db, 'monkix_ci_settings', user.id), newSettings, { merge: true });
        } catch (e) {
             console.error("Monkix CI sync error:", e);
        }

        setSaving(false);
    };

    const toggleEnable = (enabled: boolean) => {
        if (enabled && !settings.consentGiven) {
            setShowConsent(true);
            return;
        }
        const updated = { ...settings, enabled };
        setSettings(updated);
        handleSave(updated);
    };

    const handleConsentAccept = () => {
        const updated: MonkixCISettings = { ...settings, enabled: true, consentGiven: true, consentDate: new Date().toISOString() };
        setSettings(updated);
        setShowConsent(false);
        handleSave(updated);
        
        // Bootstrap Profile
        bootstrapMonkixProfile();
    };

    const bootstrapMonkixProfile = async () => {
         try {
             const { setDoc, doc } = await import('firebase/firestore');
             const { db } = await import('../../firebase/firestore.ts');
             const profileId = `${user.id}_monkixCI`;
             await setDoc(doc(db, 'monkix_ci_profiles', user.id), {
                 id: user.id,
                 userId: user.id,
                 usernameMonkixCI: `${user.fullName.replace(/\s+/g, '').toLowerCase()}_monkixCI`,
                 learningStatus: 'calibrating',
                 creationDate: new Date().toISOString(),
                 healthScore: 100,
                 toxicityRisk: 0
             }, { merge: true });
         } catch(e) {
             console.error("Monkix CI Profile error:", e);
         }
    };

    const updateMode = (mode: MonkixCISettings['mode']) => {
        const updated = { ...settings, mode };
        setSettings(updated);
        handleSave(updated);
    };

    const togglePermission = (key: keyof MonkixCISettings['permissions']) => {
        const updated = { ...settings, permissions: { ...settings.permissions, [key]: !settings.permissions[key] } };
        setSettings(updated);
        handleSave(updated);
    };

    const handleWipeMemory = async () => {
        if (!confirm("Are you sure you want to wipe Monkix CI's memory? This will reset all learned behavior.")) return;
        setSaving(true);
        try {
            const { deleteDoc, doc } = await import('firebase/firestore');
            const { db } = await import('../../firebase/firestore.ts');
            // Mock deleting the behavior collections
            await deleteDoc(doc(db, 'monkix_ci_behavior', user.id));
            alert("Monkix CI memory wiped successfully.");
        } catch(e) {
            console.error("Wipe memory error", e);
        }
        setSaving(false);
    };

    if (showConsent) {
        return (
            <div className="bg-brand-navy-dark text-white p-8 rounded-[40px] shadow-2xl relative overflow-hidden animate-fade-in border border-brand-gold/30">
                <div className="absolute top-0 right-0 w-64 h-64 bg-brand-gold/10 rounded-full blur-[80px]"></div>
                <h3 className="text-2xl font-display font-black mb-4 flex items-center gap-3 relative z-10">
                    <SparklesIcon className="w-8 h-8 text-brand-gold" /> Monkix CI Consent
                </h3>
                <p className="text-gray-300 mb-6 text-sm leading-relaxed relative z-10">
                    Monkix CI is a controlled, AI-assisted behavioral mirror and presence extension.
                    By enabling this, you authorize an AI model to learn your interaction patterns, suggest posts, and if permitted, maintain your digital presence. 
                    Your data remains private, and Monkix CI will never pretend to be you without explicit disclosure ("Assisted by Monkix CI").
                </p>
                <div className="space-y-4 mb-8 bg-black/20 p-6 rounded-3xl relative z-10 text-sm">
                    <p className="flex items-center gap-2"><WandIcon className="w-5 h-5 text-gray-400"/> Monkix learns from your app usage to reflect your tone.</p>
                    <p className="flex items-center gap-2"><ShieldCheckIcon className="w-5 h-5 text-gray-400"/> You retain 100% control and can revoke access or wipe memory anytime.</p>
                    <p className="flex items-center gap-2"><ChartBarIcon className="w-5 h-5 text-gray-400"/> Provides digital self-awareness and highlights engagement habits.</p>
                </div>
                <div className="flex gap-4 relative z-10">
                    <Button onClick={() => setShowConsent(false)} variant="outline" className="!bg-transparent !text-white !border-gray-500 hover:!bg-white/10">Decline</Button>
                    <Button onClick={handleConsentAccept} className="shadow-gold-glow">I Consent, Activate Monkix CI</Button>
                </div>
            </div>
        );
    }

    return (
        <div className="bg-white p-8 rounded-[40px] shadow-sm border border-gray-100 flex flex-col gap-8">
             <div>
                <div className="flex items-start justify-between">
                    <div>
                        <h3 className="text-2xl font-display font-black text-brand-navy-dark flex items-center gap-3">
                            <SparklesIcon className="w-7 h-7 text-[#7E57C2]"/> Monkix CI Persona
                        </h3>
                        <p className="text-sm text-gray-500 mt-2 max-w-lg">
                            Your secure, AI-assisted digital extension. Monkix CI learns your preferences and helps scale your presence intelligently.
                        </p>
                    </div>
                    <ToggleSwitch enabled={settings.enabled} setEnabled={toggleEnable} label="Enable Monkix CI" />
                </div>
             </div>

             {settings.enabled && (
                 <div className="space-y-8 animate-fade-in">
                    
                    <div className="p-6 bg-gray-50 rounded-3xl border border-gray-100">
                        <h4 className="font-bold text-brand-navy-dark text-sm uppercase tracking-wider mb-4">Operational Mode</h4>
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                            {[
                                { id: 'observation', label: 'Observation Only', desc: 'Monkix only watches and learns.' },
                                { id: 'suggestions', label: 'Suggestions Only', desc: 'Suggests content, drafts posts.' },
                                { id: 'semi-autonomous', label: 'Partial Control', desc: 'Auto-engages but waits for post approval.' },
                                { id: 'full', label: 'Full Assisted Presence', desc: 'Maintains presence completely.' }
                            ].map(m => (
                                <button 
                                    key={m.id}
                                    onClick={() => updateMode(m.id as any)}
                                    className={`text-left p-4 rounded-2xl border-2 transition-all ${settings.mode === m.id ? 'border-[#7E57C2] bg-[#7E57C2]/5' : 'border-transparent bg-white hover:border-gray-200 shadow-sm'}`}
                                >
                                    <p className={`font-bold text-sm ${settings.mode === m.id ? 'text-[#7E57C2]' : 'text-gray-800'}`}>{m.label}</p>
                                    <p className="text-xs text-gray-500 mt-1">{m.desc}</p>
                                </button>
                            ))}
                        </div>
                    </div>

                    <div className="p-6 bg-gray-50 rounded-3xl border border-gray-100">
                        <h4 className="font-bold text-brand-navy-dark text-sm uppercase tracking-wider mb-4">Granular Permissions</h4>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4">
                            <div className="flex items-center justify-between">
                                <span className="text-sm font-medium text-gray-700">Auto-Suggest Posts</span>
                                <ToggleSwitch enabled={settings.permissions.suggestPosts} setEnabled={() => togglePermission('suggestPosts')} label="Suggest" />
                            </div>
                            <div className="flex items-center justify-between">
                                <span className="text-sm font-medium text-gray-700">Auto-Engage (Likes/Replies)</span>
                                <ToggleSwitch enabled={settings.permissions.autoEngage} setEnabled={() => togglePermission('autoEngage')} label="Engage" />
                            </div>
                            <div className="flex items-center justify-between">
                                <span className="text-sm font-medium text-gray-700">Auto-Post Content</span>
                                <ToggleSwitch enabled={settings.permissions.autoPost} setEnabled={() => togglePermission('autoPost')} label="Post" />
                            </div>
                            <div className="flex items-center justify-between">
                                <span className="text-sm font-medium text-gray-700">Maintain Presence (Away)</span>
                                <ToggleSwitch enabled={settings.permissions.maintainPresence} setEnabled={() => togglePermission('maintainPresence')} label="Presence" />
                            </div>
                        </div>
                    </div>

                    {/* Behavioral Reflection Dashboard */}
                    <div className="p-6 bg-gradient-to-r from-brand-navy-dark to-[#0f1b29] text-white rounded-3xl border border-gray-700 shadow-xl relative overflow-hidden">
                        <div className="absolute top-[-50%] right-[-10%] w-64 h-64 bg-[#7E57C2]/20 rounded-full blur-[100px]"></div>
                        <h4 className="font-bold text-brand-gold-light text-sm uppercase tracking-wider mb-6 flex items-center gap-2">
                            <ChartBarIcon className="w-5 h-5"/> Behavioral Reflection Engine
                        </h4>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10">
                            <div className="bg-white/5 backdrop-blur-md p-4 rounded-2xl border border-white/10">
                                <p className="text-xs text-gray-400 uppercase tracking-wider mb-1">Tone Analysis</p>
                                <p className="text-lg font-bold text-green-400">Collaborative & Positive</p>
                            </div>
                            <div className="bg-white/5 backdrop-blur-md p-4 rounded-2xl border border-white/10">
                                <p className="text-xs text-gray-400 uppercase tracking-wider mb-1">Toxicity Risk</p>
                                <div className="flex items-center gap-2">
                                     <div className="flex-grow h-2 bg-gray-800 rounded-full overflow-hidden">
                                         <div className="h-full bg-green-500 w-[5%]"></div>
                                     </div>
                                     <span className="text-sm font-bold text-white">Low (5%)</span>
                                </div>
                            </div>
                            <div className="bg-white/5 backdrop-blur-md p-4 rounded-2xl border border-white/10">
                                <p className="text-xs text-gray-400 uppercase tracking-wider mb-1">Spam behavior</p>
                                <div className="flex items-center gap-2">
                                     <div className="flex-grow h-2 bg-gray-800 rounded-full overflow-hidden">
                                         <div className="h-full bg-green-500 w-[2%]"></div>
                                     </div>
                                     <span className="text-sm font-bold text-white">Pristine</span>
                                </div>
                            </div>
                        </div>

                        <div className="mt-6 flex flex-wrap gap-2 relative z-10">
                            <span className="bg-[#7E57C2]/20 text-[#D1C4E9] text-xs px-3 py-1 rounded-full border border-[#7E57C2]/30">Active hours: 8am - 11am</span>
                            <span className="bg-[#7E57C2]/20 text-[#D1C4E9] text-xs px-3 py-1 rounded-full border border-[#7E57C2]/30">Frequent interests: Startups, African Art</span>
                            <span className="bg-[#7E57C2]/20 text-[#D1C4E9] text-xs px-3 py-1 rounded-full border border-[#7E57C2]/30">Polite engagements: 98%</span>
                        </div>
                    </div>

                    <div className="flex justify-between items-center bg-red-50 p-6 rounded-3xl border border-red-100">
                        <div>
                            <p className="text-sm font-bold text-red-800">Clear AI Memory</p>
                            <p className="text-xs text-red-600 mt-1">Wipes all learned behavioral patterns and engagement habits.</p>
                        </div>
                        <Button variant="outline" onClick={handleWipeMemory} disabled={saving} className="!text-red-700 !border-red-200 hover:!bg-red-100 !rounded-xl text-xs">{saving ? 'Wiping...' : 'Wipe Memory'}</Button>
                    </div>

                 </div>
             )}
        </div>
    );
};

export default MonkixSettingsPanel;
