import React from 'react';
import type { GistPost } from '../../types';
import { mockGistPosts } from '../../data/mockData';
import Button from '../ui/Button';

interface SavedPostsListProps {
  postIds: string[];
  onUnsave: (postId: string) => void;
}

const SavedPostsList: React.FC<SavedPostsListProps> = ({ postIds, onUnsave }) => {
    const savedPosts = mockGistPosts.filter(p => postIds.includes(p.id));

    if (savedPosts.length === 0) {
        return <p className="text-center text-gray-500 py-8">You have no saved posts.</p>;
    }

    return (
        <div className="space-y-4">
            {savedPosts.map(post => (
                <div key={post.id} className="flex items-start gap-4 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-md">
                    <img src={post.creator.avatarUrl} alt={post.creator.name} className="w-10 h-10 rounded-full object-cover flex-shrink-0" />
                    <div className="flex-grow">
                        <div className="flex items-center gap-2">
                            <p className="font-semibold text-brand-navy-dark dark:text-white">{post.creator.name}</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">&middot; {new Date(post.timestamp).toLocaleDateString()}</p>
                        </div>
                        <p className="text-sm text-gray-700 dark:text-gray-300 mt-1 truncate">{post.content.text}</p>
                    </div>
                    <Button variant="outline" size="sm" onClick={() => onUnsave(post.id)}>
                        Unsave
                    </Button>
                </div>
            ))}
        </div>
    );
};

export default SavedPostsList;