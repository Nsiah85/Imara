import React from 'react';
import type { Participant } from '../../types';
import Button from '../ui/Button';
import { Link } from 'react-router-dom';

interface UserConnectionsListProps {
  userIds: string[];
  allUsers: Participant[];
  type: 'followers' | 'following';
}

const UserConnectionsList: React.FC<UserConnectionsListProps> = ({ userIds, allUsers, type }) => {
    const users = allUsers.filter(u => userIds.includes(u.id));

    if (users.length === 0) {
        return <p className="text-center text-gray-500 py-8">No {type} to display.</p>;
    }

    const handleUnfollow = (userId: string) => {
        // In a real app, this would call a context function to update the user's following list
        alert(`Unfollowed user ${userId}. (Demo only)`);
    };

    return (
        <div className="space-y-4">
            {users.map(user => (
                <div key={user.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-md">
                    <div className="flex items-center gap-4">
                        <img src={user.avatarUrl} alt={user.name} className="w-12 h-12 rounded-full object-cover" />
                        <div>
                            <p className="font-semibold text-brand-navy-dark dark:text-white">{user.name}</p>
                            <p className="text-sm text-gray-500 dark:text-gray-400">{user.role}</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-2">
                        <Link to={user.profileLink || '#'}>
                            <Button variant="outline" size="sm">View Profile</Button>
                        </Link>
                        {type === 'following' && (
                            <Button variant="outline" size="sm" onClick={() => handleUnfollow(user.id)}>
                                Unfollow
                            </Button>
                        )}
                    </div>
                </div>
            ))}
        </div>
    );
};

export default UserConnectionsList;