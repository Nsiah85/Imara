import React, { useState } from 'react';
import { UserOrder } from '../../types.ts';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';
import Button from '../ui/Button.tsx';
import { PencilSquareIcon, MapPinIcon, BanknotesIcon, ClipboardListIcon } from '../icons/Icons.tsx';
import OrderTrackingMap from './OrderTrackingMap.tsx';

interface OrderHistoryTabProps {
    userOrders: UserOrder[];
    setReviewingItem: (item: any) => void;
}

const OrderHistoryTab: React.FC<OrderHistoryTabProps> = ({ userOrders, setReviewingItem }) => {
    const { formatCurrency } = useCurrency();
    const [subTab, setSubTab] = useState<'list' | 'track' | 'transactions'>('list');
    
    // For Track Order
    const [trackingId, setTrackingId] = useState('');
    const [showMap, setShowMap] = useState(false);

    const handleTrack = () => {
        if (trackingId.trim().length > 3) {
            setShowMap(true);
        } else {
            alert('Please enter a valid tracking ID (e.g. TRK12345)');
        }
    };

    // Mock Transactions based on orders
    const mockTransactions = userOrders.map(order => ({
        id: `txn_${order.orderId}`,
        date: order.date,
        amount: order.total,
        status: 'Completed',
        type: 'Purchase',
        method: 'Credit Card (**** 4242)'
    }));

    return (
        <div className="space-y-6 animate-fade-in">
            {/* Sub Tabs */}
            <div className="flex flex-wrap gap-4 mb-6 border-b border-gray-100 dark:border-gray-800 pb-4">
                <button 
                    onClick={() => setSubTab('list')}
                    className={`font-bold transition-colors ${subTab === 'list' ? 'text-brand-navy-dark dark:text-brand-gold border-b-2 border-brand-navy-dark dark:border-brand-gold' : 'text-gray-400 hover:text-gray-600'}`}
                >
                    Past Orders
                </button>
                <button 
                    onClick={() => setSubTab('track')}
                    className={`font-bold transition-colors ${subTab === 'track' ? 'text-brand-navy-dark dark:text-brand-gold border-b-2 border-brand-navy-dark dark:border-brand-gold' : 'text-gray-400 hover:text-gray-600'}`}
                >
                    Track Package
                </button>
                <button 
                    onClick={() => setSubTab('transactions')}
                    className={`font-bold transition-colors ${subTab === 'transactions' ? 'text-brand-navy-dark dark:text-brand-gold border-b-2 border-brand-navy-dark dark:border-brand-gold' : 'text-gray-400 hover:text-gray-600'}`}
                >
                    Transaction History
                </button>
            </div>

            {/* List Tab */}
            {subTab === 'list' && (
                userOrders.length > 0 ? (
                    <div className="space-y-6 animate-fade-in">
                        {userOrders.map(order => (
                            <div key={order.id} className="p-6 rounded-[32px] bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 shadow-sm">
                                <div className="flex justify-between items-center mb-6 pb-4 border-b border-gray-50 dark:border-gray-700">
                                    <div>
                                        <p className="font-black text-brand-navy-dark dark:text-white text-lg uppercase tracking-tight">Order #{order.orderId}</p>
                                        <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">{order.date}</p>
                                    </div>
                                    <p className="text-xl font-display font-black text-brand-green dark:text-green-400">{formatCurrency(order.total)}</p>
                                </div>
                                <div className="space-y-4">
                                    {order.items.map(item => (
                                        <div key={item.id} className="flex items-center gap-4">
                                            <img src={item.imageUrl} alt={item.name} className="w-14 h-14 rounded-xl object-cover border border-gray-50 dark:border-gray-700"/>
                                            <div className="flex-grow min-w-0">
                                                <p className="font-bold text-sm text-brand-navy-dark dark:text-gray-200 truncate">{item.name}</p>
                                                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">{item.vendor}</p>
                                            </div>
                                            {item.reviewed ? (
                                                <span className="text-xs font-bold text-green-600 bg-green-50 dark:bg-green-900/20 dark:text-green-400 px-2 py-1 rounded-md">Reviewed</span>
                                            ) : (
                                                <Button variant="outline" size="sm" onClick={() => setReviewingItem(item)} className="!text-[10px] flex items-center gap-1.5 !px-3 !py-1">
                                                    <PencilSquareIcon className="w-3 h-3" /> Review
                                                </Button>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-20 text-gray-400 bg-white dark:bg-gray-800 rounded-3xl border border-dashed border-gray-200 dark:border-gray-700 animate-fade-in">
                        <p className="font-bold">No past orders</p>
                    </div>
                )
            )}

            {/* Track Tab */}
            {subTab === 'track' && (
                <div className="bg-white dark:bg-gray-800 p-8 rounded-[40px] border border-gray-100 dark:border-gray-700 shadow-sm animate-fade-in">
                    <div className="max-w-md mx-auto text-center mb-8">
                        <div className="w-16 h-16 bg-brand-gold/10 rounded-full flex items-center justify-center mx-auto mb-4">
                            <MapPinIcon className="w-8 h-8 text-brand-gold" />
                        </div>
                        <h2 className="text-2xl font-display font-black text-brand-navy-dark dark:text-white mb-2">Track Your Package</h2>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">Enter your Imara tracking ID to see real-time delivery status.</p>
                        
                        <div className="flex gap-2">
                            <input 
                                type="text"
                                value={trackingId}
                                onChange={(e) => setTrackingId(e.target.value)}
                                placeholder="e.g. IMR-847294"
                                className="flex-grow px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-2xl focus:outline-none focus:border-brand-gold text-brand-navy-dark dark:text-white"
                            />
                            <Button onClick={handleTrack}>Track</Button>
                        </div>
                    </div>

                    {showMap && (
                        <div className="mt-8 animate-fade-in">
                            <div className="flex items-center justify-between mb-4">
                                <h3 className="font-bold text-brand-navy-dark dark:text-white uppercase tracking-wider text-sm">Live Location</h3>
                                <div className="flex items-center gap-2">
                                    <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                                    <span className="text-xs font-bold text-green-500">In Transit</span>
                                </div>
                            </div>
                            <div className="h-96 rounded-3xl overflow-hidden border border-gray-200 dark:border-gray-700 relative">
                                <OrderTrackingMap />
                            </div>
                            <div className="mt-6 p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800">
                                <ul className="space-y-4">
                                    <li className="flex gap-4 items-start">
                                        <div className="w-8 h-8 rounded-full bg-brand-gold/20 flex items-center justify-center shrink-0 mt-1">
                                            <span className="w-3 h-3 bg-brand-gold rounded-full"></span>
                                        </div>
                                        <div>
                                            <p className="font-bold text-brand-navy-dark dark:text-white">Out for delivery</p>
                                            <p className="text-xs text-gray-500">Today, 8:45 AM • Accra, Ghana</p>
                                        </div>
                                    </li>
                                    <li className="flex gap-4 items-start opacity-50">
                                        <div className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center shrink-0 mt-1">
                                            <span className="w-3 h-3 bg-gray-400 rounded-full"></span>
                                        </div>
                                        <div>
                                            <p className="font-bold text-gray-500">Departed sorting facility</p>
                                            <p className="text-xs text-gray-400">Yesterday, 9:20 PM • Kumasi, Ghana</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    )}
                </div>
            )}

            {/* Transactions Tab */}
            {subTab === 'transactions' && (
                <div className="bg-white dark:bg-gray-800 rounded-[32px] border border-gray-100 dark:border-gray-700 shadow-sm overflow-hidden animate-fade-in">
                    <div className="p-6 border-b border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50">
                        <h3 className="font-black text-brand-navy-dark dark:text-white text-lg flex items-center gap-2">
                            <BanknotesIcon className="w-5 h-5 text-brand-gold" /> Billing & Transactions
                        </h3>
                    </div>
                    {mockTransactions.length > 0 ? (
                        <div className="overflow-x-auto">
                            <table className="w-full text-left">
                                <thead>
                                    <tr className="border-b border-gray-100 dark:border-gray-700 bg-white dark:bg-gray-800">
                                        <th className="p-4 text-xs font-black text-gray-400 uppercase tracking-widest pl-6">ID / Date</th>
                                        <th className="p-4 text-xs font-black text-gray-400 uppercase tracking-widest">Type</th>
                                        <th className="p-4 text-xs font-black text-gray-400 uppercase tracking-widest">Method</th>
                                        <th className="p-4 text-xs font-black text-gray-400 uppercase tracking-widest text-right pr-6">Amount / Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {mockTransactions.map((txn, idx) => (
                                        <tr key={txn.id} className={`border-b border-gray-50 dark:border-gray-800 ${idx % 2 === 0 ? 'bg-gray-50/30 dark:bg-gray-800/30' : 'bg-white dark:bg-gray-800'}`}>
                                            <td className="p-4 pl-6">
                                                <p className="font-bold text-sm text-brand-navy-dark dark:text-gray-200">{txn.id}</p>
                                                <p className="text-xs text-gray-500">{txn.date}</p>
                                            </td>
                                            <td className="p-4">
                                                <span className="inline-block px-3 py-1 bg-brand-navy-dark text-brand-gold text-[10px] font-black uppercase tracking-wider rounded-full">{txn.type}</span>
                                            </td>
                                            <td className="p-4">
                                                <p className="text-sm font-medium text-gray-600 dark:text-gray-300">{txn.method}</p>
                                            </td>
                                            <td className="p-4 pr-6 text-right">
                                                <p className="font-black text-brand-navy-dark dark:text-white text-lg">{formatCurrency(txn.amount)}</p>
                                                <p className="text-xs font-bold text-green-500 uppercase tracking-wide">{txn.status}</p>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    ) : (
                        <div className="p-12 text-center text-gray-500 dark:text-gray-400">
                            No billing history found.
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default OrderHistoryTab;
