import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRightIcon } from '../icons/Icons';

interface DashboardLinkCardProps {
  to: string;
  icon: React.ReactNode;
  title: string;
  description: string;
}

const DashboardLinkCard: React.FC<DashboardLinkCardProps> = ({ to, icon, title, description }) => {
  return (
    <Link to={to} className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg hover:-translate-y-1 transition-all flex items-center gap-4 h-full group">
      <div className="flex-shrink-0 text-brand-gold">{icon}</div>
      <div className="flex-grow">
        <h3 className="font-display font-semibold text-lg text-brand-green-dark group-hover:text-brand-gold transition-colors">{title}</h3>
        <p className="text-xs text-gray-500">{description}</p>
      </div>
      <ArrowRightIcon className="w-4 h-4 text-gray-400 flex-shrink-0" />
    </Link>
  );
};

export default DashboardLinkCard;