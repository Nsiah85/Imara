import React, { useState } from 'react';
import type { GiftCard } from '../../types';
import { CheckIcon, LinkIcon } from '../icons/Icons';
import { useCurrency } from '../../contexts/CurrencyContext';

interface UserGiftCardsProps {
  cards: GiftCard[];
}

const UserGiftCards: React.FC<UserGiftCardsProps> = ({ cards }) => {
    const { formatCurrency } = useCurrency();
    const [copiedCode, setCopiedCode] = useState<string | null>(null);

    const handleCopy = (code: string) => {
        navigator.clipboard.writeText(code).then(() => {
            setCopiedCode(code);
            setTimeout(() => setCopiedCode(null), 2000);
        });
    };
    
    const getCardValue = (card: GiftCard) => {
        if (card.type === 'fixed') {
            return formatCurrency(card.value);
        }
        return `${card.value}% OFF`;
    };

    return (
        <div>
            <h2 className="text-2xl font-display font-semibold text-brand-green-dark mb-6">My Rewards & Gift Cards</h2>
            <div className="space-y-4">
                {cards.map(card => {
                    const isExpired = new Date(card.expiryDate) < new Date();
                    return (
                        <div key={card.code} className={`p-4 rounded-lg border-l-4 flex flex-col sm:flex-row gap-4 items-start ${isExpired ? 'bg-gray-100 border-gray-400' : 'bg-green-50 border-brand-gold'}`}>
                            <div className="flex-grow">
                                <p className={`font-bold text-lg ${isExpired ? 'text-gray-500' : 'text-brand-green-dark'}`}>{getCardValue(card)}</p>
                                <p className={`text-sm ${isExpired ? 'text-gray-500' : 'text-gray-700'}`}>{card.description}</p>
                                <p className={`mt-2 text-xs ${isExpired ? 'text-red-500' : 'text-gray-500'}`}>
                                    {isExpired ? 'Expired on' : 'Expires on'}: {new Date(card.expiryDate).toLocaleDateString()}
                                </p>
                            </div>
                            <div className="w-full sm:w-auto">
                                <button
                                    onClick={() => handleCopy(card.code)}
                                    className="w-full sm:w-auto flex items-center justify-center gap-2 px-3 py-2 border-2 border-dashed border-gray-300 rounded-md text-gray-600 hover:border-brand-gold hover:text-brand-gold transition-colors disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:border-gray-300"
                                    disabled={isExpired}
                                >
                                    <span className="font-mono text-sm">{card.code}</span>
                                    {copiedCode === card.code ? <CheckIcon className="w-4 h-4 text-green-600" /> : <LinkIcon className="w-4 h-4" />}
                                </button>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default UserGiftCards;