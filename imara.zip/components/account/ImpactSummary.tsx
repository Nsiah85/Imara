
import React from 'react';
import type { ImpactData } from '../../types.ts';
import { UsersIcon, TreeIcon, BookOpenIcon } from '../icons/Icons.tsx';

interface ImpactSummaryProps {
    impactData: ImpactData;
}

const ImpactSummary: React.FC<ImpactSummaryProps> = ({ impactData }) => {
    const { treesPlanted, schoolDaysFunded, artisansSupported } = impactData;
    
    return (
        <div className="relative overflow-hidden bg-gradient-to-br from-[#004d40] to-[#0A2342] p-6 rounded-2xl text-white shadow-xl mb-8 border border-white/10 backdrop-blur-lg">
            {/* Background Texture */}
            <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10 pointer-events-none"></div>
            <div className="absolute bottom-0 left-0 w-40 h-40 bg-brand-green/30 rounded-full blur-3xl"></div>
            
            <h2 className="relative z-10 text-2xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-brand-gold to-white mb-6">
                Your Positive Impact
            </h2>

            <div className="relative z-10 grid grid-cols-1 sm:grid-cols-3 gap-6">
                {/* Card 1 */}
                <div className="bg-white/10 border border-white/10 p-4 rounded-xl backdrop-blur-md flex flex-col items-center text-center hover:bg-white/15 transition-colors">
                    <div className="p-3 bg-brand-green/20 rounded-full mb-3 text-brand-gold">
                        <UsersIcon className="w-6 h-6"/>
                    </div>
                    <p className="text-3xl font-bold font-mono">{artisansSupported.toLocaleString()}</p>
                    <p className="text-xs text-gray-300 uppercase tracking-wider mt-1">Artisans Supported</p>
                </div>

                {/* Card 2 */}
                <div className="bg-white/10 border border-white/10 p-4 rounded-xl backdrop-blur-md flex flex-col items-center text-center hover:bg-white/15 transition-colors">
                    <div className="p-3 bg-brand-green/20 rounded-full mb-3 text-green-400">
                        <TreeIcon className="w-6 h-6"/>
                    </div>
                    <p className="text-3xl font-bold font-mono">{treesPlanted.toLocaleString()}</p>
                    <p className="text-xs text-gray-300 uppercase tracking-wider mt-1">Trees Planted</p>
                </div>

                {/* Card 3 */}
                <div className="bg-white/10 border border-white/10 p-4 rounded-xl backdrop-blur-md flex flex-col items-center text-center hover:bg-white/15 transition-colors">
                    <div className="p-3 bg-brand-green/20 rounded-full mb-3 text-blue-300">
                        <BookOpenIcon className="w-6 h-6"/>
                    </div>
                    <p className="text-3xl font-bold font-mono">{schoolDaysFunded.toLocaleString()}</p>
                    <p className="text-xs text-gray-300 uppercase tracking-wider mt-1">School Days Funded</p>
                </div>
            </div>
            
            <div className="relative z-10 mt-6 text-center">
                <p className="text-xs text-white/50 italic">
                    "Your actions are building a stronger, greener Africa."
                </p>
            </div>
        </div>
    );
};

export default ImpactSummary;
