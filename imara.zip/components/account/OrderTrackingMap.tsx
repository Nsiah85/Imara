import React from 'react';
import { APIProvider, Map, AdvancedMarker, Pin } from '@vis.gl/react-google-maps';

const API_KEY =
  process.env.GOOGLE_MAPS_PLATFORM_KEY ||
  (import.meta as any).env?.VITE_GOOGLE_MAPS_PLATFORM_KEY ||
  (globalThis as any).GOOGLE_MAPS_PLATFORM_KEY ||
  '';
const hasValidKey = Boolean(API_KEY) && API_KEY !== 'YOUR_API_KEY';

const OrderTrackingMap: React.FC = () => {
  if (!hasValidKey) {
    return (
      <div className="flex flex-col items-center justify-center h-full bg-gray-50 dark:bg-gray-900 text-center p-6 text-brand-navy-dark dark:text-gray-300">
          <h2 className="text-xl font-bold mb-4">Live Tracking Unavailable</h2>
          <p className="text-sm">Please configure your Google Maps API Key to view live tracking.</p>
          <div className="mt-4 text-xs bg-white dark:bg-gray-800 p-4 rounded-xl shadow-sm text-left inline-block">
            <p className="font-bold mb-2">How to fix:</p>
            <ol className="list-decimal pl-4 space-y-1">
              <li>Open <strong>Settings</strong> (⚙️)</li>
              <li>Select <strong>Secrets</strong></li>
              <li>Add secret <code className="bg-gray-100 dark:bg-gray-700 px-1 py-0.5 rounded">GOOGLE_MAPS_PLATFORM_KEY</code></li>
            </ol>
          </div>
      </div>
    );
  }

  return (
    <APIProvider apiKey={API_KEY} version="weekly">
      <Map
        defaultCenter={{ lat: 5.6037, lng: -0.1870 }} // Default to Accra, Ghana
        defaultZoom={12}
        mapId="DEMO_MAP_ID"
        internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        style={{ width: '100%', height: '100%' }}
        gestureHandling={'greedy'}
        disableDefaultUI={true}
      >
        <AdvancedMarker position={{ lat: 5.6037, lng: -0.1870 }} title="Package Location">
          <Pin background="#00A34A" borderColor="#007A33" glyphColor="#fff" />
        </AdvancedMarker>
        <AdvancedMarker position={{ lat: 5.6200, lng: -0.1700 }} title="Destination">
          <Pin background="#FFAB00" borderColor="#B27700" glyphColor="#fff" />
        </AdvancedMarker>
      </Map>
    </APIProvider>
  );
};

export default OrderTrackingMap;
