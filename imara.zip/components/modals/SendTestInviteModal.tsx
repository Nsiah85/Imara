import React, { useState, useEffect, useCallback } from 'react';
// FIX: Removed deprecated GoogleGenerativeAI import.
import { GoogleGenAI, Type, GenerateContentResponse } from '@google/genai';
import type { JobApplicant, JobListing, PreInterviewTest, ApplicantTestAttempt, TestQuestion } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { XIcon, SparklesIcon } from '../icons/Icons.tsx';
import SkeletonLoader from '../ui/SkeletonLoader.tsx';

interface SendTestInviteModalProps {
  applicant: JobApplicant;
  job: JobListing;
  onClose: () => void;
  onInviteSent: (applicantId: string) => void;
}

const SendTestInviteModal: React.FC<SendTestInviteModalProps> = ({ applicant, job, onClose, onInviteSent }) => {
  const [isClosing, setIsClosing] = useState(false);
  const [timeLimit, setTimeLimit] = useState(30);
  const [useCamera, setUseCamera] = useState(false);
  const [useMicrophone, setUseMicrophone] = useState(false);
  const [questions, setQuestions] = useState<TestQuestion[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => { if (e.key === 'Escape') close(); };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);

  const generateQuestionsWithAI = async () => {
    setIsLoading(true);
    setError('');
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const prompt = `Based on the following job description, generate a pre-interview test with exactly 5 questions. The test must include a mix of 3 multiple-choice (mcq), 1 short-answer (short_answer), and 1 situational (situational) question. Provide the output as a valid JSON array. Each object in the array must have a 'type' ('mcq', 'short_answer', or 'situational'), and a 'questionText'. For 'mcq' type, also include an 'options' array of exactly 4 strings and a 'correctAnswer' string which is one of the options.

Job Title: ${job.title}
Job Description: ${job.description}
Requirements: ${job.requirements.join(', ')}`;
        
        const responseSchema = {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              type: { type: Type.STRING },
              questionText: { type: Type.STRING },
              options: { type: Type.ARRAY, items: { type: Type.STRING } },
              correctAnswer: { type: Type.STRING },
            },
            required: ['type', 'questionText'],
          },
        };

        const response: GenerateContentResponse = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
            responseSchema,
          },
        });
        
        const generatedQs = JSON.parse(response.text) as Omit<TestQuestion, 'id'>[];
        setQuestions(generatedQs.map(q => ({ ...q, id: crypto.randomUUID() })));

    } catch (e) {
        console.error("AI Generation Error:", e);
        setError("Failed to generate questions. Please try again or create them manually.");
    } finally {
        setIsLoading(false);
    }
  };

  const handleSendInvite = () => {
    // 1. Create the test
    const newTest: PreInterviewTest = {
        id: crypto.randomUUID(),
        jobListingId: job.id,
        title: `Pre-Interview Test for ${job.title}`,
        questions,
        timeLimitMinutes: timeLimit,
        useCameraMonitoring: useCamera,
        useMicrophoneMonitoring: useMicrophone,
        passingScore: 70,
    };

    // 2. Create the test attempt
    const newAttempt: ApplicantTestAttempt = {
        id: `attempt_${applicant.id}_${newTest.id}`,
        applicantId: applicant.professionalId,
        testId: newTest.id,
        status: 'invited',
        answers: [],
    };
    
    // 3. Save to localStorage (mocking backend)
    try {
        // Fix: Added type assertions for JSON.parse to ensure type safety when handling test and attempt data from localStorage.
        // FIX: In the `handleSendInvite` function, I've added explicit type casting `as PreInterviewTest[]` and `as ApplicantTestAttempt[]` to the results of `JSON.parse`. This resolves potential 'any' type errors, ensuring that the data retrieved from `localStorage` is correctly typed before being used in the application.
        const tests = JSON.parse(localStorage.getItem('imara_tests') || '[]') as PreInterviewTest[];
        localStorage.setItem('imara_tests', JSON.stringify([...tests, newTest]));

        const attempts = JSON.parse(localStorage.getItem('imara_test_attempts') || '[]') as ApplicantTestAttempt[];
        localStorage.setItem('imara_test_attempts', JSON.stringify([...attempts, newAttempt]));
        
        // 4. Update parent state
        onInviteSent(applicant.id);
        
        // 5. Close modal
        close();
    } catch (e) {
        // Fix: Added error handling for saving test invite.
        // FIX: Add error logging to catch block.
        console.error("Failed to save test invite:", e);
        setError("Failed to save the test invite. Please check your storage and try again.");
    }
  };

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`} onClick={close} role="dialog">
      <div className={`relative bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col transition-all duration-300 ${modalAnimation}`} onClick={(e) => e.stopPropagation()}>
        <header className="p-6 border-b">
          <h2 className="text-xl font-display font-semibold text-brand-navy-dark">Send Pre-Interview Test</h2>
          <p className="text-sm text-gray-500">To: {applicant.professionalName} for {job.title}</p>
        </header>
        <main className="p-6 space-y-6 overflow-y-auto">
            <div className="flex flex-col sm:flex-row gap-4 items-center">
                <Button onClick={generateQuestionsWithAI} disabled={isLoading} className="w-full sm:w-auto flex items-center justify-center gap-2">
                    <SparklesIcon className="w-5 h-5" />
                    {isLoading ? 'Generating...' : 'Generate Questions with AI'}
                </Button>
                <Button variant="outline" className="w-full sm:w-auto" disabled>Use Template (Coming Soon)</Button>
            </div>
            
            {error && <p className="text-sm text-red-600">{error}</p>}
            
            {isLoading && (
                <div className="space-y-2">
                    <SkeletonLoader className="h-8 w-full" />
                    <SkeletonLoader className="h-8 w-5/6" />
                    <SkeletonLoader className="h-8 w-3/4" />
                </div>
            )}
            
            {questions.length > 0 && (
                 <div className="space-y-4 border-t pt-4">
                     <h3 className="font-semibold">Generated Questions:</h3>
                     <ul className="space-y-2 text-sm max-h-48 overflow-y-auto pr-2">
                         {questions.map((q, i) => <li key={q.id} className="p-2 bg-gray-50 rounded-md">{i+1}. {q.questionText}</li>)}
                     </ul>
                 </div>
            )}

            <div className="border-t pt-4 space-y-4">
                <h3 className="font-semibold">Test Settings</h3>
                 <div>
                    <label htmlFor="timeLimit" className="block text-sm font-medium text-gray-700">Time Limit (minutes)</label>
                    <input type="number" id="timeLimit" value={timeLimit} onChange={e => setTimeLimit(Number(e.target.value))} className="mt-1 w-full p-2 border border-gray-300 rounded-md"/>
                </div>
                <div className="flex items-center gap-4">
                     <label className="flex items-center gap-2">
                        <input type="checkbox" checked={useCamera} onChange={e => setUseCamera(e.target.checked)} className="h-4 w-4 rounded text-brand-gold focus:ring-brand-gold"/>
                        Camera Monitoring
                    </label>
                    <label className="flex items-center gap-2">
                        <input type="checkbox" checked={useMicrophone} onChange={e => setUseMicrophone(e.target.checked)} className="h-4 w-4 rounded text-brand-gold focus:ring-brand-gold"/>
                        Microphone Check
                    </label>
                </div>
            </div>
        </main>
        <footer className="p-6 bg-gray-50 rounded-b-lg flex justify-end gap-4">
          <Button type="button" variant="outline" onClick={close}>Cancel</Button>
          <Button type="button" onClick={handleSendInvite} disabled={questions.length === 0}>Send Invite</Button>
        </footer>
        <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800" aria-label="Close modal">
          <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default SendTestInviteModal;
