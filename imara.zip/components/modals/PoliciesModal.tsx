


import React, { useState, useEffect, useCallback } from 'react';
import Button from '../ui/Button.tsx';
import { XIcon } from '../icons/Icons.tsx';

interface PoliciesModalProps {
  onClose: () => void;
}

const PoliciesModal: React.FC<PoliciesModalProps> = ({ onClose }) => {
  const [isClosing, setIsClosing] = useState(false);

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close} role="dialog" aria-modal="true" aria-labelledby="policies-title"
    >
      <div
        className={`relative bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b dark:border-gray-700 flex-shrink-0">
          <h2 id="policies-title" className="text-xl font-display font-semibold text-brand-green-dark dark:text-white">Vendor Policies & Guidelines</h2>
        </div>
        <div className="p-8 overflow-y-auto space-y-4 text-gray-700 dark:text-gray-300">
            <h3 className="text-lg font-bold text-brand-green dark:text-brand-gold-light">1. Fair Trade Principles</h3>
            <p>All vendors are expected to adhere to fair trade standards. This includes fair wages, safe working conditions, and transparent business practices. We are committed to empowering our artisan partners and ensuring ethical sourcing across our platform.</p>
            
            <h3 className="text-lg font-bold text-brand-green dark:text-brand-gold-light">2. Product Authenticity & Quality</h3>
            <p>Products must be authentic and accurately represented in listings. We celebrate handmade and traditional crafts. Any claims about materials (e.g., organic, recycled) must be verifiable. High-quality craftsmanship is essential to maintaining customer trust.</p>

            <h3 className="text-lg font-bold text-brand-green dark:text-brand-gold-light">3. Community Conduct</h3>
            <p>We foster a respectful and collaborative community. All communication with customers and fellow partners must be professional and courteous. We have a zero-tolerance policy for harassment or discrimination.</p>

            <h3 className="text-lg font-bold text-brand-green dark:text-brand-gold-light">4. Shipping & Fulfillment</h3>
            <p>Vendors are responsible for timely fulfillment of orders. Shipping times must be clearly communicated on product pages. We encourage the use of sustainable and eco-friendly packaging materials whenever possible.</p>
        </div>
        <div className="p-6 bg-gray-50 dark:bg-gray-700/50 rounded-b-lg flex justify-end flex-shrink-0">
            <Button onClick={close}>I Understand</Button>
        </div>
        <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 dark:hover:text-white transition-colors z-10" aria-label="Close policies modal">
          <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default PoliciesModal;