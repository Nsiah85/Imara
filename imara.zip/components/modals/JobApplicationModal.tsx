import React, { useState, useCallback, useEffect } from 'react';
import type { JobListing, JobApplicant } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { XIcon, ArrowUpTrayIcon, DocumentTextIcon, CheckCircleIcon } from '../icons/Icons.tsx';
import { useAuth } from '../../contexts/AuthContext.tsx';
import { mockProfessionals } from '../../data/mockData.ts';
import { useNavigate } from 'react-router-dom';

interface JobApplicationModalProps {
  job: JobListing;
  onClose: () => void;
  onApply: (applicant: JobApplicant) => void;
}

const JobApplicationModal: React.FC<JobApplicationModalProps> = ({ job, onClose, onApply }) => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const [coverLetter, setCoverLetter] = useState('');
    const [cvFile, setCvFile] = useState<File | null>(null);
    const [otherFiles, setOtherFiles] = useState<File[]>([]);
    const [error, setError] = useState('');
    const [isClosing, setIsClosing] = useState(false);
    const [isSubmitted, setIsSubmitted] = useState(false);

    const close = useCallback(() => {
        setIsClosing(true);
        setTimeout(onClose, 300);
    }, [onClose]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => { if (e.key === 'Escape') close(); };
        document.addEventListener('keydown', handleKeyDown);
        document.body.style.overflow = 'hidden';
        return () => {
            document.removeEventListener('keydown', handleKeyDown);
            document.body.style.overflow = 'auto';
        };
    }, [close]);
    
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'cv' | 'other') => {
        setError('');
        const files = e.target.files;
        if (!files) return;

        if (type === 'cv') {
            const file = files[0];
            if (file) {
                if (file.size > 5 * 1024 * 1024) { // 5MB limit
                    setError('CV file size cannot exceed 5MB.');
                    return;
                }
                setCvFile(file);
            }
        } else {
            const newFiles = Array.from(files);
            if (newFiles.some((f: File) => f.size > 10 * 1024 * 1024)) { // 10MB limit per file
                setError('Individual document size cannot exceed 10MB.');
                return;
            }
            setOtherFiles(prev => [...prev, ...newFiles]);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!user) {
            navigate('/login');
            return;
        }

        if (!cvFile) {
            setError('A CV is required to apply.');
            return;
        }
        
        const professionalProfile = mockProfessionals.find(p => p.email === user.email);
        if (!professionalProfile) {
            setError('You must have a professional profile to apply. Please create one first.');
            return;
        }

        const newApplicant: JobApplicant = {
            id: crypto.randomUUID(),
            jobListingId: job.id,
            professionalId: professionalProfile.id,
            professionalName: user.fullName,
            professionalAvatar: user.profileImageUrl,
            status: 'applied',
            appliedDate: new Date().toISOString(),
            cvUrl: URL.createObjectURL(cvFile), // Mock URL
            coverLetter: coverLetter,
            otherDocuments: otherFiles.map(f => ({ name: f.name, url: URL.createObjectURL(f) })),
        };
        onApply(newApplicant);
        setIsSubmitted(true);
    };

    const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
    const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';

    return (
        <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`} onClick={close}>
            <div className={`relative bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col transition-all duration-300 ${modalAnimation}`} onClick={e => e.stopPropagation()}>
                <header className="p-6 border-b dark:border-gray-700 flex items-start gap-4">
                    <img src={job.companyLogoUrl} alt={`${job.companyName} logo`} className="w-12 h-12 object-contain" />
                    <div>
                        <p className="text-sm text-brand-gray dark:text-gray-400">Applying for</p>
                        <h2 className="text-2xl font-display font-bold text-brand-navy-dark dark:text-white">{job.title}</h2>
                    </div>
                </header>

                {isSubmitted ? (
                    <div className="p-8 text-center flex-grow flex flex-col justify-center">
                        <CheckCircleIcon className="w-16 h-16 text-brand-gold mx-auto" />
                        <h3 className="text-2xl font-display font-bold text-brand-navy-dark dark:text-white mt-4">Application Sent!</h3>
                        <p className="mt-2 text-gray-600 dark:text-gray-300">Your application has been successfully submitted to {job.companyName}. Best of luck!</p>
                        <Button onClick={close} className="mt-6 mx-auto">Done</Button>
                    </div>
                ) : (
                    <form onSubmit={handleSubmit} className="flex-grow flex flex-col min-h-0">
                        <main className="p-8 space-y-6 overflow-y-auto">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Upload CV/Resume*</label>
                                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 dark:border-gray-600 border-dashed rounded-md">
                                    <div className="space-y-1 text-center">
                                        <DocumentTextIcon className="mx-auto h-12 w-12 text-gray-400" />
                                        <div className="flex text-sm text-gray-600 dark:text-gray-300">
                                            <label htmlFor="cv-upload" className="relative cursor-pointer bg-white dark:bg-gray-800 rounded-md font-medium text-brand-navy dark:text-brand-gold-light hover:text-brand-gold focus-within:outline-none">
                                                <span>Upload a file</span>
                                                <input id="cv-upload" name="cv-upload" type="file" className="sr-only" onChange={e => handleFileChange(e, 'cv')} accept=".pdf,.doc,.docx" />
                                            </label>
                                            <p className="pl-1">or drag and drop</p>
                                        </div>
                                        <p className="text-xs text-gray-500 dark:text-gray-400">PDF, DOC, DOCX up to 5MB</p>
                                        {cvFile && <p className="text-sm text-green-600 dark:text-green-400 mt-2">{cvFile.name}</p>}
                                    </div>
                                </div>
                            </div>
                            <div>
                                <label htmlFor="coverLetter" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Cover Letter (Optional)</label>
                                <textarea id="coverLetter" value={coverLetter} onChange={e => setCoverLetter(e.target.value)} rows={5} className="mt-1 w-full p-2 border rounded-md bg-white dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-brand-gold focus:border-brand-gold" placeholder="Briefly introduce yourself and explain why you're a great fit for this role."/>
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Other Documents (Portfolio, etc.)</label>
                                 <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 dark:border-gray-600 border-dashed rounded-md">
                                    <div className="space-y-1 text-center">
                                        <ArrowUpTrayIcon className="mx-auto h-10 w-10 text-gray-400" />
                                        <div className="flex text-sm text-gray-600 dark:text-gray-300">
                                            <label htmlFor="other-upload" className="relative cursor-pointer bg-white dark:bg-gray-800 rounded-md font-medium text-brand-navy dark:text-brand-gold-light hover:text-brand-gold focus-within:outline-none">
                                                <span>Upload files</span>
                                                <input id="other-upload" name="other-upload" type="file" multiple className="sr-only" onChange={e => handleFileChange(e, 'other')} />
                                            </label>
                                        </div>
                                        <p className="text-xs text-gray-500 dark:text-gray-400">Up to 10MB per file</p>
                                        {otherFiles.length > 0 && (
                                            <div className="mt-2 text-sm text-green-600 dark:text-green-400 space-y-1">
                                                {otherFiles.map(f => <p key={f.name}>{f.name}</p>)}
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                             {error && <p className="text-sm text-red-600">{error}</p>}
                        </main>
                        <footer className="p-6 bg-gray-50 dark:bg-gray-700/50 rounded-b-lg flex justify-end gap-4 mt-auto">
                            <Button type="button" variant="outline" onClick={close}>Cancel</Button>
                            <Button type="submit">Submit Application</Button>
                        </footer>
                    </form>
                )}
                <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 dark:hover:text-white" aria-label="Close modal">
                    <XIcon className="w-6 h-6" />
                </button>
            </div>
        </div>
    );
};

export default JobApplicationModal;