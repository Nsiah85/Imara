
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { mockProducts, mockProfessionals, mockTravelServices, mockJobListings, mockCauses, mockInvestments, mockSounds } from '../../data/mockData.ts';
import { Product, Professional, TravelService, JobListing, Cause, Investment, ProfessionalIndustry } from '../../types.ts';
import { XIcon, SearchIcon, ShoppingBagIcon, UserIcon, GlobeIcon, BriefcaseIcon, HeartIcon, StarIcon, FireIcon, MusicNoteIcon, DocumentTextIcon, SparklesIcon, PlayIcon } from '../icons/Icons.tsx';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';
import Button from '../ui/Button.tsx';
import { useDebounce } from '../../hooks/useDebounce.ts';
import TrendingGists from '../gist/TrendingGists.tsx';

interface SearchResult {
    id: string;
    type: 'product' | 'professional' | 'service' | 'job' | 'cause' | 'investment';
    title: string;
    subtitle: string;
    imageUrl: string;
    link: string;
}

type Category = 'all' | 'product' | 'service' | 'professional' | 'job' | 'impact';

// Helper for relevance scoring (unchanged)
const calculateRelevance = (item: any, term: string, type: string): number => {
    const lowerTerm = term.toLowerCase();
    let score = 0;
    
    // Title match (Highest priority)
    const title = item.name || item.title || '';
    if (title.toLowerCase() === lowerTerm) score += 100;
    else if (title.toLowerCase().startsWith(lowerTerm)) score += 80;
    else if (title.toLowerCase().includes(lowerTerm)) score += 60;

    // Subtitle/Role/Vendor/Company match (Medium priority)
    const subtitle = item.vendor || item.professionalRole || item.companyName || item.providerName || item.organization || item.vendorName || '';
    if (subtitle.toLowerCase().includes(lowerTerm)) score += 40;

    // Description/Content match (Low priority)
    const description = item.description || item.bio || item.content || '';
    if (description.toLowerCase().includes(lowerTerm)) score += 20;

    // Tags/Skills match (Medium-Low priority)
    const tags = item.sustainabilityTags || item.skills || item.requirements || [];
    if (Array.isArray(tags) && tags.some((t: string) => t.toLowerCase().includes(lowerTerm))) score += 30;

    return score;
};

const mockTemplates = [
    { id: 1, title: "Day in the Life", used: "12k uses", bg: "bg-gradient-to-br from-purple-600 to-indigo-800" },
    { id: 2, title: "OOTD Check", used: "8.5k uses", bg: "bg-gradient-to-br from-pink-600 to-rose-700" },
    { id: 3, title: "Artisan Showcase", used: "5k uses", bg: "bg-gradient-to-br from-amber-600 to-orange-700" },
];

const SearchModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const [inputValue, setInputValue] = useState('');
    const debouncedSearchTerm = useDebounce(inputValue, 300);
    const [isClosing, setIsClosing] = useState(false);
    const { formatCurrency } = useCurrency();
    const navigate = useNavigate();

    // Filter states
    const [activeCategory, setActiveCategory] = useState<Category>('all');
    const [priceRange, setPriceRange] = useState({ min: '', max: '' });
    const [selectedIndustry, setSelectedIndustry] = useState<ProfessionalIndustry | null>(null);
    const [minRating, setMinRating] = useState(0);

    const finalResults = useMemo(() => {
        if (debouncedSearchTerm.length < 2) return [];

        const allResults: (SearchResult & { score: number })[] = [];
        
        const addResults = (source: any[], type: SearchResult['type'], mapFn: (i:any) => SearchResult) => {
             source.forEach(item => {
                 const score = calculateRelevance(item, debouncedSearchTerm, type);
                 if (score > 0) {
                     // Apply category specific filters here
                     if (type === 'product') {
                         const minPrice = parseFloat(priceRange.min) || 0;
                         const maxPrice = parseFloat(priceRange.max) || Infinity;
                         if (item.price < minPrice || item.price > maxPrice) return;
                     }
                     if (type === 'service' && item.rating < minRating) return;
                     if ((type === 'professional' || type === 'job') && selectedIndustry && item.industry !== selectedIndustry) return;
                     
                     allResults.push({ ...mapFn(item), score });
                 }
             });
        };
        
        // Products
        if (activeCategory === 'all' || activeCategory === 'product') {
             addResults(mockProducts, 'product', p => ({ id: p.id, type: 'product', title: p.name, subtitle: formatCurrency(p.price), imageUrl: p.imageUrl, link: `/product/${p.id}` }));
        }
        // Services
        if (activeCategory === 'all' || activeCategory === 'service') {
            addResults(mockTravelServices, 'service', s => ({ id: s.id, type: 'service', title: s.title, subtitle: `in ${s.location}`, imageUrl: s.imageUrl, link: `/feel-afro/${s.id}` }));
        }
        // Professionals
        if (activeCategory === 'all' || activeCategory === 'professional') {
            addResults(mockProfessionals, 'professional', p => ({ id: p.id, type: 'professional', title: p.name, subtitle: p.professionalRole, imageUrl: p.profileImageUrl, link: `/workman/${p.storeSlug}` }));
        }
        // Jobs
        if (activeCategory === 'all' || activeCategory === 'job') {
            addResults(mockJobListings, 'job', j => ({ id: j.id, type: 'job', title: j.title, subtitle: `at ${j.companyName}`, imageUrl: j.companyLogoUrl, link: `/find-job` }));
        }
        // Impact
        if (activeCategory === 'all' || activeCategory === 'impact') {
            addResults(mockCauses, 'cause', c => ({ id: c.id, type: 'cause', title: c.title, subtitle: `by ${c.organization}`, imageUrl: c.imageUrl, link: `/invest` }));
            addResults(mockInvestments, 'investment', i => ({ id: i.id, type: 'investment', title: i.title, subtitle: `for ${i.vendorName}`, imageUrl: i.imageUrl, link: `/invest` }));
        }

        return allResults.sort((a, b) => b.score - a.score).slice(0, 20); // Limit total results
    }, [debouncedSearchTerm, activeCategory, priceRange, selectedIndustry, minRating, formatCurrency]);

    const close = useCallback(() => {
        setIsClosing(true);
        setTimeout(onClose, 300);
    }, [onClose]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => { if (e.key === 'Escape') close(); };
        document.addEventListener('keydown', handleKeyDown);
        document.body.style.overflow = 'hidden';
        return () => {
            document.removeEventListener('keydown', handleKeyDown);
            document.body.style.overflow = 'auto';
        };
    }, [close]);
    
    const handleResetFilters = () => {
        setPriceRange({ min: '', max: '' });
        setSelectedIndustry(null);
        setMinRating(0);
    };

    useEffect(handleResetFilters, [activeCategory]);
    
    const renderIcon = (type: SearchResult['type']) => {
        switch (type) {
            case 'product': return <ShoppingBagIcon className="w-5 h-5"/>;
            case 'professional': return <UserIcon className="w-5 h-5"/>;
            case 'service': return <GlobeIcon className="w-5 h-5"/>;
            case 'job': return <BriefcaseIcon className="w-5 h-5"/>;
            case 'cause': case 'investment': return <HeartIcon className="w-5 h-5"/>;
            default: return null;
        }
    };

    const handleTrendClick = (trend: string) => {
        setInputValue(trend);
    };

    const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
    const modalAnimation = isClosing ? 'opacity-0 -translate-y-4' : 'opacity-100 translate-y-0';

    const categories: { id: Category, name: string }[] = [
        { id: 'all', name: 'All' },
        { id: 'product', name: 'Products' },
        { id: 'service', name: 'Services' },
        { id: 'professional', name: 'Talent' },
        { id: 'job', name: 'Jobs' },
        { id: 'impact', name: 'Impact' },
    ];
    
    const renderAdvancedFilters = () => {
        const showFilters = ['product', 'service', 'professional', 'job'].includes(activeCategory);
        if (!showFilters || inputValue.length < 2) return null;

        return (
            <div className="px-4 py-3 bg-gray-50/80 dark:bg-gray-700/50 border-b dark:border-gray-600 animate-fade-in-down">
                <div className="flex items-center justify-between">
                     <div className="flex items-center gap-4">
                        {activeCategory === 'product' && (
                            <div className="flex items-center gap-2">
                                <label className="text-sm text-gray-600 dark:text-gray-300">Price:</label>
                                <input type="number" placeholder="Min" value={priceRange.min} onChange={e => setPriceRange(p => ({ ...p, min: e.target.value }))} className="w-24 p-1.5 border border-gray-300 dark:border-gray-500 dark:bg-gray-800 rounded-md text-sm"/>
                                <span className="text-gray-500 dark:text-gray-400">-</span>
                                <input type="number" placeholder="Max" value={priceRange.max} onChange={e => setPriceRange(p => ({ ...p, max: e.target.value }))} className="w-24 p-1.5 border border-gray-300 dark:border-gray-500 dark:bg-gray-800 rounded-md text-sm"/>
                            </div>
                        )}
                        {(activeCategory === 'professional' || activeCategory === 'job') && (
                            <div className="flex items-center gap-2">
                                <label className="text-sm text-gray-600 dark:text-gray-300">Industry:</label>
                                <select value={selectedIndustry || ''} onChange={e => setSelectedIndustry(e.target.value as ProfessionalIndustry || null)} className="p-1.5 border border-gray-300 dark:border-gray-500 dark:bg-gray-800 rounded-md text-sm">
                                    <option value="">All Industries</option>
                                    {Object.values(ProfessionalIndustry).map(ind => <option key={ind} value={ind}>{ind}</option>)}
                                </select>
                            </div>
                        )}
                        {activeCategory === 'service' && (
                             <div className="flex items-center gap-2">
                                <label className="text-sm text-gray-600 dark:text-gray-300">Rating:</label>
                                {[4, 3, 0].map(rating => (
                                    <button key={rating} onClick={() => setMinRating(rating)} className={`px-2 py-1 text-xs rounded-md border transition-colors ${minRating === rating ? 'bg-brand-green text-white border-brand-green' : 'bg-white dark:bg-gray-800 dark:border-gray-500 hover:border-brand-green'}`}>
                                        {rating > 0 ? <span className="flex items-center">{rating}<StarIcon className="w-3 h-3 ml-1 text-yellow-500"/>+</span> : 'Any'}
                                    </button>
                                ))}
                             </div>
                        )}
                    </div>
                    <Button variant="outline" size="sm" onClick={handleResetFilters}>Reset</Button>
                </div>
            </div>
        );
    };

    return (
        <div
            className={`fixed inset-0 z-50 flex items-start justify-center bg-black/50 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation} pt-0 sm:pt-16`}
            onClick={close}
            role="dialog"
            aria-modal="true"
        >
            <div
                className={`relative bg-white dark:bg-brand-navy-dark w-full h-full sm:h-auto sm:rounded-xl sm:max-w-3xl transform transition-all duration-300 flex flex-col ${modalAnimation} overflow-hidden`}
                onClick={(e) => e.stopPropagation()}
                style={{ maxHeight: '90vh' }}
            >
                <div className="relative border-b dark:border-gray-700">
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4">
                        <SearchIcon className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                        type="search"
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        placeholder="Search products, professionals, services, and more..."
                        className="w-full bg-transparent p-4 pl-12 text-lg text-brand-navy-dark dark:text-white placeholder:text-gray-400 focus:outline-none"
                        autoFocus
                    />
                     <button onClick={close} className="absolute top-1/2 right-4 -translate-y-1/2 text-gray-400 hover:text-gray-800 dark:hover:text-white" aria-label="Close search">
                        <XIcon className="w-6 h-6" />
                    </button>
                </div>

                {inputValue.length > 0 && (
                    <div className="px-4 py-2 border-b dark:border-gray-700 flex flex-wrap gap-2">
                        {categories.map(cat => (
                            <button 
                                key={cat.id} 
                                onClick={() => setActiveCategory(cat.id)}
                                className={`px-3 py-1 text-sm rounded-full transition-colors ${activeCategory === cat.id ? 'bg-brand-gold text-brand-navy-dark font-semibold' : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-600'}`}
                            >
                                {cat.name}
                            </button>
                        ))}
                    </div>
                )}

                {renderAdvancedFilters()}

                <div className="flex-grow min-h-0 overflow-y-auto bg-gray-50 dark:bg-gray-900">
                    {inputValue.length > 1 ? (
                        /* Search Results */
                        <ul className="divide-y divide-gray-100 dark:divide-gray-800">
                            {finalResults.length > 0 && finalResults.map(item => (
                                <li key={`${item.type}-${item.id}`}>
                                    <Link to={item.link} onClick={close} className="flex items-center gap-4 p-4 hover:bg-white dark:hover:bg-brand-navy-dark transition-colors">
                                        <div className="w-12 h-12 rounded-md bg-gray-200 dark:bg-gray-700 flex-shrink-0 flex items-center justify-center overflow-hidden">
                                           <img src={item.imageUrl} alt={item.title} className={`w-full h-full ${item.type === 'job' ? 'object-contain' : 'object-cover'}`} />
                                        </div>
                                        <div className="flex-grow">
                                            <p className="font-semibold text-brand-navy-dark dark:text-white">{item.title}</p>
                                            <p className="text-sm text-gray-500 dark:text-gray-400">{item.subtitle}</p>
                                        </div>
                                        <div className="flex-shrink-0 text-gray-400 dark:text-gray-500">
                                            {renderIcon(item.type)}
                                        </div>
                                    </Link>
                                </li>
                            ))}
                            {finalResults.length === 0 && (
                                <div className="p-8 text-center text-gray-500 dark:text-gray-400">
                                    <p>No results found for "{debouncedSearchTerm}".</p>
                                </div>
                             )}
                        </ul>
                    ) : (
                        /* Discover Dashboard (When no search input) */
                        <div className="p-6 space-y-8">
                             {/* Trending Section */}
                            <section>
                                <div className="flex items-center gap-2 mb-4 text-brand-gold">
                                    <FireIcon className="w-5 h-5 animate-pulse" />
                                    <h3 className="font-bold text-lg text-brand-navy-dark dark:text-white">Trending Now</h3>
                                </div>
                                <div className="bg-white dark:bg-brand-navy-dark/50 rounded-xl p-2 border border-gray-200 dark:border-gray-700 h-48">
                                     <TrendingGists onTrendClick={handleTrendClick} activeTrend={null} />
                                </div>
                            </section>

                            {/* Viral Sounds */}
                             <section>
                                <div className="flex justify-between items-center mb-4">
                                    <h2 className="text-lg font-bold flex items-center gap-2 text-brand-navy-dark dark:text-white">
                                        <MusicNoteIcon className="w-5 h-5 text-brand-green"/> Viral Sounds
                                    </h2>
                                </div>
                                <div className="space-y-3">
                                    {mockSounds.slice(0, 3).map((sound, i) => (
                                        <div key={sound.id} className="flex items-center gap-4 p-3 bg-white dark:bg-white/5 rounded-2xl shadow-sm border border-gray-100 dark:border-white/5 hover:border-brand-gold/50 transition-all group">
                                            <div className="relative w-10 h-10 bg-brand-navy-dark rounded-xl flex items-center justify-center text-brand-gold font-bold text-sm shadow-inner flex-shrink-0">
                                                {i + 1}
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <p className="font-bold text-sm truncate text-brand-navy-dark dark:text-white">{sound.title}</p>
                                                <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{sound.artist}</p>
                                            </div>
                                            <button className="p-2 bg-gray-100 dark:bg-white/10 rounded-full hover:bg-brand-green hover:text-white transition-colors">
                                                <PlayIcon className="w-4 h-4" />
                                            </button>
                                        </div>
                                    ))}
                                </div>
                            </section>
                            
                            {/* Hot in ShopHub */}
                            <section>
                                <h2 className="text-lg font-bold mb-4 text-brand-navy-dark dark:text-white flex items-center gap-2">
                                     <ShoppingBagIcon className="w-5 h-5 text-brand-gold"/> Hot in ShopHub
                                </h2>
                                <div className="grid grid-cols-2 gap-4">
                                    {mockProducts.slice(0, 2).map(product => (
                                        <div key={product.id} className="bg-white dark:bg-white/5 rounded-xl overflow-hidden shadow-md group border border-gray-100 dark:border-white/5">
                                            <div className="relative h-24 overflow-hidden">
                                                <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"/>
                                            </div>
                                            <div className="p-2">
                                                <p className="font-bold text-xs truncate text-brand-navy-dark dark:text-white">{product.name}</p>
                                                <p className="text-[10px] text-gray-500 dark:text-gray-400 truncate">${product.price}</p>
                                                <button onClick={() => { close(); navigate(`/product/${product.id}`); }} className="w-full mt-2 py-1 text-[10px] font-bold border border-brand-green text-brand-green rounded hover:bg-brand-green hover:text-white transition-colors">
                                                    View
                                                </button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </section>

                            {/* Templates */}
                            <section>
                                <h2 className="text-lg font-bold mb-4 text-brand-navy-dark dark:text-white flex items-center gap-2">
                                     <DocumentTextIcon className="w-5 h-5 text-purple-500"/> Templates
                                </h2>
                                <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
                                    {mockTemplates.map(template => (
                                        <div key={template.id} className={`w-28 h-40 ${template.bg} rounded-xl flex-shrink-0 flex flex-col justify-between p-3 shadow-lg transform transition-transform hover:scale-105 cursor-pointer text-white relative overflow-hidden`}>
                                            <div className="absolute top-0 right-0 w-16 h-16 bg-white/10 rounded-full blur-xl"></div>
                                            <SparklesIcon className="w-5 h-5 opacity-90"/>
                                            <div>
                                                <p className="text-xs font-bold leading-tight mb-1">{template.title}</p>
                                                <p className="text-[8px] opacity-80">{template.used}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </section>
                        </div>
                    )}
                 </div>
            </div>
        </div>
    );
};

export default SearchModal;
