
import React, { useState, useEffect } from 'react';
import { XIcon, UserPlusIcon, PencilSquareIcon, TrashIcon, SearchIcon, EnvelopeIcon, CheckCircleIcon } from '../icons/Icons';
import Button from '../ui/Button';
import { useAuth } from '../../contexts/AuthContext';
import Avatar from '../ui/Avatar';
import { mockAllUsersAndPartners } from '../../data/mockData';
import { Link } from 'react-router-dom';
import type { Participant } from '../../types';

interface ContactsModalProps {
    onClose: () => void;
}

const ContactsModal: React.FC<ContactsModalProps> = ({ onClose }) => {
    const { user, addContact, removeContact } = useAuth();
    const [activeTab, setActiveTab] = useState<'contacts' | 'add' | 'edit'>('contacts');
    const [username, setUsername] = useState(user?.fullName?.replace(/\s+/g, '').toLowerCase() || '');
    const [phone, setPhone] = useState('+233 55 123 4567');
    const [searchTerm, setSearchTerm] = useState('');
    const [feedback, setFeedback] = useState<string | null>(null);

    // 1. Get real contacts based on IDs stored in UserProfile
    const userContacts = React.useMemo(() => {
        if (!user || !user.contactIds) return [];
        return mockAllUsersAndPartners.filter(p => user.contactIds?.includes(p.id));
    }, [user]);

    // 2. Filter for "Add New" tab
    const searchResults = React.useMemo(() => {
        if (!searchTerm) return [];
        return mockAllUsersAndPartners.filter(p => 
            p.id !== user?.id && // Don't show self
            !user?.contactIds?.includes(p.id) && // Don't show existing contacts
            (p.name.toLowerCase().includes(searchTerm.toLowerCase()) || p.role?.toLowerCase().includes(searchTerm.toLowerCase()))
        ).slice(0, 5);
    }, [searchTerm, user]);

    const handleAdd = (participant: Participant) => {
        addContact(participant.id);
        setFeedback(`Added ${participant.name}`);
        setTimeout(() => setFeedback(null), 2000);
    };

    const handleRemove = (participant: Participant) => {
        if(window.confirm(`Remove ${participant.name} from contacts?`)) {
            removeContact(participant.id);
        }
    };

    return (
        <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white dark:bg-gray-800 w-full max-w-md rounded-2xl shadow-xl overflow-hidden flex flex-col max-h-[80vh] border-2 border-brand-gold/20">
                
                {/* Header */}
                <div className="p-4 border-b dark:border-gray-700 flex justify-between items-center bg-brand-navy-dark">
                    <h3 className="font-bold text-white">Contacts & Profile</h3>
                    <button onClick={onClose}><XIcon className="w-5 h-5 text-gray-400 hover:text-white"/></button>
                </div>
                
                {/* Tabs */}
                <div className="flex border-b dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <button onClick={() => setActiveTab('contacts')} className={`flex-1 py-3 text-sm font-bold transition-colors ${activeTab === 'contacts' ? 'text-brand-gold border-b-2 border-brand-gold bg-white dark:bg-gray-800' : 'text-gray-500'}`}>My Contacts</button>
                    <button onClick={() => setActiveTab('add')} className={`flex-1 py-3 text-sm font-bold transition-colors ${activeTab === 'add' ? 'text-brand-green border-b-2 border-brand-green bg-white dark:bg-gray-800' : 'text-gray-500'}`}>Add New</button>
                    <button onClick={() => setActiveTab('edit')} className={`flex-1 py-3 text-sm font-bold transition-colors ${activeTab === 'edit' ? 'text-blue-500 border-b-2 border-blue-500 bg-white dark:bg-gray-800' : 'text-gray-500'}`}>Edit Info</button>
                </div>

                <div className="p-6 space-y-6 overflow-y-auto flex-1 bg-white dark:bg-gray-800">
                    
                    {/* Feedback Toast */}
                    {feedback && (
                        <div className="bg-green-100 text-green-800 px-3 py-2 rounded-lg text-sm text-center mb-4 flex items-center justify-center gap-2">
                            <CheckCircleIcon className="w-4 h-4" /> {feedback}
                        </div>
                    )}

                    {activeTab === 'contacts' && (
                        <div className="space-y-4">
                             <div className="flex justify-between items-center mb-2">
                                 <span className="text-xs font-bold text-gray-500 uppercase">{userContacts.length} Contacts</span>
                             </div>
                             {userContacts.length > 0 ? (
                                 userContacts.map(contact => (
                                     <div key={contact.id} className="flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-xl border border-gray-100 dark:border-gray-700 transition-all group">
                                         <div className="flex items-center gap-3">
                                             <Avatar imageUrl={contact.avatarUrl} name={contact.name} id={contact.id} className="w-10 h-10 rounded-full" />
                                             <div>
                                                 <p className="font-bold text-sm text-brand-navy-dark dark:text-white">{contact.name}</p>
                                                 <p className="text-xs text-gray-500 capitalize">{contact.role}</p>
                                             </div>
                                         </div>
                                         <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                             <Link to={`/messages/new?recipientId=${contact.id}&recipientName=${encodeURIComponent(contact.name)}`} onClick={onClose}>
                                                <button className="p-2 text-brand-green bg-brand-green/10 rounded-full hover:bg-brand-green hover:text-white transition-colors" title="Message">
                                                    <EnvelopeIcon className="w-4 h-4"/>
                                                </button>
                                             </Link>
                                             <button onClick={() => handleRemove(contact)} className="p-2 text-red-500 bg-red-50 rounded-full hover:bg-red-500 hover:text-white transition-colors" title="Remove">
                                                 <TrashIcon className="w-4 h-4"/>
                                             </button>
                                         </div>
                                     </div>
                                 ))
                             ) : (
                                 <div className="text-center py-8 text-gray-400">
                                     <p>No contacts yet.</p>
                                     <button onClick={() => setActiveTab('add')} className="text-brand-green font-bold text-sm mt-2 hover:underline">Find people</button>
                                 </div>
                             )}
                        </div>
                    )}

                    {activeTab === 'add' && (
                        <div className="space-y-4">
                            <div className="relative">
                                <SearchIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                                <input 
                                    type="text" 
                                    placeholder="Search by name or role..." 
                                    className="w-full pl-10 pr-4 py-2 border rounded-lg dark:bg-gray-700 dark:text-white dark:border-gray-600 focus:ring-2 focus:ring-brand-green outline-none"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    autoFocus
                                />
                            </div>
                            
                            <div className="space-y-2">
                                {searchResults.map(user => (
                                    <div key={user.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
                                        <div className="flex items-center gap-3">
                                            <Avatar imageUrl={user.avatarUrl} name={user.name} id={user.id} className="w-10 h-10 rounded-full" />
                                            <div>
                                                <p className="font-bold text-sm text-brand-navy-dark dark:text-white">{user.name}</p>
                                                <p className="text-xs text-gray-500">{user.role}</p>
                                            </div>
                                        </div>
                                        <button onClick={() => handleAdd(user)} className="text-xs font-bold bg-brand-navy-dark text-white px-3 py-1.5 rounded-full hover:bg-brand-green transition-colors flex items-center gap-1">
                                            <UserPlusIcon className="w-3 h-3" /> Add
                                        </button>
                                    </div>
                                ))}
                                {searchTerm && searchResults.length === 0 && (
                                    <p className="text-center text-gray-400 text-sm py-4">No users found.</p>
                                )}
                            </div>
                        </div>
                    )}

                    {activeTab === 'edit' && (
                        <div className="space-y-6">
                            <div>
                                <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">Username</label>
                                <div className="flex">
                                    <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 text-sm">@</span>
                                    <input 
                                        type="text" 
                                        value={username} 
                                        onChange={(e) => setUsername(e.target.value)} 
                                        className="flex-1 min-w-0 block w-full px-3 py-2 rounded-none rounded-r-md focus:ring-brand-gold focus:border-brand-gold sm:text-sm border-gray-300" 
                                    />
                                </div>
                                <p className="text-xs text-gray-500 mt-1">People can find you by this username.</p>
                            </div>
                            
                            <div>
                                <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">Phone Number</label>
                                <input 
                                    type="tel" 
                                    value={phone} 
                                    onChange={(e) => setPhone(e.target.value)} 
                                    className="block w-full px-3 py-2 rounded-md border-gray-300 shadow-sm focus:border-brand-gold focus:ring-brand-gold sm:text-sm" 
                                />
                            </div>
                            
                            <Button className="w-full mt-4">Save Changes</Button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ContactsModal;
