

import React, { useState, useEffect, useCallback } from 'react';
import type { GiftCard } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { XIcon } from '../icons/Icons.tsx';

interface GiftCardEditModalProps {
  card: Partial<GiftCard> | null;
  onClose: () => void;
  onSave: (card: GiftCard) => void;
}

const GiftCardEditModal: React.FC<GiftCardEditModalProps> = ({ card, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    code: card?.code || '',
    type: card?.type || 'fixed',
    value: card?.value || 0,
    description: card?.description || '',
    expiryDate: card?.expiryDate ? card.expiryDate.split('T')[0] : '',
    isActive: card?.isActive === undefined ? true : card.isActive,
  });
  const [isClosing, setIsClosing] = useState(false);

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      const { checked } = e.target as HTMLInputElement;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
      setFormData(prev => ({ ...prev, [name]: name === 'value' ? Number(value) : value }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalCard: GiftCard = {
      ...formData,
      code: formData.code.toUpperCase(),
      expiryDate: new Date(formData.expiryDate).toISOString(),
    };
    onSave(finalCard);
  };

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';
  const inputClass = "mt-1 block w-full bg-brand-green-dark text-white border border-brand-green rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent placeholder:text-gray-400";
  const selectClass = `${inputClass} appearance-none`;

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close} role="dialog" aria-modal="true" aria-labelledby="edit-card-title"
    >
      <div
        className={`relative bg-white rounded-lg shadow-xl w-full max-w-lg transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b">
          <h2 id="edit-card-title" className="text-xl font-display font-semibold text-brand-green-dark">
            {card?.code ? 'Edit' : 'Add'} Gift Card
          </h2>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-8 space-y-6">
            <div>
              <label htmlFor="code" className="block text-sm font-medium text-gray-700">Coupon Code</label>
              <input type="text" name="code" id="code" value={formData.code} onChange={handleChange} required className={`${inputClass} font-mono uppercase`} disabled={!!card?.code} />
            </div>
            <div className="grid grid-cols-2 gap-6">
                <div>
                    <label htmlFor="type" className="block text-sm font-medium text-gray-700">Type</label>
                    <select name="type" id="type" value={formData.type} onChange={handleChange} required className={selectClass}>
                        <option value="fixed">Fixed Amount</option>
                        <option value="percentage">Percentage</option>
                    </select>
                </div>
                <div>
                    <label htmlFor="value" className="block text-sm font-medium text-gray-700">Value ({formData.type === 'fixed' ? '$' : '%'})</label>
                    <input type="number" name="value" id="value" value={formData.value} onChange={handleChange} required className={inputClass} />
                </div>
            </div>
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700">Description</label>
              <input type="text" name="description" id="description" value={formData.description} onChange={handleChange} required className={inputClass} />
            </div>
            <div>
                <label htmlFor="expiryDate" className="block text-sm font-medium text-gray-700">Expiry Date</label>
                <input type="date" name="expiryDate" id="expiryDate" value={formData.expiryDate} onChange={handleChange} required className={inputClass} />
            </div>
            <div className="flex items-center">
                <input id="isActive" name="isActive" type="checkbox" checked={formData.isActive} onChange={handleChange} className="h-4 w-4 rounded border-gray-300 text-brand-gold focus:ring-brand-gold" />
                <label htmlFor="isActive" className="ml-3 block text-sm font-medium text-gray-700">Card is Active</label>
            </div>
          </div>
          <div className="p-6 bg-gray-50 rounded-b-lg flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={close}>Cancel</Button>
            <Button type="submit">Save Card</Button>
          </div>
        </form>
        <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 transition-colors z-10" aria-label="Close modal">
          <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default GiftCardEditModal;