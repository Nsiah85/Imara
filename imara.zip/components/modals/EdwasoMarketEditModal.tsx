

import React, { useState, useEffect, useCallback } from 'react';
import type { EdwasoMarket } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { XIcon } from '../icons/Icons.tsx';
import { countries } from '../../utils/currency.ts';

interface EdwasoMarketEditModalProps {
  market: Partial<EdwasoMarket> | null;
  onClose: () => void;
  onSave: (market: EdwasoMarket) => void;
}

const EdwasoMarketEditModal: React.FC<EdwasoMarketEditModalProps> = ({ market, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    name: market?.name || '',
    country: market?.country || '',
    region: market?.region || '',
  });
  const [isClosing, setIsClosing] = useState(false);

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name.trim() && formData.country && formData.region) {
        const finalMarket: EdwasoMarket = {
            id: market?.id || crypto.randomUUID(),
            name: formData.name.trim(),
            country: formData.country,
            region: formData.region.trim(),
        };
        onSave(finalMarket);
    }
  };

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';
  const inputClass = "mt-1 block w-full bg-brand-navy-dark text-white border border-brand-emerald rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent placeholder:text-gray-400";
  const selectClass = `${inputClass} appearance-none`;

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close} role="dialog" aria-modal="true" aria-labelledby="edit-market-title"
    >
      <div
        className={`relative bg-white rounded-lg shadow-xl w-full max-w-lg transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b">
          <h2 id="edit-market-title" className="text-xl font-display font-semibold text-brand-navy-dark">
            {market?.id ? 'Edit' : 'Add'} Edwaso Market
          </h2>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-8 space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">Market Name</label>
              <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className={inputClass} autoFocus />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="country" className="block text-sm font-medium text-gray-700">Country</label>
                    <select name="country" id="country" value={formData.country} onChange={handleChange} required className={selectClass}>
                        <option value="" disabled>Select a country</option>
                        {countries.map(c => <option key={c.code} value={c.name}>{c.name}</option>)}
                    </select>
                </div>
                 <div>
                    <label htmlFor="region" className="block text-sm font-medium text-gray-700">Region / State</label>
                    <input type="text" name="region" id="region" value={formData.region} onChange={handleChange} required className={inputClass} placeholder="e.g., Ashanti, Lagos" />
                </div>
            </div>
          </div>
          <div className="p-6 bg-gray-50 rounded-b-lg flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={close}>Cancel</Button>
            <Button type="submit">Save Market</Button>
          </div>
        </form>
        <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 transition-colors z-10" aria-label="Close modal">
          <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default EdwasoMarketEditModal;