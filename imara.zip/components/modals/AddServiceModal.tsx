import React, { useState, useEffect, useCallback } from 'react';
import type { TravelService, ServiceType } from '../../types';
import Button from '../ui/Button';
import { XIcon } from '../icons/Icons';

interface AddServiceModalProps {
  onClose: () => void;
  onAddService: (serviceData: Omit<TravelService, 'id' | 'providerName' | 'rating'>) => void;
  allowedServices: ServiceType[];
}

type FormData = Omit<TravelService, 'id' | 'providerName' | 'rating'>;

const validateImage = (file: File): Promise<void> => {
    return new Promise((resolve, reject) => {
        const MIN_WIDTH = 400;
        const MIN_HEIGHT = 300;
        const MIN_SIZE_KB = 10;
        const MAX_SIZE_MB = 50; // Increased to 50MB

        if (file.size < MIN_SIZE_KB * 1024) {
            return reject(`Image is too small (min ${MIN_SIZE_KB}KB).`);
        }
        if (file.size > MAX_SIZE_MB * 1024 * 1024) {
            return reject(`Image is too large (max ${MAX_SIZE_MB}MB).`);
        }
        const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
        if (!allowedTypes.includes(file.type)) {
            return reject('Invalid file type (JPG, PNG, WEBP only).');
        }

        const img = new Image();
        img.src = URL.createObjectURL(file);
        img.onload = () => {
            if (img.width < MIN_WIDTH || img.height < MIN_HEIGHT) {
                reject(`Image is too small (min ${MIN_WIDTH}x${MIN_HEIGHT}px).`);
            } else {
                resolve();
            }
        };
        img.onerror = () => reject('Could not read image file.');
    });
};

const AddServiceModal: React.FC<AddServiceModalProps> = ({ onClose, onAddService, allowedServices }) => {
  const [formData, setFormData] = useState<FormData>({
    title: '',
    type: allowedServices[0],
    location: '',
    price: 0,
    priceUnit: 'ticket',
    imageUrl: '',
    description: '',
  });
  const [isClosing, setIsClosing] = useState(false);
  const [fileError, setFileError] = useState('');

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'price' ? parseFloat(value) : value }));
  };

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
          const file = e.target.files[0];
          try {
              await validateImage(file);
              setFileError('');
              setSelectedFile(file);
              setFormData(prev => ({ ...prev, imageUrl: URL.createObjectURL(file) }));
          } catch (error) {
              const errorMessage = error instanceof Error ? error.message : String(error);
              setFileError(errorMessage);
              e.target.value = '';
          }
      }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (fileError) return;
    
    setIsSubmitting(true);
    let finalData = { ...formData };
    
    if (selectedFile) {
        try {
            const { uploadFile } = await import('../../firebase/storage.ts');
            const url = await uploadFile(selectedFile, `services/${Date.now()}`);
            finalData.imageUrl = url;
        } catch (err) {
            console.error("Failed to upload service image", err);
        }
    }

    onAddService(finalData);
    setIsSubmitting(false);
  };

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';
  const inputClass = "mt-1 block w-full bg-brand-green-dark text-brand-gold-light border border-brand-green rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent placeholder:text-gray-400";
  const selectClass = `${inputClass} appearance-none`;
  const fileInputClass = `${inputClass} file:mr-4 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-brand-gold file:text-brand-green-dark hover:file:bg-brand-gold-light cursor-pointer ${fileError ? '!border-red-500 !focus:ring-red-500' : ''}`;

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close} role="dialog" aria-modal="true" aria-labelledby="add-service-title"
    >
      <div
        className={`relative bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b">
          <h2 id="add-service-title" className="text-xl font-display font-semibold text-brand-green-dark">Add New Service</h2>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-8 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="title" className="block text-sm font-medium text-gray-700">Service Title</label>
                    <input type="text" name="title" id="title" value={formData.title} onChange={handleChange} required className={inputClass} placeholder="e.g., Accra to Lagos Flight" />
                </div>
                 <div>
                    <label htmlFor="type" className="block text-sm font-medium text-gray-700">Service Type</label>
                    <select name="type" id="type" value={formData.type} onChange={handleChange} required className={selectClass}>
                        {allowedServices.map(st => <option key={st} value={st}>{st}</option>)}
                    </select>
                </div>
            </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="price" className="block text-sm font-medium text-gray-700">Price (USD)</label>
                    <input type="number" name="price" id="price" value={formData.price || ''} onChange={handleChange} required className={inputClass} step="0.01" min="0" />
                </div>
                <div>
                    <label htmlFor="priceUnit" className="block text-sm font-medium text-gray-700">Price Unit</label>
                     <select name="priceUnit" id="priceUnit" value={formData.priceUnit} onChange={handleChange} required className={selectClass}>
                        <option value="ticket">per ticket</option>
                        <option value="night">per night</option>
                        <option value="ride">per ride</option>
                        <option value="person">per person</option>
                    </select>
                </div>
            </div>
            <div>
                <label htmlFor="location" className="block text-sm font-medium text-gray-700">Location</label>
                <input type="text" name="location" id="location" value={formData.location} onChange={handleChange} required className={inputClass} placeholder="e.g., Lagos, Nigeria" />
            </div>
             <div>
                <label htmlFor="imageUrl" className="block text-sm font-medium text-gray-700">Service Image</label>
                <input type="file" name="imageUrl" id="imageUrl" onChange={handleFileChange} required className={fileInputClass} accept="image/*" />
                {fileError && <p className="mt-1 text-xs text-red-500">{fileError}</p>}
            </div>
             <div>
                <label htmlFor="description" className="block text-sm font-medium text-gray-700">Description</label>
                <textarea name="description" id="description" rows={4} value={formData.description} onChange={handleChange} required className={inputClass}></textarea>
            </div>
          </div>
          <div className="p-6 bg-gray-50 rounded-b-lg flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={close}>Cancel</Button>
            <Button type="submit" disabled={!!fileError || isSubmitting}>
              {isSubmitting ? 'Uploading...' : 'Add Service'}
            </Button>
          </div>
        </form>
        <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 transition-colors z-10" aria-label="Close add service modal">
          <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default AddServiceModal;