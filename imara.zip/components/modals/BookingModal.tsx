
import React, { useState, useEffect, useCallback } from 'react';
import type { TravelService, Booking } from '../../types.ts';
import { ServiceType } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { XIcon, CheckCircleIcon } from '../icons/Icons.tsx';
import { useAuth } from '../../contexts/AuthContext.tsx';
import { generateTransactionId } from '../../utils/transaction.ts';

interface BookingModalProps {
  service: TravelService;
  onClose: () => void;
}

const BookingModal: React.FC<BookingModalProps> = ({ service, onClose }) => {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    startDate: '',
    endDate: '',
    destination: '',
    guests: 1,
    requests: '',
  });
  const [isClosing, setIsClosing] = useState(false);
  const [isBooked, setIsBooked] = useState(false);
  const [error, setError] = useState('');
  const [generatedBookingId, setGeneratedBookingId] = useState('');

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'guests' ? parseInt(value) : value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
        setError("You must be logged in to make a booking.");
        return;
    }
    
    // Generate ID
    try {
        const storedBookings = localStorage.getItem('imara_bookings') || '[]';
        const bookings = JSON.parse(storedBookings);
        
        const id = generateTransactionId(service.providerName, bookings.length + 1, 'booking');
        setGeneratedBookingId(id);

        const newBooking: Booking = {
            id: id, // Use the formatted ID
            userId: user.id,
            serviceId: service.id,
            serviceTitle: service.title,
            serviceType: service.type,
            providerName: service.providerName,
            bookingDate: new Date().toISOString(),
            startDate: formData.startDate,
            endDate: formData.endDate,
            destination: formData.destination,
            guests: formData.guests,
            requests: formData.requests,
            rated: false,
            status: 'confirmed',
        };
        
        bookings.push(newBooking);
        localStorage.setItem('imara_bookings', JSON.stringify(bookings));
        setIsBooked(true);
        setError('');
    } catch (error) {
        console.error("Failed to save booking:", error);
        setError("There was an error saving your booking. Please try again.");
    }
  };

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';
  const inputClass = "mt-1 block w-full bg-brand-navy-dark text-brand-gold-light border border-brand-emerald rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent placeholder:text-gray-400";
  
  const showDateRange = service.type === ServiceType.HOTEL || service.type === ServiceType.RESORT;
  const showDestination = service.type === ServiceType.FLIGHT || service.type === ServiceType.RIDE;

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close} role="dialog" aria-modal="true" aria-labelledby="booking-title"
    >
      <div
        className={`relative bg-white rounded-lg shadow-xl w-full max-w-lg transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b flex items-start gap-4">
          <img src={service.imageUrl} alt={service.title} className="w-20 h-20 rounded-md object-cover"/>
          <div>
            <p className="text-xs uppercase tracking-wider text-brand-gray">{service.type}</p>
            <h2 id="booking-title" className="text-xl font-display font-semibold text-brand-navy-dark">{service.title}</h2>
            <p className="text-sm text-gray-500">by {service.providerName}</p>
          </div>
        </div>

        {isBooked ? (
             <div className="p-8 text-center">
                <CheckCircleIcon className="w-16 h-16 text-brand-gold mx-auto" />
                <h3 className="text-2xl font-display font-bold text-brand-navy-dark mt-4">Booking Confirmed!</h3>
                <p className="text-lg font-mono font-bold text-brand-green-dark mt-2">{generatedBookingId}</p>
                <p className="mt-2 text-gray-600">Your request has been sent to {service.providerName}. They will contact you shortly to finalize the details.</p>
                <Button onClick={close} className="mt-6">Close</Button>
            </div>
        ) : (
             <form onSubmit={handleSubmit}>
                <div className="p-8 space-y-6">
                    {showDateRange ? (
                         <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="startDate" className="block text-sm font-medium text-gray-700">Check-in</label>
                                <input type="date" name="startDate" id="startDate" value={formData.startDate} onChange={handleChange} required className={inputClass} />
                            </div>
                            <div>
                                <label htmlFor="endDate" className="block text-sm font-medium text-gray-700">Check-out</label>
                                <input type="date" name="endDate" id="endDate" value={formData.endDate} onChange={handleChange} required className={inputClass} />
                            </div>
                        </div>
                    ) : (
                         <div>
                            <label htmlFor="startDate" className="block text-sm font-medium text-gray-700">Date</label>
                            <input type="date" name="startDate" id="startDate" value={formData.startDate} onChange={handleChange} required className={inputClass} />
                        </div>
                    )}

                    {showDestination && (
                         <div>
                            <label htmlFor="destination" className="block text-sm font-medium text-gray-700">Destination</label>
                            <input type="text" name="destination" id="destination" value={formData.destination} onChange={handleChange} required className={inputClass} placeholder="e.g., Kotoka International Airport" />
                        </div>
                    )}

                    <div>
                        <label htmlFor="guests" className="block text-sm font-medium text-gray-700">Guests / People</label>
                        <input type="number" name="guests" id="guests" value={formData.guests} onChange={handleChange} required className={inputClass} min="1" />
                    </div>

                    <div>
                        <label htmlFor="requests" className="block text-sm font-medium text-gray-700">Specific Requests</label>
                        <textarea name="requests" id="requests" rows={3} value={formData.requests} onChange={handleChange} className={inputClass} placeholder="e.g., Window seat, dietary restrictions..."></textarea>
                    </div>
                    {error && <p className="text-sm text-red-600">{error}</p>}
                </div>
                <div className="p-6 bg-gray-50 rounded-b-lg flex justify-end gap-4">
                    <Button type="button" variant="outline" onClick={close}>Cancel</Button>
                    <Button type="submit">Confirm Booking</Button>
                </div>
            </form>
        )}
       
        <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 transition-colors z-10" aria-label="Close booking modal">
          <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default BookingModal;
