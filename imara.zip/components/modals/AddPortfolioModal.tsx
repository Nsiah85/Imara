

import React, { useState, useEffect, useCallback } from 'react';
import Button from '../ui/Button.tsx';
import { XIcon, ArrowUpTrayIcon } from '../icons/Icons.tsx';

interface AddPortfolioModalProps {
  onClose: () => void;
  onAddItems: (items: { url: string; type: 'image' | 'video' }[]) => void;
}

interface FilePreview {
    url: string;
    type: 'image' | 'video';
    name: string;
}

const validateMedia = (file: File): Promise<void> => {
    return new Promise((resolve, reject) => {
        const MIN_SIZE_KB = 10;
        const PHOTO_MAX_SIZE_MB = 10;
        const VIDEO_MAX_SIZE_MB = 50;
        
        const isImage = file.type.startsWith('image/');
        const isVideo = file.type.startsWith('video/');

        if (!isImage && !isVideo) {
            return reject('Invalid file type. Please upload images or videos.');
        }

        const maxSize = isImage ? PHOTO_MAX_SIZE_MB : VIDEO_MAX_SIZE_MB;

        if (file.size < MIN_SIZE_KB * 1024) {
            return reject(`File is too small (min ${MIN_SIZE_KB}KB).`);
        }
        if (file.size > maxSize * 1024 * 1024) {
            return reject(`File is too large (max ${maxSize}MB).`);
        }
        
        if (isImage) {
            const img = new Image();
            img.src = URL.createObjectURL(file);
            img.onload = () => {
                if (img.width < 400 || img.height < 300) {
                    reject(`Image dimensions are too small (min 400x300px).`);
                } else {
                    resolve();
                }
            };
            img.onerror = () => reject('Could not read image file.');
        } else {
            // Basic validation for video, more complex checks (duration, etc.) need a library
            resolve();
        }
    });
};

const AddPortfolioModal: React.FC<AddPortfolioModalProps> = ({ onClose, onAddItems }) => {
  const [previews, setPreviews] = useState<FilePreview[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isClosing, setIsClosing] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);
  
  const handleFiles = async (files: FileList) => {
    setError(null);
    const newPreviews: FilePreview[] = [];
    for (const file of Array.from(files)) {
        try {
            await validateMedia(file);
            const type = file.type.startsWith('image/') ? 'image' : 'video';
            newPreviews.push({ url: URL.createObjectURL(file), type, name: file.name });
        } catch (validationError) {
            const errorMessage = validationError instanceof Error ? validationError.message : String(validationError);
            setError(errorMessage);
            return; // Stop processing on first error
        }
    }
    setPreviews(prev => [...prev, ...newPreviews]);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) handleFiles(e.target.files);
  };
  
  const handleDragEvents = (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      e.stopPropagation();
      if (e.type === "dragenter" || e.type === "dragover") {
          setIsDragging(true);
      } else if (e.type === "dragleave") {
          setIsDragging(false);
      }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      e.stopPropagation();
      setIsDragging(false);
      if (e.dataTransfer.files) handleFiles(e.dataTransfer.files);
  };

  const removePreview = (urlToRemove: string) => {
      setPreviews(prev => prev.filter(p => p.url !== urlToRemove));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (previews.length > 0) {
      onAddItems(previews);
    }
  };

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close} role="dialog" aria-modal="true" aria-labelledby="portfolio-title"
    >
      <div
        className={`relative bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b dark:border-gray-700">
          <h2 id="portfolio-title" className="text-xl font-display font-semibold text-brand-green-dark dark:text-white">Add to Portfolio</h2>
        </div>
        <form onSubmit={handleSubmit} className="flex flex-col flex-grow">
          <div className="p-8 space-y-6 overflow-y-auto">
            <div
                onDragEnter={handleDragEvents}
                onDragLeave={handleDragEvents}
                onDragOver={handleDragEvents}
                onDrop={handleDrop}
                className={`p-6 border-2 border-dashed rounded-md text-center transition-colors ${isDragging ? 'border-brand-gold bg-brand-gold/10' : 'border-gray-300'}`}
            >
                <ArrowUpTrayIcon className="w-10 h-10 mx-auto text-gray-400" />
                <label htmlFor="file-upload" className="mt-2 block text-sm font-medium text-brand-green hover:text-brand-gold cursor-pointer">
                    Click to upload or drag and drop
                </label>
                <input id="file-upload" name="file-upload" type="file" multiple onChange={handleFileChange} className="sr-only" accept="image/*,video/*" />
                <p className="mt-1 text-xs text-gray-500">Images (max 10MB) or short videos (max 50MB)</p>
            </div>

            {error && <p className="text-sm text-red-600 text-center">{error}</p>}

            {previews.length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                    {previews.map(preview => (
                        <div key={preview.url} className="relative group">
                            {preview.type === 'image' ? (
                                <img src={preview.url} alt={preview.name} className="w-full h-full aspect-square object-cover rounded-md" />
                            ) : (
                                <video src={preview.url} className="w-full h-full aspect-square object-cover rounded-md" />
                            )}
                            <button
                                type="button"
                                onClick={() => removePreview(preview.url)}
                                className="absolute top-1 right-1 p-1 bg-black/50 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                                aria-label="Remove item"
                            >
                                <XIcon className="w-4 h-4" />
                            </button>
                        </div>
                    ))}
                </div>
            )}
          </div>
          <div className="p-6 bg-gray-50 dark:bg-gray-700/50 rounded-b-lg flex justify-end gap-4 mt-auto">
            <Button type="button" variant="outline" onClick={close}>Cancel</Button>
            <Button type="submit" disabled={previews.length === 0}>Add {previews.length} Item(s)</Button>
          </div>
        </form>
        <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 dark:hover:text-white transition-colors z-10" aria-label="Close portfolio modal">
          <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default AddPortfolioModal;