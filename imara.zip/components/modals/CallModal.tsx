import React, { useState, useEffect, useCallback } from 'react';
import type { Participant } from '../../types';
import Button from '../ui/Button';
import { XIcon, PhoneIcon, MicrophoneIcon, VideoCameraIcon } from '../icons/Icons';
import Badge from '../ui/Badge';
import Avatar from '../ui/Avatar';

interface CallModalProps {
  participant: Participant;
  callType: 'voice' | 'video';
  onClose: () => void;
}

const CallModal: React.FC<CallModalProps> = ({ participant, callType, onClose }) => {
    const [isClosing, setIsClosing] = useState(false);
    const [callStatus, setCallStatus] = useState<'ringing' | 'connected'>('ringing');
    const [callDuration, setCallDuration] = useState(0);
    const [isMuted, setIsMuted] = useState(false);
    const [isCameraOff, setIsCameraOff] = useState(false);

    const close = useCallback(() => {
        setIsClosing(true);
        setTimeout(onClose, 300);
    }, [onClose]);

    useEffect(() => {
        // Simulate call connection
        const ringTimer = setTimeout(() => {
            setCallStatus('connected');
        }, 3000);

        return () => clearTimeout(ringTimer);
    }, []);

    useEffect(() => {
        let interval: number | null = null;
        if (callStatus === 'connected') {
            interval = window.setInterval(() => {
                setCallDuration(prev => prev + 1);
            }, 1000);
        }
        return () => {
            if (interval) clearInterval(interval);
        };
    }, [callStatus]);

    const formatDuration = (seconds: number) => {
        const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
        const secs = (seconds % 60).toString().padStart(2, '0');
        return `${mins}:${secs}`;
    };

    const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
    const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';

    return (
        <div
            className={`fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
            role="dialog"
            aria-modal="true"
        >
            <div
                className={`relative bg-brand-navy-dark text-white rounded-lg shadow-xl w-full max-w-sm transition-all duration-300 ${modalAnimation} overflow-hidden`}
                style={{ backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.05) 1px, transparent 1px)', backgroundSize: '20px 20px' }}
            >
                <div className="p-8 flex flex-col items-center justify-center">
                    <Avatar 
                        imageUrl={participant.avatarUrl}
                        name={participant.name}
                        id={participant.id}
                        className="w-32 h-32 rounded-full object-cover border-4 border-white/20"
                        textClassName="text-5xl font-bold text-white"
                    />
                    <h2 className="mt-4 text-3xl font-display font-bold">{participant.name}</h2>
                    <p className="mt-2 text-lg text-brand-gold">
                        {callStatus === 'ringing' ? 'Ringing...' : formatDuration(callDuration)}
                    </p>
                    
                    {callStatus === 'connected' && (
                        <Badge className="mt-3 bg-green-500/20 text-green-300 border border-green-400 text-xs">HD Quality</Badge>
                    )}

                    <div className="mt-12 flex items-center justify-center gap-6">
                        <button 
                            onClick={() => setIsMuted(p => !p)}
                            className={`w-16 h-16 rounded-full flex items-center justify-center transition-colors ${isMuted ? 'bg-white text-brand-navy-dark' : 'bg-white/20 hover:bg-white/30'}`}
                            aria-label={isMuted ? "Unmute" : "Mute"}
                        >
                            <MicrophoneIcon className="w-8 h-8" />
                        </button>

                        <button 
                            onClick={close}
                            className="w-20 h-20 rounded-full flex items-center justify-center bg-red-600 hover:bg-red-700 transform hover:scale-105 transition-transform"
                            aria-label="End call"
                        >
                            <PhoneIcon className="w-10 h-10 transform rotate-[135deg]" />
                        </button>
                        
                        {callType === 'video' && (
                             <button 
                                onClick={() => setIsCameraOff(p => !p)}
                                className={`w-16 h-16 rounded-full flex items-center justify-center transition-colors ${isCameraOff ? 'bg-white text-brand-navy-dark' : 'bg-white/20 hover:bg-white/30'}`}
                                aria-label={isCameraOff ? "Turn camera on" : "Turn camera off"}
                            >
                                <VideoCameraIcon className="w-8 h-8" />
                            </button>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CallModal;