
import React, { useState, useEffect, useCallback } from 'react';
import type { Vendor, TravelPartner } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { XIcon, LinkIcon } from '../icons/Icons.tsx';
import { countries } from '../../utils/currency.ts';

interface EditVendorModalProps {
  vendor: Vendor | TravelPartner;
  onClose: () => void;
  onSave: (vendor: Vendor | TravelPartner) => void;
}

const EditVendorModal: React.FC<EditVendorModalProps> = ({ vendor, onClose, onSave }) => {
  const [formData, setFormData] = useState<Vendor | TravelPartner>(vendor);
  const [isClosing, setIsClosing] = useState(false);

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSlugChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      // Ensure slug is URL safe: lowercase, replace spaces with hyphens, remove special chars
      const val = e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '-');
      setFormData(prev => ({ ...prev, storeSlug: val }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
          const file = e.target.files[0];
          setFormData(prev => ({ ...prev, brandLogoUrl: URL.createObjectURL(file) }));
      }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';
  const inputClass = "mt-1 block w-full bg-brand-green-dark text-white border border-brand-green rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent placeholder:text-gray-400";
  const selectClass = `${inputClass} appearance-none`;
  const fileInputClass = `${inputClass} file:mr-4 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-brand-gold file:text-brand-green-dark hover:file:bg-brand-gold-light cursor-pointer`;

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close} role="dialog" aria-modal="true" aria-labelledby="edit-vendor-title"
    >
      <div
        className={`relative bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b">
          <h2 id="edit-vendor-title" className="text-xl font-display font-semibold text-brand-green-dark">Edit Partner Details</h2>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-8 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {formData.role === 'vendor' && (
                  <div>
                      <label htmlFor="fullName" className="block text-sm font-medium text-gray-700">Full Name</label>
                      <input type="text" name="fullName" id="fullName" value={(formData as Vendor).fullName} onChange={handleChange} required className={inputClass} />
                  </div>
                )}
                <div>
                    <label htmlFor="brandName" className="block text-sm font-medium text-gray-700">Brand Name</label>
                    <input type="text" name="brandName" id="brandName" value={formData.brandName} onChange={handleChange} required className={inputClass} />
                </div>
            </div>

            {/* Custom URL Slug Field */}
            <div>
                <label htmlFor="storeSlug" className="block text-sm font-medium text-gray-700 flex items-center gap-1">
                   <LinkIcon className="w-4 h-4 text-brand-gold"/> Custom Store Link
                </label>
                <div className="mt-1 flex rounded-md shadow-sm">
                    <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-brand-green bg-brand-green-dark text-gray-300 text-sm">
                        imara.app/{formData.role === 'vendor' ? 'vendor' : 'travel'}/
                    </span>
                    <input 
                        type="text" 
                        name="storeSlug" 
                        id="storeSlug" 
                        value={formData.storeSlug} 
                        onChange={handleSlugChange} 
                        required 
                        className={`block w-full min-w-0 flex-1 rounded-none rounded-r-md border border-brand-green bg-brand-green-dark text-white px-3 py-2 focus:ring-brand-gold focus:border-brand-gold sm:text-sm`} 
                    />
                </div>
                <p className="mt-1 text-xs text-gray-500">This is your unique web address. Keep it short and memorable.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email Address</label>
                    <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} required className={inputClass} />
                </div>
                 <div>
                    <label htmlFor="country" className="block text-sm font-medium text-gray-700">Country</label>
                    <select name="country" id="country" value={formData.country} onChange={handleChange} required className={selectClass}>
                        {countries.map(c => <option key={c.code} value={c.name}>{c.name}</option>)}
                    </select>
                </div>
            </div>
             <div>
                <label htmlFor="brandLogoUrl" className="block text-sm font-medium text-gray-700">Brand Logo</label>
                <input type="file" name="brandLogoUrl" id="brandLogoUrl" onChange={handleFileChange} className={fileInputClass} accept="image/*" />
                {formData.brandLogoUrl && <img src={formData.brandLogoUrl} alt="Logo Preview" className="mt-4 rounded-md max-h-24"/>}
            </div>
             {formData.role === 'vendor' && (
                <div>
                  <label htmlFor="story" className="block text-sm font-medium text-gray-700">Brand Story</label>
                  <textarea name="story" id="story" rows={4} value={(formData as Vendor).story} onChange={handleChange} required className={inputClass}></textarea>
                </div>
             )}
          </div>
          <div className="p-6 bg-gray-50 rounded-b-lg flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={close}>Cancel</Button>
            <Button type="submit">Save Changes</Button>
          </div>
        </form>
        <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 transition-colors z-10" aria-label="Close modal">
          <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default EditVendorModal;
