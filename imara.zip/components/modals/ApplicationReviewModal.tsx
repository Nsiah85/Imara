

import React, { useState, useEffect, useCallback } from 'react';
import type { PartnerApplication, EdwasoMarket } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { XIcon } from '../icons/Icons.tsx';
import { mockEdwasoMarkets } from '../../data/mockData.ts';

interface ApplicationReviewModalProps {
  application: PartnerApplication;
  onClose: () => void;
  onApprove: () => void;
  onReject: () => void;
}

const DetailItem: React.FC<{ label: string; value?: string | React.ReactNode }> = ({ label, value }) => {
    if (!value) return null;
    return (
        <div>
            <p className="text-sm font-medium text-gray-500">{label}</p>
            <div className="text-brand-navy-dark font-semibold">{value}</div>
        </div>
    );
};


const ApplicationReviewModal: React.FC<ApplicationReviewModalProps> = ({ application, onClose, onApprove, onReject }) => {
  const [isClosing, setIsClosing] = useState(false);
  const [marketName, setMarketName] = useState('');

  useEffect(() => {
    if (application.marketId) {
        try {
            const storedMarkets = localStorage.getItem('edwaso_markets');
            const markets: EdwasoMarket[] = storedMarkets ? JSON.parse(storedMarkets) : mockEdwasoMarkets;
            const market = markets.find(m => m.id === application.marketId);
            if (market) {
                setMarketName(market.name);
            }
        } catch (e) {
            console.error(e);
        }
    }
  }, [application.marketId]);

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close} role="dialog" aria-modal="true" aria-labelledby="review-title"
    >
      <div
        className={`relative bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b">
          <h2 id="review-title" className="text-xl font-display font-semibold text-brand-navy-dark">Review Application</h2>
          <p className="text-sm text-gray-500">Applicant: {application.fullName} ({application.role})</p>
        </div>
        <div className="p-8 space-y-6 overflow-y-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <DetailItem label="Full Name" value={application.fullName} />
                <DetailItem label="Email Address" value={application.email} />
                <DetailItem label="Country" value={application.country} />
                <DetailItem label="Role" value={application.role} />
                {application.role === 'vendor' && (
                  <DetailItem label="Vendor Type" value={application.vendorType} />
                )}
                 {application.vendorType && ['Market Woman', 'Farmer'].includes(application.vendorType) && (
                    <DetailItem label="Primary Market" value={marketName} />
                )}
                {(application.role === 'vendor' || application.role === 'travel') && (
                    <DetailItem label="Brand Name" value={application.brandName} />
                )}
                {application.role === 'workman' && (
                    <>
                        <DetailItem label="Industry" value={application.industry} />
                         <DetailItem label="Skills" value={application.skills} />
                    </>
                )}
                 {application.role === 'travel' && (
                    <DetailItem 
                        label="Service Types" 
                        value={
                            <div className="flex flex-wrap gap-2 mt-1">
                                {application.serviceTypes?.map(st => <span key={st} className="text-xs bg-gray-200 text-gray-800 px-2 py-1 rounded-full">{st}</span>)}
                            </div>
                        } 
                    />
                )}
            </div>
            {application.role === 'vendor' && application.story && (
                 <div>
                    <p className="text-sm font-medium text-gray-500">Brand Story</p>
                    <p className="text-brand-navy-dark font-semibold bg-gray-50 p-3 rounded-md mt-1">{application.story}</p>
                </div>
            )}
        </div>
        <div className="p-6 bg-gray-50 rounded-b-lg flex justify-between items-center mt-auto">
          <Button type="button" variant="outline" onClick={close}>Cancel</Button>
          <div className="flex gap-4">
            <Button type="button" className="bg-red-600 hover:bg-red-700 text-white" onClick={onReject}>Reject</Button>
            <Button type="button" onClick={onApprove}>Approve</Button>
          </div>
        </div>
        <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 transition-colors z-10" aria-label="Close modal">
          <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default ApplicationReviewModal;
