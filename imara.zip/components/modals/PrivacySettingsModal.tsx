
import React from 'react';
import { usePrivacy } from '../../contexts/PrivacyContext';
import { XIcon, TrashIcon, ArrowUpTrayIcon, ShieldCheckIcon, LockClosedIcon } from '../icons/Icons';
import Button from '../ui/Button';
import ToggleSwitch from '../ui/ToggleSwitch';

interface PrivacySettingsModalProps {
    onClose: () => void;
}

const PrivacySettingsModal: React.FC<PrivacySettingsModalProps> = ({ onClose }) => {
    const { syncSettings, updateSyncSettings, purgeLocalData, storageUsageMB, requestDataExport, consentData } = usePrivacy();

    return (
        <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white dark:bg-gray-800 w-full max-w-lg rounded-2xl shadow-xl overflow-hidden flex flex-col max-h-[90vh]">
                <div className="p-6 border-b dark:border-gray-700 flex justify-between items-center bg-gray-50 dark:bg-gray-900">
                    <h3 className="font-display font-bold text-xl text-brand-navy-dark dark:text-white flex items-center gap-2">
                        <ShieldCheckIcon className="w-6 h-6 text-brand-green"/> Data & Privacy
                    </h3>
                    <button onClick={onClose}><XIcon className="w-6 h-6 text-gray-500 hover:text-red-500"/></button>
                </div>

                <div className="p-6 space-y-8 overflow-y-auto flex-1">
                    
                    {/* Consent Info */}
                    <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-xl border border-blue-100 dark:border-blue-800">
                        <h4 className="font-bold text-blue-800 dark:text-blue-300 text-sm mb-2">Consent Record</h4>
                        <p className="text-xs text-blue-600 dark:text-blue-400">
                            Accepted Version: <span className="font-mono font-bold">{consentData?.policyVersion || '1.0'}</span><br/>
                            Date: {consentData?.acceptedAt ? new Date(consentData.acceptedAt).toLocaleDateString() : 'N/A'}
                        </p>
                    </div>

                    {/* Local Storage Control */}
                    <div>
                        <h4 className="font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                            <LockClosedIcon className="w-5 h-5 text-gray-500"/> Device Storage
                        </h4>
                        <div className="flex justify-between items-center mb-4">
                            <div>
                                <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Local Cache</p>
                                <p className="text-xs text-gray-500">Encrypted media on this device.</p>
                            </div>
                            <span className="font-mono text-sm font-bold text-brand-navy-dark dark:text-brand-gold">{storageUsageMB.toFixed(2)} MB</span>
                        </div>
                        <Button variant="outline" onClick={purgeLocalData} className="w-full !border-red-500 !text-red-500 hover:!bg-red-500 hover:!text-white flex items-center justify-center gap-2">
                            <TrashIcon className="w-4 h-4"/> Clear Local Data
                        </Button>
                    </div>

                    <div className="border-t dark:border-gray-700"></div>

                    {/* Sync Settings */}
                    <div>
                        <h4 className="font-bold text-gray-800 dark:text-white mb-4">Cloud Sync Preferences</h4>
                        <div className="space-y-4">
                            <div className="flex justify-between items-center">
                                <div>
                                    <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Sync Heavy Media</p>
                                    <p className="text-xs text-gray-500">Upload high-res images/videos to cloud.</p>
                                </div>
                                <ToggleSwitch 
                                    label="Sync Media" 
                                    enabled={syncSettings.syncMedia} 
                                    setEnabled={(val) => updateSyncSettings({...syncSettings, syncMedia: val})} 
                                />
                            </div>
                             <div className="flex justify-between items-center">
                                <div>
                                    <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Sync Chat History</p>
                                    <p className="text-xs text-gray-500">Back up encrypted chat logs.</p>
                                </div>
                                <ToggleSwitch 
                                    label="Sync Chats" 
                                    enabled={syncSettings.syncChats} 
                                    setEnabled={(val) => updateSyncSettings({...syncSettings, syncChats: val})} 
                                />
                            </div>
                        </div>
                    </div>

                    <div className="border-t dark:border-gray-700"></div>

                    {/* Export */}
                    <div>
                        <h4 className="font-bold text-gray-800 dark:text-white mb-4">Your Data Rights</h4>
                        <Button variant="secondary" onClick={requestDataExport} className="w-full flex items-center justify-center gap-2">
                            <ArrowUpTrayIcon className="w-4 h-4"/> Request Data Download
                        </Button>
                        <p className="text-[10px] text-gray-400 mt-2 text-center">
                            Includes interaction logs, order history, and account details in JSON format.
                        </p>
                    </div>

                </div>
            </div>
        </div>
    );
};

export default PrivacySettingsModal;
