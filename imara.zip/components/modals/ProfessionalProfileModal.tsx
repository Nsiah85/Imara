import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { GoogleGenAI } from '@google/genai';
import type { Professional } from '../../types';
import Button from '../ui/Button.tsx';
import Badge from '../ui/Badge.tsx';
import { XIcon, GlobeIcon, VerifiedIcon, BriefcaseIcon, DollarSignIcon, CalendarDaysIcon } from '../icons/Icons.tsx';
import SkeletonLoader from '../ui/SkeletonLoader.tsx';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';

interface ProfessionalProfileModalProps {
  professional: Professional;
  onClose: () => void;
}

const ProfessionalProfileModal: React.FC<ProfessionalProfileModalProps> = ({ professional, onClose }) => {
  const [isClosing, setIsClosing] = useState(false);
  const [bio, setBio] = useState<string>('');
  const [isBioLoading, setIsBioLoading] = useState(true);
  const { formatCurrency } = useCurrency();

  const getWageText = (wageRange: [number, number], wageType: string) => {
    const typeText = wageType === 'hourly' ? 'per hour' : wageType === 'daily' ? 'per day' : 'per project';
    const formattedRange = wageRange.map(w => formatCurrency(w, { minimumFractionDigits: 0 }));

    if (wageRange[0] === wageRange[1]) {
        return `${formattedRange[0]} ${typeText}`;
    }
    return `${formattedRange[0]} - ${formattedRange[1]} ${typeText}`;
  };

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300); // Wait for animation
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        close();
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);

  useEffect(() => {
    const generateBio = async () => {
      setIsBioLoading(true);
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const prompt = `Generate a short, professional, and engaging bio (2-3 sentences) for a professional profile. Here are the details:\nName: ${professional.name}\nRole: ${professional.role}\nIndustry: ${professional.industry}\nLocation: ${professional.location}\nSkills: ${professional.skills.join(', ')}\n\nFocus on their expertise and location. Write it in the first person, as if ${professional.name} is introducing themself.`;

        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt,
        });

        setBio(response.text);
      } catch (error) {
        console.error("Error generating bio:", error);
        setBio(`A dedicated ${professional.role} based in ${professional.location}, specializing in ${professional.skills.slice(0, 2).join(' and ')}.`); // Fallback bio
      } finally {
        setIsBioLoading(false);
      }
    };

    generateBio();
  }, [professional]);

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close}
      role="dialog"
      aria-modal="true"
      aria-labelledby="professional-profile-title"
    >
      <div
        className={`relative bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto flex flex-col transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Section */}
        <div className="p-8 bg-brand-off-white/80 rounded-t-lg">
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <img src={professional.profileImageUrl} alt={professional.name} className="w-32 h-32 rounded-full object-cover border-4 border-white shadow-md" />
            <div className="text-center sm:text-left">
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <h1 id="professional-profile-title" className="text-3xl font-display font-bold text-brand-green-dark">{professional.name}</h1>
                {professional.isVerified && <VerifiedIcon className="w-6 h-6 text-brand-green" />}
              </div>
              <p className="text-lg text-brand-green font-semibold">{professional.role}</p>
              <div className="flex items-center justify-center sm:justify-start gap-1.5 mt-2 text-sm text-gray-500">
                <GlobeIcon className="w-4 h-4" />
                <span>{professional.location}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Body Section */}
        <div className="p-8 flex-grow">
          <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-2">About</h2>
          {isBioLoading ? (
            <div className="space-y-2">
              <SkeletonLoader className="h-4 w-full" />
              <SkeletonLoader className="h-4 w-5/6" />
              <SkeletonLoader className="h-4 w-1/2" />
            </div>
          ) : (
            <p className="text-gray-700">{bio}</p>
          )}

          {professional.portfolioImageUrls && professional.portfolioImageUrls.length > 0 && (
            <div className="mt-6 pt-6 border-t">
                <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">Portfolio</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    {professional.portfolioImageUrls.map((url, index) => (
                        <a href={url} target="_blank" rel="noopener noreferrer" key={index} className="block rounded-lg overflow-hidden group shadow-sm">
                            <img src={url} alt={`${professional.name}'s portfolio item ${index + 1}`} className="w-full h-full object-cover aspect-square group-hover:scale-105 transition-transform duration-300"/>
                        </a>
                    ))}
                </div>
            </div>
          )}


          <div className="mt-6 pt-6 border-t grid grid-cols-2 gap-6">
             <div>
                <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">Industry</h2>
                <Badge className="bg-blue-100 text-blue-800" icon={<BriefcaseIcon className="w-3 h-3"/>}>
                    {professional.industry}
                </Badge>
             </div>
             <div>
                <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">Rate</h2>
                <Badge className="bg-green-100 text-green-800" icon={<DollarSignIcon className="w-4 h-4"/>}>
                    {getWageText(professional.wageRange, professional.wageType)}
                </Badge>
             </div>
          </div>


          <div className="mt-6">
            <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">Skills</h2>
            <div className="flex flex-wrap gap-2">
              {professional.skills.map(skill => (
                <Badge key={skill} className="bg-gray-200 text-gray-700">
                  {skill}
                </Badge>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 bg-gray-50 rounded-b-lg mt-auto">
          <Link to={`/messages/new?recipientId=${professional.id}&recipientName=${encodeURIComponent(professional.name)}&recipientRole=${encodeURIComponent(professional.role)}&recipientAvatar=${encodeURIComponent(professional.profileImageUrl)}`} className="w-full" onClick={close}>
            <Button size="lg" className="w-full flex items-center justify-center gap-2">
                <CalendarDaysIcon className="w-5 h-5" />
                Book Now
            </Button>
          </Link>
        </div>

        <button 
          onClick={close} 
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 transition-colors z-10 p-2 rounded-full bg-white/50 hover:bg-white"
          aria-label="Close profile view"
        >
          <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default ProfessionalProfileModal;
