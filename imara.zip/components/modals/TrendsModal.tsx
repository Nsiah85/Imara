
import React from 'react';
import { XIcon } from '../icons/Icons.tsx';
import TrendingGists from '../gist/TrendingGists.tsx';

interface TrendsModalProps {
  onClose: () => void;
  onTrendClick: (trend: string) => void;
  activeTrend: string | null;
}

const TrendsModal: React.FC<TrendsModalProps> = ({ onClose, onTrendClick, activeTrend }) => {
    const handleTrendSelect = (trend: string) => {
        onTrendClick(trend);
        onClose();
    };

    return (
        <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
            <div className="bg-white dark:bg-brand-navy-dark rounded-2xl shadow-xl w-full max-w-sm h-[70vh] overflow-hidden flex flex-col relative border-2 border-brand-gold" onClick={e => e.stopPropagation()}>
                <button onClick={onClose} className="absolute top-4 right-4 p-2 text-gray-500 hover:text-black dark:text-gray-400 dark:hover:text-white z-10">
                    <XIcon className="w-6 h-6" />
                </button>
                <div className="p-6 h-full">
                    <TrendingGists onTrendClick={handleTrendSelect} activeTrend={activeTrend} />
                </div>
            </div>
        </div>
    );
};

export default TrendsModal;
