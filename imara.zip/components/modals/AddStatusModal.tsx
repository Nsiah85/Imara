
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { XIcon, ArrowUpTrayIcon, MicrophoneIcon, PlayIcon, TrashIcon, MusicNoteIcon, CameraIcon, SparklesIcon, ChevronDownIcon, CheckIcon, SearchIcon, CheckCircleIcon } from '../icons/Icons';
import Button from '../ui/Button';
import { mockSounds } from '../../data/mockData';

interface AddStatusModalProps {
  onClose: () => void;
  onAddStatus: (item: { type: 'text', text: string, backgroundColor: string, gradient?: string, font: string, soundUrl?: string } | { type: 'media', file: File, soundUrl?: string }) => void;
}

const gradients = [
    { name: 'Midnight', value: 'linear-gradient(180deg, #0A2342 0%, #000000 100%)' },
    { name: 'Imara Gold', value: 'linear-gradient(45deg, #FFD700, #FF8C00)' },
    { name: 'Forest', value: 'linear-gradient(to bottom right, #00A550, #004d40)' },
    { name: 'Afro Punk', value: 'linear-gradient(to right, #ec4899, #8b5cf6)' },
    { name: 'Savanna', value: 'linear-gradient(120deg, #f6d365 0%, #fda085 100%)' },
    { name: 'Oceanic', value: 'linear-gradient(to top, #30cfd0 0%, #330867 100%)' },
    { name: 'Royal', value: 'linear-gradient(to top, #5f72bd 0%, #9b23ea 100%)' }
];

const fonts = ['Inter', 'Poppins', 'Lobster', 'Caveat', 'Playfair Display', 'Oswald', 'Pacifico'];

const templates = [
    { name: 'Motivation', text: 'Believe in your hustle. 💪 #MondayMotivation', bgIndex: 3 },
    { name: 'Culture', text: 'Celebrating our heritage today. 🌍✨', bgIndex: 2 },
    { name: 'Business', text: 'New stock alert! Check the shop. 🛍️', bgIndex: 1 },
    { name: 'Vibe', text: 'Current Mood 🎵', bgIndex: 5 }
];

const AddStatusModal: React.FC<AddStatusModalProps> = ({ onClose, onAddStatus }) => {
    const [mode, setMode] = useState<'media' | 'text'>('text');
    const [file, setFile] = useState<File | null>(null);
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);
    const [isClosing, setIsClosing] = useState(false);

    // Text Status State
    const [text, setText] = useState('');
    const [activeGradient, setActiveGradient] = useState(gradients[0].value);
    const [font, setFont] = useState(fonts[1]);
    const [showTemplates, setShowTemplates] = useState(false);

    // Sound State
    const [showSoundPicker, setShowSoundPicker] = useState(false);
    const [selectedSound, setSelectedSound] = useState<{id: string, title: string, url: string} | null>(null);
    
    const fileInputRef = useRef<HTMLInputElement>(null);

    const close = useCallback(() => {
        setIsClosing(true);
        setTimeout(onClose, 300);
    }, [onClose]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => { if (e.key === 'Escape') close(); };
        document.addEventListener('keydown', handleKeyDown);
        return () => document.removeEventListener('keydown', handleKeyDown);
    }, [close]);

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            setFile(file);
            setPreviewUrl(URL.createObjectURL(file));
            setMode('media');
        }
    };

    const handleTemplateSelect = (template: typeof templates[0]) => {
        setText(template.text);
        setActiveGradient(gradients[template.bgIndex].value);
        setShowTemplates(false);
    };

    const handleSubmit = () => {
        if (mode === 'media' && file) {
            onAddStatus({ type: 'media', file, soundUrl: selectedSound?.url });
        } else if (mode === 'text' && text.trim()) {
            onAddStatus({ type: 'text', text: text.trim(), backgroundColor: '#000', gradient: activeGradient, font, soundUrl: selectedSound?.url });
        }
        close();
    };

    const modalAnimation = isClosing ? 'translate-y-full opacity-0' : 'translate-y-0 opacity-100';

    return (
        <div className="fixed inset-0 z-[150] bg-black flex justify-center items-center overflow-hidden">
            {/* Mobile-First Container (Restricted Aspect Ratio) */}
            <div className={`relative w-full h-full md:w-[450px] md:h-[800px] md:max-h-[90vh] md:rounded-3xl bg-black overflow-hidden shadow-2xl transition-all duration-300 ${modalAnimation} flex flex-col`}>
                
                {/* Background Render */}
                <div 
                    className="absolute inset-0 z-0 transition-colors duration-500" 
                    style={{ background: mode === 'text' ? activeGradient : '#000' }}
                >
                    {mode === 'media' && previewUrl && (
                        file?.type.startsWith('video') 
                            ? <video src={previewUrl} className="w-full h-full object-cover" autoPlay loop muted />
                            : <img src={previewUrl} className="w-full h-full object-cover" alt="Preview" />
                    )}
                </div>

                {/* Header Controls */}
                <div className="relative z-10 flex justify-between items-start p-6 pt-8 md:pt-6">
                    <button onClick={close} className="p-2 bg-black/20 backdrop-blur-md rounded-full text-white hover:bg-white/20 transition-colors">
                        <XIcon className="w-6 h-6" />
                    </button>

                    {/* Top Actions Stack */}
                    <div className="flex flex-col gap-4">
                         <button 
                            onClick={() => setMode(mode === 'text' ? 'media' : 'text')} 
                            className="w-10 h-10 bg-black/20 backdrop-blur-md rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-colors"
                            title={mode === 'text' ? "Switch to Camera" : "Switch to Text"}
                        >
                            {mode === 'text' ? <CameraIcon className="w-6 h-6" /> : <span className="font-display font-bold text-lg">Aa</span>}
                        </button>
                        <button 
                            onClick={() => setShowSoundPicker(true)} 
                            className={`w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-md transition-colors ${selectedSound ? 'bg-brand-gold text-brand-navy-dark' : 'bg-black/20 text-white hover:bg-white/20'}`}
                        >
                            <MusicNoteIcon className="w-5 h-5" />
                        </button>
                        <button 
                            onClick={() => setShowTemplates(!showTemplates)} 
                            className={`w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-md transition-colors ${showTemplates ? 'bg-white text-black' : 'bg-black/20 text-white hover:bg-white/20'}`}
                            title="Templates"
                        >
                            <SparklesIcon className="w-5 h-5" />
                        </button>
                    </div>
                </div>

                {/* Main Content Input */}
                <div className="relative z-10 flex-1 flex items-center justify-center p-8">
                    {mode === 'text' ? (
                         <textarea 
                            value={text}
                            onChange={e => setText(e.target.value)}
                            placeholder="Type something..."
                            className="w-full h-full bg-transparent text-center text-4xl font-bold text-white placeholder:text-white/50 resize-none focus:outline-none"
                            style={{ fontFamily: font, textShadow: '0 2px 10px rgba(0,0,0,0.3)' }}
                            autoFocus
                        />
                    ) : (
                        !previewUrl && (
                            <div 
                                onClick={() => fileInputRef.current?.click()}
                                className="flex flex-col items-center justify-center p-8 border-2 border-dashed border-white/30 rounded-2xl cursor-pointer hover:bg-white/10 transition-colors"
                            >
                                <ArrowUpTrayIcon className="w-12 h-12 text-white mb-4" />
                                <p className="text-white font-bold">Upload Media</p>
                            </div>
                        )
                    )}
                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*,video/*" onChange={handleFileSelect} />
                </div>

                {/* Selected Sound Display (Visual Trim UI Mock) */}
                {selectedSound && (
                    <div className="relative z-10 px-6 pb-4">
                        <div className="bg-black/40 backdrop-blur-md rounded-xl p-3 flex items-center gap-3 border border-white/10">
                            <div className="w-8 h-8 bg-brand-gold rounded-full flex items-center justify-center text-brand-navy-dark">
                                <MusicNoteIcon className="w-4 h-4" />
                            </div>
                            <div className="flex-1 min-w-0">
                                <p className="text-white text-xs font-bold truncate">{selectedSound.title}</p>
                                <p className="text-white/70 text-[10px] truncate">{selectedSound.artist}</p>
                            </div>
                            <button onClick={() => setSelectedSound(null)} className="text-white/50 hover:text-white"><XIcon className="w-4 h-4"/></button>
                        </div>
                        {/* Visual Waveform / Trim UI */}
                        <div className="flex items-center gap-1 mt-2 h-6 px-2">
                             {Array.from({length: 20}).map((_, i) => (
                                 <div key={i} className={`flex-1 rounded-full bg-brand-gold/50 ${i > 5 && i < 15 ? 'bg-brand-gold h-full' : 'h-1/2'}`}></div>
                             ))}
                        </div>
                    </div>
                )}

                {/* Templates Overlay */}
                {showTemplates && mode === 'text' && (
                    <div className="relative z-20 px-6 pb-4 flex gap-3 overflow-x-auto scrollbar-hide">
                        {templates.map(t => (
                            <button key={t.name} onClick={() => handleTemplateSelect(t)} className="px-4 py-2 bg-white/20 backdrop-blur-md rounded-full text-white text-xs font-bold hover:bg-white/30 whitespace-nowrap border border-white/10">
                                {t.name}
                            </button>
                        ))}
                    </div>
                )}

                {/* Bottom Controls */}
                <div className="relative z-10 px-6 pb-8 md:pb-6 flex flex-col gap-6">
                    {/* Style Controls (Text Mode Only) */}
                    {mode === 'text' && (
                        <div className="space-y-4">
                             {/* Font Selector */}
                            <div className="flex gap-4 overflow-x-auto scrollbar-hide justify-center">
                                {fonts.map(f => (
                                    <button 
                                        key={f} 
                                        onClick={() => setFont(f)} 
                                        className={`w-8 h-8 rounded-full border flex items-center justify-center font-bold text-xs transition-all ${font === f ? 'bg-white text-black scale-110 border-white' : 'bg-black/40 text-white border-white/30'}`}
                                        style={{ fontFamily: f }}
                                    >
                                        Aa
                                    </button>
                                ))}
                            </div>
                             {/* Gradient Selector */}
                            <div className="flex gap-3 overflow-x-auto scrollbar-hide justify-center">
                                {gradients.map((g, i) => (
                                    <button 
                                        key={i} 
                                        onClick={() => setActiveGradient(g.value)}
                                        className={`w-6 h-6 rounded-full border-2 transition-all ${activeGradient === g.value ? 'border-white scale-125' : 'border-transparent opacity-70'}`}
                                        style={{ background: g.value }}
                                    />
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Post Button */}
                    <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2 bg-black/30 px-3 py-1 rounded-full">
                            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                            <span className="text-[10px] text-white font-bold uppercase tracking-wider">Your Story</span>
                        </div>
                        <Button 
                            onClick={handleSubmit} 
                            disabled={mode === 'text' && !text.trim()} 
                            className="!bg-brand-gold !text-brand-navy-dark rounded-full px-8 font-bold shadow-lg hover:scale-105 transition-transform disabled:opacity-50 disabled:hover:scale-100 flex items-center gap-2"
                        >
                            Share <ArrowUpTrayIcon className="w-4 h-4 transform rotate-90" />
                        </Button>
                    </div>
                </div>

                {/* Sound Picker Sheet */}
                {showSoundPicker && (
                    <div className="absolute inset-0 z-30 bg-gray-900/95 backdrop-blur-xl flex flex-col animate-slide-up">
                        <div className="p-4 flex items-center gap-3 border-b border-white/10">
                             <SearchIcon className="w-5 h-5 text-gray-400"/>
                             <input 
                                type="text" 
                                placeholder="Search global sounds..." 
                                onChange={(e) => {
                                    const value = e.target.value.toLowerCase();
                                    const items = document.querySelectorAll('.sound-item');
                                    items.forEach(item => {
                                        const text = item.textContent?.toLowerCase() || '';
                                        if (text.includes(value)) {
                                            (item as HTMLElement).style.display = 'flex';
                                        } else {
                                            (item as HTMLElement).style.display = 'none';
                                        }
                                    });
                                }}
                                className="bg-transparent text-white w-full outline-none placeholder:text-gray-500" 
                                autoFocus 
                             />
                             <button onClick={() => {
                                 setShowSoundPicker(false);
                                 document.querySelectorAll('audio').forEach(a => a.pause());
                             }} className="text-white font-bold text-sm">Cancel</button>
                        </div>
                        <div className="flex-1 overflow-y-auto p-2">
                             <div className="text-xs text-brand-gold font-bold px-3 py-2 uppercase tracking-wider bg-black/20 sticky top-0 backdrop-blur-md z-10 flex items-center gap-2">
                                 <SparklesIcon className="w-4 h-4"/> Viral Global Sounds
                             </div>
                            {mockSounds.map(sound => (
                                <div key={sound.id} className="sound-item flex items-center justify-between p-3 hover:bg-white/10 rounded-xl group transition-colors">
                                    <div className="flex items-center gap-4 flex-1 cursor-pointer" onClick={() => { 
                                        setSelectedSound(sound); 
                                        setShowSoundPicker(false); 
                                        document.querySelectorAll('audio').forEach(a => a.pause());
                                    }}>
                                        <div className="w-10 h-10 bg-brand-gold/20 rounded-lg flex items-center justify-center text-brand-gold relative overflow-hidden">
                                            <MusicNoteIcon className="w-5 h-5 absolute" />
                                        </div>
                                        <div className="flex-1">
                                            <p className="text-white font-bold text-sm truncate max-w-[200px]">{sound.title}</p>
                                            <p className="text-gray-400 text-xs truncate">{sound.artist}</p>
                                        </div>
                                    </div>
                                    <button 
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            const audioEl = document.getElementById(`audio-${sound.id}`) as HTMLAudioElement;
                                            if (audioEl) {
                                                if (audioEl.paused) {
                                                    document.querySelectorAll('audio').forEach(a => a.pause());
                                                    audioEl.play();
                                                } else {
                                                    audioEl.pause();
                                                }
                                            }
                                        }}
                                        className="w-8 h-8 rounded-full border border-white/20 flex items-center justify-center text-white hover:bg-white/20 hover:text-brand-gold transition-colors z-10"
                                    >
                                        <PlayIcon className="w-4 h-4" />
                                        <audio id={`audio-${sound.id}`} src={sound.url} loop={false} />
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

            </div>
        </div>
    );
};

export default AddStatusModal;
