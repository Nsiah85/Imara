import React, { useState, useEffect, useCallback } from 'react';
import type { Product, Review } from '../../types';
import { useAuth } from '../../contexts/AuthContext';
import Button from '../ui/Button.tsx';
import StarRating from '../reviews/StarRating.tsx';
import { XIcon } from '../icons/Icons.tsx';

interface ReviewModalProps {
  product: Product;
  onClose: () => void;
  onSubmit: (review: Review) => void;
}

const ReviewModal: React.FC<ReviewModalProps> = ({ product, onClose, onSubmit }) => {
  const { user } = useAuth();
  const [isClosing, setIsClosing] = useState(false);
  const [rating, setRating] = useState(0);
  const [title, setTitle] = useState('');
  const [comment, setComment] = useState('');
  const [error, setError] = useState('');

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (rating === 0) {
      setError('Please select a star rating.');
      return;
    }
    if (!title.trim() || !comment.trim()) {
      setError('Please provide a title and a comment for your review.');
      return;
    }
    if (!user) {
        setError('You must be logged in to submit a review.');
        return;
    }

    const newReview: Review = {
        id: crypto.randomUUID(),
        productId: product.id,
        vendorId: product.vendor, // Assuming product object has vendorId. Let's use vendor name for now.
        userId: user.id,
        userName: user.fullName,
        userAvatarUrl: user.profileImageUrl,
        rating,
        title,
        comment,
        createdAt: new Date().toISOString(),
        isVerifiedPurchase: true, // Assuming this modal is only opened for purchased items.
    };

    onSubmit(newReview);
    close();
  };

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';
  const inputClass = "mt-1 block w-full bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent";

  return (
    <div
      className={`fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close} role="dialog" aria-modal="true"
    >
      <div
        className={`relative bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-lg transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b dark:border-gray-700 flex items-start gap-4">
            <img src={product.imageUrl} alt={product.name} className="w-16 h-16 rounded-md object-cover"/>
            <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Write a review for</p>
                <h2 className="text-xl font-display font-semibold text-brand-navy-dark dark:text-white">{product.name}</h2>
            </div>
        </div>

        <form onSubmit={handleSubmit}>
            <div className="p-8 space-y-6">
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Your overall rating</label>
                    <StarRating rating={rating} setRating={setRating} iconClassName="w-8 h-8"/>
                </div>
                 <div>
                    <label htmlFor="title" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Review title</label>
                    <input type="text" name="title" id="title" value={title} onChange={e => setTitle(e.target.value)} required className={inputClass} />
                </div>
                <div>
                    <label htmlFor="comment" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Your review</label>
                    <textarea name="comment" id="comment" rows={5} value={comment} onChange={e => setComment(e.target.value)} required className={inputClass}></textarea>
                </div>
                {error && <p className="text-sm text-red-500">{error}</p>}
            </div>
            <div className="p-6 bg-gray-50 dark:bg-gray-700/50 rounded-b-lg flex justify-end gap-4">
                <Button type="button" variant="outline" onClick={close}>Cancel</Button>
                <Button type="submit">Submit Review</Button>
            </div>
        </form>

        <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 dark:hover:text-white" aria-label="Close review modal">
            <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default ReviewModal;
