
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { UserProfile } from '../../types';
import Button from '../ui/Button';
import { XIcon, CameraIcon, FacebookIcon, TwitterXIcon, InstagramIcon, TikTokIcon, LinkedInIcon, LinkIcon, PhotoIcon, UserIcon, Cog6ToothIcon, LockClosedIcon, ShieldCheckIcon } from '../icons/Icons';
import { countries } from '../../utils/currency';
import ToggleSwitch from '../ui/ToggleSwitch';
import Avatar from '../ui/Avatar';
import { useSecurity } from '../../contexts/SecurityContext';

interface ProfileEditModalProps {
  user: UserProfile;
  onClose: () => void;
  onSave: (updatedUser: UserProfile) => void;
}

type Tab = 'profile' | 'preferences' | 'security';

const ProfileEditModal: React.FC<ProfileEditModalProps> = ({ user, onClose, onSave }) => {
  const { verifyImageConsistency } = useSecurity();
  const [formData, setFormData] = useState<UserProfile>(user);
  const [activeTab, setActiveTab] = useState<Tab>('profile');
  const [isClosing, setIsClosing] = useState(false);
  const [imagePreview, setImagePreview] = useState(user.profileImageUrl);
  const [coverPreview, setCoverPreview] = useState(user.coverImageUrl);
  const [isVerifying, setIsVerifying] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        close();
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
         // Handle checkboxes if any
    } else {
        setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSettingChange = (key: keyof UserProfile, value: any) => {
      setFormData(prev => ({ ...prev, [key]: value }));
  };

  const handleSocialChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      socialMediaLinks: {
        ...prev.socialMediaLinks,
        [name]: value,
      },
    }));
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>, type: 'avatar' | 'cover') => {
      if (e.target.files && e.target.files[0]) {
          const file = e.target.files[0];
          
          // Security Check for Avatar
          if (type === 'avatar') {
              setIsVerifying(true);
              const { safe, reason } = await verifyImageConsistency(file, 'face');
              setIsVerifying(false);
              
              if (!safe) {
                  alert(`Image Rejected: ${reason}`);
                  return;
              }
          }

          try {
              // We should import uploadFile dynamically or at top level to use
              // Wait, we need to upload during handleSubmit or right away?
              // Standard is to upload right away, then update formData.
              const path = `users/${user.id}/${type}_${Date.now()}`;
              let downloadURL = '';
              try {
                  const { uploadFile } = await import('../../firebase/storage.ts');
                  downloadURL = await uploadFile(file, `users/${user.id}`);
              } catch (err) {
                  console.error("Upload error, using local URL", err);
                  downloadURL = URL.createObjectURL(file);
              }

              if (type === 'avatar') {
                  setFormData(prev => ({ ...prev, profileImageUrl: downloadURL }));
                  setImagePreview(downloadURL);
              } else {
                  setFormData(prev => ({ ...prev, coverImageUrl: downloadURL }));
                  setCoverPreview(downloadURL);
              }
          } catch(error) {
              console.error("Failed to process image", error);
          }
      }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 translate-y-full' : 'opacity-100 translate-y-0';
  const inputClass = "mt-1 block w-full bg-brand-navy-dark text-white border border-brand-green rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent placeholder:text-gray-400";
  const socialInputClass = `${inputClass} pl-10`;
  const selectClass = `${inputClass} appearance-none`;

  return (
    <div
      className={`fixed inset-0 z-[60] bg-black/80 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close}
      role="dialog"
      aria-modal="true"
    >
      <div
        className={`fixed inset-0 bg-white dark:bg-gray-900 w-full h-full overflow-hidden flex flex-col transition-transform duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 border-b dark:border-gray-700 flex justify-between items-center bg-white dark:bg-brand-navy-dark shadow-sm z-10">
          <h2 className="text-xl font-display font-bold text-brand-navy-dark dark:text-white">Edit Profile</h2>
          <div className="flex gap-4">
              <Button type="button" variant="outline" onClick={close} className="hidden sm:block">Cancel</Button>
              <Button type="button" onClick={handleSubmit}>Save Changes</Button>
              <button onClick={close} className="sm:hidden p-2 text-gray-500"><XIcon className="w-6 h-6"/></button>
          </div>
        </div>

        <div className="flex flex-1 overflow-hidden">
            {/* Sidebar Tabs (Desktop) */}
            <div className="hidden md:block w-64 bg-gray-50 dark:bg-gray-800 border-r dark:border-gray-700 p-4 space-y-2">
                <button onClick={() => setActiveTab('profile')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${activeTab === 'profile' ? 'bg-brand-gold text-brand-navy-dark font-bold' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'}`}>
                    <UserIcon className="w-5 h-5" /> Profile
                </button>
                <button onClick={() => setActiveTab('preferences')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${activeTab === 'preferences' ? 'bg-brand-gold text-brand-navy-dark font-bold' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'}`}>
                    <Cog6ToothIcon className="w-5 h-5" /> Preferences
                </button>
                <button onClick={() => setActiveTab('security')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${activeTab === 'security' ? 'bg-brand-gold text-brand-navy-dark font-bold' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'}`}>
                    <LockClosedIcon className="w-5 h-5" /> Security
                </button>
            </div>

            {/* Mobile Tabs */}
            <div className="md:hidden absolute bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t dark:border-gray-700 p-2 flex justify-around z-20">
                <button onClick={() => setActiveTab('profile')} className={`flex flex-col items-center p-2 ${activeTab === 'profile' ? 'text-brand-gold' : 'text-gray-500'}`}>
                    <UserIcon className="w-6 h-6" /><span className="text-xs">Profile</span>
                </button>
                <button onClick={() => setActiveTab('preferences')} className={`flex flex-col items-center p-2 ${activeTab === 'preferences' ? 'text-brand-gold' : 'text-gray-500'}`}>
                    <Cog6ToothIcon className="w-6 h-6" /><span className="text-xs">Preferences</span>
                </button>
                <button onClick={() => setActiveTab('security')} className={`flex flex-col items-center p-2 ${activeTab === 'security' ? 'text-brand-gold' : 'text-gray-500'}`}>
                    <LockClosedIcon className="w-6 h-6" /><span className="text-xs">Security</span>
                </button>
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-y-auto p-6 pb-24 md:pb-6 bg-brand-off-white dark:bg-gray-900">
                <div className="max-w-3xl mx-auto">
                    {activeTab === 'profile' && (
                        <div className="space-y-8 animate-fade-in">
                             {/* Images */}
                            <div className="relative mb-16">
                                <div className="relative h-48 w-full bg-gray-200 rounded-xl overflow-hidden group cursor-pointer shadow-md" onClick={() => coverInputRef.current?.click()}>
                                    {coverPreview ? <img src={coverPreview} className="w-full h-full object-cover" alt="Cover"/> : <div className="flex items-center justify-center h-full text-gray-400">Upload Cover Photo</div>}
                                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                        <PhotoIcon className="w-8 h-8 text-white" />
                                    </div>
                                    <input type="file" ref={coverInputRef} onChange={e => handleImageChange(e, 'cover')} className="hidden" accept="image/*" />
                                </div>
                                <div className="absolute -bottom-12 left-8">
                                    <div className="relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                                        <div className="relative">
                                            <Avatar 
                                                imageUrl={imagePreview} 
                                                name={formData.fullName} 
                                                className={`w-32 h-32 rounded-full border-4 border-white dark:border-gray-900 bg-white shadow-lg ${isVerifying ? 'opacity-50' : ''}`} 
                                                textClassName="text-5xl font-bold"
                                            />
                                            {isVerifying && (
                                                <div className="absolute inset-0 flex items-center justify-center">
                                                    <div className="w-8 h-8 border-4 border-brand-gold border-t-transparent rounded-full animate-spin"></div>
                                                </div>
                                            )}
                                        </div>
                                        <div className="absolute inset-0 rounded-full bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                            <CameraIcon className="w-8 h-8 text-white" />
                                        </div>
                                        <div className="absolute bottom-1 right-1 bg-brand-green text-white p-1 rounded-full shadow-sm" title="AI Consistency Check Active">
                                            <ShieldCheckIcon className="w-4 h-4"/>
                                        </div>
                                        <input type="file" ref={fileInputRef} onChange={e => handleImageChange(e, 'avatar')} className="hidden" accept="image/*" />
                                    </div>
                                </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Full Name</label>
                                    <input type="text" name="fullName" id="fullName" value={formData.fullName} onChange={handleChange} required className={inputClass} />
                                </div>
                                <div>
                                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Email Address</label>
                                    <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} required className={inputClass} />
                                </div>
                            </div>

                            <div>
                                <label htmlFor="bio" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Bio / About Me</label>
                                <textarea name="bio" id="bio" value={formData.bio || ''} onChange={handleChange} className={inputClass} rows={4} placeholder="Tell us about yourself..." />
                            </div>

                            <div>
                                <label htmlFor="country" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Country</label>
                                <select name="country" id="country" value={formData.country} onChange={handleChange} required className={selectClass}>
                                    <option value="" disabled>Select your country</option>
                                    {countries.map(c => <option key={c.code} value={c.name}>{c.name}</option>)}
                                </select>
                            </div>

                            <div className="border-t dark:border-gray-700 pt-6">
                                <h3 className="text-lg font-bold text-brand-navy-dark dark:text-white mb-4">Social Links</h3>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {[
                                        { name: 'instagram', icon: <InstagramIcon className="w-5 h-5" /> },
                                        { name: 'x', icon: <TwitterXIcon className="w-5 h-5" /> },
                                        { name: 'facebook', icon: <FacebookIcon className="w-5 h-5" /> },
                                        { name: 'tiktok', icon: <TikTokIcon className="w-5 h-5" /> },
                                        { name: 'linkedin', icon: <LinkedInIcon className="w-5 h-5" /> },
                                        { name: 'website', icon: <LinkIcon className="w-5 h-5" /> }
                                    ].map(field => (
                                        <div key={field.name} className="relative">
                                            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">{field.icon}</div>
                                            <input type="url" name={field.name} value={field.name === 'website' ? formData.website || '' : formData.socialMediaLinks?.[field.name as keyof typeof formData.socialMediaLinks] || ''} onChange={field.name === 'website' ? handleChange : handleSocialChange} placeholder={`https://${field.name}.com/...`} className={socialInputClass} />
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}

                    {activeTab === 'preferences' && (
                         <div className="space-y-8 animate-fade-in">
                            <h3 className="text-xl font-bold text-brand-navy-dark dark:text-white">App Preferences</h3>
                            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-100 dark:border-gray-700 space-y-6">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="font-semibold text-gray-900 dark:text-white">Profile Visibility</p>
                                        <p className="text-sm text-gray-500">Control who can see your profile details.</p>
                                    </div>
                                    <select value={formData.profileVisibility || 'public'} onChange={(e) => handleSettingChange('profileVisibility', e.target.value)} className="rounded-md bg-gray-100 dark:bg-gray-700 border-none py-2 px-4 text-sm">
                                        <option value="public">Public</option>
                                        <option value="followers_only">Followers Only</option>
                                    </select>
                                </div>
                                
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="font-semibold text-gray-900 dark:text-white">Show Native Name</p>
                                        <p className="text-sm text-gray-500">Display your local name alongside your full name.</p>
                                    </div>
                                    <ToggleSwitch enabled={!!formData.showNativeName} setEnabled={(val) => handleSettingChange('showNativeName', val)} label="Native Name" />
                                </div>
                            </div>
                         </div>
                    )}

                    {activeTab === 'security' && (
                        <div className="space-y-8 animate-fade-in">
                            <h3 className="text-xl font-bold text-brand-navy-dark dark:text-white">Security Settings</h3>
                             <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-100 dark:border-gray-700 space-y-6">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="font-semibold text-gray-900 dark:text-white">Two-Factor Authentication</p>
                                        <p className="text-sm text-gray-500">Add an extra layer of security to your account.</p>
                                    </div>
                                    <ToggleSwitch enabled={!!formData.twoFactorEnabled} setEnabled={(val) => handleSettingChange('twoFactorEnabled', val)} label="2FA" />
                                </div>
                                <div className="pt-6 border-t dark:border-gray-700">
                                    <Button variant="outline" className="w-full sm:w-auto">Change Password</Button>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileEditModal;
