import React, { useState, useCallback, useEffect } from 'react';
import { Link } from 'react-router-dom';
import type { Participant } from '../../types';
import { XIcon, EnvelopeIcon, UserPlusIcon, UserMinusIcon } from '../icons/Icons';
import Button from '../ui/Button';
import Avatar from '../ui/Avatar';
import { useAuth } from '../../contexts/AuthContext';

interface ContactActionModalProps {
  participant: Participant;
  onClose: () => void;
}

const ContactActionModal: React.FC<ContactActionModalProps> = ({ participant, onClose }) => {
  const [isClosing, setIsClosing] = useState(false);
  const { isContact, addContact, removeContact } = useAuth();
  const inContacts = isContact(participant.id);

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [close]);

  const handleContactAction = () => {
    if (inContacts) {
        removeContact(participant.id);
    } else {
        addContact(participant.id);
    }
  };

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';

  return (
    <div
      className={`fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close}
      role="dialog"
      aria-modal="true"
    >
      <div
        className={`relative bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-sm transition-all duration-300 ${modalAnimation}`}
        onClick={e => e.stopPropagation()}
      >
        <div className="p-8 text-center border-b dark:border-gray-700">
            <Avatar
                imageUrl={participant.avatarUrl}
                name={participant.name}
                id={participant.id}
                className="w-24 h-24 rounded-full object-cover mx-auto border-4 border-brand-gold"
                textClassName="text-4xl font-bold text-white"
            />
          <h2 className="mt-4 text-xl font-display font-bold text-brand-navy-dark dark:text-white">{participant.name}</h2>
          <p className="text-sm text-brand-gray dark:text-gray-400">{participant.role}</p>
        </div>
        <div className="p-4 space-y-2">
            <Link to={`/messages/new?recipientId=${participant.id}&recipientName=${encodeURIComponent(participant.name)}&recipientRole=${encodeURIComponent(participant.role || '')}&recipientAvatar=${encodeURIComponent(participant.avatarUrl)}`} onClick={close}>
                <button className="w-full flex items-center gap-3 p-3 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 text-left">
                    <EnvelopeIcon className="w-5 h-5 text-gray-500 dark:text-gray-300" />
                    <span className="font-semibold text-brand-navy-dark dark:text-white">Send Message</span>
                </button>
            </Link>
            <button
                onClick={handleContactAction}
                className="w-full flex items-center gap-3 p-3 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 text-left"
            >
                {inContacts ? (
                    <>
                        <UserMinusIcon className="w-5 h-5 text-red-500" />
                        <span className="font-semibold text-red-500">Remove from Contacts</span>
                    </>
                ) : (
                    <>
                        <UserPlusIcon className="w-5 h-5 text-brand-green" />
                        <span className="font-semibold text-brand-green">Add to Contacts</span>
                    </>
                )}
            </button>
        </div>
        <button onClick={close} className="absolute top-2 right-2 text-gray-400 hover:text-gray-800 dark:hover:text-white p-2 rounded-full" aria-label="Close">
          <XIcon className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export default ContactActionModal;