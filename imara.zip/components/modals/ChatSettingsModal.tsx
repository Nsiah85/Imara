
import React, { useState } from 'react';
import Button from '../ui/Button';
import { XIcon, CheckCircleIcon, LockClosedIcon, EyeIcon, TrashIcon, ArrowUpTrayIcon } from '../icons/Icons';
import ToggleSwitch from '../ui/ToggleSwitch';

interface ChatSettingsModalProps {
    onClose: () => void;
    onSave: (settings: ChatSettings) => void;
    currentSettings: ChatSettings;
}

export interface ChatSettings {
    wallpaper: string; 
    bubbleColor: string; 
}

const wallpapers = [
    { id: 'default', name: 'Default', value: '#f3f4f6' },
    { id: 'navy', name: 'Midnight', value: '#0A2342' },
    { id: 'pattern1', name: 'African Print', value: 'url("https://www.transparenttextures.com/patterns/cubes.png")' },
    { id: 'pattern2', name: 'Geometric', value: 'url("https://www.transparenttextures.com/patterns/diagmonds-light.png")' }
];

const bubbles = [
    { id: 'gold', name: 'Imara Gold', value: 'bg-brand-gold text-brand-navy-dark' },
    { id: 'green', name: 'Brand Green', value: 'bg-brand-green text-white' },
    { id: 'blue', name: 'Cool Blue', value: 'bg-blue-500 text-white' },
    { id: 'purple', name: 'Royal Purple', value: 'bg-purple-600 text-white' }
];

const ChatSettingsModal: React.FC<ChatSettingsModalProps> = ({ onClose, onSave, currentSettings }) => {
    const [settings, setSettings] = useState<ChatSettings>(currentSettings);
    const [activeTab, setActiveTab] = useState<'general' | 'privacy'>('general');
    
    // Mock Privacy State
    const [readReceipts, setReadReceipts] = useState(true);
    const [lastSeen, setLastSeen] = useState(true);

    const handleSave = () => {
        onSave(settings);
        onClose();
    };
    
    const handleRestoreChats = () => {
        alert("Archived chats restored successfully.");
    };

    return (
        <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white dark:bg-gray-800 w-full max-w-md rounded-2xl shadow-xl overflow-hidden flex flex-col max-h-[80vh]">
                <div className="p-4 border-b dark:border-gray-700 flex justify-between items-center">
                    <h3 className="font-bold text-brand-navy-dark dark:text-white">Chat Settings</h3>
                    <button onClick={onClose}><XIcon className="w-5 h-5 text-gray-500"/></button>
                </div>
                
                <div className="flex border-b dark:border-gray-700">
                    <button onClick={() => setActiveTab('general')} className={`flex-1 py-3 text-sm font-bold ${activeTab === 'general' ? 'text-brand-gold border-b-2 border-brand-gold' : 'text-gray-500'}`}>Appearance</button>
                    <button onClick={() => setActiveTab('privacy')} className={`flex-1 py-3 text-sm font-bold ${activeTab === 'privacy' ? 'text-brand-gold border-b-2 border-brand-gold' : 'text-gray-500'}`}>Privacy & Security</button>
                </div>

                <div className="p-6 space-y-6 overflow-y-auto">
                    {activeTab === 'general' ? (
                        <>
                            <div>
                                <p className="text-sm font-bold text-gray-500 mb-3 uppercase">Wallpaper</p>
                                <div className="grid grid-cols-4 gap-3">
                                    {wallpapers.map(wp => (
                                        <button 
                                            key={wp.id}
                                            onClick={() => setSettings(prev => ({ ...prev, wallpaper: wp.value }))}
                                            className={`h-16 w-full rounded-lg border-2 transition-all relative ${settings.wallpaper === wp.value ? 'border-brand-green' : 'border-transparent'}`}
                                            style={{ background: wp.value }}
                                        >
                                            {settings.wallpaper === wp.value && (
                                                <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                                                    <CheckCircleIcon className="w-6 h-6 text-white" />
                                                </div>
                                            )}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            <div>
                                <p className="text-sm font-bold text-gray-500 mb-3 uppercase">Bubble Style</p>
                                 <div className="grid grid-cols-2 gap-3">
                                    {bubbles.map(b => (
                                        <button 
                                            key={b.id}
                                            onClick={() => setSettings(prev => ({ ...prev, bubbleColor: b.value }))}
                                            className={`p-3 rounded-lg border-2 flex items-center justify-center ${settings.bubbleColor === b.value ? 'border-brand-green bg-gray-50 dark:bg-gray-700' : 'border-gray-200 dark:border-gray-600'}`}
                                        >
                                            <div className={`px-3 py-2 rounded-lg text-xs font-medium ${b.value}`}>
                                                Hello!
                                            </div>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        </>
                    ) : (
                        <div className="space-y-6">
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <EyeIcon className="w-5 h-5 text-brand-gold" />
                                    <span className="text-gray-800 dark:text-white font-medium">Read Receipts</span>
                                </div>
                                <ToggleSwitch enabled={readReceipts} setEnabled={setReadReceipts} label="Read Receipts" />
                            </div>
                             <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <LockClosedIcon className="w-5 h-5 text-brand-gold" />
                                    <span className="text-gray-800 dark:text-white font-medium">Last Seen</span>
                                </div>
                                <ToggleSwitch enabled={lastSeen} setEnabled={setLastSeen} label="Last Seen" />
                            </div>
                            
                            <div className="pt-6 border-t dark:border-gray-700 space-y-3">
                                <p className="text-xs font-bold text-gray-500 uppercase">Data Management</p>
                                <button onClick={handleRestoreChats} className="w-full flex items-center gap-3 p-3 bg-gray-100 dark:bg-gray-700 rounded-xl hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors text-left">
                                    <ArrowUpTrayIcon className="w-5 h-5 text-brand-green" />
                                    <div>
                                        <span className="font-bold text-brand-navy-dark dark:text-white block">Restore Chats</span>
                                        <span className="text-xs text-gray-500">Recover archived conversations</span>
                                    </div>
                                </button>
                                <button className="w-full flex items-center gap-3 p-3 bg-red-50 dark:bg-red-900/20 rounded-xl hover:bg-red-100 dark:hover:bg-red-900/40 transition-colors text-left">
                                    <TrashIcon className="w-5 h-5 text-red-500" />
                                    <div>
                                        <span className="font-bold text-red-600 dark:text-red-400 block">Clear All Chats</span>
                                        <span className="text-xs text-gray-500">Permanently delete history</span>
                                    </div>
                                </button>
                            </div>
                        </div>
                    )}
                </div>

                <div className="p-4 bg-gray-50 dark:bg-gray-900 border-t dark:border-gray-700 flex justify-end gap-3">
                    <Button variant="outline" onClick={onClose}>Cancel</Button>
                    <Button onClick={handleSave}>Save Changes</Button>
                </div>
            </div>
        </div>
    );
};

export default ChatSettingsModal;
