import React, { useState, useEffect, useCallback } from 'react';
import type { GistPost, GistComment } from '../../types';
import { useLanguage } from '../../contexts/LanguageContext';
import { XIcon, PaperAirplaneIcon } from '../icons/Icons.tsx';
import Button from '../ui/Button';
import Avatar from '../ui/Avatar.tsx';

interface CommentModalProps {
  post: GistPost;
  onClose: () => void;
  onAddComment: (postId: string, text: string) => void;
}

const CommentItem: React.FC<{ comment: GistComment }> = ({ comment }) => (
    <div className="flex items-start gap-3">
        <Avatar 
            imageUrl={comment.author.avatarUrl}
            name={comment.author.name}
            className="w-8 h-8 rounded-full object-cover flex-shrink-0"
            textClassName="text-sm font-bold text-white"
        />
        <div className="flex-grow">
            <div className="bg-brand-off-white/80 dark:bg-gray-700 p-3 rounded-lg">
                <p className="font-bold text-sm text-brand-navy-dark dark:text-white">{comment.author.name}</p>
                <p className="text-sm text-gray-800 dark:text-gray-300">{comment.text}</p>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 pl-1">{comment.timestamp}</p>
        </div>
    </div>
);


const CommentModal: React.FC<CommentModalProps> = ({ post, onClose, onAddComment }) => {
    const { t } = useLanguage();
    const [isClosing, setIsClosing] = useState(false);
    const [newComment, setNewComment] = useState('');

    const close = useCallback(() => {
        setIsClosing(true);
        setTimeout(onClose, 300);
    }, [onClose]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => { if (e.key === 'Escape') close(); };
        document.addEventListener('keydown', handleKeyDown);
        document.body.style.overflow = 'hidden';
        return () => {
            document.removeEventListener('keydown', handleKeyDown);
            document.body.style.overflow = 'auto';
        };
    }, [close]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (newComment.trim()) {
            onAddComment(post.id, newComment.trim());
            setNewComment('');
        }
    };
    
    const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
    const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';

    return (
        <div
            className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
            onClick={close} role="dialog" aria-modal="true"
        >
            <div
                className={`relative bg-white dark:bg-gray-800 rounded-2xl shadow-xl w-full max-w-lg max-h-[80vh] flex flex-col transition-all duration-300 ${modalAnimation}`}
                onClick={(e) => e.stopPropagation()}
            >
                <header className="p-4 border-b dark:border-gray-700 text-center relative">
                    <h2 className="text-lg font-bold text-brand-navy-dark dark:text-white">{t('toast.commentsTitle')}</h2>
                    <button onClick={close} className="absolute top-1/2 -translate-y-1/2 right-4 p-2 text-gray-500 hover:text-black dark:text-gray-400 dark:hover:text-white">
                        <XIcon className="w-5 h-5" />
                    </button>
                </header>

                <main className="flex-grow p-4 overflow-y-auto space-y-4">
                    {post.comments.length > 0 ? (
                        post.comments.map(comment => <CommentItem key={comment.id} comment={comment} />)
                    ) : (
                        <p className="text-center text-gray-500 dark:text-gray-400 py-8">No comments yet. Be the first!</p>
                    )}
                </main>

                <footer className="p-4 border-t dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <form onSubmit={handleSubmit} className="flex items-center gap-3">
                        <input
                            type="text"
                            value={newComment}
                            onChange={(e) => setNewComment(e.target.value)}
                            placeholder="Add a comment..."
                            className="flex-1 p-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white rounded-full focus:ring-2 focus:ring-brand-gold focus:border-brand-gold"
                            autoFocus
                        />
                        <Button type="submit" className="rounded-full !p-2.5" disabled={!newComment.trim()}>
                            <PaperAirplaneIcon className="w-5 h-5" />
                        </Button>
                    </form>
                </footer>
            </div>
        </div>
    );
};

export default CommentModal;
