import React from 'react';
import { XIcon, UsersIcon, BanknotesIcon, GlobeIcon } from '../icons/Icons.tsx';
import Button from '../ui/Button.tsx';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';

interface ImpactQuickViewModalProps {
    program: any;
    onClose: () => void;
    onAction: (program: any) => void;
}

const ImpactQuickViewModal: React.FC<ImpactQuickViewModalProps> = ({ program, onClose, onAction }) => {
    const { formatCurrency } = useCurrency();
    const isInvestment = 'vendorName' in program;
    const target = isInvestment ? program.goal : program.goal || 5000;
    const current = isInvestment ? program.raised : program.raised || 0;
    const percentage = Math.round((current / target) * 100);

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
            <div className="relative bg-white dark:bg-brand-navy-dark w-full max-w-2xl rounded-[32px] overflow-hidden shadow-2xl animate-fade-in flex flex-col md:flex-row">
                <button onClick={onClose} className="absolute top-4 right-4 z-10 p-2 bg-black/20 hover:bg-black/40 rounded-full text-white backdrop-blur-md transition-colors">
                    <XIcon className="w-5 h-5" />
                </button>
                
                <div className="md:w-2/5 h-64 md:h-auto relative">
                    <img src={program.imageUrl} alt={program.title} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-6">
                        <div>
                            <span className="px-3 py-1 bg-brand-gold text-brand-navy-dark text-[10px] font-black uppercase tracking-widest rounded-full mb-2 inline-block">
                                {isInvestment ? 'Partner Biz' : 'Social Cause'}
                            </span>
                            <p className="text-white font-bold text-sm">
                                {isInvestment ? program.vendorName : program.organization}
                            </p>
                        </div>
                    </div>
                </div>
                
                <div className="md:w-3/5 p-8 flex flex-col">
                    <h2 className="text-2xl font-display font-black text-brand-navy-dark dark:text-white mb-4 leading-tight">{program.title}</h2>
                    <p className="text-gray-500 dark:text-gray-400 text-sm mb-6 leading-relaxed flex-grow">
                        {program.description || 'Join us in making a real difference. This project aims to bring sustainable change and measurable impact to the community. Your contribution makes this possible.'}
                    </p>
                    
                    <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-2xl mb-6">
                        <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest mb-2">
                            <span className="text-gray-500 dark:text-gray-400">Progression</span>
                            <span className="text-brand-green">{percentage}%</span>
                        </div>
                        <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden mb-3">
                            <div className="h-full bg-brand-green rounded-full" style={{ width: `${Math.min(100, percentage)}%` }}></div>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                            <span className="font-bold text-brand-navy-dark dark:text-white">{formatCurrency(current)} <span className="text-gray-400 text-xs font-normal">raised</span></span>
                            <span className="text-gray-500 dark:text-gray-400 font-mono text-xs">Target: {formatCurrency(target)}</span>
                        </div>
                    </div>
                    
                    <Button onClick={() => { onClose(); onAction(program); }} className="w-full py-4 text-sm tracking-widest uppercase font-black !rounded-2xl">
                        {isInvestment ? 'Invest Now' : 'Donate Now'}
                    </Button>
                </div>
            </div>
        </div>
    );
};

export default ImpactQuickViewModal;
