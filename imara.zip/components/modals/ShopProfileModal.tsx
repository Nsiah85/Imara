

import React, { useState, useEffect, useCallback } from 'react';
import type { ShopProfile } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { XIcon } from '../icons/Icons.tsx';

interface ShopProfileModalProps {
  profile: ShopProfile;
  onClose: () => void;
  onSave: (updatedProfile: ShopProfile) => void;
}

const validateImage = (file: File, minWidth: number, minHeight: number, maxSizeMB: number): Promise<void> => {
    return new Promise((resolve, reject) => {
        const MIN_SIZE_KB = 10;

        if (file.size < MIN_SIZE_KB * 1024) {
            return reject(`Image is too small (min ${MIN_SIZE_KB}KB). It may appear blurry.`);
        }
        if (file.size > maxSizeMB * 1024 * 1024) {
            return reject(`Image is too large (max ${maxSizeMB}MB).`);
        }
        const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
        if (!allowedTypes.includes(file.type)) {
            return reject('Invalid file type. Please use JPG, PNG, or WEBP.');
        }

        const img = new Image();
        img.src = URL.createObjectURL(file);
        img.onload = () => {
            if (img.width < minWidth || img.height < minHeight) {
                reject(`Image is too small (min ${minWidth}x${minHeight}px). It may appear blurry.`);
            } else {
                resolve();
            }
        };
        img.onerror = () => {
            reject('Could not read image file.');
        };
    });
};


const ShopProfileModal: React.FC<ShopProfileModalProps> = ({ profile, onClose, onSave }) => {
  const [formData, setFormData] = useState<ShopProfile>(profile);
  const [isClosing, setIsClosing] = useState(false);
  const [fileErrors, setFileErrors] = useState({ logoUrl: '', bannerUrl: '' });

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, files } = e.target;
    if (!files || files.length === 0) return;

    const file = files[0];
    const fieldName = name as keyof typeof fileErrors;
    const isLogo = name === 'logoUrl';
    const minWidth = isLogo ? 200 : 800;
    const minHeight = isLogo ? 200 : 200;
    const maxSizeMB = isLogo ? 10 : 15;

    try {
        await validateImage(file, minWidth, minHeight, maxSizeMB);
        setFileErrors(prev => ({ ...prev, [fieldName]: '' }));
        setFormData(prev => ({ ...prev, [name]: URL.createObjectURL(file) }));
    } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        setFileErrors(prev => ({ ...prev, [fieldName]: errorMessage }));
        e.target.value = ''; // Reset file input on error
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (fileErrors.logoUrl || fileErrors.bannerUrl) return;
    onSave(formData);
  };

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';
  const inputClass = "mt-1 block w-full bg-brand-green-dark text-white border border-brand-green rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent placeholder:text-gray-400";
  const fileInputClass = (name: keyof typeof fileErrors) => `${inputClass} file:mr-4 file:py-1.5 file:px-3 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-brand-gold file:text-brand-green-dark hover:file:bg-brand-gold-light cursor-pointer ${fileErrors[name] ? '!border-red-500 !focus:ring-red-500' : ''}`;

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close} role="dialog" aria-modal="true" aria-labelledby="edit-profile-title"
    >
      <div
        className={`relative bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b dark:border-gray-700">
          <h2 id="edit-profile-title" className="text-xl font-display font-semibold text-brand-green-dark dark:text-white">Edit Your Shop Profile</h2>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-8 space-y-6">
            <div>
              <label htmlFor="brandName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Brand Name</label>
              <input type="text" name="brandName" id="brandName" value={formData.brandName} onChange={handleChange} required className={inputClass} />
            </div>
             <div>
              <label htmlFor="story" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Brand Story</label>
              <textarea name="story" id="story" rows={5} value={formData.story} onChange={handleChange} required className={inputClass}></textarea>
              <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">Tell your customers what makes your brand special.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="logoUrl" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Logo Image</label>
                    <input type="file" name="logoUrl" id="logoUrl" onChange={handleFileChange} className={fileInputClass('logoUrl')} accept="image/png, image/jpeg, image/webp" />
                    <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">Min 200x200px. Max 10MB.</p>
                    {fileErrors.logoUrl && <p className="mt-1 text-xs text-red-500">{fileErrors.logoUrl}</p>}
                </div>
                 <div>
                    <label htmlFor="bannerUrl" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Banner Image</label>
                    <input type="file" name="bannerUrl" id="bannerUrl" onChange={handleFileChange} className={fileInputClass('bannerUrl')} accept="image/png, image/jpeg, image/webp" />
                    <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">Min 800x200px. Max 15MB.</p>
                    {fileErrors.bannerUrl && <p className="mt-1 text-xs text-red-500">{fileErrors.bannerUrl}</p>}
                </div>
            </div>
          </div>
          <div className="p-6 bg-gray-50 dark:bg-gray-700/50 rounded-b-lg flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={close}>Cancel</Button>
            <Button type="submit">Save Changes</Button>
          </div>
        </form>
        <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 dark:hover:text-white transition-colors z-10" aria-label="Close edit profile modal">
          <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default ShopProfileModal;