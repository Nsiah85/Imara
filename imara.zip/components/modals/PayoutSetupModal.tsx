


import React, { useState, useEffect, useCallback } from 'react';
import Button from '../ui/Button.tsx';
import { XIcon } from '../icons/Icons.tsx';
import PaymentMethodForm from '../shared/PaymentMethodForm.tsx';

interface PayoutSetupModalProps {
  onClose: () => void;
}

const PayoutSetupModal: React.FC<PayoutSetupModalProps> = ({ onClose }) => {
  const [isClosing, setIsClosing] = useState(false);

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, save the payout details
    console.log("Saving payout details...");
    onClose();
  };

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close} role="dialog" aria-modal="true" aria-labelledby="payout-title"
    >
      <div
        className={`relative bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-lg transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b dark:border-gray-700">
          <h2 id="payout-title" className="text-xl font-display font-semibold text-brand-green-dark dark:text-white">Configure Payouts</h2>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-8">
            <p className="text-gray-600 dark:text-gray-300 mb-6">Set up how you'd like to receive your earnings. Your information is encrypted and stored securely.</p>
            <PaymentMethodForm />
          </div>
          <div className="p-6 bg-gray-50 dark:bg-gray-700/50 rounded-b-lg flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={close}>Cancel</Button>
            <Button type="submit">Save Payout Method</Button>
          </div>
        </form>
        <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 dark:hover:text-white transition-colors z-10" aria-label="Close payout setup modal">
          <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default PayoutSetupModal;