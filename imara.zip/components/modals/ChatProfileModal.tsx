import React, { useCallback, useEffect, useState } from 'react';
import type { Participant } from '../../types';
import { XIcon } from '../icons/Icons.tsx';
import Button from '../ui/Button.tsx';
import { Link } from 'react-router-dom';

interface ChatProfileModalProps {
  participant: Participant;
  onClose: () => void;
}

const ChatProfileModal: React.FC<ChatProfileModalProps> = ({ participant, onClose }) => {
    const [isClosing, setIsClosing] = useState(false);

    const close = useCallback(() => {
        setIsClosing(true);
        setTimeout(onClose, 300);
    }, [onClose]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => { if (e.key === 'Escape') close(); };
        document.addEventListener('keydown', handleKeyDown);
        document.body.style.overflow = 'hidden';
        return () => {
            document.removeEventListener('keydown', handleKeyDown);
            document.body.style.overflow = 'auto';
        };
    }, [close]);

    const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
    const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';

    return (
        <div className={`fixed inset-0 z-[80] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`} onClick={close} role="dialog">
            <div className={`relative bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-sm transition-all duration-300 ${modalAnimation}`} onClick={e => e.stopPropagation()}>
                <div className="p-8 text-center">
                    <img src={participant.avatarUrl} alt={participant.name} className="w-32 h-32 rounded-full object-cover mx-auto border-4 border-brand-gold" />
                    <h2 className="mt-4 text-2xl font-display font-bold text-brand-navy-dark dark:text-white">{participant.name}</h2>
                    <p className="text-brand-gray dark:text-gray-400">{participant.role}</p>
                    {participant.bio && (
                        <p className="mt-4 text-sm text-gray-600 dark:text-gray-300 italic">"{participant.bio}"</p>
                    )}
                </div>
                <div className="p-6 bg-gray-50 dark:bg-gray-700/50 rounded-b-lg flex justify-center">
                    <Link to={participant.profileLink || '#'}>
                         <Button variant="secondary" onClick={close}>View Full Profile</Button>
                    </Link>
                </div>
                <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 dark:hover:text-white" aria-label="Close profile">
                    <XIcon className="w-6 h-6" />
                </button>
            </div>
        </div>
    );
};

export default ChatProfileModal;
