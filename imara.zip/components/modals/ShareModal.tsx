import React, { useEffect, useCallback } from 'react';
import { XIcon, FacebookIcon, TwitterXIcon, WhatsAppIcon, PinterestIcon, TikTokIcon, EnvelopeIcon, LinkIcon } from '../icons/Icons';
import Button from '../ui/Button';

interface ShareModalProps {
  postUrl: string;
  postTitle: string;
  onClose: () => void;
}

const ShareModal: React.FC<ShareModalProps> = ({ postUrl, postTitle, onClose }) => {
    const encodedUrl = encodeURIComponent(postUrl);
    const encodedText = encodeURIComponent(postTitle);

    const handleCopyLink = () => {
        navigator.clipboard.writeText(postUrl);
        // You might want to show a toast here
        onClose();
    };

    const shareLinks = [
        { name: 'WhatsApp', icon: <WhatsAppIcon className="w-8 h-8 text-[#25D366]" />, url: `https://api.whatsapp.com/send?text=${encodedText}%20${encodedUrl}` },
        { name: 'Facebook', icon: <FacebookIcon className="w-8 h-8 text-[#1877F2]" />, url: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}` },
        { name: 'X', icon: <TwitterXIcon className="w-8 h-8 text-black dark:text-white" />, url: `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedText}` },
        { name: 'Pinterest', icon: <PinterestIcon className="w-8 h-8 text-[#E60023]" />, url: `https://pinterest.com/pin/create/button/?url=${encodedUrl}&description=${encodedText}` },
        { name: 'Email', icon: <EnvelopeIcon className="w-8 h-8 text-gray-600" />, url: `mailto:?subject=${encodedText}&body=Check this out: ${encodedUrl}` },
        { name: 'TikTok', icon: <TikTokIcon className="w-8 h-8 text-black dark:text-white" />, url: `https://www.tiktok.com/share` }, // Note: TikTok web share is limited
    ];

    const close = useCallback(() => {
        onClose();
    }, [onClose]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => { if (e.key === 'Escape') close(); };
        document.addEventListener('keydown', handleKeyDown);
        return () => document.removeEventListener('keydown', handleKeyDown);
    }, [close]);

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in" onClick={close}>
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-sm p-6 relative" onClick={e => e.stopPropagation()}>
                <h3 className="text-lg font-bold text-center mb-6 text-brand-navy-dark dark:text-white">Share to...</h3>
                <div className="grid grid-cols-3 gap-4 mb-6">
                    {shareLinks.map(link => (
                        <a 
                            key={link.name} 
                            href={link.url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="flex flex-col items-center gap-2 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        >
                            {link.icon}
                            <span className="text-xs text-gray-600 dark:text-gray-300">{link.name}</span>
                        </a>
                    ))}
                </div>
                <div className="border-t dark:border-gray-700 pt-4">
                    <button 
                        onClick={handleCopyLink}
                        className="flex items-center justify-center gap-2 w-full p-3 rounded-lg bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors font-semibold text-sm text-gray-700 dark:text-gray-200"
                    >
                        <LinkIcon className="w-5 h-5" />
                        Copy Link
                    </button>
                </div>
                <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 dark:hover:text-white">
                    <XIcon className="w-5 h-5" />
                </button>
            </div>
        </div>
    );
};

export default ShareModal;