
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import type { Product, SustainabilityTag, EdwasoMarket } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { XIcon, ShieldCheckIcon } from '../icons/Icons.tsx';
import { SustainabilityTag as SustainabilityTagEnum, ProductCategory } from '../../types.ts';
import { useSecurity } from '../../contexts/SecurityContext.tsx';

interface AddProductModalProps {
  onClose: () => void;
  onAddProduct: (productData: Omit<Product, 'id' | 'vendor' | 'isVerified' | 'impactPerPurchase'>) => void;
}

type FormData = Omit<Product, 'id' | 'vendor' | 'isVerified' | 'impactPerPurchase' | 'sustainabilityTags'> & {
    sustainabilityTags: SustainabilityTag[];
};

const AddProductModal: React.FC<AddProductModalProps> = ({ onClose, onAddProduct }) => {
  const { verifyImageConsistency } = useSecurity();
  const [formData, setFormData] = useState<FormData>({
    name: '',
    price: 0,
    imageUrl: '',
    originCountry: '',
    sustainabilityTags: [],
    description: '',
    category: ProductCategory.FASHION,
    marketId: '',
  });
  const [isClosing, setIsClosing] = useState(false);
  const [fileError, setFileError] = useState('');
  const [isCheckingFraud, setIsCheckingFraud] = useState(false);
  const [markets, setMarkets] = useState<EdwasoMarket[]>([]);

  const isEdwasoCategory = useMemo(() => [ProductCategory.FOODSTUFF, ProductCategory.FRUITS_VEGETABLES, ProductCategory.PROTEINS].includes(formData.category), [formData.category]);

  useEffect(() => {
    try {
        const storedMarkets = localStorage.getItem('edwaso_markets');
        if (storedMarkets) {
            setMarkets(JSON.parse(storedMarkets));
        }
    } catch (error) {
        console.error("Failed to load markets", error);
    }
  }, []);

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'price' ? parseFloat(value) : value }));
  };

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
          const file = e.target.files[0];
          
          setIsCheckingFraud(true);
          const { safe, reason } = await verifyImageConsistency(file, 'product');
          setIsCheckingFraud(false);

          if (!safe) {
              setFileError(`Image blocked by Fraud Filters: ${reason}`);
              e.target.value = '';
              return;
          }

          setFileError('');
          setSelectedFile(file);
          setFormData(prev => ({ ...prev, imageUrl: URL.createObjectURL(file) }));
      }
  };
  
  const handleTagToggle = (tag: SustainabilityTag) => {
    setFormData(prev => ({
        ...prev,
        sustainabilityTags: prev.sustainabilityTags.includes(tag)
            ? prev.sustainabilityTags.filter(t => t !== tag)
            : [...prev.sustainabilityTags, tag]
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (fileError) return;
    
    setIsSubmitting(true);
    let finalData = { ...formData };
    
    if (selectedFile) {
        try {
             const { uploadFile } = await import('../../firebase/storage.ts');
             const url = await uploadFile(selectedFile, `products/${Date.now()}`);
             finalData.imageUrl = url;
        } catch (error) {
             console.error("Failed to upload file to Firebase Storage", error);
        }
    }
    
    onAddProduct(finalData);
    setIsSubmitting(false);
  };

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';
  const inputClass = "mt-1 block w-full bg-brand-navy-dark text-brand-gold-light border border-brand-green rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent placeholder:text-gray-400";
  const selectClass = `${inputClass} appearance-none`;
  const fileInputClass = `${inputClass} file:mr-4 file:py-1.5 file:px-3 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-brand-gold file:text-brand-navy-dark hover:file:bg-brand-gold-light cursor-pointer ${fileError ? '!border-red-500 !focus:ring-red-500' : ''}`;

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close} role="dialog" aria-modal="true" aria-labelledby="add-product-title"
    >
      <div
        className={`relative bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b dark:border-gray-700 flex justify-between items-center">
          <h2 id="add-product-title" className="text-xl font-display font-semibold text-brand-navy-dark dark:text-white">Add New Product</h2>
          <div className="flex items-center gap-1 text-xs text-brand-green font-semibold">
              <ShieldCheckIcon className="w-4 h-4" /> Fraud Protection Active
          </div>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-8 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Product Name</label>
                    <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className={inputClass} />
                </div>
                <div>
                    <label htmlFor="price" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Price (USD)</label>
                    <input type="number" name="price" id="price" value={formData.price || ''} onChange={handleChange} required className={inputClass} step="0.01" min="0" />
                </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="category" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Category</label>
                    <select name="category" id="category" value={formData.category} onChange={handleChange} required className={selectClass}>
                        {Object.values(ProductCategory).map(cat => (
                            <option key={cat} value={cat}>{cat}</option>
                        ))}
                    </select>
                </div>
                {isEdwasoCategory && (
                    <div className="animate-fade-in">
                        <label htmlFor="marketId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Market</label>
                        <select name="marketId" id="marketId" value={formData.marketId} onChange={handleChange} required={isEdwasoCategory} className={selectClass}>
                           <option value="" disabled>Select market</option>
                           {markets.map(market => <option key={market.id} value={market.id}>{market.name}</option>)}
                        </select>
                    </div>
                )}
            </div>
             <div>
                <label htmlFor="imageUrl" className="block text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-2">
                    Product Image {isCheckingFraud && <span className="text-brand-gold text-xs font-bold animate-pulse">(Scanning for authenticity...)</span>}
                </label>
                <input type="file" name="imageUrl" id="imageUrl" onChange={handleFileChange} required className={fileInputClass} accept="image/*" disabled={isCheckingFraud} />
                {fileError && <p className="mt-1 text-xs text-red-500 font-bold">{fileError}</p>}
            </div>
            <div>
                <label htmlFor="originCountry" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Origin Country</label>
                <input type="text" name="originCountry" id="originCountry" value={formData.originCountry} onChange={handleChange} required className={inputClass} />
            </div>
            {!isEdwasoCategory && (
                 <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Sustainability Tags</label>
                    <div className="mt-2 flex flex-wrap gap-2">
                        {Object.values(SustainabilityTagEnum).map(tag => (
                            <button
                                type="button"
                                key={tag}
                                onClick={() => handleTagToggle(tag)}
                                className={`px-3 py-1 text-sm rounded-full border-2 transition-colors ${formData.sustainabilityTags.includes(tag) ? 'bg-brand-green text-white border-brand-green' : 'bg-transparent text-gray-600 border-gray-300 hover:border-brand-green'}`}
                            >
                                {tag}
                            </button>
                        ))}
                    </div>
                </div>
            )}
             <div>
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Description</label>
                <textarea name="description" id="description" rows={4} value={formData.description} onChange={handleChange} required className={inputClass}></textarea>
            </div>
          </div>
          <div className="p-6 bg-gray-50 dark:bg-gray-700/50 rounded-b-lg flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={close}>Cancel</Button>
            <Button type="submit" disabled={isCheckingFraud || !!fileError || isSubmitting}>
              {isSubmitting ? 'Uploading...' : 'Add Product'}
            </Button>
          </div>
        </form>
        <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 dark:hover:text-white transition-colors z-10" aria-label="Close add product modal">
          <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default AddProductModal;
