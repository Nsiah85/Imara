
import React, { useState, useEffect, useCallback } from 'react';
import type { PaymentItem, ImpactData } from '../../types.ts';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';
import Button from '../ui/Button.tsx';
import { XIcon, ArrowLeftIcon, CheckCircleIcon, SparklesIcon } from '../icons/Icons.tsx';
import { useAuth } from '../../contexts/AuthContext.tsx';
import { usePayment } from '../../hooks/usePayment.ts';

interface PaymentModalProps {
  item: PaymentItem;
  onClose: () => void;
  onSuccess: (amount: number) => void;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ item, onClose, onSuccess }) => {
  const { user } = useAuth();
  const { formatCurrency } = useCurrency();
  const { initializePayment, isProcessing } = usePayment();
  const [isClosing, setIsClosing] = useState(false);
  const [step, setStep] = useState<'amount' | 'success'>('amount');
  const [amount, setAmount] = useState('');
  const [ref, setRef] = useState('');

  const presetAmounts = [5, 20, 50, 200];

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  const handleStartPayment = (e: React.FormEvent) => {
    e.preventDefault();
    const numericAmount = Number(amount);
    if (numericAmount <= 0) return;

    initializePayment({
        amount: numericAmount,
        email: user?.email || 'impact@imara.com',
        metadata: {
            type: item.type as any,
            itemId: item.id,
            description: `Contribution to: ${item.title}`,
        },
        onSuccess: (reference) => {
            setRef(reference);
            setStep('success');
            setTimeout(() => onSuccess(numericAmount), 3000);
        }
    });
  };

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';

  return (
    <div
      className={`fixed inset-0 z-[150] flex items-center justify-center p-4 bg-brand-navy-dark/90 backdrop-blur-md transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close} role="dialog" aria-modal="true"
    >
      <div
        className={`relative bg-white dark:bg-gray-800 rounded-[40px] shadow-2xl w-full max-w-md transition-all duration-300 ${modalAnimation} overflow-hidden`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-8">
            {step === 'amount' && (
                <form onSubmit={handleStartPayment} className="animate-fade-in">
                    <div className="flex flex-col items-center text-center mb-8">
                        <div className="w-20 h-20 rounded-3xl overflow-hidden mb-4 shadow-lg border-2 border-brand-gold">
                            <img src={item.imageUrl} className="w-full h-full object-cover" alt="" />
                        </div>
                        <p className="text-[10px] font-black uppercase text-brand-gold tracking-[0.2em] mb-1">{item.type}</p>
                        <h2 className="text-2xl font-display font-black text-brand-navy-dark dark:text-white leading-tight">{item.title}</h2>
                    </div>

                    <div className="relative mb-6">
                        <span className="absolute left-6 top-1/2 -translate-y-1/2 text-3xl font-display font-black text-brand-gold">$</span>
                        <input
                            type="number"
                            value={amount}
                            onChange={(e) => setAmount(e.target.value)}
                            placeholder="0.00"
                            className="w-full bg-gray-50 dark:bg-gray-900 text-brand-navy-dark dark:text-white text-5xl font-display font-black text-center border-none rounded-3xl py-8 px-12 focus:ring-4 focus:ring-brand-gold/20"
                            required
                            autoFocus
                        />
                    </div>

                    <div className="grid grid-cols-4 gap-2 mb-6">
                        {presetAmounts.map(preset => (
                            <button
                                type="button"
                                key={preset}
                                onClick={() => setAmount(String(preset))}
                                className={`py-3 rounded-xl text-sm font-black transition-all ${amount === String(preset) ? 'bg-brand-gold text-brand-navy-dark scale-105' : 'bg-gray-100 dark:bg-gray-700 text-gray-500 hover:bg-gray-200'}`}
                            >
                                ${preset}
                            </button>
                        ))}
                    </div>

                    {amount && Number(amount) > 0 && (
                        <div className="mb-8 p-4 bg-brand-green/10 rounded-xl border border-brand-green/20">
                            <h4 className="text-xs font-bold text-brand-green uppercase tracking-wider mb-2">Transparent Impact Revenue Split</h4>
                            <div className="flex justify-between items-center text-sm text-gray-600 dark:text-gray-300">
                                <span>Going directly to {item.recipient} (80%):</span>
                                <span className="font-bold text-brand-navy-dark dark:text-white">{formatCurrency(Number(amount) * 0.8)}</span>
                            </div>
                            <div className="flex justify-between items-center text-sm text-gray-600 dark:text-gray-300 mt-1">
                                <span>Platform reinvestment & operations (20%):</span>
                                <span className="font-bold text-gray-500">{formatCurrency(Number(amount) * 0.2)}</span>
                            </div>
                        </div>
                    )}

                    <Button 
                        type="submit" 
                        size="lg" 
                        disabled={isProcessing || !amount}
                        className="w-full !rounded-full py-5 text-lg font-black uppercase tracking-widest shadow-gold-glow flex justify-center items-center gap-3"
                    >
                        {isProcessing ? (
                            <div className="w-6 h-6 border-3 border-brand-navy-dark border-t-transparent rounded-full animate-spin"></div>
                        ) : (
                            <>Authorize Contribution &rarr;</>
                        )}
                    </Button>
                </form>
            )}

            {step === 'success' && (
                <div className="text-center py-6 animate-fade-in">
                    <div className="w-24 h-24 bg-brand-green/10 rounded-full flex items-center justify-center mx-auto mb-6">
                        <CheckCircleIcon className="w-16 h-16 text-brand-green animate-bounce" />
                    </div>
                    <h2 className="text-4xl font-display font-black text-brand-navy-dark dark:text-white leading-tight">Legacy <br/>Contribution Confirmed</h2>
                    <p className="mt-4 text-gray-500 dark:text-gray-400 font-medium">
                        Your payment of <span className="text-brand-green font-black">{formatCurrency(Number(amount))}</span> has been verified and allocated.
                    </p>
                    <div className="mt-8 p-4 bg-brand-off-white dark:bg-gray-900/50 rounded-2xl border border-dashed border-gray-200 dark:border-gray-700">
                        <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Digital Reference</p>
                        <p className="font-mono text-sm font-bold text-brand-navy-dark dark:text-white mt-1">{ref}</p>
                    </div>
                </div>
            )}
        </div>
        
        {!isProcessing && (
             <button
                onClick={close}
                className="absolute top-6 right-6 text-gray-400 hover:text-red-500 transition-colors z-10"
            >
                <XIcon className="w-6 h-6" />
            </button>
        )}
      </div>
    </div>
  );
};

export default PaymentModal;
