
import React, { useState, useCallback, useEffect } from 'react';
import type { GistPost, Product, TravelService, Partner } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { XIcon, CalendarDaysIcon } from '../icons/Icons.tsx';

interface PostToGistModalProps {
  item: Product | TravelService;
  partner: Partner;
  onClose: () => void;
  onPost: (post: GistPost) => void;
}

const PostToGistModal: React.FC<PostToGistModalProps> = ({ item, partner, onClose, onPost }) => {
    const [text, setText] = useState('');
    const [isClosing, setIsClosing] = useState(false);
    const [isScheduled, setIsScheduled] = useState(false);
    const [scheduleDate, setScheduleDate] = useState('');

    const isProduct = 'vendor' in item;
    const isService = 'providerName' in item;

    const close = useCallback(() => {
        setIsClosing(true);
        setTimeout(onClose, 300);
    }, [onClose]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => { if (e.key === 'Escape') close(); };
        document.addEventListener('keydown', handleKeyDown);
        document.body.style.overflow = 'hidden';
        return () => {
            document.removeEventListener('keydown', handleKeyDown);
            document.body.style.overflow = 'auto';
        };
    }, [close]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (text.trim()) {
            let creatorName: string;
            let creatorAvatarUrl: string;
            let creatorProfileLink: string;

            if (partner.role === 'workman') {
                creatorName = partner.name;
                creatorAvatarUrl = partner.profileImageUrl;
                creatorProfileLink = `/workman/${partner.storeSlug}`;
            } else { // 'vendor' or 'travel'
                creatorName = partner.brandName;
                creatorAvatarUrl = partner.brandLogoUrl || '';
                creatorProfileLink = partner.role === 'vendor'
                    ? `/vendor/${partner.storeSlug}`
                    : `/travel/${partner.storeSlug}`;
            }
            
            const newPost: GistPost = {
                id: crypto.randomUUID(),
                creator: {
                    id: partner.id,
                    name: creatorName,
                    avatarUrl: creatorAvatarUrl,
                    profileLink: creatorProfileLink,
                    role: 'partner',
                    isVerified: partner.isVerified,
                },
                timestamp: new Date().toISOString(),
                content: {
                    text: text.trim(),
                    type: isProduct ? 'product_card' : 'booking_card',
                    productId: isProduct ? item.id : undefined,
                    serviceId: isService ? item.id : undefined,
                },
                tags: [`#${creatorName.replace(/\s+/g, '')}`, `#${isProduct ? 'NewProduct' : 'NewService'}`],
                engagement: { likes: 0, commentsCount: 0, shares: 0, saves: 0, rating: 0, ratingCount: 0 },
                comments: [],
                status: isScheduled && scheduleDate ? 'scheduled' : 'published',
                scheduledFor: isScheduled && scheduleDate ? new Date(scheduleDate).toISOString() : undefined,
            };
            onPost(newPost);
            close();
        }
    };
    
    const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
    const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';

    return (
        <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`} onClick={close}>
            <div className={`relative bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-lg transition-all duration-300 ${modalAnimation}`} onClick={e => e.stopPropagation()}>
                <div className="p-6 border-b dark:border-gray-700">
                    <h2 className="text-xl font-display font-semibold text-brand-navy-dark dark:text-white">Post to Toast Feed</h2>
                </div>
                <form onSubmit={handleSubmit}>
                    <div className="p-8 space-y-6 overflow-y-auto">
                        <div className="flex items-start gap-4 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-md">
                            <img src={item.imageUrl} alt={isProduct ? item.name : item.title} className="w-20 h-20 object-cover rounded-md flex-shrink-0" />
                            <div>
                                <p className="font-bold text-brand-navy-dark dark:text-white">{isProduct ? item.name : item.title}</p>
                                <p className="text-sm text-gray-500 dark:text-gray-400">This card will be attached to your post.</p>
                            </div>
                        </div>
                        <div>
                            <label htmlFor="text" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Your message</label>
                            <textarea
                                id="text"
                                value={text}
                                onChange={e => setText(e.target.value)}
                                rows={4}
                                className="mt-1 w-full p-2 border rounded-md bg-white dark:bg-gray-700 dark:border-gray-600 dark:text-white focus:ring-brand-gold focus:border-brand-gold"
                                placeholder={`Announce your ${isProduct ? 'product' : 'service'}...`}
                                required
                            />
                        </div>
                        
                        <div className="pt-2 border-t dark:border-gray-700">
                            <div className="flex items-center gap-3 mb-3">
                                <input 
                                    type="checkbox" 
                                    id="schedule" 
                                    checked={isScheduled} 
                                    onChange={e => setIsScheduled(e.target.checked)}
                                    className="h-4 w-4 text-brand-gold rounded focus:ring-brand-gold border-gray-300" 
                                />
                                <label htmlFor="schedule" className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-2">
                                    <CalendarDaysIcon className="w-4 h-4"/> Schedule Post
                                </label>
                            </div>
                            
                            {isScheduled && (
                                <div className="animate-fade-in">
                                    <input 
                                        type="datetime-local" 
                                        value={scheduleDate}
                                        onChange={e => setScheduleDate(e.target.value)}
                                        className="w-full p-2 border rounded-md text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                                    />
                                </div>
                            )}
                        </div>
                    </div>
                    <div className="p-6 bg-gray-50 dark:bg-gray-700/50 rounded-b-lg flex justify-end gap-4">
                        <Button type="button" variant="outline" onClick={close}>Cancel</Button>
                        <Button type="submit">{isScheduled ? 'Schedule' : 'Post to Toast'}</Button>
                    </div>
                </form>
                <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 dark:hover:text-white" aria-label="Close modal">
                    <XIcon className="w-6 h-6" />
                </button>
            </div>
        </div>
    );
};

export default PostToGistModal;
