import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import type { Product } from '../../types';
import { useCart } from '../../contexts/CartContext.tsx';
import Button from '../ui/Button.tsx';
import Badge from '../ui/Badge.tsx';
import { XIcon, LeafIcon, GlobeIcon, SparklesIcon } from '../icons/Icons.tsx';
import WishlistButton from '../ui/WishlistButton.tsx';
import OptimizedImage from '../ui/OptimizedImage.tsx';

interface QuickViewModalProps {
  product: Product;
  onClose: () => void;
}

const QuickViewModal: React.FC<QuickViewModalProps> = ({ product, onClose }) => {
  const { addToCart } = useCart();
  const [isAdded, setIsAdded] = useState(false);
  const [isClosing, setIsClosing] = useState(false);

  const handleAddToCart = () => {
    addToCart(product);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300); // Wait for animation
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        close();
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close}
      role="dialog"
      aria-modal="true"
      aria-labelledby="quick-view-title"
    >
      <div
        className={`relative bg-white dark:bg-brand-navy-dark rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-6 transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative h-64 md:h-auto">
          <OptimizedImage src={product.imageUrl} alt={product.name} className="absolute w-full h-full object-cover rounded-t-lg md:rounded-l-lg md:rounded-tr-none" />
        </div>
        
        <div className="p-8 flex flex-col">
          <div>
            <p className="text-sm uppercase tracking-widest text-brand-gray dark:text-gray-400">{product.vendor}</p>
            <h1 id="quick-view-title" className="text-3xl font-display font-bold text-brand-green-dark dark:text-white mt-1">{product.name}</h1>
            <p className="text-2xl font-display font-semibold text-brand-green dark:text-brand-gold-light mt-3">${product.price.toFixed(2)}</p>
          </div>

          <div className="mt-4 border-t dark:border-gray-700 pt-4 text-gray-700 dark:text-gray-300 leading-relaxed overflow-y-auto max-h-32">
            <p>{product.description}</p>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
             {product.sustainabilityTags.map(tag => (
                <Badge key={tag} className="bg-green-100 text-green-800" icon={<LeafIcon className="w-3 h-3"/>}>{tag}</Badge>
             ))}
             <Badge className="bg-blue-100 text-blue-800" icon={<GlobeIcon className="w-3 h-3"/>}>{product.originCountry}</Badge>
          </div>

          <div className="mt-4 bg-green-50/50 dark:bg-green-900/20 border border-green-200 dark:border-green-700/50 text-green-900 dark:text-green-200 p-3 rounded-lg flex items-start gap-3 text-sm">
            <SparklesIcon className="w-6 h-6 text-brand-gold flex-shrink-0 mt-1" />
            <div>
                <h4 className="font-bold">Impact</h4>
                <p>{product.impactPerPurchase}</p>
            </div>
          </div>

          <div className="mt-auto pt-6">
            <div className="flex items-stretch gap-3 mb-3">
                <Button size="lg" className="flex-grow" onClick={handleAddToCart} disabled={isAdded}>
                {isAdded ? 'Added to Cart!' : 'Add to Cart'}
                </Button>
                <WishlistButton product={product} className="border-2 border-brand-green-dark dark:border-brand-gold-light rounded-md flex-shrink-0 bg-white dark:bg-gray-800" />
            </div>
            <Link to={`/product/${product.id}`} onClick={close} className="block text-center text-sm text-brand-green hover:text-brand-gold font-semibold">
              View Full Details
            </Link>
          </div>
        </div>

        <button 
          onClick={close} 
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 dark:hover:text-white transition-colors z-10"
          aria-label="Close quick view"
        >
          <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default QuickViewModal;
