
import React, { useState, useCallback, useEffect } from 'react';
import { XIcon, PlusCircleIcon, TrashIcon } from '../icons/Icons.tsx';
import Button from '../ui/Button.tsx';
import { ProductCategory } from '../../types.ts';

interface BatchProductModalProps {
  onClose: () => void;
  onBatchAdd: (products: any[]) => void;
}

interface BatchRow {
    id: string;
    name: string;
    price: string;
    category: ProductCategory;
    description: string;
    image: File | null;
    imagePreview: string | null;
}

const BatchProductModal: React.FC<BatchProductModalProps> = ({ onClose, onBatchAdd }) => {
    const [rows, setRows] = useState<BatchRow[]>([
        { id: crypto.randomUUID(), name: '', price: '', category: ProductCategory.FASHION, description: '', image: null, imagePreview: null }
    ]);
    const [isClosing, setIsClosing] = useState(false);

    const close = useCallback(() => {
        setIsClosing(true);
        setTimeout(onClose, 300);
    }, [onClose]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => { if (e.key === 'Escape') close(); };
        document.addEventListener('keydown', handleKeyDown);
        return () => document.removeEventListener('keydown', handleKeyDown);
    }, [close]);

    const addRow = () => {
        setRows(prev => [...prev, { id: crypto.randomUUID(), name: '', price: '', category: ProductCategory.FASHION, description: '', image: null, imagePreview: null }]);
    };

    const removeRow = (id: string) => {
        setRows(prev => prev.filter(r => r.id !== id));
    };

    const updateRow = (id: string, field: keyof BatchRow, value: any) => {
        setRows(prev => prev.map(r => r.id === id ? { ...r, [field]: value } : r));
    };

    const handleImageChange = (id: string, e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            const preview = URL.createObjectURL(file);
            setRows(prev => prev.map(r => r.id === id ? { ...r, image: file, imagePreview: preview } : r));
        }
    };

    const handleSubmit = () => {
        // Basic validation: ensure name and price exist for all rows
        if (rows.some(r => !r.name || !r.price)) {
            alert("Please fill in Name and Price for all items.");
            return;
        }
        
        const products = rows.map(r => ({
            name: r.name,
            price: parseFloat(r.price),
            category: r.category,
            description: r.description || 'No description provided.',
            imageUrl: r.imagePreview || 'https://via.placeholder.com/150', // In real app, upload file and get URL
            originCountry: 'Ghana', // Default for batch
            sustainabilityTags: [],
        }));
        
        onBatchAdd(products);
        close();
    };

    const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
    const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';
    const inputClass = "w-full p-2 border rounded text-sm bg-gray-50 focus:ring-1 focus:ring-brand-gold outline-none";

    return (
        <div className={`fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`} onClick={close}>
            <div className={`relative bg-white w-full max-w-5xl max-h-[90vh] flex flex-col rounded-xl shadow-2xl transition-all duration-300 ${modalAnimation}`} onClick={e => e.stopPropagation()}>
                <div className="p-6 border-b flex justify-between items-center">
                    <h2 className="text-xl font-bold text-brand-navy-dark">Batch Upload Products</h2>
                    <button onClick={close}><XIcon className="w-6 h-6 text-gray-500" /></button>
                </div>
                
                <div className="flex-1 overflow-x-auto overflow-y-auto p-6">
                    <table className="w-full min-w-[800px] border-collapse">
                        <thead>
                            <tr className="bg-gray-100 text-left text-sm font-bold text-gray-600">
                                <th className="p-3 rounded-l-lg">Image</th>
                                <th className="p-3">Name</th>
                                <th className="p-3 w-24">Price</th>
                                <th className="p-3">Category</th>
                                <th className="p-3">Description</th>
                                <th className="p-3 rounded-r-lg"></th>
                            </tr>
                        </thead>
                        <tbody className="space-y-2">
                            {rows.map(row => (
                                <tr key={row.id} className="border-b border-gray-100">
                                    <td className="p-2">
                                        <label className="cursor-pointer block w-16 h-16 bg-gray-200 rounded overflow-hidden relative group">
                                            {row.imagePreview ? <img src={row.imagePreview} className="w-full h-full object-cover" /> : <span className="absolute inset-0 flex items-center justify-center text-xs text-gray-500">+ Img</span>}
                                            <div className="absolute inset-0 bg-black/30 hidden group-hover:flex items-center justify-center text-white text-xs">Edit</div>
                                            <input type="file" className="hidden" onChange={(e) => handleImageChange(row.id, e)} accept="image/*" />
                                        </label>
                                    </td>
                                    <td className="p-2">
                                        <input type="text" value={row.name} onChange={e => updateRow(row.id, 'name', e.target.value)} className={inputClass} placeholder="Product Name" />
                                    </td>
                                    <td className="p-2">
                                        <input type="number" value={row.price} onChange={e => updateRow(row.id, 'price', e.target.value)} className={inputClass} placeholder="0.00" />
                                    </td>
                                    <td className="p-2">
                                        <select value={row.category} onChange={e => updateRow(row.id, 'category', e.target.value)} className={inputClass}>
                                            {Object.values(ProductCategory).map(c => <option key={c} value={c}>{c}</option>)}
                                        </select>
                                    </td>
                                    <td className="p-2">
                                        <input type="text" value={row.description} onChange={e => updateRow(row.id, 'description', e.target.value)} className={inputClass} placeholder="Short description..." />
                                    </td>
                                    <td className="p-2">
                                        <button onClick={() => removeRow(row.id)} className="p-2 text-red-500 hover:bg-red-50 rounded-full"><TrashIcon className="w-5 h-5" /></button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    <div className="mt-4">
                        <button onClick={addRow} className="flex items-center gap-2 text-brand-green font-bold text-sm hover:underline">
                            <PlusCircleIcon className="w-5 h-5" /> Add Another Product
                        </button>
                    </div>
                </div>

                <div className="p-6 border-t bg-gray-50 rounded-b-xl flex justify-end gap-4">
                    <Button variant="outline" onClick={close}>Cancel</Button>
                    <Button onClick={handleSubmit}>Upload {rows.length} Products</Button>
                </div>
            </div>
        </div>
    );
};

export default BatchProductModal;
