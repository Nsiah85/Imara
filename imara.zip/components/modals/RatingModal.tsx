import React, { useState, useEffect, useCallback } from 'react';
import type { Booking } from '../../types';
import Button from '../ui/Button';
import { XIcon } from '../icons/Icons';

interface RatingModalProps {
  booking: Booking;
  onClose: () => void;
  onSubmit: (ratingData: { rating: number; comment?: string }) => void;
}

const RatingModal: React.FC<RatingModalProps> = ({ booking, onClose, onSubmit }) => {
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('');
  const [isClosing, setIsClosing] = useState(false);

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (rating > 0) {
      onSubmit({ rating, comment });
    }
  };

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';
  const inputClass = "mt-1 block w-full bg-brand-green-dark text-brand-gold-light border border-brand-green rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent placeholder:text-gray-400";

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close} role="dialog" aria-modal="true" aria-labelledby="rating-title"
    >
      <div
        className={`relative bg-white rounded-lg shadow-xl w-full max-w-lg transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b">
          <h2 id="rating-title" className="text-xl font-display font-semibold text-brand-green-dark">Rate Your Experience</h2>
          <p className="text-sm text-gray-500">{booking.serviceTitle}</p>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-8 space-y-6">
            <div>
                <label className="block text-sm font-medium text-center text-gray-700 mb-4">How was your experience?</label>
                <div 
                    className="flex justify-center gap-2"
                    onMouseLeave={() => setHoverRating(0)}
                >
                    {[1, 2, 3, 4, 5].map((star) => (
                        <button
                            type="button"
                            key={star}
                            className="transition-colors"
                            onClick={() => setRating(star)}
                            onMouseEnter={() => setHoverRating(star)}
                            aria-label={`Rate ${star} star${star > 1 ? 's' : ''}`}
                        >
                           <span className={`text-4xl transition-colors ${(hoverRating || rating) >= star ? 'text-brand-gold' : 'text-gray-300'}`}>
                                🔱
                            </span>
                        </button>
                    ))}
                </div>
            </div>
             <div>
                <label htmlFor="comment" className="block text-sm font-medium text-gray-700">Add a comment (optional)</label>
                <textarea 
                    name="comment" 
                    id="comment" 
                    rows={4} 
                    value={comment} 
                    onChange={(e) => setComment(e.target.value)} 
                    className={inputClass}
                    placeholder="Tell us more about your experience..."
                ></textarea>
            </div>
          </div>
          <div className="p-6 bg-gray-50 rounded-b-lg flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={close}>Cancel</Button>
            <Button type="submit" disabled={rating === 0}>Submit Rating</Button>
          </div>
        </form>
        <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 transition-colors z-10" aria-label="Close rating modal">
          <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default RatingModal;