
import React, { useState, useEffect } from 'react';
import { XIcon, UserGroupIcon, PlusCircleIcon, TrashIcon, LinkIcon, CheckCircleIcon, UsersIcon } from '../icons/Icons';
import Button from '../ui/Button';
import Avatar from '../ui/Avatar';
import { useAuth } from '../../contexts/AuthContext';
import type { GroupConversation, Participant } from '../../types';

interface GroupInfoModalProps {
    onClose: () => void;
}

const GroupInfoModal: React.FC<GroupInfoModalProps> = ({ onClose }) => {
    const { user } = useAuth();
    const [activeTab, setActiveTab] = useState<'groups' | 'create'>('groups');
    const [groups, setGroups] = useState<GroupConversation[]>([]);
    const [newGroupName, setNewGroupName] = useState('');
    const [copySuccessId, setCopySuccessId] = useState<string | null>(null);

    // 1. Fetch real groups from LocalStorage
    useEffect(() => {
        if (user) {
            try {
                const storedChats = localStorage.getItem(`imara_chats_${user.id}`);
                if (storedChats) {
                    const parsed = JSON.parse(storedChats);
                    const groupChats = parsed.filter((c: any) => c.type === 'group');
                    setGroups(groupChats);
                }
            } catch (e) {
                console.error("Error fetching groups", e);
            }
        }
    }, [user]);

    const handleCreateGroup = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newGroupName.trim() || !user) return;

        const newGroupId = `group_${Date.now()}`;
        const newGroup: GroupConversation = {
            id: newGroupId,
            type: 'group',
            groupName: newGroupName,
            groupAvatarUrl: '', // Could add avatar picker later
            participants: [{ id: user.id, name: user.fullName, avatarUrl: user.profileImageUrl, role: 'Admin' }],
            messages: [],
            adminIds: [user.id],
            isUnread: false,
            inviteLink: `${window.location.origin}/join-group/${newGroupId}`
        };

        // Update State
        const updatedGroups = [...groups, newGroup];
        setGroups(updatedGroups);

        // Update LocalStorage (This updates the conversation list effectively)
        try {
            const storedChats = localStorage.getItem(`imara_chats_${user.id}`);
            const allChats = storedChats ? JSON.parse(storedChats) : [];
            localStorage.setItem(`imara_chats_${user.id}`, JSON.stringify([...allChats, newGroup]));
            
            // In a real app, this would sync to backend.
            alert(`Group "${newGroupName}" created!`);
            setNewGroupName('');
            setActiveTab('groups');
        } catch (e) {
            console.error(e);
        }
    };

    const handleCopyInvite = (link: string, id: string) => {
        navigator.clipboard.writeText(link);
        setCopySuccessId(id);
        setTimeout(() => setCopySuccessId(null), 2000);
    };

    return (
        <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white dark:bg-gray-800 w-full max-w-md rounded-2xl shadow-xl overflow-hidden flex flex-col max-h-[80vh] border-2 border-brand-gold/20">
                
                <div className="p-4 border-b dark:border-gray-700 flex justify-between items-center bg-brand-navy-dark text-white">
                    <h3 className="font-bold flex items-center gap-2">
                        <UserGroupIcon className="w-5 h-5 text-brand-gold" /> Groups & Teams
                    </h3>
                    <button onClick={onClose}><XIcon className="w-5 h-5 text-gray-400 hover:text-white"/></button>
                </div>
                
                <div className="flex border-b dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <button onClick={() => setActiveTab('groups')} className={`flex-1 py-3 text-sm font-bold transition-colors ${activeTab === 'groups' ? 'text-brand-navy-dark border-b-2 border-brand-navy-dark bg-white dark:bg-gray-800 dark:text-white' : 'text-gray-500'}`}>My Groups</button>
                    <button onClick={() => setActiveTab('create')} className={`flex-1 py-3 text-sm font-bold transition-colors ${activeTab === 'create' ? 'text-brand-green border-b-2 border-brand-green bg-white dark:bg-gray-800' : 'text-gray-500'}`}>Create New</button>
                </div>
                
                <div className="p-6 space-y-6 overflow-y-auto flex-1 bg-white dark:bg-gray-800">
                     {activeTab === 'groups' ? (
                         <>
                             {groups.length > 0 ? (
                                 <div className="space-y-4">
                                     {groups.map(group => (
                                         <div key={group.id} className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl border border-gray-200 dark:border-gray-600 transition-all hover:shadow-md">
                                             <div className="flex items-center justify-between mb-3">
                                                 <div className="flex items-center gap-3">
                                                     <Avatar name={group.groupName} id={group.id} className="w-10 h-10 rounded-full" />
                                                     <div>
                                                         <p className="font-bold text-brand-navy-dark dark:text-white">{group.groupName}</p>
                                                         <p className="text-xs text-gray-500 flex items-center gap-1"><UsersIcon className="w-3 h-3"/> {group.participants.length} members</p>
                                                     </div>
                                                 </div>
                                                 {group.adminIds.includes(user?.id || '') && <span className="text-[10px] bg-brand-gold/20 text-brand-navy-dark px-2 py-0.5 rounded-full font-bold">Admin</span>}
                                             </div>
                                             
                                             {/* Invite Link Section for Admins */}
                                             {group.inviteLink && (
                                                <div className="flex items-center gap-2 bg-white dark:bg-gray-800 p-2 rounded-lg border border-gray-200 dark:border-gray-600">
                                                    <div className="p-1.5 bg-gray-100 rounded-full"><LinkIcon className="w-4 h-4 text-gray-500"/></div>
                                                    <input type="text" readOnly value={group.inviteLink} className="flex-1 bg-transparent text-xs text-gray-500 truncate outline-none" />
                                                    <button 
                                                        onClick={() => handleCopyInvite(group.inviteLink!, group.id)}
                                                        className={`text-xs font-bold px-3 py-1.5 rounded-md transition-colors ${copySuccessId === group.id ? 'bg-green-100 text-green-700' : 'bg-brand-navy-dark text-white hover:bg-brand-navy'}`}
                                                    >
                                                        {copySuccessId === group.id ? 'Copied' : 'Copy'}
                                                    </button>
                                                </div>
                                             )}
                                         </div>
                                     ))}
                                 </div>
                             ) : (
                                 <div className="text-center py-10">
                                     <UserGroupIcon className="w-16 h-16 text-gray-300 mx-auto mb-4"/>
                                     <p className="text-gray-500">You are not in any groups yet.</p>
                                     <Button variant="outline" className="mt-4" onClick={() => setActiveTab('create')}>Create one now</Button>
                                 </div>
                             )}
                         </>
                     ) : (
                         <form onSubmit={handleCreateGroup} className="space-y-4">
                             <div>
                                 <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">Group Name</label>
                                 <input 
                                    type="text" 
                                    value={newGroupName} 
                                    onChange={e => setNewGroupName(e.target.value)} 
                                    className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-brand-green outline-none dark:bg-gray-700 dark:text-white"
                                    placeholder="e.g. Design Team, Weekend Trip"
                                    autoFocus
                                />
                             </div>
                             <div className="bg-blue-50 text-blue-800 p-3 rounded-lg text-sm flex gap-2">
                                <CheckCircleIcon className="w-5 h-5 flex-shrink-0"/>
                                <p>An invite link will be generated automatically for you to share.</p>
                             </div>
                             <div className="pt-4 flex justify-end gap-3">
                                 <Button type="button" variant="outline" onClick={() => setActiveTab('groups')}>Cancel</Button>
                                 <Button type="submit" disabled={!newGroupName.trim()}>Create Group</Button>
                             </div>
                         </form>
                     )}
                </div>
            </div>
        </div>
    );
};

export default GroupInfoModal;
