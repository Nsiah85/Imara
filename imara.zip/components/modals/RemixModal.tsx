import React from 'react';
import { GistPost } from '../../types';
import { XIcon, VideoCameraIcon, PhotoIcon } from '../icons/Icons';
import Button from '../ui/Button';

interface RemixModalProps {
  originalPost: GistPost;
  onClose: () => void;
}

const RemixModal: React.FC<RemixModalProps> = ({ originalPost, onClose }) => {
    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
            <div className="bg-brand-navy-dark rounded-2xl shadow-2xl w-full max-w-4xl h-[80vh] overflow-hidden relative flex flex-col md:flex-row">
                {/* Original Content Side */}
                <div className="w-full md:w-1/2 bg-black relative flex items-center justify-center border-b md:border-b-0 md:border-r border-white/10">
                    <div className="absolute top-4 left-4 z-10 bg-black/50 px-2 py-1 rounded text-white text-xs font-bold">Original</div>
                    {originalPost.content.videoUrl ? (
                        <video src={originalPost.content.videoUrl} className="max-w-full max-h-full object-contain" muted />
                    ) : (
                        <img src={originalPost.content.imageUrl} className="max-w-full max-h-full object-contain" alt="Original" />
                    )}
                </div>

                {/* Creator Side */}
                <div className="w-full md:w-1/2 bg-gray-900 flex flex-col items-center justify-center p-8 text-white">
                    <h3 className="text-2xl font-display font-bold mb-2">Remix this Gist</h3>
                    <p className="text-gray-400 text-center mb-8">Add your reaction, commentary, or twist to {originalPost.creator.name}'s post.</p>
                    
                    <div className="grid grid-cols-2 gap-6 w-full max-w-sm">
                        <button className="flex flex-col items-center justify-center p-6 bg-white/10 hover:bg-white/20 rounded-xl transition-all hover:scale-105 border-2 border-transparent hover:border-brand-gold">
                            <VideoCameraIcon className="w-12 h-12 text-brand-gold mb-3" />
                            <span className="font-bold">Record Camera</span>
                        </button>
                        <button className="flex flex-col items-center justify-center p-6 bg-white/10 hover:bg-white/20 rounded-xl transition-all hover:scale-105 border-2 border-transparent hover:border-brand-green">
                            <PhotoIcon className="w-12 h-12 text-brand-green mb-3" />
                            <span className="font-bold">Upload Media</span>
                        </button>
                    </div>
                </div>

                <button onClick={onClose} className="absolute top-4 right-4 p-2 bg-black/50 text-white rounded-full hover:bg-white hover:text-black transition-colors z-20">
                    <XIcon className="w-6 h-6" />
                </button>
            </div>
        </div>
    );
};

export default RemixModal;