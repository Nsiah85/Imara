

import React, { useState, useEffect, useCallback } from 'react';
import type { SubscriptionPlan } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { XIcon } from '../icons/Icons.tsx';

interface SubscriptionEditModalProps {
  plan: Partial<SubscriptionPlan> | null;
  onClose: () => void;
  onSave: (plan: SubscriptionPlan) => void;
}

const SubscriptionEditModal: React.FC<SubscriptionEditModalProps> = ({ plan, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    name: plan?.name || '',
    price: plan?.price || 0,
    billingCycle: plan?.billingCycle || 'monthly',
    features: plan?.features?.join('\n') || '',
    isFeatured: plan?.isFeatured || false,
    type: plan?.type || 'vendor',
  });
  const [isClosing, setIsClosing] = useState(false);

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
        const { checked } = e.target as HTMLInputElement;
        setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
        setFormData(prev => ({ ...prev, [name]: name === 'price' ? Number(value) : value }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalPlan: SubscriptionPlan = {
      ...(plan || {}),
      id: plan?.id || crypto.randomUUID(),
      ...formData,
      features: formData.features.split('\n').filter(Boolean),
    };
    onSave(finalPlan);
  };

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';
  const inputClass = "mt-1 block w-full bg-brand-green-dark text-white border border-brand-green rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent placeholder:text-gray-400";
  const selectClass = `${inputClass} appearance-none`;

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close} role="dialog" aria-modal="true" aria-labelledby="edit-plan-title"
    >
      <div
        className={`relative bg-white rounded-lg shadow-xl w-full max-w-lg transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b">
          <h2 id="edit-plan-title" className="text-xl font-display font-semibold text-brand-green-dark">
            {plan?.id ? 'Edit' : 'Add'} Subscription Plan
          </h2>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-8 space-y-6">
            <input type="hidden" name="type" value={formData.type} />
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">Plan Name</label>
              <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className={inputClass} />
            </div>
            <div className="grid grid-cols-2 gap-6">
                <div>
                    <label htmlFor="price" className="block text-sm font-medium text-gray-700">Price (USD)</label>
                    <input type="number" name="price" id="price" value={formData.price} onChange={handleChange} required className={inputClass} />
                </div>
                <div>
                    <label htmlFor="billingCycle" className="block text-sm font-medium text-gray-700">Billing Cycle</label>
                    <select name="billingCycle" id="billingCycle" value={formData.billingCycle} onChange={handleChange} required className={selectClass}>
                        <option value="monthly">Monthly</option>
                        <option value="yearly">Yearly</option>
                    </select>
                </div>
            </div>
            <div>
              <label htmlFor="features" className="block text-sm font-medium text-gray-700">Features</label>
              <textarea name="features" id="features" rows={5} value={formData.features} onChange={handleChange} required className={inputClass}></textarea>
              <p className="mt-1 text-xs text-gray-500">Enter one feature per line.</p>
            </div>
             <div className="flex items-center">
                <input id="isFeatured" name="isFeatured" type="checkbox" checked={formData.isFeatured} onChange={handleChange} className="h-4 w-4 rounded border-gray-300 text-brand-gold focus:ring-brand-gold" />
                <label htmlFor="isFeatured" className="ml-3 block text-sm font-medium text-gray-700">Mark as "Most Popular"</label>
            </div>
          </div>
          <div className="p-6 bg-gray-50 rounded-b-lg flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={close}>Cancel</Button>
            <Button type="submit">Save Plan</Button>
          </div>
        </form>
        <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 transition-colors z-10" aria-label="Close modal">
          <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default SubscriptionEditModal;