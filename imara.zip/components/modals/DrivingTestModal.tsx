

import React, { useState, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../ui/Button.tsx';
import { XIcon } from '../icons/Icons.tsx';
import { useCart } from '../../contexts/CartContext.tsx';
import { mockProducts } from '../../data/mockData.ts';
import { ProductCategory } from '../../types.ts';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';
import { useLanguage } from '../../contexts/LanguageContext.tsx';

const DrivingTestModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const [isClosing, setIsClosing] = useState(false);
    const navigate = useNavigate();
    const { addToCart } = useCart();
    const { formatCurrency } = useCurrency();
    const { t } = useLanguage();
    const [formData, setFormData] = useState({ name: '', email: '', phone: '', vehicleType: 'sedan' });

    const drivingTestProduct = mockProducts.find(p => p.category === ProductCategory.DRIVING_TEST);

    const close = useCallback(() => {
        setIsClosing(true);
        setTimeout(onClose, 300);
    }, [onClose]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => { if (e.key === 'Escape') close(); };
        document.addEventListener('keydown', handleKeyDown);
        document.body.style.overflow = 'hidden';
        return () => {
            document.removeEventListener('keydown', handleKeyDown);
            document.body.style.overflow = 'auto';
        };
    }, [close]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (drivingTestProduct) {
            addToCart(drivingTestProduct);
            navigate('/checkout');
        } else {
            alert("Driving test booking is currently unavailable. Please try again later.");
        }
    };

    if (!drivingTestProduct) return null;

    const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
    const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';
    const inputClass = "mt-1 block w-full bg-brand-green-dark text-brand-gold-light border border-brand-green rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent placeholder:text-gray-400";

    return (
        <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`} onClick={close}>
            <div className={`relative bg-white rounded-lg shadow-xl w-full max-w-lg transition-all duration-300 ${modalAnimation}`} onClick={(e) => e.stopPropagation()}>
                <div className="p-6 border-b">
                    <h2 className="text-xl font-display font-semibold text-brand-green-dark">{t('automotive.modal.title')}</h2>
                </div>
                <form onSubmit={handleSubmit}>
                    <div className="p-8 space-y-6">
                        <p className="text-sm text-gray-600">{t('automotive.modal.subtitle', { amount: formatCurrency(drivingTestProduct.price) })}</p>
                        <div>
                            <label htmlFor="name" className="block text-sm font-medium text-gray-700">{t('automotive.modal.name')}</label>
                            <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className={inputClass} />
                        </div>
                         <div className="grid grid-cols-2 gap-6">
                             <div>
                                <label htmlFor="email" className="block text-sm font-medium text-gray-700">{t('automotive.modal.email')}</label>
                                <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} required className={inputClass} />
                            </div>
                            <div>
                                <label htmlFor="phone" className="block text-sm font-medium text-gray-700">{t('automotive.modal.phone')}</label>
                                <input type="tel" name="phone" id="phone" value={formData.phone} onChange={handleChange} required className={inputClass} />
                            </div>
                        </div>
                        <div>
                            <label htmlFor="vehicleType" className="block text-sm font-medium text-gray-700">{t('automotive.modal.vehicleType')}</label>
                            <select name="vehicleType" id="vehicleType" value={formData.vehicleType} onChange={handleChange} required className={`${inputClass} appearance-none`}>
                                <option value="sedan">Sedan / Saloon Car</option>
                                <option value="suv">SUV / 4x4</option>
                                <option value="truck">Pickup Truck</option>
                                <option value="manual">Manual Transmission Car</option>
                            </select>
                        </div>
                    </div>
                    <div className="p-6 bg-gray-50 rounded-b-lg flex justify-end gap-4">
                        <Button type="button" variant="outline" onClick={close}>{t('general.cancel')}</Button>
                        <Button type="submit">{t('automotive.modal.submit')}</Button>
                    </div>
                </form>
                <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800" aria-label="Close modal">
                    <XIcon className="w-6 h-6" />
                </button>
            </div>
        </div>
    );
};

export default DrivingTestModal;