

import React, { useState, useEffect, useCallback } from 'react';
import type { Professional } from '../../types.ts';
import { ProfessionalIndustry } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { XIcon, CameraIcon } from '../icons/Icons.tsx';

interface EditWorkmanProfileModalProps {
  professional: Professional;
  onClose: () => void;
  onSave: (professional: Professional) => void;
}

const EditWorkmanProfileModal: React.FC<EditWorkmanProfileModalProps> = ({ professional, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    ...professional,
    skills: professional.skills.join(', '),
    wageMin: professional.wageRange[0],
    wageMax: professional.wageRange[1],
  });
  const [isClosing, setIsClosing] = useState(false);
  const [imagePreview, setImagePreview] = useState(professional.profileImageUrl || '');

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: (name === 'wageMin' || name === 'wageMax') ? Number(value) : value }));
  };

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
          const file = e.target.files[0];
          setSelectedFile(file);
          const newImageUrl = URL.createObjectURL(file);
          setImagePreview(newImageUrl);
          setFormData(prev => ({ ...prev, profileImageUrl: newImageUrl }));
      }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    let finalImageUrl = formData.profileImageUrl;
    
    if (selectedFile) {
        try {
            const { uploadFile } = await import('../../firebase/storage.ts');
            finalImageUrl = await uploadFile(selectedFile, `professionals/${formData.id}/${Date.now()}`);
        } catch (error) {
            console.error("Failed to upload professional profile image", error);
        }
    }

    const { wageMin, wageMax, ...rest } = formData;
    const finalData: Professional = {
        ...rest,
        profileImageUrl: finalImageUrl,
        skills: formData.skills.split(',').map(s => s.trim()).filter(Boolean),
        wageRange: [formData.wageMin, formData.wageMax],
    };
    onSave(finalData);
    setIsSubmitting(false);
  };

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';
  const inputClass = "mt-1 block w-full bg-brand-green-dark text-white border border-brand-green rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent placeholder:text-gray-400";
  const selectClass = `${inputClass} appearance-none`;

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close} role="dialog" aria-modal="true" aria-labelledby="edit-profile-title"
    >
      <div
        className={`relative bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b">
          <h2 id="edit-profile-title" className="text-xl font-display font-semibold text-brand-green-dark">Edit Professional Profile</h2>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-8 space-y-6">
            <div className="flex justify-center">
                <div className="relative">
                    <img src={imagePreview || 'https://picsum.photos/seed/placeholder-user/300'} alt="Profile" className="w-32 h-32 rounded-full object-cover border-4 border-brand-gold" />
                     <label htmlFor="profile-image-upload" className="absolute bottom-1 right-1 bg-brand-navy text-white rounded-full p-2 hover:bg-brand-navy-dark transition-colors cursor-pointer" aria-label="Change profile picture">
                        <CameraIcon className="w-5 h-5" />
                    </label>
                    <input type="file" id="profile-image-upload" onChange={handleImageChange} className="hidden" accept="image/*" />
                </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">Full Name</label>
                    <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className={inputClass} />
                </div>
                <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email Address</label>
                    <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} required className={inputClass} />
                </div>
            </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="professionalRole" className="block text-sm font-medium text-gray-700">Professional Role</label>
                    <input type="text" name="professionalRole" id="professionalRole" value={formData.professionalRole} onChange={handleChange} required className={inputClass} />
                </div>
                <div>
                    <label htmlFor="industry" className="block text-sm font-medium text-gray-700">Industry</label>
                    <select name="industry" id="industry" value={formData.industry} onChange={handleChange} required className={selectClass}>
                        {Object.values(ProfessionalIndustry).map(ind => <option key={ind} value={ind}>{ind}</option>)}
                    </select>
                </div>
            </div>
            <div>
                <label htmlFor="skills" className="block text-sm font-medium text-gray-700">Skills (comma-separated)</label>
                <input type="text" name="skills" id="skills" value={formData.skills} onChange={handleChange} required className={inputClass} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                    <label htmlFor="wageMin" className="block text-sm font-medium text-gray-700">Min Wage</label>
                    <input type="number" name="wageMin" id="wageMin" value={formData.wageMin} onChange={handleChange} required className={inputClass} min="0" />
                </div>
                 <div>
                    <label htmlFor="wageMax" className="block text-sm font-medium text-gray-700">Max Wage</label>
                    <input type="number" name="wageMax" id="wageMax" value={formData.wageMax} onChange={handleChange} required className={inputClass} min={formData.wageMin} />
                </div>
                <div>
                    <label htmlFor="wageType" className="block text-sm font-medium text-gray-700">Wage Type</label>
                    <select name="wageType" id="wageType" value={formData.wageType} onChange={handleChange} required className={selectClass}>
                       <option value="hourly">Hourly</option>
                       <option value="daily">Daily</option>
                       <option value="project">Project</option>
                    </select>
                </div>
            </div>
          </div>
          <div className="p-6 bg-gray-50 rounded-b-lg flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={close}>Cancel</Button>
            <Button type="submit">Save Changes</Button>
          </div>
        </form>
        <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 transition-colors z-10" aria-label="Close modal">
          <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default EditWorkmanProfileModal;