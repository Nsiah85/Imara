
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../ui/Button.tsx';
import { XIcon, ImaraDiskIcon } from '../icons/Icons.tsx';

const SignupPromptModal: React.FC = () => {
    const [isVisible, setIsVisible] = useState(false);
    const [isClosing, setIsClosing] = useState(false);
    const navigate = useNavigate();

    const close = useCallback(() => {
        setIsClosing(true);
        setTimeout(() => {
            setIsVisible(false);
            try {
                sessionStorage.setItem('imara_signup_prompt_seen', 'true');
            } catch (e) { console.error(e); }
        }, 300);
    }, []);

    useEffect(() => {
        try {
            const hasSeenPrompt = sessionStorage.getItem('imara_signup_prompt_seen');
            if (!hasSeenPrompt) {
                const timer = setTimeout(() => {
                    setIsVisible(true);
                }, 15000); // Show after 15 seconds
                return () => clearTimeout(timer);
            }
        } catch (e) { console.error(e); }
    }, []);

    const handleSignup = () => {
        navigate('/login'); 
        close();
    };

    if (!isVisible) {
        return null;
    }

    const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
    const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';

    return (
        <div className={`fixed inset-0 z-[200] flex items-center justify-center p-4 bg-brand-navy-dark/90 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`} onClick={close}>
            <div className={`relative bg-white dark:bg-gray-900 rounded-3xl shadow-2xl p-1 max-w-md w-full transform transition-all duration-300 overflow-hidden ${modalAnimation}`} onClick={e => e.stopPropagation()}>
                
                {/* Border Gradient Container */}
                <div className="bg-gradient-to-br from-brand-gold via-brand-green to-brand-navy-dark p-1 rounded-[22px] h-full w-full">
                    <div className="bg-white dark:bg-brand-navy-dark rounded-[20px] p-8 text-center relative h-full flex flex-col justify-center items-center">
                        
                        <div className="absolute -top-10 -right-10 w-32 h-32 bg-brand-gold/10 rounded-full blur-2xl"></div>
                        <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-brand-green/10 rounded-full blur-2xl"></div>
                        
                        <div className="mb-4 relative z-10">
                            <ImaraDiskIcon className="w-16 h-16 text-brand-navy-dark dark:text-white" />
                        </div>
                        
                        <h2 className="text-2xl font-display font-bold text-brand-navy-dark dark:text-white mb-2 relative z-10">
                            Experience the Full Power of Imara
                        </h2>
                        
                        <p className="text-gray-600 dark:text-gray-300 text-sm mb-8 leading-relaxed max-w-xs mx-auto relative z-10">
                            Join our community to unlock exclusive features, save items, track your impact, and build your African legacy.
                        </p>

                        <div className="flex flex-col gap-3 w-full relative z-10">
                            <Button 
                                variant="primary" 
                                onClick={handleSignup} 
                                className="w-full !bg-brand-gold !text-brand-navy-dark font-bold hover:shadow-gold-glow"
                            >
                                Create Free Account
                            </Button>
                            <button 
                                onClick={close} 
                                className="text-sm font-medium text-gray-400 hover:text-brand-navy-dark dark:hover:text-white transition-colors py-2"
                            >
                                Maybe Later
                            </button>
                        </div>
                        
                        <button 
                            onClick={close} 
                            className="absolute top-4 right-4 p-1 rounded-full text-gray-300 hover:text-gray-500 hover:bg-gray-100 dark:hover:bg-white/10 transition-all"
                        >
                            <XIcon className="w-5 h-5" />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SignupPromptModal;
