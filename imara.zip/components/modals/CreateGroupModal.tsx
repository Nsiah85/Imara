

import React, { useState, useEffect, useCallback } from 'react';
import type { Participant } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { XIcon, SearchIcon, CheckCircleIcon } from '../icons/Icons.tsx';

interface CreateGroupModalProps {
  allUsers: Participant[];
  onClose: () => void;
  onCreateGroup: (groupData: { name: string, participants: Participant[] }) => void;
}

const CreateGroupModal: React.FC<CreateGroupModalProps> = ({ allUsers, onClose, onCreateGroup }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUsers, setSelectedUsers] = useState<Participant[]>([]);
  const [groupName, setGroupName] = useState('');
  const [isClosing, setIsClosing] = useState(false);

  const filteredUsers = allUsers.filter(user =>
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) && !selectedUsers.some(su => su.id === user.id)
  );

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => { if (e.key === 'Escape') close(); };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);

  const handleToggleUser = (user: Participant) => {
    setSelectedUsers(prev =>
      prev.some(su => su.id === user.id)
        ? prev.filter(su => su.id !== user.id)
        : [...prev, user]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (groupName.trim() && selectedUsers.length > 0) {
        onCreateGroup({ name: groupName.trim(), participants: selectedUsers });
    }
  };

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close} role="dialog" aria-modal="true"
    >
      <div
        className={`relative bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md max-h-[70vh] flex flex-col transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        <header className="p-4 border-b dark:border-gray-700 flex-shrink-0">
          <h2 className="text-xl font-display font-semibold text-brand-navy-dark dark:text-white">Create a Group</h2>
        </header>
        
        <form onSubmit={handleSubmit} className="flex-grow flex flex-col min-h-0">
            <main className="p-4 space-y-4 overflow-y-auto">
                <div>
                    <label htmlFor="groupName" className="text-sm font-medium text-gray-700 dark:text-gray-300">Group Name</label>
                    <input
                        type="text"
                        id="groupName"
                        value={groupName}
                        onChange={e => setGroupName(e.target.value)}
                        placeholder="e.g., Project Team, Family Chat"
                        className="mt-1 w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md py-2 px-4 focus:ring-brand-gold focus:border-brand-gold"
                        required
                    />
                </div>
                <div>
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Add Members</label>
                    <div className="relative mt-1">
                        <SearchIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                        type="text"
                        placeholder="Search people..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md py-2 pl-10 pr-4 focus:ring-brand-gold focus:border-brand-gold"
                        />
                    </div>
                </div>
                
                <div className="space-y-2 max-h-48 overflow-y-auto">
                    {selectedUsers.map(user => (
                        <div key={user.id} className="flex items-center gap-3 p-2 bg-brand-gold/10 rounded-md">
                            <img src={user.avatarUrl} alt={user.name} className="w-8 h-8 rounded-full"/>
                            <p className="flex-grow font-semibold text-sm">{user.name}</p>
                            <button type="button" onClick={() => handleToggleUser(user)}>
                                <XIcon className="w-5 h-5 text-gray-500"/>
                            </button>
                        </div>
                    ))}
                    {filteredUsers.map(user => (
                        <button
                            type="button"
                            key={user.id}
                            onClick={() => handleToggleUser(user)}
                            className="w-full text-left flex items-center gap-4 p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md"
                        >
                            <img src={user.avatarUrl} alt={user.name} className="w-8 h-8 rounded-full"/>
                            <div>
                                <p className="font-semibold text-sm text-brand-navy-dark dark:text-white">{user.name}</p>
                                <p className="text-xs text-gray-500 dark:text-gray-400">{user.role}</p>
                            </div>
                        </button>
                    ))}
                </div>
            </main>

            <footer className="p-4 border-t dark:border-gray-700 bg-gray-50 dark:bg-gray-900 flex-shrink-0 flex justify-end gap-3">
                <Button type="button" variant="outline" onClick={close}>Cancel</Button>
                <Button type="submit" disabled={!groupName.trim() || selectedUsers.length === 0}>
                    Create Group ({selectedUsers.length + 1})
                </Button>
            </footer>

            <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 dark:hover:text-white transition-colors z-10" aria-label="Close modal">
            <XIcon className="w-6 h-6" />
            </button>
        </form>
      </div>
    </div>
  );
};

export default CreateGroupModal;