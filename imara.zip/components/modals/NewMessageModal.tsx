
import React, { useState, useEffect, useCallback } from 'react';
import type { Participant } from '../../types';
import Button from '../ui/Button';
import { XIcon, SearchIcon, UsersIcon, UserGroupIcon, VerifiedBadgeIcon } from '../icons/Icons';

interface NewMessageModalProps {
  allUsers: Participant[];
  onClose: () => void;
  onStartConversation: (participant: Participant) => void;
}

type FilterType = 'all' | 'contacts' | 'verified';

const NewMessageModal: React.FC<NewMessageModalProps> = ({ allUsers, onClose, onStartConversation }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState<FilterType>('all');
  const [isClosing, setIsClosing] = useState(false);

  const filteredUsers = allUsers.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) || user.role?.toLowerCase().includes(searchTerm.toLowerCase());
    if (!matchesSearch) return false;
    
    if (activeFilter === 'verified') return user.isVerified;
    // In a real app, 'contacts' would check the user's contact list
    return true;
  });

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';

  return (
    <div
      className={`fixed inset-0 z-[100] flex items-center justify-center bg-brand-off-white dark:bg-gray-900 transition-opacity duration-300 ${backdropAnimation}`}
      role="dialog"
    >
      <div className={`w-full h-full max-w-4xl mx-auto flex flex-col bg-white dark:bg-gray-800 shadow-2xl relative ${modalAnimation}`}>
        
        {/* Header */}
        <div className="p-6 border-b dark:border-gray-700 flex justify-between items-center">
            <h2 id="new-message-title" className="text-2xl font-display font-bold text-brand-navy-dark dark:text-white">New Gossip</h2>
            <button onClick={close} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700">
                <XIcon className="w-6 h-6 text-gray-500 dark:text-gray-300" />
            </button>
        </div>

        {/* Search & Filters */}
        <div className="p-6 space-y-4 border-b dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50">
             <div className="relative">
                <SearchIcon className="w-5 h-5 text-gray-400 absolute left-4 top-1/2 -translate-y-1/2" />
                <input
                    type="text"
                    placeholder="Search people, partners, or groups..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl py-3 pl-12 pr-4 focus:ring-2 focus:ring-brand-gold focus:border-transparent transition-shadow shadow-sm"
                    autoFocus
                />
            </div>
            <div className="flex gap-2">
                <button onClick={() => setActiveFilter('all')} className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${activeFilter === 'all' ? 'bg-brand-navy-dark text-white' : 'bg-gray-200 text-gray-600 dark:bg-gray-700 dark:text-gray-300'}`}>All</button>
                <button onClick={() => setActiveFilter('contacts')} className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${activeFilter === 'contacts' ? 'bg-brand-navy-dark text-white' : 'bg-gray-200 text-gray-600 dark:bg-gray-700 dark:text-gray-300'}`}>My Contacts</button>
                <button onClick={() => setActiveFilter('verified')} className={`px-4 py-2 rounded-full text-sm font-medium transition-colors flex items-center gap-1 ${activeFilter === 'verified' ? 'bg-brand-navy-dark text-white' : 'bg-gray-200 text-gray-600 dark:bg-gray-700 dark:text-gray-300'}`}><VerifiedBadgeIcon className="w-3 h-3"/> Verified</button>
            </div>
        </div>
        
        {/* List */}
        <div className="flex-grow overflow-y-auto p-4">
          {filteredUsers.length > 0 ? (
            <ul className="space-y-2">
              {filteredUsers.map(user => (
                <li key={user.id}>
                  <button
                    onClick={() => onStartConversation(user)}
                    className="w-full text-left flex items-center gap-4 p-4 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-xl transition-colors group"
                  >
                    <div className="relative flex-shrink-0">
                        <img src={user.avatarUrl} alt={user.name} className="w-12 h-12 rounded-full object-cover border border-gray-200 dark:border-gray-600" />
                         {user.isOnline && (
                            <span className="absolute bottom-0 right-0 block h-3 w-3 rounded-full bg-green-500 ring-2 ring-white dark:ring-gray-800" />
                        )}
                    </div>
                    <div className="flex-grow">
                      <div className="flex items-center gap-2">
                          <p className="font-bold text-lg text-brand-navy-dark dark:text-white group-hover:text-brand-green transition-colors">{user.name}</p>
                          {user.isVerified && <VerifiedBadgeIcon className="w-4 h-4 text-brand-gold"/>}
                      </div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{user.role}</p>
                    </div>
                    <div className="text-brand-green opacity-0 group-hover:opacity-100 transition-opacity font-bold text-sm">
                        Start Chat
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-center text-gray-500 space-y-4">
              <UsersIcon className="w-16 h-16 opacity-20"/>
              <p>No results found for "{searchTerm}".</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default NewMessageModal;
