
import React, { useState } from 'react';
import Button from '../ui/Button';
import { XIcon, VideoCameraIcon } from '../icons/Icons';
import { useNavigate } from 'react-router-dom';

const GoLiveModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const navigate = useNavigate();
    const [title, setTitle] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleStartStream = () => {
        if (!title.trim()) return;
        setIsLoading(true);

        // Simulate updating global state (in real app this hits API)
        const eventSettings = {
            isActive: true,
            eventName: title,
            bannerText: `Live: ${title}`,
            startTime: new Date().toISOString(),
            durationMinutes: 60
        };
        localStorage.setItem('imara_live_event', JSON.stringify(eventSettings));

        setTimeout(() => {
            setIsLoading(false);
            onClose();
            navigate('/live/my-stream'); // Redirect to stream view
            // Trigger feed refresh if listener is set up
            window.dispatchEvent(new CustomEvent('refresh-toast-feed'));
        }, 1500);
    };

    return (
        <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white dark:bg-brand-navy-dark rounded-2xl shadow-xl w-full max-w-md p-6 relative">
                <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <VideoCameraIcon className="w-8 h-8 text-red-600" />
                    </div>
                    <h2 className="text-2xl font-bold text-brand-navy-dark dark:text-white">Go Live</h2>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Notify your followers and start streaming.</p>
                </div>
                
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Stream Title</label>
                        <input 
                            type="text" 
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                            placeholder="e.g. New Collection Launch!" 
                            className="w-full p-3 border rounded-md bg-gray-50 dark:bg-gray-800 dark:border-gray-600 dark:text-white focus:ring-2 focus:ring-red-500"
                        />
                    </div>
                    <Button 
                        onClick={handleStartStream} 
                        disabled={!title.trim() || isLoading} 
                        className="w-full !bg-red-600 hover:!bg-red-700 border-none text-white flex justify-center items-center gap-2"
                    >
                        {isLoading ? 'Starting...' : 'Start Live Stream'}
                    </Button>
                </div>

                <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"><XIcon className="w-5 h-5"/></button>
            </div>
        </div>
    );
};

export default GoLiveModal;
