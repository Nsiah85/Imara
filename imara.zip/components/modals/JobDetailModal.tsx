import React, { useState, useEffect, useCallback } from 'react';
import type { JobListing, JobApplicant } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { XIcon, GlobeIcon, CalendarDaysIcon, BriefcaseIcon } from '../icons/Icons.tsx';
import JobApplicationModal from './JobApplicationModal.tsx';

interface JobDetailModalProps {
  job: JobListing;
  onClose: () => void;
}

const JobDetailModal: React.FC<JobDetailModalProps> = ({ job, onClose }) => {
    const [isClosing, setIsClosing] = useState(false);
    const [isApplying, setIsApplying] = useState(false);

    const close = useCallback(() => {
        setIsClosing(true);
        setTimeout(onClose, 300);
    }, [onClose]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'Escape') close();
        };
        document.addEventListener('keydown', handleKeyDown);
        document.body.style.overflow = 'hidden';
        return () => {
            document.removeEventListener('keydown', handleKeyDown);
            document.body.style.overflow = 'auto';
        };
    }, [close]);

    const handleApplySuccess = (newApplicant: JobApplicant) => {
        try {
            const storedApplicants = localStorage.getItem('imara_job_applicants') || '[]';
            const applicants = JSON.parse(storedApplicants);
            applicants.push(newApplicant);
            localStorage.setItem('imara_job_applicants', JSON.stringify(applicants));
        } catch (error) {
            console.error("Failed to save job application", error);
        }
        // The JobApplicationModal shows its own success message and will close itself,
        // so we just need to close the detail modal behind it.
        setIsApplying(false);
    };

    const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
    const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';

    return (
        <>
            <div
                className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
                onClick={close} role="dialog" aria-modal="true" aria-labelledby="job-title"
            >
                <div
                    className={`relative bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col transition-all duration-300 ${modalAnimation}`}
                    onClick={(e) => e.stopPropagation()}
                >
                    <header className="p-6 border-b dark:border-gray-700 flex items-start gap-4 flex-shrink-0">
                        <img src={job.companyLogoUrl} alt={`${job.companyName} logo`} className="w-16 h-16 object-contain"/>
                        <div>
                            <p className="text-sm text-brand-gray dark:text-gray-400">{job.companyName}</p>
                            <h2 id="job-title" className="text-2xl font-display font-bold text-brand-navy-dark dark:text-white">{job.title}</h2>
                        </div>
                    </header>

                    <main className="p-8 space-y-6 overflow-y-auto">
                        <div className="flex flex-wrap gap-x-6 gap-y-3 text-gray-600 dark:text-gray-300">
                             <div className="flex items-center gap-2"><GlobeIcon className="w-5 h-5 text-gray-400" /><span>{job.location}</span></div>
                             <div className="flex items-center gap-2"><BriefcaseIcon className="w-5 h-5 text-gray-400" /><span>{job.industry}</span></div>
                             <div className="flex items-center gap-2"><CalendarDaysIcon className="w-5 h-5 text-gray-400" /><span>{job.jobType}</span></div>
                        </div>
                        <div>
                           <h3 className="font-semibold text-brand-navy-dark dark:text-white mb-2">Job Description</h3>
                           <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{job.description}</p>
                        </div>
                        <div>
                           <h3 className="font-semibold text-brand-navy-dark dark:text-white mb-2">Requirements</h3>
                           <ul className="list-disc list-inside space-y-1 text-gray-700 dark:text-gray-300">
                               {job.requirements.map((req, i) => <li key={i}>{req}</li>)}
                           </ul>
                        </div>
                    </main>

                    <footer className="p-6 bg-gray-50 dark:bg-gray-700/50 rounded-b-lg flex justify-end gap-4 mt-auto flex-shrink-0">
                        <Button type="button" variant="outline" onClick={close}>Close</Button>
                        <Button type="button" onClick={() => setIsApplying(true)}>Apply Now</Button>
                    </footer>

                    <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 dark:hover:text-white transition-colors z-10" aria-label="Close job details">
                        <XIcon className="w-6 h-6" />
                    </button>
                </div>
            </div>
            {isApplying && (
                <JobApplicationModal 
                    job={job}
                    onClose={() => setIsApplying(false)}
                    onApply={handleApplySuccess}
                />
            )}
        </>
    );
};

export default JobDetailModal;
