
import React, { useState, useEffect, useCallback } from 'react';
import type { Cause, Investment } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { XIcon } from '../icons/Icons.tsx';

interface ContentEditModalProps {
  item: Partial<Cause | Investment> | null;
  type: 'cause' | 'investment';
  onClose: () => void;
  onSave: (content: Cause | Investment) => void;
}

const ContentEditModal: React.FC<ContentEditModalProps> = ({ item, type, onClose, onSave }) => {
  const [formData, setFormData] = useState<Partial<Cause | Investment>>(item || {});
  const [isClosing, setIsClosing] = useState(false);

  const close = useCallback(() => {
    setIsClosing(true);
    setTimeout(onClose, 300);
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [close]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
        const { checked } = e.target as HTMLInputElement;
        setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
        setFormData(prev => ({ ...prev, [name]: (name === 'goal' || name === 'raised') ? Number(value) : value }));
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
          const file = e.target.files[0];
          setFormData(prev => ({ ...prev, imageUrl: URL.createObjectURL(file) }));
      }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData as Cause | Investment);
  };

  const backdropAnimation = isClosing ? 'opacity-0' : 'opacity-100';
  const modalAnimation = isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100';
  const inputClass = "mt-1 block w-full bg-brand-navy-dark text-white border border-brand-emerald rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent placeholder:text-gray-400";
  const fileInputClass = `${inputClass} file:mr-4 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-brand-gold file:text-brand-navy-dark hover:file:bg-brand-gold-light cursor-pointer`;


  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${backdropAnimation}`}
      onClick={close} role="dialog" aria-modal="true" aria-labelledby="edit-content-title"
    >
      <div
        className={`relative bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto transition-all duration-300 ${modalAnimation}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b">
          <h2 id="edit-content-title" className="text-xl font-display font-semibold text-brand-navy-dark">
            {item?.id ? 'Edit' : 'Add'} {type === 'cause' ? 'Cause' : 'Investment'}
          </h2>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-8 space-y-6">
            <input type="hidden" name="id" value={formData.id || ''} />
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700">Title</label>
              <input type="text" name="title" id="title" value={formData.title || ''} onChange={handleChange} required className={inputClass} />
            </div>
            {type === 'cause' && (
              <>
                <div>
                  <label htmlFor="organization" className="block text-sm font-medium text-gray-700">Organization</label>
                  <input type="text" name="organization" id="organization" value={(formData as Cause).organization || ''} onChange={handleChange} required className={inputClass} />
                </div>
                <div className="flex items-center">
                    <input id="isFeatured" name="isFeatured" type="checkbox" checked={(formData as Cause).isFeatured || false} onChange={handleChange} className="h-4 w-4 rounded border-gray-300 text-brand-gold focus:ring-brand-gold" />
                    <label htmlFor="isFeatured" className="ml-3 block text-sm font-medium text-gray-700">Mark as Featured</label>
                </div>
              </>
            )}
            {type === 'investment' && (
              <div>
                <label htmlFor="vendorName" className="block text-sm font-medium text-gray-700">Vendor Name</label>
                <input type="text" name="vendorName" id="vendorName" value={(formData as Investment).vendorName || ''} onChange={handleChange} required className={inputClass} />
              </div>
            )}
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700">Description</label>
              <textarea name="description" id="description" rows={4} value={formData.description || ''} onChange={handleChange} required className={inputClass}></textarea>
            </div>
            {type === 'investment' && (
              <>
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="goal" className="block text-sm font-medium text-gray-700">Goal (USD)</label>
                    <input type="number" name="goal" id="goal" value={(formData as Investment).goal || ''} onChange={handleChange} required className={inputClass} />
                  </div>
                  <div>
                    <label htmlFor="raised" className="block text-sm font-medium text-gray-700">Raised (USD)</label>
                    <input type="number" name="raised" id="raised" value={(formData as Investment).raised || ''} onChange={handleChange} required className={inputClass} />
                  </div>
                </div>
                <div>
                  <label htmlFor="videoUrl" className="block text-sm font-medium text-gray-700">Video URL (for Top Priority)</label>
                  <input type="text" name="videoUrl" id="videoUrl" value={(formData as Investment).videoUrl || ''} onChange={handleChange} className={inputClass} />
                </div>
                <div className="flex items-center">
                    <input id="isTopPriority" name="isTopPriority" type="checkbox" checked={(formData as Investment).isTopPriority || false} onChange={handleChange} className="h-4 w-4 rounded border-gray-300 text-brand-gold focus:ring-brand-gold" />
                    <label htmlFor="isTopPriority" className="ml-3 block text-sm font-medium text-gray-700">Mark as Top Priority / Featured</label>
                </div>
              </>
            )}
             <div>
                <label htmlFor="imageUrl" className="block text-sm font-medium text-gray-700">Image</label>
                <input type="file" name="imageUrl" id="imageUrl" onChange={handleFileChange} className={fileInputClass} accept="image/*" />
                 {formData.imageUrl && <img src={formData.imageUrl} alt="Preview" className="mt-4 rounded-md max-h-40"/>}
            </div>
          </div>
          <div className="p-6 bg-gray-50 rounded-b-lg flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={close}>Cancel</Button>
            <Button type="submit">Save</Button>
          </div>
        </form>
        <button onClick={close} className="absolute top-4 right-4 text-gray-400 hover:text-gray-800 transition-colors z-10" aria-label="Close modal">
          <XIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default ContentEditModal;
