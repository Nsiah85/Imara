
import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import { useChat } from '../../hooks/useChat.ts';
import ChatWindow from './ChatWindow.tsx';
import { MonkixAIIcon, XIcon } from '../icons/Icons.tsx';
import WelcomePopup from './WelcomePopup.tsx';
import { useTheme } from '../../contexts/ThemeContext.tsx';

const ChatWidget: React.FC = () => {
    const location = useLocation();
    const [isOpen, setIsOpen] = useState(false);
    const { messages, isLoading, sendMessage, error } = useChat();
    const { theme } = useTheme();

    // Whitelist routes where Monkix AI should appear
    const allowedRoutes = [
        '/shop-hub', '/shop', '/feel-afro', '/edwaso', '/automotive', // ShopHub and its children
        '/invest', // Impact page
        '/find-talent', '/marketplace', '/find-job' // AfroTalent and its children
    ];
    
    // Exact match or sub-paths for whitelist
    const shouldShow = allowedRoutes.some(route => location.pathname === route || location.pathname.startsWith(route + '/'));

    if (!shouldShow) {
        return null;
    }

    const toggleChat = () => setIsOpen(!isOpen);

    const windowAnimation = isOpen ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-4 scale-95 pointer-events-none';
    const buttonThemeClass = theme === 'light' 
        ? 'bg-white hover:bg-gray-100 focus:ring-brand-navy'
        : 'bg-brand-navy-dark hover:bg-black focus:ring-brand-gold';

    return (
        <>
            <div className="fixed bottom-24 right-4 sm:bottom-6 sm:right-6 z-[60] group flex items-center flex-row-reverse gap-3">
                <WelcomePopup />
                
                {/* Main Button */}
                <div className="relative">
                    {!isOpen && (
                        <div className="absolute inset-0 rounded-full bg-brand-gold/30 animate-ping"></div>
                    )}
                    
                    <button
                        onClick={toggleChat}
                        className={`relative flex items-center justify-center w-16 h-16 rounded-full shadow-xl border-2 border-brand-gold/50 focus:outline-none focus:ring-2 focus:ring-offset-2 transition-all duration-300 overflow-hidden z-10 ${buttonThemeClass}`}
                        aria-label={isOpen ? "Close chat" : "Open chat"}
                        title={isOpen ? "Close AI Assistant" : "Ask Monkix AI"}
                        aria-expanded={isOpen}
                    >
                        <div className="relative w-full h-full">
                            <div className={`absolute inset-0 flex items-center justify-center transition-all duration-300 transform ${isOpen ? 'rotate-90 scale-0 opacity-0' : 'rotate-0 scale-100 opacity-100'}`}>
                                 <MonkixAIIcon className="w-full h-full p-2" />
                            </div>
                            <div className={`absolute inset-0 flex items-center justify-center transition-all duration-300 transform ${isOpen ? 'rotate-0 scale-100 opacity-100' : '-rotate-90 scale-0 opacity-0'}`}>
                                <XIcon className="w-8 h-8 text-brand-navy-dark dark:text-white" />
                            </div>
                        </div>
                    </button>
                </div>

                {/* Hover Label */}
                {!isOpen && (
                    <div className="bg-brand-navy-dark text-white text-sm font-medium py-1.5 px-4 rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 transform translate-x-2 group-hover:translate-x-0 whitespace-nowrap border border-brand-gold/20 hidden sm:block">
                        Ask Monkix AI
                        <div className="absolute right-[-4px] top-1/2 -translate-y-1/2 w-2 h-2 bg-brand-navy-dark transform rotate-45 border-t border-r border-brand-gold/20"></div>
                    </div>
                )}
            </div>
            
            <div className={`fixed bottom-44 right-4 sm:bottom-24 sm:right-8 z-[70] transition-all duration-300 ease-out origin-bottom-right ${windowAnimation}`}>
                {isOpen && (
                    <ChatWindow
                        messages={messages}
                        isLoading={isLoading}
                        onSendMessage={sendMessage}
                        onClose={toggleChat}
                        error={error}
                    />
                )}
            </div>
        </>
    );
};

export default ChatWidget;
