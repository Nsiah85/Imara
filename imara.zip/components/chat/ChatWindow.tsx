
import React, { useState, useRef, useEffect } from 'react';
import type { ChatMessage as Message } from '../../types.ts';
import ChatMessage from './ChatMessage.tsx';
import { 
    XIcon, PaperAirplaneIcon, FaceSmileIcon, PaperclipIcon, 
    MicrophoneIcon, BookOpenIcon, SearchIcon, MonkixAIIcon, 
    ChatBubbleIcon, ChevronDownIcon, GlobeIcon, PhotoIcon
} from '../icons/Icons.tsx';
import Button from '../ui/Button.tsx';

interface ChatWindowProps {
    messages: Message[];
    isLoading: boolean;
    onSendMessage: (message: string, attachment?: File | null, tool?: 'search' | 'maps') => void;
    onClose: () => void;
    error: string | null;
}

type ActiveTab = 'chat' | 'help';

const helpArticles = [
    { title: "How to track impact?", subtitle: "Learn how your purchases plant trees and fund education.", content: "When you make a purchase on Imara, our platform automatically sets aside a portion to support local communities. Head to the 'Impact' page to see the total number of trees planted, artisans supported, and schools funded. You can also view a transparent breakdown in your user dashboard under the 'My Impact' tab." },
    { title: "Vendor Verification", subtitle: "Understand our vetting process for artisans and partners.", content: "We enforce a strict verification process. All vendors and professionals must submit a business registration or ID, undergo a background check, and provide portfolios or proof of certification for skilled labor. Look for the 'Verified Artisan' badge on their profile to ensure you are transacting with a vetted partner." },
    { title: "Shipping & Delivery", subtitle: "Estimated times for local and international shipping.", content: "Local shipping within major African cities generally takes 1-3 business days depending on the vendor. International and cross-border shipping typically takes 5-14 business days. The exact timeframe is calculated at checkout. You can track your shipment live via the 'Orders' section in your account." },
    { title: "Return Policy", subtitle: "Guidelines for returning products or cancelling bookings.", content: "Items can be returned within 14 days of delivery if they are defective, damaged, or not as described. Please retain all packaging and tags. Perishable goods like fresh groceries (Edwaso) cannot be returned but can be refunded if spoiled upon arrival. Booking cancellations must occur at least 48 hours before the service to receive a full refund." },
    { title: "Payment Methods", subtitle: "Supported options: Mobile Money, Cards, and more.", content: "We support a wide array of payment methods optimized for Africa. You can pay securely via Paystack and Flutterwave using Mobile Money (MTN, Vodafone, Airtel), as well as direct Bank Transfers, Visa, Mastercard, and Apple Pay." },
];

const HelpArticleItem: React.FC<{ 
    title: string; 
    subtitle: string; 
    content: string; 
    isExpanded: boolean; 
    onClick: () => void 
}> = ({ title, subtitle, content, isExpanded, onClick }) => (
    <div 
        className="flex flex-col p-3 hover:bg-gray-50 cursor-pointer border-b border-gray-100 last:border-0 group transition-colors"
        onClick={onClick}
    >
        <div className="flex items-center justify-between">
            <div className="flex items-start gap-3">
                <div className="text-brand-navy-dark mt-1">
                    <BookOpenIcon className="w-5 h-5" />
                </div>
                <div>
                    <h4 className="text-sm font-bold text-gray-800 group-hover:text-brand-green-dark transition-colors">{title}</h4>
                    <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">{subtitle}</p>
                </div>
            </div>
            <ChevronDownIcon className={`w-4 h-4 text-gray-400 transform transition-transform ${isExpanded ? 'rotate-0' : '-rotate-90'}`} />
        </div>
        {isExpanded && (
            <div className="mt-3 pl-8 text-sm text-gray-600 border-l border-brand-gold ml-2 py-1 leading-relaxed animate-fade-in">
                {content}
            </div>
        )}
    </div>
);

const ChatWindow: React.FC<ChatWindowProps> = ({ messages, isLoading, onSendMessage, onClose, error }) => {
    const [expandedArticle, setExpandedArticle] = useState<string | null>(null);
    const [activeTab, setActiveTab] = useState<ActiveTab>('chat');
    const [inputText, setInputText] = useState('');
    const [selectedFile, setSelectedFile] = useState<File | null>(null);
    const [activeTool, setActiveTool] = useState<'search' | 'maps' | null>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        if (activeTab === 'chat') {
            scrollToBottom();
        }
    }, [messages, activeTab]);

    // Prevent body scroll when chat is open on mobile
    useEffect(() => {
        document.body.classList.add('overflow-hidden');
        document.documentElement.classList.add('overflow-hidden');
        return () => {
            document.body.classList.remove('overflow-hidden');
            document.documentElement.classList.remove('overflow-hidden');
        };
    }, []); 

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setSelectedFile(e.target.files[0]);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if ((inputText.trim() || selectedFile) && !isLoading) {
            onSendMessage(inputText, selectedFile, activeTool || undefined);
            setInputText('');
            setSelectedFile(null);
            setActiveTool(null);
        }
    };

    return (
        <div className="flex flex-col w-[calc(100vw-2rem)] sm:w-[400px] h-[65vh] sm:h-[80vh] max-h-[700px] bg-white rounded-xl shadow-2xl overflow-hidden border border-gray-200 font-sans" role="dialog" aria-modal="true">
            {/* Header */}
            <header className="bg-brand-navy-dark text-white p-6 rounded-t-xl relative overflow-hidden flex-shrink-0">
                {/* Pattern Overlay */}
                <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>

                <div className="relative z-10">
                    <div className="flex justify-center gap-4 mb-6">
                        <button
                            onClick={() => setActiveTab('chat')}
                            className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold transition-all ${activeTab === 'chat' ? 'bg-white text-brand-navy-dark shadow-lg' : 'bg-white/10 text-white/80 hover:bg-white/20'}`}
                        >
                            <ChatBubbleIcon className="w-4 h-4" /> Chat
                        </button>
                        <button
                            onClick={() => setActiveTab('help')}
                            className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold transition-all ${activeTab === 'help' ? 'bg-white text-brand-navy-dark shadow-lg' : 'bg-white/10 text-white/80 hover:bg-white/20'}`}
                        >
                            <BookOpenIcon className="w-4 h-4" /> Help
                        </button>
                    </div>

                    <div className="text-center">
                         <div className="w-12 h-12 mx-auto bg-white rounded-full p-0.5 mb-2 shadow-md relative">
                            <MonkixAIIcon className="w-full h-full" />
                            <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></span>
                        </div>
                        <h2 className="font-display font-bold text-xl">Monkix AI Support</h2>
                        <p className="text-xs text-white/70 mt-1">We typically reply in a few minutes</p>
                    </div>
                </div>

                <button onClick={onClose} className="absolute top-4 right-4 p-2 text-white/50 hover:text-white transition-colors z-20">
                    <XIcon className="w-6 h-6" />
                </button>
            </header>

            {/* Content Body */}
            <div className="flex-1 flex flex-col min-h-0 bg-gray-50 relative">
                {activeTab === 'chat' ? (
                    <>
                        {/* Messages Area */}
                        <div className="flex-1 overflow-y-auto p-4 space-y-4">
                             <div className="text-center my-4">
                                <span className="text-xs font-medium text-gray-400 uppercase tracking-widest bg-gray-100 px-2 py-1 rounded">Today</span>
                            </div>
                            {messages.map((msg, index) => (
                                <ChatMessage key={index} message={msg} />
                            ))}
                            {isLoading && (
                                <div className="flex items-center gap-2 text-xs text-gray-500 ml-4 animate-pulse">
                                    <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                                    <div className="w-2 h-2 bg-gray-400 rounded-full animation-delay-200"></div>
                                    <div className="w-2 h-2 bg-gray-400 rounded-full animation-delay-400"></div>
                                    Monkix is thinking...
                                </div>
                            )}
                            {error && <div className="p-3 bg-red-50 text-red-600 text-xs rounded-md text-center mx-4 border border-red-100">{error}</div>}
                            <div ref={messagesEndRef} />
                        </div>

                        {/* Input Area */}
                        <div className="p-2 bg-white border-t border-gray-100 flex-shrink-0">
                            {selectedFile && (
                                <div className="flex items-center gap-2 mb-2 p-2 bg-gray-100 rounded-lg text-xs">
                                    <PhotoIcon className="w-4 h-4 text-gray-500"/>
                                    <span className="truncate max-w-[200px]">{selectedFile.name}</span>
                                    <button onClick={() => setSelectedFile(null)}><XIcon className="w-4 h-4 text-gray-500"/></button>
                                </div>
                            )}
                            
                            {/* Tool Toggles */}
                            <div className="flex gap-2 mb-2 px-2">
                                <button 
                                    onClick={() => setActiveTool(activeTool === 'search' ? null : 'search')}
                                    className={`text-[10px] font-bold px-2 py-1 rounded-full border flex items-center gap-1 ${activeTool === 'search' ? 'bg-blue-100 text-blue-700 border-blue-200' : 'bg-gray-50 text-gray-500 border-gray-200'}`}
                                >
                                    <GlobeIcon className="w-3 h-3" /> Web Search
                                </button>
                                <button 
                                    onClick={() => setActiveTool(activeTool === 'maps' ? null : 'maps')}
                                    className={`text-[10px] font-bold px-2 py-1 rounded-full border flex items-center gap-1 ${activeTool === 'maps' ? 'bg-green-100 text-green-700 border-green-200' : 'bg-gray-50 text-gray-500 border-gray-200'}`}
                                >
                                    <SearchIcon className="w-3 h-3" /> Maps
                                </button>
                            </div>

                            <form onSubmit={handleSubmit} className="relative px-2 pb-2">
                                <textarea
                                    value={inputText}
                                    onChange={(e) => setInputText(e.target.value)}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' && !e.shiftKey) {
                                            e.preventDefault();
                                            handleSubmit(e);
                                        }
                                    }}
                                    placeholder="Compose your message..."
                                    className="w-full p-2 pb-8 border border-gray-200 rounded-lg focus:ring-2 focus:ring-brand-gold focus:border-transparent resize-none text-sm bg-gray-50 focus:bg-white transition-colors text-brand-green-dark placeholder:text-gray-400"
                                    rows={1}
                                    disabled={isLoading}
                                />
                                <div className="absolute bottom-3 left-4 flex gap-3 text-gray-400">
                                    <button type="button" className="hover:text-brand-gold transition-colors"><FaceSmileIcon className="w-4 h-4" /></button>
                                    <button type="button" onClick={() => fileInputRef.current?.click()} className="hover:text-brand-gold transition-colors"><PaperclipIcon className="w-4 h-4" /></button>
                                    <input type="file" ref={fileInputRef} onChange={handleFileSelect} className="hidden" accept="image/*" />
                                    <button type="button" className="hover:text-brand-gold transition-colors"><MicrophoneIcon className="w-4 h-4" /></button>
                                </div>
                                <button
                                    type="submit"
                                    disabled={isLoading || (!inputText.trim() && !selectedFile)}
                                    className="absolute bottom-3 right-4 p-1.5 bg-brand-navy-dark text-white rounded-full hover:bg-brand-green disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-md"
                                >
                                    <PaperAirplaneIcon className="w-4 h-4 transform rotate-90 translate-x-0.5" />
                                </button>
                            </form>
                            <div className="flex justify-center gap-4 mt-1 text-[9px] text-gray-400">
                                <a href="#" className="hover:underline hover:text-brand-navy-dark">Terms & Conditions</a>
                                <span>•</span>
                                <a href="#" className="hover:underline hover:text-brand-navy-dark">Privacy Policy</a>
                            </div>
                        </div>
                    </>
                ) : (
                    /* Help Tab Content */
                    <div className="flex flex-col h-full">
                         <div className="p-4 bg-white shadow-sm z-10 border-b border-gray-100 flex-shrink-0">
                            <h3 className="font-bold text-brand-navy-dark">Most Frequently Read Articles</h3>
                        </div>
                        <div className="flex-1 overflow-y-auto p-4">
                            <div className="bg-white rounded-lg shadow-sm border border-gray-100 divide-y divide-gray-100">
                                {helpArticles.map((article, i) => (
                                    <HelpArticleItem 
                                        key={i} 
                                        {...article} 
                                        isExpanded={expandedArticle === article.title}
                                        onClick={() => setExpandedArticle(expandedArticle === article.title ? null : article.title)}
                                    />
                                ))}
                            </div>
                        </div>
                        <div className="p-4 bg-white border-t border-gray-200 flex-shrink-0">
                            <div className="relative">
                                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                <input 
                                    type="text" 
                                    placeholder="Find help articles..." 
                                    className="w-full pl-9 pr-4 py-2.5 bg-gray-100 border-transparent rounded-full text-sm focus:bg-white focus:ring-2 focus:ring-brand-gold focus:border-transparent transition-colors"
                                />
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ChatWindow;
