import React, { useState, useEffect, useRef } from 'react';
import { XIcon } from '../icons/Icons.tsx';

const WelcomePopup: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const popupRef = useRef<HTMLDivElement>(null);

  const handleClose = () => {
    setIsVisible(false);
    try {
      sessionStorage.setItem('imara_welcome_popup_seen', 'true');
    } catch (error) {
      console.error("Failed to write to sessionStorage:", error);
    }
  };
  
  useEffect(() => {
    try {
      const hasSeenPopup = sessionStorage.getItem('imara_welcome_popup_seen');
      if (!hasSeenPopup) {
        const timer = setTimeout(() => {
          setIsVisible(true);
        }, 1500);
        return () => clearTimeout(timer);
      }
    } catch (error) {
        console.error("Could not access sessionStorage:", error);
    }
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        // Also check if the click is on the main chat widget button to avoid closing immediately
        const chatWidgetButton = document.querySelector('[aria-label="Open chat"]');
        if (
            popupRef.current && 
            !popupRef.current.contains(event.target as Node) &&
            !chatWidgetButton?.contains(event.target as Node)
        ) {
            handleClose();
        }
    };

    if (isVisible) {
        document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
        document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isVisible]);


  if (!isVisible) {
    return null;
  }

  return (
    <div ref={popupRef} className="absolute bottom-full right-0 mb-3 w-64 animate-fade-in-up">
        <div className="bg-brand-navy-dark text-white rounded-lg p-4 shadow-lg relative">
            <button
                onClick={handleClose}
                className="absolute top-2 right-2 p-1 text-white/70 hover:text-white"
                aria-label="Dismiss welcome message"
            >
                <XIcon className="w-4 h-4" />
            </button>
            <p className="text-sm">
                Akwaaba to Imara, kindly tell us what you need or make a complaint.
            </p>
            <div className="absolute top-full right-6 border-l-8 border-l-transparent border-r-8 border-r-transparent border-t-8 border-t-brand-navy-dark"></div>
        </div>
    </div>
  );
};

export default WelcomePopup;