
import React from 'react';
import { UserIcon, MonkixAIIcon } from '../icons/Icons.tsx';

// The ChatMessage type from useChat hook
interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}

const ChatMessageComponent: React.FC<{ message: ChatMessage }> = ({ message }) => {
    const isModel = message.role === 'model';

    // A simple loading indicator for streaming responses
    if (isModel && message.content === '') {
        return (
            <div className="flex items-start gap-3 animate-fade-in">
                <MonkixAIIcon className="w-8 h-8 flex-shrink-0" />
                <div className="max-w-xs md:max-w-md rounded-2xl p-3 text-sm bg-gray-200 dark:bg-brand-navy text-brand-navy-dark dark:text-white rounded-bl-none">
                    <div className="flex items-center gap-1">
                        <span className="h-2 w-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                        <span className="h-2 w-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                        <span className="h-2 w-2 bg-gray-400 rounded-full animate-bounce"></span>
                    </div>
                </div>
            </div>
        );
    }
    
    // Regular message display
    return (
        <div className={`flex items-start gap-3 animate-fade-in ${isModel ? '' : 'justify-end'}`}>
            {isModel && <MonkixAIIcon className="w-8 h-8 flex-shrink-0" />}
            <div className={`max-w-xs md:max-w-md rounded-2xl p-3 text-sm ${isModel ? 'bg-gray-200 dark:bg-brand-navy text-brand-navy-dark dark:text-white rounded-bl-none' : 'bg-brand-gold text-brand-navy-dark rounded-br-none'}`}>
                {/* A simple markdown-like renderer for links and formatting */}
                {message.content.split(/(\[.*?\]\(.*?\)|`.*?`|\*.*?\*)/g).map((part, index) => {
                    const linkMatch = part.match(/\[(.*?)\]\((.*?)\)/);
                    if (linkMatch) {
                        return <a key={index} href={linkMatch[2]} target="_blank" rel="noopener noreferrer" className="text-brand-green dark:text-brand-gold-light underline">{linkMatch[1]}</a>;
                    }
                    if (part.startsWith('`') && part.endsWith('`')) {
                        return <code key={index} className="bg-gray-300 dark:bg-gray-900 rounded px-1.5 py-0.5 text-xs font-mono">{part.slice(1,-1)}</code>;
                    }
                    if (part.startsWith('*') && part.endsWith('*')) {
                        return <strong key={index}>{part.slice(1,-1)}</strong>
                    }
                    return <span key={index}>{part}</span>;
                })}
            </div>
             {!isModel && <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center flex-shrink-0"><UserIcon className="w-5 h-5 text-gray-500"/></div>}
        </div>
    );
};

export default ChatMessageComponent;
