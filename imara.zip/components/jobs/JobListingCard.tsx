import React from 'react';
import type { JobListing } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { GlobeIcon, CalendarDaysIcon } from '../icons/Icons.tsx';

interface JobListingCardProps {
  job: JobListing;
  onViewDetails: (job: JobListing) => void;
}

const JobListingCard: React.FC<JobListingCardProps> = ({ job, onViewDetails }) => {
  const getTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    let interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + "d ago";
    return "Today";
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow border border-gray-100 dark:border-gray-700 flex flex-col sm:flex-row gap-6 items-start">
        <div className="w-16 h-16 rounded-2xl bg-gray-50 dark:bg-gray-700 flex items-center justify-center flex-shrink-0 border border-gray-100 dark:border-gray-600">
             <img src={job.companyLogoUrl} alt={job.companyName} className="w-10 h-10 object-contain" />
        </div>
        
        <div className="flex-grow">
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start mb-2">
                <div>
                    <h3 className="font-display font-bold text-xl text-brand-navy-dark dark:text-white">{job.title}</h3>
                    <p className="text-sm font-medium text-gray-500">{job.companyName}</p>
                </div>
                <span className="text-xs font-bold text-brand-green bg-brand-green/10 px-3 py-1 rounded-full mt-2 sm:mt-0 w-fit">{getTimeAgo(job.postedDate)}</span>
            </div>
            
            <div className="flex flex-wrap gap-3 my-3 text-sm text-gray-600 dark:text-gray-300">
                <div className="flex items-center gap-1.5 bg-gray-100 dark:bg-gray-700 px-3 py-1 rounded-lg"><GlobeIcon className="w-4 h-4" />{job.location}</div>
                <div className="flex items-center gap-1.5 bg-gray-100 dark:bg-gray-700 px-3 py-1 rounded-lg"><CalendarDaysIcon className="w-4 h-4" />{job.jobType}</div>
            </div>

            <div className="flex justify-end mt-2">
                <Button variant="outline" onClick={() => onViewDetails(job)} className="rounded-full !py-2 !px-6 text-sm">
                    View Details
                </Button>
            </div>
        </div>
    </div>
  );
};

export default JobListingCard;