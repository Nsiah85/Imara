
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext.tsx';
import { XIcon } from '../icons/Icons.tsx';
import Button from '../ui/Button.tsx';

const tourSteps = [
    {
        title: "Akwaaba to Imara!",
        content: "Welcome to the heartbeat of African commerce. Imara isn't just an app; it's a movement connecting you to the authenticity, talent, and spirit of the continent.",
        target: "/",
    },
    {
        title: "The Toast Feed",
        content: "Stay connected with the 'Toast' feed. It's your window into live trends, artisan stories, and community updates. Don't just scroll—engage, remix, and share the vibe.",
        target: "/",
    },
    {
        title: "ShopHub & Edwaso",
        content: "Discover the ShopHub for curated goods and visit the Edwaso Market for fresh, local foodstuffs directly from market women and farmers.",
        target: "/shop-hub",
    },
    {
        title: "AfroTalents",
        content: "Need a skilled professional? The AfroTalents Hub connects you with verified experts, from tech wizards to master craftsmen, ready to bring your vision to life.",
        target: "/find-talent",
    },
    {
        title: "Make an Impact",
        content: "Your actions matter here. Use the Impact Hub to micro-invest in a partner's business or donate to community causes. Track your influence as you grow.",
        target: "/impact",
    },
    {
        title: "Your Hub",
        content: "Your personal dashboard lives here. Track orders, manage bookings, view your impact stats, and access your saved treasures.",
        target: "/account",
    },
];

const AppTour: React.FC = () => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const [step, setStep] = useState(0);
    const [isVisible, setIsVisible] = useState(false);

    useEffect(() => {
        const isNewUser = sessionStorage.getItem('imara_is_new_user') === 'true';
        const tourCompleted = localStorage.getItem('imara_tour_completed') === 'true';
        if (user && isNewUser && !tourCompleted) {
            setIsVisible(true);
        }
    }, [user]);

    const endTour = () => {
        setIsVisible(false);
        try {
            localStorage.setItem('imara_tour_completed', 'true');
            sessionStorage.removeItem('imara_is_new_user');
        } catch (e) { console.error(e); }
    };

    const nextStep = () => {
        if (step < tourSteps.length - 1) {
            setStep(prev => prev + 1);
            navigate(tourSteps[step + 1].target);
        } else {
            endTour();
        }
    };

    const prevStep = () => {
        if (step > 0) {
            setStep(prev => prev - 1);
            navigate(tourSteps[step - 1].target);
        }
    };

    if (!isVisible) {
        return null;
    }

    const currentStep = tourSteps[step];
    
    return (
        <div className="fixed inset-0 z-[200] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 transition-opacity duration-300">
            <div className="relative bg-brand-navy-dark text-white rounded-2xl shadow-2xl p-8 max-w-md w-full text-center border-2 border-brand-gold/50 transform transition-all animate-fade-in-up">
                <div className="flex justify-center mb-4">
                    <div className="flex items-center gap-2">
                        {tourSteps.map((_, index) => (
                            <div key={index} className={`w-2 h-2 rounded-full transition-all ${index === step ? 'bg-brand-gold scale-125' : 'bg-gray-500'}`} />
                        ))}
                    </div>
                </div>

                <h2 className="text-3xl font-display font-extrabold text-brand-gold">{currentStep.title}</h2>
                <p className="mt-4 text-brand-off-white/90 leading-relaxed">{currentStep.content}</p>

                <div className="mt-8 flex items-center justify-between">
                    <Button variant="outline" onClick={prevStep} disabled={step === 0} className="!text-white !border-white/50 hover:!bg-white/10">Previous</Button>
                    <Button variant="primary" onClick={nextStep}>
                        {step === tourSteps.length - 1 ? "Get Started" : "Next"}
                    </Button>
                </div>
                
                 <button onClick={endTour} className="absolute top-4 right-4 text-gray-400 hover:text-white">
                    <XIcon className="w-6 h-6" />
                 </button>
            </div>
        </div>
    );
};

export default AppTour;
