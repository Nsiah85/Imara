
import React, { useEffect } from 'react';

interface SEOProps {
  title: string;
  description: string;
  image?: string;
}

const SEO: React.FC<SEOProps> = ({ title, description, image }) => {
  useEffect(() => {
    // Update Title
    document.title = title;

    // Helper to update meta tags
    const updateMeta = (name: string, content: string, attribute = 'name') => {
      let element = document.querySelector(`meta[${attribute}="${name}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attribute, name);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    // Update Meta Description
    updateMeta('description', description);

    // Update Open Graph tags (for social sharing)
    updateMeta('og:title', title, 'property');
    updateMeta('og:description', description, 'property');
    if (image) {
      updateMeta('og:image', image, 'property');
    }
    updateMeta('og:type', 'website', 'property');

    // Cleanup not strictly necessary for meta tags in a simple SPA, 
    // but good practice if we wanted to revert to a default state on unmount.
  }, [title, description, image]);

  return null;
};

export default SEO;
