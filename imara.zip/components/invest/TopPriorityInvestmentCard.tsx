import React from 'react';
import type { Investment } from '../../types';
import ProgressBar from '../ui/ProgressBar';
import Button from '../ui/Button';
import { useCurrency } from '../../contexts/CurrencyContext';
import { FireIcon } from '../icons/Icons';

interface TopPriorityInvestmentCardProps {
  investment: Investment;
  highestFunded: Investment;
  onPledgeNow: (investment: Investment) => void;
}

const TopPriorityInvestmentCard: React.FC<TopPriorityInvestmentCardProps> = ({ investment, highestFunded, onPledgeNow }) => {
  const { formatCurrency } = useCurrency();

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden flex flex-col lg:flex-row border-2 border-brand-gold">
      {/* Video Section */}
      <div className="lg:w-1/2 relative">
        {investment.videoUrl ? (
          <video
            src={investment.videoUrl}
            className="w-full h-64 lg:h-full object-cover"
            autoPlay
            loop
            muted
            playsInline
          />
        ) : (
          <img src={investment.imageUrl} alt={investment.title} className="w-full h-64 lg:h-full object-cover" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
        <div className="absolute top-4 left-4">
             <span className="px-3 py-1 text-xs font-semibold tracking-wider uppercase rounded-full bg-brand-gold text-brand-navy-dark">
                Top Priority
            </span>
        </div>
      </div>

      {/* Details Section */}
      <div className="lg:w-1/2 p-6 md:p-8 flex flex-col">
        <p className="text-sm text-brand-gray uppercase tracking-wider">{investment.vendorName}</p>
        <h3 className="font-display font-bold text-3xl text-brand-navy-dark mt-1">{investment.title}</h3>
        <p className="text-gray-600 mt-3 text-base flex-grow">{investment.description}</p>
        
        <div className="mt-6">
          <ProgressBar value={investment.raised} max={investment.goal} />
          <div className="flex justify-between items-center mt-2 text-sm">
            <span className="font-semibold text-brand-navy">{formatCurrency(investment.raised)} raised</span>
            <span className="text-gray-500">Goal: {formatCurrency(investment.goal)}</span>
          </div>
        </div>

        {/* Community Favorite Matrix */}
        <div className="mt-6 p-4 bg-brand-off-white/80 rounded-md border border-gray-200">
            <div className="flex items-center gap-2">
                <FireIcon className="w-5 h-5 text-red-500"/>
                <h4 className="font-bold text-sm text-brand-navy-dark">Community Favorite</h4>
            </div>
            <p className="text-xs text-gray-500 mt-1">
                Our highest-funded program right now is{' '}
                <span className="font-semibold text-brand-navy">{highestFunded.title}</span> with{' '}
                <span className="font-semibold text-brand-navy">{formatCurrency(highestFunded.raised)}</span> raised!
            </p>
        </div>

        <div className="mt-8">
          <Button variant="primary" size="lg" className="w-full" onClick={() => onPledgeNow(investment)}>Pledge Now</Button>
        </div>
      </div>
    </div>
  );
};

export default TopPriorityInvestmentCard;