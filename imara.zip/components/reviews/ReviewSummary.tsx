import React, { useMemo } from 'react';
import type { Review } from '../../types';
import StarRating from './StarRating.tsx';
import ProgressBar from '../ui/ProgressBar.tsx';

interface ReviewSummaryProps {
  reviews: Review[];
}

const ReviewSummary: React.FC<ReviewSummaryProps> = ({ reviews }) => {
  const { averageRating, ratingDistribution, totalReviews } = useMemo(() => {
    if (reviews.length === 0) {
      return { averageRating: 0, ratingDistribution: [0, 0, 0, 0, 0], totalReviews: 0 };
    }

    const total = reviews.reduce((sum, review) => sum + review.rating, 0);
    const avg = total / reviews.length;

    const distribution = [5, 4, 3, 2, 1].map(
      (star) => reviews.filter((review) => review.rating === star).length
    );

    return { averageRating: avg, ratingDistribution: distribution, totalReviews: reviews.length };
  }, [reviews]);

  return (
    <div className="bg-brand-off-white/80 dark:bg-gray-800/50 p-6 rounded-lg">
      <h3 className="text-xl font-display font-bold text-brand-navy-dark dark:text-white mb-4">Customer Reviews</h3>
      <div className="flex flex-col sm:flex-row items-center gap-6">
        <div className="text-center">
          <p className="text-5xl font-display font-bold text-brand-navy-dark dark:text-white">
            {averageRating.toFixed(1)}
          </p>
          <StarRating rating={averageRating} iconClassName="w-6 h-6" />
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Based on {totalReviews} reviews</p>
        </div>
        <div className="w-full flex-grow">
          {ratingDistribution.map((count, index) => {
            const star = 5 - index;
            const percentage = totalReviews > 0 ? (count / totalReviews) * 100 : 0;
            return (
              <div key={star} className="flex items-center gap-3">
                <span className="text-sm font-medium text-gray-600 dark:text-gray-300">{star} star</span>
                <div className="flex-grow">
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 overflow-hidden">
                        <div
                            className="bg-brand-gold h-2 rounded-full"
                            style={{ width: `${percentage}%` }}
                        ></div>
                    </div>
                </div>
                <span className="text-sm text-gray-500 dark:text-gray-400 w-8 text-right">{count}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ReviewSummary;
