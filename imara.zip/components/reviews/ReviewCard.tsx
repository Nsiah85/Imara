import React from 'react';
import type { Review } from '../../types.ts';
import StarRating from './StarRating.tsx';
import Avatar from '../ui/Avatar.tsx';
import { VerifiedIcon } from '../icons/Icons.tsx';

interface ReviewCardProps {
  review: Review;
}

const ReviewCard: React.FC<ReviewCardProps> = ({ review }) => {
  return (
    <div className="py-6 border-b border-gray-200 dark:border-gray-700">
      <div className="flex items-center gap-3">
        <Avatar
          imageUrl={review.userAvatarUrl}
          name={review.userName}
          id={review.userId}
          className="w-10 h-10 rounded-full object-cover"
          textClassName="text-lg font-bold text-white"
        />
        <div>
          <p className="font-semibold text-brand-navy-dark dark:text-white">{review.userName}</p>
          <div className="flex items-center gap-2">
            <StarRating rating={review.rating} />
            {review.isVerifiedPurchase && (
              <span className="text-xs text-brand-green flex items-center gap-1">
                <VerifiedIcon className="w-4 h-4" /> Verified Purchase
              </span>
            )}
          </div>
        </div>
        <p className="ml-auto text-sm text-gray-500 dark:text-gray-400">
          {new Date(review.createdAt).toLocaleDateString()}
        </p>
      </div>
      <div className="mt-4 pl-13">
        <h4 className="font-bold text-gray-800 dark:text-gray-200">{review.title}</h4>
        <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed">{review.comment}</p>
      </div>
    </div>
  );
};

export default ReviewCard;