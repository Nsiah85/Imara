import React, { useState } from 'react';
import { SolidStarIcon, StarIcon } from '../icons/Icons.tsx';

interface StarRatingProps {
  rating: number;
  setRating?: (rating: number) => void;
  totalStars?: number;
  className?: string;
  iconClassName?: string;
}

const StarRating: React.FC<StarRatingProps> = ({
  rating,
  setRating,
  totalStars = 5,
  className = '',
  iconClassName = 'w-5 h-5',
}) => {
  const [hoverRating, setHoverRating] = useState(0);
  const isInteractive = !!setRating;

  return (
    <div
      className={`flex items-center ${className}`}
      onMouseLeave={() => isInteractive && setHoverRating(0)}
    >
      {[...Array(totalStars)].map((_, index) => {
        const starValue = index + 1;
        const isFilled = starValue <= (hoverRating || rating);

        return (
          <button
            key={starValue}
            type="button"
            disabled={!isInteractive}
            onClick={() => isInteractive && setRating(starValue)}
            onMouseEnter={() => isInteractive && setHoverRating(starValue)}
            className={`transition-colors duration-150 ${isInteractive ? 'cursor-pointer' : 'cursor-default'}`}
            aria-label={`Rate ${starValue} star${starValue > 1 ? 's' : ''}`}
          >
            {isFilled ? (
              <SolidStarIcon className={`${iconClassName} text-brand-gold`} />
            ) : (
              <StarIcon className={`${iconClassName} text-gray-300`} />
            )}
          </button>
        );
      })}
    </div>
  );
};

export default StarRating;
