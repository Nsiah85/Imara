import React, { useState } from 'react';
import { CreditCardIcon } from '../icons/Icons';

const PaymentMethodForm: React.FC = () => {
    const [method, setMethod] = useState<'card' | 'mobile'>('card');

    const inputClass = "block w-full bg-brand-green-dark text-brand-gold-light border border-brand-green rounded-md shadow-sm py-3 px-4 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent placeholder:text-gray-400";

    const tabButtonClass = (isActive: boolean) =>
        `w-full py-3 text-sm font-medium transition-colors ${
            isActive ? 'bg-brand-green text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
        }`;

    return (
        <div>
            <div className="flex rounded-md overflow-hidden border border-gray-200">
                <button
                    onClick={() => setMethod('card')}
                    className={`${tabButtonClass(method === 'card')} rounded-l-md`}
                >
                    Credit Card
                </button>
                <button
                    onClick={() => setMethod('mobile')}
                    className={`${tabButtonClass(method === 'mobile')} rounded-r-md`}
                >
                    Mobile Money
                </button>
            </div>

            <div className="mt-6">
                {method === 'card' && (
                    <div className="space-y-4 animate-fade-in">
                        <div>
                            <label htmlFor="cardName" className="block text-sm font-medium text-gray-700">Name on Card</label>
                            <input type="text" id="cardName" className={`mt-1 ${inputClass}`} required />
                        </div>
                        <div>
                            <label htmlFor="cardNumber" className="block text-sm font-medium text-gray-700">Card Number</label>
                            <div className="relative mt-1">
                                <input type="text" id="cardNumber" className={`${inputClass} pl-12`} placeholder="0000 0000 0000 0000" required />
                                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                    <CreditCardIcon className="w-6 h-6 text-gray-400" />
                                </div>
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="expiryDate" className="block text-sm font-medium text-gray-700">Expiry</label>
                                <input type="text" id="expiryDate" className={`mt-1 ${inputClass}`} placeholder="MM / YY" required />
                            </div>
                             <div>
                                <label htmlFor="cvc" className="block text-sm font-medium text-gray-700">CVC</label>
                                <input type="text" id="cvc" className={`mt-1 ${inputClass}`} placeholder="123" required />
                            </div>
                        </div>
                    </div>
                )}

                {method === 'mobile' && (
                     <div className="space-y-4 animate-fade-in">
                        <div>
                            <label htmlFor="mobileProvider" className="block text-sm font-medium text-gray-700">Provider</label>
                            <select id="mobileProvider" className={`mt-1 ${inputClass} appearance-none`} required>
                                <option>MTN Mobile Money</option>
                                <option>Vodafone Cash</option>
                                <option>AirtelTigo Money</option>
                                <option>M-Pesa</option>
                            </select>
                        </div>
                        <div>
                            <label htmlFor="mobileNumber" className="block text-sm font-medium text-gray-700">Phone Number</label>
                            <input type="tel" id="mobileNumber" className={`mt-1 ${inputClass}`} required />
                        </div>
                     </div>
                )}
            </div>
        </div>
    );
};

export default PaymentMethodForm;