import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import { useMonetization } from '../../contexts/MonetizationContext';
// Added missing LockClosedIcon import
import { ShieldCheckIcon, CheckCircleIcon, BanknotesIcon, LockClosedIcon } from '../icons/Icons';
import Button from '../ui/Button';

interface PaystackIntegrationProps {
    amount: number; // In USD (will be converted to local currency for Paystack)
    email: string;
    onSuccess: (reference: string) => void;
    onClose: () => void;
    metadata?: any;
}

const PaystackIntegration: React.FC<PaystackIntegrationProps> = ({ amount, email, onSuccess, onClose, metadata }) => {
    const { currency } = useCurrency();
    const [isProcessing, setIsProcessing] = useState(false);

    // Paystack usually expects amounts in kobo/pesewas (amount * 100)
    // We assume a fixed conversion for this demo or use the CurrencyContext rate
    const localAmount = Math.round(amount * 15 * 100); // Mocking GHS conversion

    const handlePaystackPayment = () => {
        setIsProcessing(true);
        
        // In a real app, you would load the Paystack script:
        // https://js.paystack.co/v1/inline.js
        
        // Simulated Paystack logic
        const handler = (window as any).PaystackPop?.setup({
            key: 'pk_test_xxxxxxxxxxxxxxxxxxxxxxxx', // Replace with process.env.VITE_PAYSTACK_KEY
            email: email,
            amount: localAmount,
            currency: currency === 'USD' ? 'GHS' : currency, // Paystack supports local African currencies
            metadata: {
                ...metadata,
                custom_fields: [
                    { display_name: "Platform", variable_name: "platform", value: "Imara" }
                ]
            },
            callback: (response: any) => {
                setIsProcessing(false);
                onSuccess(response.reference);
            },
            onClose: () => {
                setIsProcessing(false);
                onClose();
            }
        });

        // Fallback for demo since we can't load external scripts easily here
        setTimeout(() => {
            console.log("Simulating successful Paystack response...");
            onSuccess(`T${Math.random().toString(36).substring(7).toUpperCase()}`);
            setIsProcessing(false);
        }, 2000);
    };

    return (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-3xl border border-gray-100 dark:border-gray-700 shadow-xl">
            <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-brand-gold/10 rounded-full">
                    <ShieldCheckIcon className="w-6 h-6 text-brand-gold" />
                </div>
                <div>
                    <h3 className="font-display font-bold text-brand-navy-dark dark:text-white">Secure Checkout</h3>
                    <p className="text-[10px] text-gray-500 uppercase font-black tracking-widest">Powered by Paystack</p>
                </div>
            </div>

            <div className="space-y-4 mb-8">
                <div className="flex justify-between items-center py-2 border-b border-gray-50 dark:border-gray-700">
                    <span className="text-sm text-gray-500">Order Total</span>
                    <span className="font-bold text-brand-navy-dark dark:text-white">${amount.toFixed(2)}</span>
                </div>
                <div className="bg-gray-50 dark:bg-gray-900/50 p-3 rounded-xl flex items-start gap-3">
                    <BanknotesIcon className="w-5 h-5 text-brand-green mt-0.5" />
                    <p className="text-xs text-gray-600 dark:text-gray-400">
                        Supports MTN MoMo, Telecel Cash, and all major bank cards.
                    </p>
                </div>
            </div>

            <Button 
                onClick={handlePaystackPayment} 
                disabled={isProcessing}
                className="w-full flex justify-center items-center gap-2 py-4"
            >
                {isProcessing ? (
                    <div className="w-5 h-5 border-2 border-brand-navy-dark border-t-transparent rounded-full animate-spin"></div>
                ) : (
                    <>Authorize Payment &rarr;</>
                )}
            </Button>
            
            <p className="text-[9px] text-center text-gray-400 mt-4 flex items-center justify-center gap-1">
                <LockClosedIcon className="w-3 h-3" /> Encrypted Transaction Layer
            </p>
        </div>
    );
};

export default PaystackIntegration;