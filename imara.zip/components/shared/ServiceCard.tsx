
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import type { TravelService } from '../../types';
import { ServiceType } from '../../types';
import { useCurrency } from '../../contexts/CurrencyContext';
import Badge from '../ui/Badge.tsx';
import Button from '../ui/Button.tsx';
import { StarIcon, GlobeIcon, UserGroupIcon, ClockIcon } from '../icons/Icons.tsx';

interface ServiceCardProps {
  service: TravelService;
  onBookNow: (service: TravelService) => void;
  onAddToCart: (service: TravelService) => void;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ service, onBookNow, onAddToCart }) => {
    const { formatCurrency } = useCurrency();
    const [isAdded, setIsAdded] = useState(false);

    return (
        <div className="group bg-white dark:bg-gray-800 rounded-[32px] shadow-sm hover:shadow-xl transition-all duration-500 flex flex-col overflow-hidden border border-gray-100 dark:border-gray-700">
            <div className="relative h-56 overflow-hidden">
                <img src={service.imageUrl} alt={service.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                
                <div className="absolute top-4 left-4 flex gap-2">
                    <Badge className="bg-white/20 backdrop-blur-md text-white border-none font-bold text-[10px]">
                        {service.type}
                    </Badge>
                    {service.isAvailableNow && (
                        <div className="flex items-center gap-1.5 bg-green-500 text-white text-[9px] font-black uppercase tracking-wider px-2 py-1 rounded-full shadow-lg">
                            <span className="w-1.5 h-1.5 bg-white rounded-full animate-ping"></span> Live Now
                        </div>
                    )}
                </div>

                <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-white font-display font-bold text-xl leading-tight drop-shadow-md">{service.title}</h3>
                </div>
            </div>
            
            <div className="p-5 flex flex-col flex-grow">
                <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-1 text-xs text-gray-500 font-medium">
                        <GlobeIcon className="w-4 h-4 text-brand-green"/>
                        {service.location}
                    </div>
                    <div className="flex items-center gap-1 bg-brand-gold/10 px-2 py-0.5 rounded-full">
                        <StarIcon className="w-3 h-3 text-brand-gold" />
                        <span className="text-xs font-bold text-brand-navy-dark">{service.rating.toFixed(1)}</span>
                    </div>
                </div>

                {service.socialProofLabel && (
                    <div className="mb-4 flex items-center gap-2 p-2 bg-brand-off-white dark:bg-gray-700 rounded-xl text-[10px] font-bold text-brand-navy-dark dark:text-white">
                        <UserGroupIcon className="w-4 h-4 text-brand-green"/>
                        {service.socialProofLabel}
                    </div>
                )}
                
                <div className="mt-auto flex items-center justify-between">
                    <div>
                        <p className="text-[10px] text-gray-400 uppercase font-bold">Estimated Cost</p>
                        <p className="font-display font-black text-lg text-brand-navy-dark dark:text-white">
                            {formatCurrency(service.price)}
                            <span className="text-xs font-normal text-gray-400">/{service.priceUnit}</span>
                        </p>
                    </div>
                    <Button 
                        onClick={() => onBookNow(service)}
                        className="rounded-full !px-6 !py-2.5 bg-brand-navy-dark text-white hover:bg-brand-gold hover:text-brand-navy-dark border-none shadow-md"
                    >
                        Book
                    </Button>
                </div>
            </div>
        </div>
    );
};

export default ServiceCard;
