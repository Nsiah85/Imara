import React, { useState, useMemo, useEffect } from 'react';
import { Link } from 'react-router-dom';
import type { Product, EdwasoMarket } from '../../types.ts';
import { ProductCategory, VendorType } from '../../types.ts';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';
import { useCart } from '../../contexts/CartContext.tsx';
import Button from '../ui/Button.tsx';
import WishlistButton from '../ui/WishlistButton.tsx';
import { VerifiedIcon, LeafIcon, UserGroupIcon } from '../icons/Icons.tsx';
import Badge from '../ui/Badge.tsx';
import OptimizedImage from '../ui/OptimizedImage.tsx';
import { mockVendors, mockEdwasoMarkets } from '../../data/mockData.ts';

interface ProductListCardProps {
  product: Product;
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

const ProductListCard: React.FC<ProductListCardProps> = ({ product, onQuickView, onAddToCart }) => {
  const { formatCurrency } = useCurrency();
  const [isAdded, setIsAdded] = useState(false);
  const [markets, setMarkets] = useState<EdwasoMarket[]>([]);

  useEffect(() => {
    try {
        const storedMarkets = localStorage.getItem('edwaso_markets');
        if (storedMarkets) {
            const parsed = JSON.parse(storedMarkets);
            if (Array.isArray(parsed)) {
                setMarkets(parsed);
            } else {
                setMarkets(mockEdwasoMarkets);
            }
        } else {
            setMarkets(mockEdwasoMarkets);
        }
    } catch(e) {
        console.error("Failed to parse markets from localStorage", e);
        setMarkets(mockEdwasoMarkets);
    }
  }, []);
  
  const vendor = useMemo(() => mockVendors.find(v => v.brandName === product.vendor), [product.vendor]);
  const isEdwasoProduct = [ProductCategory.FOODSTUFF, ProductCategory.FRUITS_VEGETABLES, ProductCategory.PROTEINS].includes(product.category);
  const market = useMemo(() => isEdwasoProduct && product.marketId ? markets.find(m => m.id === product.marketId) : null, [product, isEdwasoProduct, markets]);


  const VendorBadge = () => {
    if (!isEdwasoProduct || !vendor) return null;

    if (vendor.vendorType === VendorType.FARMER) {
      return (
        <Badge className="bg-green-100 text-green-800" icon={<LeafIcon className="w-3 h-3" />}>
          Farmer
        </Badge>
      );
    }
    if (vendor.vendorType === VendorType.MARKET_WOMAN) {
       return (
        <Badge className="bg-orange-100 text-orange-800" icon={<UserGroupIcon className="w-4 h-4" />}>
          Market Woman
        </Badge>
      );
    }
    return null;
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onAddToCart(product);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden flex flex-col sm:flex-row group transition-all duration-300 hover:shadow-md">
      <div className="relative sm:w-1/3 lg:w-1/4 flex-shrink-0">
        <OptimizedImage
          src={product.imageUrl}
          alt={product.name}
          className="w-full h-48 sm:h-full object-cover"
        />
        <div className="absolute top-3 left-3 z-10">
          <WishlistButton product={product} />
        </div>
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <div className="flex justify-between items-start">
          <div className="flex-grow">
            <div className="flex items-center gap-2">
                <p className="text-xs text-brand-gray uppercase tracking-wider">{product.vendor}</p>
                <VendorBadge />
            </div>
            <h3 className="font-display font-semibold text-xl text-brand-green-dark group-hover:text-brand-gold transition-colors">
              <Link to={`/product/${product.id}`}>{product.name}</Link>
            </h3>
            {market && <p className="text-sm text-brand-emerald">{market.name}</p>}
          </div>
          <p className="font-display font-bold text-xl text-brand-green flex-shrink-0 ml-4">
            {formatCurrency(product.price)}
          </p>
        </div>

        <p className="text-gray-600 mt-2 text-sm flex-grow">
          {product.description.length > 150 ? `${product.description.substring(0, 150)}...` : product.description}
        </p>

        {product.isVerified && (
          <div className="flex items-center gap-2 mt-3 text-sm text-brand-green">
            <VerifiedIcon className="w-5 h-5" />
            <span>Verified Artisan</span>
          </div>
        )}

        <div className="mt-4 pt-4 border-t border-gray-100 flex flex-col sm:flex-row items-center gap-4">
          <Button
            variant="primary"
            size="md"
            className="w-full sm:w-auto"
            onClick={handleAddToCart}
            disabled={isAdded}
          >
            {isAdded ? 'Added!' : 'Add to Cart'}
          </Button>
          <Button variant="outline" size="md" className="w-full sm:w-auto" onClick={() => onQuickView(product)}>
            Quick View
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProductListCard;
