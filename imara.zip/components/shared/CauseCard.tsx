import React from 'react';
import type { Cause } from '../../types.ts';
import Button from '../ui/Button.tsx';

interface CauseCardProps {
  cause: Cause;
  onDonateNow: (cause: Cause) => void;
}

const CauseCard: React.FC<CauseCardProps> = ({ cause, onDonateNow }) => {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-sm hover:shadow-xl transition-all duration-300 ease-out flex flex-col overflow-hidden border-2 border-transparent hover:border-brand-green">
      <div className="relative h-48 overflow-hidden">
        <img src={cause.imageUrl} alt={cause.title} className="w-full h-full object-cover transition-transform duration-700 hover:scale-105" />
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <p className="text-xs text-brand-gray dark:text-gray-400 uppercase tracking-wider font-bold mb-1">{cause.organization}</p>
        <h3 className="font-display font-bold text-xl text-brand-navy-dark dark:text-white leading-tight mb-2">{cause.title}</h3>
        <p className="text-gray-600 dark:text-gray-300 text-sm flex-grow">{cause.description}</p>
        <div className="mt-6">
          <Button variant="secondary" className="w-full rounded-full" onClick={() => onDonateNow(cause)}>Donate Now</Button>
        </div>
      </div>
    </div>
  );
};

export default CauseCard;