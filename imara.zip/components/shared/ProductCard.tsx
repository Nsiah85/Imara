
import React, { useState, useMemo, useEffect } from 'react';
import type { Product, EdwasoMarket } from '../../types.ts';
import { ProductCategory, VendorType } from '../../types.ts';
import { Link } from 'react-router-dom';
import Badge from '../ui/Badge.tsx';
import Button from '../ui/Button.tsx';
import { VerifiedBadgeIcon, GlobeIcon, LeafIcon, SparklesIcon, MapPinIcon, HeartIcon, ShareIcon } from '../icons/Icons.tsx';
import { useIntersectionObserver } from '../../hooks/useIntersectionObserver.ts';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';
import WishlistButton from '../ui/WishlistButton.tsx';
import Avatar from '../ui/Avatar.tsx';
import OptimizedImage from '../ui/OptimizedImage.tsx';
import { mockVendors } from '../../data/mockData.ts';

interface ProductCardProps {
  product: Product;
  animationDelay?: number;
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onBookNow?: (product: Product) => void;
  compact?: boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, animationDelay = 75, onQuickView, onAddToCart, compact = false }) => {
  const [cardRef, isVisible] = useIntersectionObserver<HTMLDivElement>({ threshold: 0.1 });
  const [isAdded, setIsAdded] = useState(false);
  const { formatCurrency } = useCurrency();
  
  const vendor = useMemo(() => mockVendors.find(v => v.id === product.vendorId || v.brandName === product.vendor), [product]);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onAddToCart(product);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <div
      ref={cardRef}
      className={`bg-white dark:bg-gray-800 rounded-[32px] shadow-sm hover:shadow-2xl transition-all duration-500 ease-out transform hover:-translate-y-2 flex flex-col overflow-hidden border border-gray-100 dark:border-gray-700 group ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
      }`}
      style={{ transitionDelay: `${animationDelay}ms` }}
    >
      <div className="relative">
        {/* Seen in Toast Indicator */}
        {product.seenInToast && (
            <div className="absolute top-4 left-4 z-20 bg-brand-gold text-brand-navy-dark text-[10px] font-bold px-2 py-1 rounded-full flex items-center gap-1 shadow-lg animate-pulse">
                <SparklesIcon className="w-3 h-3" /> Seen in Toast
            </div>
        )}

        <OptimizedImage
          src={product.imageUrl}
          alt={product.name}
          className={`w-full ${compact ? 'h-48' : 'h-64'} object-cover cursor-pointer transition-transform duration-700 group-hover:scale-110`}
          onClick={() => onQuickView(product)}
        />
        
        <div className="absolute bottom-4 right-4 z-10 flex flex-col gap-2">
            <WishlistButton product={product} className="!bg-white/90 backdrop-blur-md shadow-md" />
            <button className="p-2 rounded-full bg-white/90 backdrop-blur-md shadow-md text-gray-500 hover:text-brand-green transition-colors" title="Share to Gist">
                <ShareIcon className="w-5 h-5" />
            </button>
        </div>
      </div>

      <div className="p-5 flex flex-col flex-grow">
        {/* Heritage & Vendor Section */}
        <div className="flex items-center justify-between mb-3">
             <Link to={`/vendor/${vendor?.storeSlug || '#'}`} className="flex items-center gap-2 group/vendor">
                <Avatar 
                    imageUrl={vendor?.brandLogoUrl} 
                    name={product.vendor} 
                    trustScore={product.trustScore}
                    className="w-8 h-8 rounded-full"
                    hasRing={true}
                />
                <div className="flex flex-col">
                    <span className="text-[10px] text-brand-gray uppercase tracking-widest font-bold group-hover/vendor:text-brand-gold transition-colors">{product.vendor}</span>
                    <span className="text-[9px] text-brand-green font-medium flex items-center gap-0.5"><MapPinIcon className="w-2 h-2"/> {product.originRegion}, {product.originCountry}</span>
                </div>
             </Link>
             <div className="flex gap-1">
                 {product.sustainabilityTags.slice(0, 1).map(tag => (
                     <Badge key={tag} className="bg-emerald-50 text-emerald-700 text-[9px] border border-emerald-100" icon={<LeafIcon className="w-2.5 h-2.5"/>}>{tag}</Badge>
                 ))}
             </div>
        </div>

        <h3 className="font-display font-bold text-lg text-brand-navy-dark dark:text-white leading-tight mb-2 group-hover:text-brand-green transition-colors line-clamp-2">
            {product.name}
        </h3>
        
        {product.storySnippet && (
            <p className="text-xs text-gray-500 italic mb-4 line-clamp-2 leading-relaxed">"{product.storySnippet}"</p>
        )}

        <div className="mt-auto pt-4 border-t border-gray-50 dark:border-gray-700 flex items-center justify-between">
            <p className="font-display font-black text-xl text-brand-navy dark:text-brand-gold-light">{formatCurrency(product.price)}</p>
            <Button
                variant="primary"
                size="sm"
                className="rounded-full !px-5 shadow-lg group-hover:shadow-gold-glow"
                onClick={handleAddToCart}
                disabled={isAdded}
            >
                {isAdded ? 'Added' : 'Get Item'}
            </Button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
