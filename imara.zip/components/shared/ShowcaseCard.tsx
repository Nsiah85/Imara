import React from 'react';
import { Link } from 'react-router-dom';
import { ShowcaseItem, Product, Professional, JobListing, TravelService } from '../../types';
import { ShoppingBagIcon, UserIcon, BriefcaseIcon, GlobeIcon } from '../icons/Icons';

interface ShowcaseCardProps {
    item: ShowcaseItem;
}

const ShowcaseCard: React.FC<ShowcaseCardProps> = ({ item }) => {
    let title = '';
    let subtitle = '';
    let imageUrl = '';
    let link = '/';
    let typeLabel = '';
    let icon: React.ReactNode = null;
    let imageContain = false;

    switch (item.itemType) {
        case 'product':
            const product = item as Product;
            title = product.name;
            subtitle = `by ${product.vendor}`;
            imageUrl = product.imageUrl;
            link = `/product/${product.id}`;
            typeLabel = 'Product';
            icon = <ShoppingBagIcon className="w-4 h-4" />;
            break;
        case 'professional':
            const prof = item as Professional;
            title = prof.name;
            subtitle = prof.professionalRole;
            imageUrl = prof.profileImageUrl;
            link = `/workman/${prof.storeSlug}`;
            typeLabel = 'Professional';
            icon = <UserIcon className="w-4 h-4" />;
            break;
        case 'job':
            const job = item as JobListing;
            title = job.title;
            subtitle = `at ${job.companyName}`;
            imageUrl = job.companyLogoUrl;
            link = `/find-job`; // Link to page, modal handled there
            typeLabel = 'Job Opening';
            icon = <BriefcaseIcon className="w-4 h-4" />;
            imageContain = true;
            break;
        case 'service':
            const service = item as TravelService;
            title = service.title;
            subtitle = `in ${service.location}`;
            imageUrl = service.imageUrl;
            link = `/feel-afro/${service.id}`;
            typeLabel = 'Experience';
            icon = <GlobeIcon className="w-4 h-4" />;
            break;
    }

    return (
        <Link to={link} className="block group bg-white/50 dark:bg-gray-800/50 rounded-lg shadow-md hover:shadow-xl hover:-translate-y-1 transition-all duration-300 overflow-hidden flex flex-col">
            <div className="relative h-48 bg-gray-200">
                <img 
                    src={imageUrl} 
                    alt={title} 
                    className={`w-full h-full ${imageContain ? 'object-contain p-4' : 'object-cover'}`}
                />
                <div className="absolute top-2 right-2">
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-full bg-brand-green/80 text-white backdrop-blur-sm">
                        {icon}
                        {typeLabel}
                    </div>
                </div>
            </div>
            <div className="p-4 flex-grow flex flex-col">
                <h3 className="font-display font-semibold text-brand-green-dark dark:text-white group-hover:text-brand-gold transition-colors">{title}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1 flex-grow">{subtitle}</p>
                <div className="mt-4 text-right text-sm font-semibold text-brand-green dark:text-brand-gold-light group-hover:text-brand-gold">
                    View More &rarr;
                </div>
            </div>
        </Link>
    );
};

export default ShowcaseCard;