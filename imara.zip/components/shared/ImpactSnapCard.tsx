
import React from 'react';
import { CulturalImpactEntry } from '../../types';
import { MapPinIcon, SparklesIcon } from '../icons/Icons';

interface ImpactSnapCardProps {
  entry: CulturalImpactEntry;
  compact?: boolean;
}

const ImpactSnapCard: React.FC<ImpactSnapCardProps> = ({ entry, compact = false }) => {
  return (
    <div className={`relative overflow-hidden rounded-3xl bg-white dark:bg-gray-800 shadow-lg border border-gray-100 dark:border-gray-700 transition-all duration-500 hover:shadow-2xl hover:-translate-y-1 group flex flex-col ${compact ? 'h-72' : 'h-96'}`}>
      {/* Visual Header */}
      <div className="relative h-2/3 overflow-hidden">
        <img 
          src={entry.imageUrl} 
          alt={entry.artistName} 
          className="w-full h-full object-cover transition-transform duration-[10000ms] group-hover:scale-110"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
        
        {/* Art Form Badge */}
        <div className="absolute top-4 left-4">
          <div className="px-3 py-1.5 bg-brand-gold/90 backdrop-blur-md rounded-full text-[10px] font-black text-brand-navy-dark uppercase tracking-widest shadow-lg flex items-center gap-1.5">
            <SparklesIcon className="w-3 h-3" />
            {entry.category}
          </div>
        </div>

        {/* Location Info */}
        <div className="absolute bottom-4 left-4 right-4">
          <h3 className="text-white font-display font-black text-2xl leading-tight group-hover:text-brand-gold transition-colors">{entry.artistName}</h3>
          <div className="flex items-center gap-1.5 mt-1 text-white/70 text-xs font-bold uppercase tracking-wider">
            <MapPinIcon className="w-3.5 h-3.5 text-brand-gold" />
            {entry.region}, {entry.country}
          </div>
        </div>
      </div>

      {/* Content Area */}
      <div className="p-5 flex flex-col flex-grow bg-white dark:bg-gray-800">
        <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed italic line-clamp-3">
          "{entry.impactStory}"
        </p>
        
        <div className="mt-auto flex justify-between items-center pt-3 border-t border-gray-50 dark:border-gray-700">
            <span className="text-[10px] font-black text-brand-green uppercase tracking-[0.2em]">Impact Legacy</span>
            <span className="text-[10px] font-bold text-gray-400">{entry.engagementCount.toLocaleString()} Influence Tts</span>
        </div>
      </div>
    </div>
  );
};

export default ImpactSnapCard;
