import React from 'react';
import type { Investment } from '../../types.ts';
import ProgressBar from '../ui/ProgressBar.tsx';
import Button from '../ui/Button.tsx';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';

interface MicroFundCardProps {
  investment: Investment;
  onPledgeNow: (investment: Investment) => void;
}

const MicroFundCard: React.FC<MicroFundCardProps> = ({ investment, onPledgeNow }) => {
  const { formatCurrency } = useCurrency();

  return (
    <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-sm hover:shadow-xl transition-all duration-300 ease-out flex flex-col overflow-hidden border-2 border-transparent hover:border-brand-gold">
      <div className="relative h-48 overflow-hidden">
        <img src={investment.imageUrl} alt={investment.title} className="w-full h-full object-cover transition-transform duration-700 hover:scale-105" />
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <p className="text-xs text-brand-gray dark:text-gray-400 uppercase tracking-wider font-bold mb-1">{investment.vendorName}</p>
        <h3 className="font-display font-bold text-xl text-brand-navy-dark dark:text-white leading-tight mb-2">{investment.title}</h3>
        <p className="text-gray-600 dark:text-gray-300 text-sm flex-grow mb-4">{investment.description}</p>
        
        <div className="mt-auto">
          <div className="flex justify-between items-center mb-1 text-sm font-medium text-brand-navy dark:text-brand-gold-light">
             <span>{formatCurrency(investment.raised)} raised</span>
             <span className="text-gray-500 dark:text-gray-400">Goal: {formatCurrency(investment.goal)}</span>
          </div>
          <ProgressBar value={investment.raised} max={investment.goal} />
        </div>
        
        <div className="mt-6">
          <Button variant="primary" className="w-full rounded-full" onClick={() => onPledgeNow(investment)}>Pledge Now</Button>
        </div>
      </div>
    </div>
  );
};

export default MicroFundCard;