
import React, { useState } from 'react';
import { LinkIcon, CheckIcon, ShareIcon, GlobeIcon } from '../icons/Icons';
import Button from '../ui/Button';

interface ShareLinkCardProps {
    title: string;
    description: string;
    urlPath: string;
    variant?: 'profile' | 'store';
}

const ShareLinkCard: React.FC<ShareLinkCardProps> = ({ title, description, urlPath, variant = 'profile' }) => {
    const [copied, setCopied] = useState(false);
    
    // Construct full URL based on current environment
    const fullUrl = `${window.location.origin}${urlPath}`;

    const handleCopy = () => {
        navigator.clipboard.writeText(fullUrl).then(() => {
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        });
    };

    const handleNativeShare = async () => {
        if (navigator.share) {
            try {
                await navigator.share({
                    title: 'Imara Link',
                    text: title,
                    url: fullUrl,
                });
            } catch (err) {
                console.error('Share failed:', err);
            }
        } else {
            handleCopy();
        }
    };

    const isStore = variant === 'store';
    const accentColor = isStore ? 'text-brand-green' : 'text-brand-gold';
    const borderColor = isStore ? 'border-brand-green' : 'border-brand-gold';
    const bgGradient = isStore ? 'from-brand-green/5 to-transparent' : 'from-brand-gold/5 to-transparent';

    return (
        <div className={`relative overflow-hidden bg-gradient-to-r ${bgGradient} border ${borderColor} rounded-2xl p-6 shadow-sm`}>
            <div className="flex flex-col md:flex-row gap-6 items-start md:items-center justify-between relative z-10">
                
                <div className="flex items-start gap-4">
                    <div className={`p-3 bg-white dark:bg-gray-800 rounded-full shadow-sm ${accentColor}`}>
                        {isStore ? <GlobeIcon className="w-6 h-6" /> : <LinkIcon className="w-6 h-6" />}
                    </div>
                    <div>
                        <h3 className="text-lg font-display font-bold text-brand-navy-dark dark:text-white">{title}</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">{description}</p>
                        <a 
                            href={urlPath} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-xs font-mono text-gray-500 hover:text-brand-navy-dark dark:hover:text-white underline decoration-dotted"
                        >
                            {fullUrl}
                        </a>
                    </div>
                </div>

                <div className="flex gap-3 w-full md:w-auto">
                    <Button 
                        onClick={handleCopy} 
                        variant="outline" 
                        size="sm" 
                        className={`flex-1 md:flex-none flex items-center justify-center gap-2 ${copied ? '!border-green-500 !text-green-600' : ''}`}
                    >
                        {copied ? <CheckIcon className="w-4 h-4"/> : <LinkIcon className="w-4 h-4"/>}
                        {copied ? 'Copied' : 'Copy Link'}
                    </Button>
                    <Button 
                        onClick={handleNativeShare} 
                        variant="secondary" 
                        size="sm" 
                        className="flex-1 md:flex-none flex items-center justify-center gap-2"
                    >
                        <ShareIcon className="w-4 h-4" /> Share
                    </Button>
                </div>
            </div>

            {/* Background decoration */}
            <div className="absolute -right-10 -bottom-10 w-32 h-32 rounded-full bg-current opacity-5 pointer-events-none text-gray-500"></div>
        </div>
    );
};

export default ShareLinkCard;
