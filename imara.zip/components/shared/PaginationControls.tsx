import React from 'react';
import { ArrowRightIcon } from '../icons/Icons.tsx';

interface PaginationControlsProps {
    currentPage: number;
    totalPages: number;
    onPageChange: (page: number) => void;
}

const PaginationControls: React.FC<PaginationControlsProps> = ({ currentPage, totalPages, onPageChange }) => {
    
    const pageNumbers = Array.from({ length: totalPages }, (_, i) => i + 1);

    const activeButtonClass = "flex items-center justify-center px-4 h-10 text-brand-gold bg-brand-green border border-brand-green hover:bg-brand-green-dark z-10 relative";
    const baseButtonClass = "flex items-center justify-center px-4 h-10 text-base font-medium text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700 transition-colors";

    return (
        <nav aria-label="Page navigation" className="flex justify-center mt-12">
            <ul className="flex items-center -space-x-px h-10 text-base">
                <li>
                    <button
                        onClick={() => onPageChange(currentPage - 1)}
                        disabled={currentPage === 1}
                        className={`${baseButtonClass} rounded-l-lg disabled:opacity-50 disabled:cursor-not-allowed`}
                    >
                        <span className="sr-only">Previous</span>
                        <ArrowRightIcon className="w-5 h-5 transform rotate-180" />
                    </button>
                </li>
                {pageNumbers.map(number => (
                    <li key={number}>
                        <button
                            onClick={() => onPageChange(number)}
                             className={currentPage === number ? activeButtonClass : baseButtonClass}
                             aria-current={currentPage === number ? 'page' : undefined}
                        >
                            {number}
                        </button>
                    </li>
                ))}
                <li>
                    <button
                        onClick={() => onPageChange(currentPage + 1)}
                        disabled={currentPage === totalPages}
                        className={`${baseButtonClass} rounded-r-lg disabled:opacity-50 disabled:cursor-not-allowed`}
                    >
                        <span className="sr-only">Next</span>
                        <ArrowRightIcon className="w-5 h-5" />
                    </button>
                </li>
            </ul>
        </nav>
    );
};

export default PaginationControls;
