
import React, { useState } from 'react';
import { useMonetization } from '../../contexts/MonetizationContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import { BanknotesIcon, SparklesIcon, StarIcon, ArrowRightIcon, XIcon, TicketIcon, ArrowUpTrayIcon, CheckCircleIcon, XCircleIcon, BoltIcon } from '../icons/Icons';
import Button from '../ui/Button';

const EarningsDashboard: React.FC = () => {
    const { profile, getLevelProgress, redeemPoints, minRedeemThresholdTokens } = useMonetization();
    const { formatCurrency } = useCurrency();
    const [showRedeemMenu, setShowRedeemMenu] = useState(false);
    const [notification, setNotification] = useState<{ type: 'success' | 'error', message: string } | null>(null);

    const isEligible = profile.tokens >= minRedeemThresholdTokens;

    const showNotification = (type: 'success' | 'error', message: string) => {
        setNotification({ type, message });
        setTimeout(() => setNotification(null), 3000);
    };

    const handleRedeemOption = async (option: string, costTorts: number) => {
        setShowRedeemMenu(false);
        const costTokens = Math.ceil(costTorts / 100);

        if (!isEligible) {
            showNotification('error', `Minimum ${minRedeemThresholdTokens} Tokens required to redeem.`);
            return;
        }

        if (profile.tokens < costTokens) {
            showNotification('error', `Insufficient Tokens. You need ${costTokens} Tokens.`);
            return;
        }

        const success = await redeemPoints(costTorts, 'shop');
        if (success) {
            showNotification('success', `Redeemed ${option}! Check your digital ledger.`);
        } else {
            showNotification('error', "Transaction failed.");
        }
    };

    return (
        <div className="relative mb-6">
            {notification && (
                <div className={`fixed top-24 left-1/2 transform -translate-x-1/2 z-[100] px-6 py-3 rounded-full shadow-xl flex items-center gap-3 animate-fade-in-down ${notification.type === 'success' ? 'bg-green-600 text-white' : 'bg-red-600 text-white'}`}>
                    {notification.type === 'success' ? <CheckCircleIcon className="w-5 h-5"/> : <XCircleIcon className="w-5 h-5"/>}
                    <span className="font-bold text-sm">{notification.message}</span>
                </div>
            )}

            <div className="absolute inset-0 overflow-hidden rounded-2xl bg-gradient-to-br from-[#0A2342] to-[#000] shadow-xl border border-white/10">
                <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10 pointer-events-none"></div>
                <div className="absolute -top-10 -right-10 w-40 h-40 bg-brand-gold/20 rounded-full blur-3xl"></div>
            </div>
            
            <div className="relative z-10 p-5 text-white">
                <div className="flex justify-between items-start">
                    <div>
                        <h2 className="text-lg font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-brand-gold to-yellow-200">
                            Earnings Matrix
                        </h2>
                        <div className="flex items-center gap-2 mt-1">
                            <div className="px-2 py-0.5 bg-brand-green/20 border border-brand-green/50 rounded text-[10px] font-bold tracking-wider text-green-400 uppercase">
                                {profile.level}
                            </div>
                        </div>
                    </div>
                    <div className="text-right">
                        <p className="text-[10px] text-gray-400 uppercase tracking-widest">Token Ledger</p>
                        <p className="text-2xl font-bold font-mono text-white flex items-center justify-end gap-2">
                             <BoltIcon className="w-5 h-5 text-brand-gold" />
                             {profile.tokens.toLocaleString()}
                        </p>
                        <p className="text-[10px] text-brand-gold font-bold">≈ {formatCurrency(profile.pendingPayout)}</p>
                    </div>
                </div>

                <div className="my-5">
                    <div className="flex justify-between text-[10px] text-gray-400 mb-1 uppercase tracking-wider">
                        <span>Tier Velocity</span>
                        <span>{Math.round(getLevelProgress())}%</span>
                    </div>
                    <div className="w-full bg-gray-800 rounded-full h-1.5 overflow-hidden">
                        <div 
                            className="bg-gradient-to-r from-brand-green to-emerald-400 h-full rounded-full transition-all duration-1000 shadow-[0_0_10px_rgba(0,165,80,0.5)]" 
                            style={{ width: `${getLevelProgress()}%` }}
                        ></div>
                    </div>
                    <div className="flex justify-between mt-1">
                        <span className="text-[9px] text-gray-500 italic">Authenticity Filter Active</span>
                        <span className="text-[10px] text-gray-400">{profile.torts.toLocaleString()} Tts total</span>
                    </div>
                </div>

                <div className="grid grid-cols-3 gap-3">
                    <div className="bg-white/5 border border-white/5 p-3 rounded-xl backdrop-blur-sm">
                        <SparklesIcon className="w-4 h-4 text-brand-gold mb-2"/>
                        <p className="text-[10px] text-gray-400">Torts (Tts)</p>
                        <p className="font-bold text-sm">{profile.torts.toLocaleString()}</p>
                    </div>
                    <div className="bg-white/5 border border-white/5 p-3 rounded-xl backdrop-blur-sm">
                        <BanknotesIcon className="w-4 h-4 text-brand-green mb-2"/>
                        <p className="text-[10px] text-gray-400">Yield</p>
                        <p className="font-bold text-sm">{formatCurrency(profile.totalEarnings)}</p>
                    </div>
                    <div className="relative">
                        <div 
                            onClick={() => setShowRedeemMenu(!showRedeemMenu)}
                            className={`p-3 rounded-xl backdrop-blur-sm flex flex-col justify-between group cursor-pointer transition-all h-full border ${isEligible ? 'bg-white/10 border-white/20 hover:bg-white/20' : 'bg-gray-800/40 border-gray-700 opacity-60'}`}
                        >
                            <div className="flex justify-between items-start">
                                <StarIcon className={`w-4 h-4 ${isEligible ? 'text-purple-400' : 'text-gray-600'}`}/>
                                <ArrowRightIcon className={`w-3 h-3 text-gray-500 group-hover:text-white transition-transform ${showRedeemMenu ? 'rotate-90' : '-rotate-45'}`}/>
                            </div>
                            <p className="text-[10px] text-gray-300 font-semibold mt-2">{isEligible ? 'Redeem' : 'Locked'}</p>
                        </div>
                        
                        {showRedeemMenu && (
                            <div className="absolute top-full right-0 mt-2 w-56 bg-brand-navy-dark border border-white/20 rounded-xl shadow-xl z-20 overflow-hidden animate-fade-in-up">
                                {!isEligible ? (
                                    <div className="p-4 text-center">
                                        <p className="text-xs text-red-400 font-bold">Not Eligible Yet</p>
                                        <p className="text-[9px] text-gray-400 mt-1">Minimum {minRedeemThresholdTokens} Tokens required.</p>
                                    </div>
                                ) : (
                                    <div className="p-2 space-y-1">
                                        <button onClick={() => handleRedeemOption('Gift Card', 5000)} className="w-full flex items-center justify-between p-2 hover:bg-white/10 rounded-lg text-left transition-colors">
                                            <div className="flex items-center gap-2">
                                                <div className="p-1.5 bg-brand-gold/20 rounded-full text-brand-gold"><TicketIcon className="w-3 h-3"/></div>
                                                <span className="text-xs font-medium text-white">Gift Card</span>
                                            </div>
                                            <span className="text-[10px] text-gray-400">50 Tokens</span>
                                        </button>
                                        <button onClick={() => handleRedeemOption('Momo Payout', 10000)} className="w-full flex items-center justify-between p-2 hover:bg-white/10 rounded-lg text-left transition-colors">
                                            <div className="flex items-center gap-2">
                                                <div className="p-1.5 bg-green-500/20 rounded-full text-green-400"><BanknotesIcon className="w-3 h-3"/></div>
                                                <span className="text-xs font-medium text-white">Momo Payout</span>
                                            </div>
                                            <span className="text-[10px] text-gray-400">100 Tokens</span>
                                        </button>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </div>
            
            {showRedeemMenu && (
                <div className="fixed inset-0 z-0" onClick={() => setShowRedeemMenu(false)}></div>
            )}
        </div>
    );
};

export default EarningsDashboard;
