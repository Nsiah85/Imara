
import React from 'react';

const LoadingSpinner: React.FC<{ className?: string }> = ({ className = 'w-12 h-12' }) => {
  return (
    <div className={`relative ${className} animate-spin`}>
       <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill="none"
        className="w-full h-full"
      >
        <defs>
          <linearGradient id="spinnerGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#00A550" />
            <stop offset="50%" stopColor="#FFD700" />
            <stop offset="100%" stopColor="#0077BE" />
          </linearGradient>
        </defs>
        <circle
            cx="12"
            cy="12"
            r="10"
            stroke="url(#spinnerGradient)"
            strokeWidth="3"
            strokeLinecap="round"
            strokeDasharray="30 30" 
            className="opacity-90"
        />
      </svg>
    </div>
  );
};

export default LoadingSpinner;
