import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeftIcon } from '../icons/Icons.tsx';

const BackButton: React.FC<{ text?: string, className?: string }> = ({ text, className = '' }) => {
    const navigate = useNavigate();
    const location = useLocation();

    const from = location.state?.from;

    // A more robust check for history in a React Router app.
    if (!from && (window.history.state === null || window.history.state.idx === 0)) {
        return null;
    }
    
    let buttonText = text || 'Back';
    if (!text && from === '/') {
      buttonText = 'Back to Feed';
    }

    return (
        <button
            onClick={() => from ? navigate(from) : navigate(-1)}
            className={`flex items-center gap-2 text-sm text-brand-green dark:text-brand-gold-light hover:text-brand-gold font-semibold ${className}`}
        >
            <ArrowLeftIcon className="w-4 h-4" />
            {buttonText}
        </button>
    );
};

export default BackButton;