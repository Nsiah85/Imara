import React from 'react';
import { Squares2X2Icon, RectangleGroupIcon, Bars3Icon } from '../icons/Icons';

export type ViewMode = 'grid' | 'tile' | 'list';

interface ViewSwitcherProps {
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
}

const ViewSwitcher: React.FC<ViewSwitcherProps> = ({ viewMode, setViewMode }) => {
  const iconData = [
    { mode: 'grid', label: 'Grid View', icon: <Squares2X2Icon className="w-5 h-5" /> },
    { mode: 'tile', label: 'Tile View', icon: <RectangleGroupIcon className="w-5 h-5" /> },
    { mode: 'list', label: 'List View', icon: <Bars3Icon className="w-5 h-5" /> },
  ];

  return (
    <div className="inline-flex items-center bg-gray-100 rounded-md p-1">
      {iconData.map(({ mode, label, icon }) => (
        <button
          key={mode}
          onClick={() => setViewMode(mode as ViewMode)}
          className={`p-2 rounded transition-colors ${
            viewMode === mode ? 'bg-white text-brand-gold shadow-sm' : 'text-gray-500 hover:text-brand-green'
          }`}
          aria-label={label}
          aria-pressed={viewMode === mode}
        >
          {icon}
        </button>
      ))}
    </div>
  );
};

export default ViewSwitcher;