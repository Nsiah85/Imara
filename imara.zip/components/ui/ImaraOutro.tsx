
import React from 'react';
import { ImaraDiskIcon } from '../icons/Icons';

export const ImaraOutro: React.FC = () => {
  return (
    <div className="absolute inset-0 z-30 bg-black flex flex-col items-center justify-center animate-fade-in pointer-events-none">
      <div className="relative">
        <div className="absolute inset-0 bg-brand-gold/20 rounded-full blur-xl animate-pulse"></div>
        <div className="animate-bounce">
            <ImaraDiskIcon className="w-24 h-24" />
        </div>
      </div>
      <h2 className="text-brand-gold font-display font-bold text-3xl mt-6 tracking-widest uppercase animate-pulse">Imara</h2>
      <p className="text-white/70 text-sm mt-2 font-light tracking-wide">Commerce in Unity</p>
    </div>
  );
};

export default ImaraOutro;
