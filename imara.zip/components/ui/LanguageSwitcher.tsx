import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { LanguageCode } from '../../types';
import { LanguageIcon } from '../icons/Icons';

const LanguageSwitcher: React.FC = () => {
    const { language, setLanguage, languages } = useLanguage();

    const handleLanguageChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setLanguage(e.target.value as LanguageCode);
    };

    return (
        <div className="relative">
            <LanguageIcon className="h-5 w-5 text-gray-500 dark:text-white/80 pointer-events-none absolute left-2 top-1/2 -translate-y-1/2" />
            <select
                id="language-select"
                name="language"
                value={language}
                onChange={handleLanguageChange}
                className="block w-full appearance-none rounded-md border-0 bg-black/10 dark:bg-white/10 py-2 pl-8 pr-3 text-sm text-brand-navy-dark dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-gold sm:text-sm"
                aria-label="Select language"
            >
                {languages.map(lang => (
                    <option key={lang.code} value={lang.code} className="text-brand-navy-dark bg-white">{lang.name}</option>
                ))}
            </select>
        </div>
    );
};

export default LanguageSwitcher;
