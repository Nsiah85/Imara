import React from 'react';
import SkeletonLoader from './SkeletonLoader';

const SkeletonServiceCard: React.FC = () => {
  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden flex flex-col">
      <SkeletonLoader className="w-full h-48" />
      <div className="p-4 flex flex-col flex-grow">
        <SkeletonLoader className="h-3 w-1/2 mb-2" />
        <SkeletonLoader className="h-5 w-5/6 mb-2" />
        <SkeletonLoader className="h-4 w-1/3 mb-4" />
        <SkeletonLoader className="h-6 w-1/2" />
      </div>
      <div className="p-4 pt-0 mt-auto">
        <div className="pt-4 border-t border-gray-100">
          <SkeletonLoader className="h-10 w-full rounded-md" />
        </div>
      </div>
    </div>
  );
};

export default SkeletonServiceCard;
