import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useWishlist } from '../../contexts/WishlistContext';
import { Product } from '../../types';
import { HeartIcon, SolidHeartIcon } from '../icons/Icons';

interface WishlistButtonProps {
  product: Product;
  className?: string;
}

const WishlistButton: React.FC<WishlistButtonProps> = ({ product, className = '' }) => {
  const { user } = useAuth();
  const { isInWishlist, addToWishlist, removeFromWishlist } = useWishlist();

  if (!user) {
    return (
      <button
        className={`p-2 rounded-full bg-white/80 text-gray-400 cursor-not-allowed ${className}`}
        aria-label="Login to add to wishlist"
        title="Login to add to wishlist"
        disabled
      >
        <HeartIcon className="w-6 h-6" />
      </button>
    );
  }

  const isWishlisted = isInWishlist(product.id);

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isWishlisted) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };

  return (
    <button
      onClick={handleClick}
      className={`p-2 rounded-full bg-white/80 backdrop-blur-sm transition-colors duration-300 ${isWishlisted ? 'text-red-500' : 'text-brand-gray hover:text-red-500'} ${className}`}
      aria-label={isWishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
    >
      {isWishlisted ? <SolidHeartIcon className="w-6 h-6" /> : <HeartIcon className="w-6 h-6" />}
    </button>
  );
};

export default WishlistButton;
