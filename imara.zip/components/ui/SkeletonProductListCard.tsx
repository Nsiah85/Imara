import React from 'react';
import SkeletonLoader from './SkeletonLoader';

const SkeletonProductListCard: React.FC = () => {
  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden flex flex-col sm:flex-row">
      <SkeletonLoader className="w-full h-48 sm:h-auto sm:w-1/3 lg:w-1/4 flex-shrink-0" />
      <div className="p-6 flex flex-col flex-grow w-full">
        <div className="flex justify-between items-start">
          <div className="flex-grow space-y-2">
            <SkeletonLoader className="h-3 w-1/4" />
            <SkeletonLoader className="h-6 w-3/4" />
          </div>
          <SkeletonLoader className="h-6 w-1/5 flex-shrink-0 ml-4" />
        </div>

        <div className="space-y-2 mt-3 flex-grow">
          <SkeletonLoader className="h-4 w-full" />
          <SkeletonLoader className="h-4 w-5/6" />
        </div>

        <div className="mt-4 pt-4 border-t border-gray-100 flex flex-col sm:flex-row items-center gap-4">
          <SkeletonLoader className="h-10 w-full sm:w-32 rounded-md" />
          <SkeletonLoader className="h-10 w-full sm:w-32 rounded-md" />
        </div>
      </div>
    </div>
  );
};

export default SkeletonProductListCard;
