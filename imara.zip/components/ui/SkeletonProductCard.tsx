import React from 'react';
import SkeletonLoader from './SkeletonLoader';

const SkeletonProductCard: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden flex flex-col">
      <SkeletonLoader className={`w-full ${compact ? 'h-48' : 'h-64'}`} />
      <div className="p-4 flex flex-col flex-grow">
        <SkeletonLoader className="h-3 w-1/3 mb-2" />
        <SkeletonLoader className="h-5 w-3/4 mb-3" />
        {!compact && (
          <div className="flex gap-2 mt-2 flex-grow">
            <SkeletonLoader className="h-6 w-1/2 rounded-full" />
            <SkeletonLoader className="h-6 w-1/3 rounded-full" />
          </div>
        )}
        <div className={`mt-auto ${compact ? 'pt-2' : 'mt-4 pt-4 border-t border-gray-100'}`}>
          <SkeletonLoader className={`rounded-md ${compact ? 'h-8' : 'h-10'} w-full`} />
        </div>
      </div>
    </div>
  );
};

export default SkeletonProductCard;
