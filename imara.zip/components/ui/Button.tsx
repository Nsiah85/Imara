import React from 'react';

type ButtonVariant = 'primary' | 'secondary' | 'outline';
type ButtonSize = 'sm' | 'md' | 'lg';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  children: React.ReactNode;
  className?: string;
}

const Button: React.FC<ButtonProps> = ({ variant = 'primary', size = 'md', children, className = '', ...props }) => {
  const baseStyles = 'font-display font-semibold rounded-full transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-brand-off-white dark:focus:ring-offset-gray-900';

  const variantStyles = {
    primary: 'bg-brand-gold text-brand-navy-dark hover:bg-brand-gold-light hover:shadow-gold-glow focus:ring-brand-gold',
    secondary: 'bg-brand-green text-white hover:bg-brand-green-dark hover:shadow-gold-glow focus:ring-brand-green',
    outline: 'bg-transparent border-2 border-brand-green text-brand-green hover:bg-brand-green hover:text-white focus:ring-brand-green dark:border-brand-gold-light dark:text-brand-gold-light dark:hover:bg-brand-gold-light dark:hover:text-brand-navy-dark',
  };

  const sizeStyles = {
    sm: 'px-3 py-1.5 text-sm',
    md: 'px-5 py-2.5 text-base',
    lg: 'px-8 py-3 text-lg',
  };

  return (
    <button
      className={`${baseStyles} ${variantStyles[variant]} ${sizeStyles[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};

export default Button;