
import React from 'react';
import { generateAvatar } from '../../utils/avatar.ts';
import { UserIcon, ImaraDiskIcon, VerifiedBadgeIcon, MonkixAIIcon } from '../icons/Icons.tsx';

interface AvatarProps {
    imageUrl?: string;
    name: string;
    id?: string;
    className?: string;
    textClassName?: string;
    hasRing?: boolean;
    trustScore?: number; // 0-100
}

const Avatar: React.FC<AvatarProps> = ({ 
    imageUrl, 
    name, 
    id, 
    className = '', 
    textClassName = '', 
    hasRing = true,
    trustScore 
}) => {
    
    // Determine Ring Color based on Trust
    const getRingColor = () => {
        if (!trustScore) return 'ring-brand-green dark:ring-brand-gold';
        if (trustScore >= 95) return 'ring-brand-gold shadow-[0_0_10px_rgba(255,215,0,0.4)]';
        if (trustScore >= 80) return 'ring-brand-green';
        if (trustScore >= 60) return 'ring-brand-navy';
        return 'ring-gray-300';
    };

    const ringClass = hasRing 
        ? `ring-2 ring-offset-2 ring-offset-white dark:ring-offset-brand-navy-dark ${getRingColor()}` 
        : '';
    
    const combinedClassName = `${className} ${ringClass} box-content overflow-hidden flex-shrink-0 relative transition-all duration-500`;

    const systemIds = ['imara_brand', 'imara_ai', 'imara_whatsapp', 'system_toast_feed', 'toast_feed_notifications'];
    
    const content = () => {
        if (id === 'imara_ai' || id === 'imara_ai_chat') {
            return (
                <div className={`bg-brand-navy-dark flex items-center justify-center ${combinedClassName}`}>
                    <MonkixAIIcon className="w-full h-full p-0.5" />
                </div>
            );
        }

        if (id && systemIds.includes(id)) {
            return (
                <div className={`bg-brand-navy-dark flex items-center justify-center ${combinedClassName}`}>
                    <ImaraDiskIcon className="w-full h-full p-1" />
                </div>
            );
        }

        if (imageUrl) {
            return <img src={imageUrl} alt={name} className={`${combinedClassName} object-cover`} />;
        }

        const { bgColor } = generateAvatar(name, id);
        return (
            <div style={{ backgroundColor: bgColor }} className={`flex items-center justify-center ${combinedClassName}`}>
                <UserIcon className="w-[60%] h-[60%] text-white/90" />
            </div>
        );
    };

    return (
        <div className="relative inline-block group">
            {content()}
            {trustScore && trustScore >= 90 && (
                <div className="absolute -bottom-1 -right-1 bg-white dark:bg-brand-navy-dark rounded-full p-0.5 shadow-sm scale-75 group-hover:scale-100 transition-transform">
                    <VerifiedBadgeIcon className="w-5 h-5 text-brand-gold" />
                </div>
            )}
        </div>
    );
};

export default Avatar;
