
import React from 'react';
import { XIcon, ArrowLeftIcon, ArrowRightIcon, LockClosedIcon } from '../icons/Icons';

interface InAppBrowserProps {
    url: string;
    title?: string;
    onClose: () => void;
}

const InAppBrowser: React.FC<InAppBrowserProps> = ({ url, title, onClose }) => {
    // Extract domain for display
    let domain = '';
    try {
        domain = new URL(url).hostname;
    } catch {
        domain = url;
    }

    return (
        <div className="fixed inset-0 z-[200] bg-white flex flex-col animate-slide-up">
            {/* Browser Toolbar */}
            <div className="bg-gray-100 border-b border-gray-200 px-4 py-3 flex items-center justify-between flex-shrink-0 safe-top">
                <button onClick={onClose} className="p-2 -ml-2 rounded-full hover:bg-gray-200 text-brand-navy-dark">
                    <XIcon className="w-6 h-6" />
                </button>
                
                <div className="flex-1 mx-4 flex flex-col items-center justify-center">
                    <div className="flex items-center gap-1.5 text-xs text-gray-500 bg-gray-200 px-3 py-1.5 rounded-full max-w-full truncate">
                        <LockClosedIcon className="w-3 h-3" />
                        <span className="truncate font-medium">{domain}</span>
                    </div>
                </div>

                <div className="w-8"></div> {/* Spacer for balance */}
            </div>

            {/* Content Area (Simulated Iframe) */}
            <div className="flex-1 bg-white relative">
                <iframe 
                    src={url} 
                    className="w-full h-full border-none" 
                    title={title || "External Content"}
                    sandbox="allow-scripts allow-same-origin allow-forms"
                    // Note: Many sites block embedding via X-Frame-Options. 
                    // In a real React Native/Capacitor app, this would use a native webview.
                    // For a web app PWA, this is a best-effort simulation or fallback to new tab.
                />
                
                {/* Fallback link if iframe is blocked */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-[-1]">
                    <div className="text-center p-8 pointer-events-auto">
                        <p className="text-gray-500 mb-4">If content doesn't load, open in external browser.</p>
                        <a 
                            href={url} 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="px-6 py-3 bg-brand-navy-dark text-white rounded-full font-bold shadow-lg"
                        >
                            Open Link
                        </a>
                    </div>
                </div>
            </div>

            {/* Bottom Nav Bar */}
            <div className="bg-gray-50 border-t border-gray-200 px-6 py-3 flex justify-between items-center flex-shrink-0 safe-bottom">
                <button className="p-2 text-gray-400 hover:text-brand-navy-dark"><ArrowLeftIcon className="w-6 h-6"/></button>
                <button className="p-2 text-gray-400 hover:text-brand-navy-dark"><ArrowRightIcon className="w-6 h-6"/></button>
            </div>
        </div>
    );
};

export default InAppBrowser;
