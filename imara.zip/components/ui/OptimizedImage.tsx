import React, { useState } from 'react';
import { ImaraDiskIcon } from '../icons/Icons';

interface OptimizedImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
    fallbackText?: string;
}

const OptimizedImage: React.FC<OptimizedImageProps> = ({ className, alt, fallbackText, src, ...props }) => {
    const [hasError, setHasError] = useState(false);
    const [isLoaded, setIsLoaded] = useState(false);

    if (hasError || !src) {
        return (
            <div className={`flex flex-col items-center justify-center bg-gray-200 dark:bg-gray-800 text-gray-400 p-2 ${className}`}>
                <ImaraDiskIcon className="w-8 h-8 opacity-50 mb-1" />
                <span className="text-xs text-center line-clamp-2">{fallbackText || alt || 'Image unavailable'}</span>
            </div>
        );
    }

    return (
        <div className={`relative overflow-hidden ${className}`}>
            {!isLoaded && (
                <div className="absolute inset-0 bg-gray-200 dark:bg-gray-800 animate-pulse" />
            )}
            <img
                src={src}
                alt={alt}
                className={`w-full h-full ${isLoaded ? 'opacity-100' : 'opacity-0'} transition-opacity duration-300 ${className?.includes('object-') ? '' : 'object-cover'}`}
                onLoad={() => setIsLoaded(true)}
                onError={() => setHasError(true)}
                {...props}
            />
        </div>
    );
};

export default OptimizedImage;
