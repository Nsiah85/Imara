import React, { useEffect, useMemo } from 'react';
import { XCircleIcon, CheckCircleIcon } from '../icons/Icons.tsx';

interface PasswordStrengthIndicatorProps {
  password?: string;
  onValidityChange: (isValid: boolean) => void;
}

const PasswordStrengthIndicator: React.FC<PasswordStrengthIndicatorProps> = ({ password = '', onValidityChange }) => {
    const checks = useMemo(() => {
        const hasLowerCase = /[a-z]/.test(password);
        const hasUpperCase = /[A-Z]/.test(password);
        const hasNumber = /\d/.test(password);
        const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
        const isLongEnough = password.length >= 8;

        return [
            { label: "At least 8 characters", valid: isLongEnough },
            { label: "One uppercase letter", valid: hasUpperCase },
            { label: "One lowercase letter", valid: hasLowerCase },
            { label: "One number", valid: hasNumber },
            { label: "One special character", valid: hasSpecialChar },
        ];
    }, [password]);

    const strength = useMemo(() => checks.filter(c => c.valid).length, [checks]);
    
    useEffect(() => {
        onValidityChange(strength === 5);
    }, [strength, onValidityChange]);

    if (!password) {
        return null;
    }

    const getBarColor = () => {
        if (strength <= 2) return 'bg-red-500';
        if (strength <= 4) return 'bg-yellow-500';
        return 'bg-green-500';
    };

    return (
        <div className="mt-2 space-y-2">
            <div className="w-full bg-gray-200 rounded-full h-1.5">
                <div 
                    className={`h-1.5 rounded-full transition-all duration-300 ${getBarColor()}`}
                    style={{ width: `${(strength / 5) * 100}%` }}
                ></div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 text-xs">
                {checks.map(check => (
                    <div key={check.label} className={`flex items-center gap-1.5 ${check.valid ? 'text-green-600' : 'text-gray-500'}`}>
                        {check.valid 
                            ? <CheckCircleIcon className="w-3.5 h-3.5" /> 
                            : <XCircleIcon className="w-3.5 h-3.5" />
                        }
                        <span>{check.label}</span>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default PasswordStrengthIndicator;
