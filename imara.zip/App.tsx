
import React, { useEffect, useState, Suspense, lazy } from 'react';
import { HashRouter, Route, Routes, Navigate, useNavigate, useLocation } from 'react-router-dom';
import Layout from './components/layout/Layout.tsx';
import HomePage from './pages/HomePage.tsx'; // Keep core route eager
import AuthPage from './pages/AuthPage.tsx'; // Keep Auth eager
import { CartProvider } from './contexts/CartContext.tsx';
import { CurrencyProvider } from './contexts/CurrencyContext.tsx';
import { ThemeProvider } from './contexts/ThemeContext.tsx';
import { AuthProvider, useAuth } from './contexts/AuthContext.tsx';
import { WishlistProvider } from './contexts/WishlistContext.tsx';
import { LanguageProvider } from './contexts/LanguageContext.tsx';
import { CallProvider } from './contexts/CallContext.tsx';
import { MonetizationProvider } from './contexts/MonetizationContext.tsx';
import { SecurityProvider } from './contexts/SecurityContext.tsx';
import { PrivacyProvider, usePrivacy } from './contexts/PrivacyContext.tsx';
import { DataSyncProvider } from './contexts/DataSyncContext.tsx';

// Move to lazy loading
const ShopPage = lazy(() => import('./pages/ShopPage.tsx'));
const ProductDetailPage = lazy(() => import('./pages/ProductDetailPage.tsx'));
const ImpactPage = lazy(() => import('./pages/ImpactPage.tsx'));
const AccountPage = lazy(() => import('./pages/AccountPage.tsx'));
const CheckoutPage = lazy(() => import('./pages/CheckoutPage.tsx'));
const CartPage = lazy(() => import('./pages/CartPage.tsx'));
const TodoPage = lazy(() => import('./pages/TodoPage.tsx'));
const MarketplacePage = lazy(() => import('./pages/MarketplacePage.tsx'));
const PartnerApplicationPage = lazy(() => import('./pages/PartnerApplicationPage.tsx'));
const WishlistPage = lazy(() => import('./pages/WishlistPage.tsx'));
const ShopHubPage = lazy(() => import('./pages/ShopHubPage.tsx'));
const FeelAfroPage = lazy(() => import('./pages/FeelAfroPage.tsx'));
const ServiceDetailPage = lazy(() => import('./pages/ServiceDetailPage.tsx'));
const VendorStorePage = lazy(() => import('./pages/VendorStorePage.tsx'));
const ProfessionalPublicProfilePage = lazy(() => import('./pages/ProfessionalPublicProfilePage.tsx'));
const TravelPartnerPage = lazy(() => import('./pages/TravelPartnerPage.tsx'));
const FindTalentHubPage = lazy(() => import('./pages/FindTalentHubPage.tsx'));
const FindJobPage = lazy(() => import('./pages/FindJobPage.tsx'));
const AutomotivePage = lazy(() => import('./pages/AutomotivePage.tsx'));
const EdwasoPage = lazy(() => import('./pages/EdwasoPage.tsx'));
const UpgradePage = lazy(() => import('./pages/UpgradePage.tsx'));
const PreInterviewTestPage = lazy(() => import('./pages/PreInterviewTestPage.tsx'));
const AppTour = lazy(() => import('./components/tour/AppTour.tsx'));
const LiveStreamPage = lazy(() => import('./pages/LiveStreamPage.tsx'));
const SignupPromptModal = lazy(() => import('./components/modals/SignupPromptModal.tsx'));
const UserProfilePage = lazy(() => import('./pages/UserProfilePage.tsx'));
import LoadingSpinner from './components/ui/LoadingSpinner.tsx';
const DiscoverPage = lazy(() => import('./pages/DiscoverPage.tsx'));
const TransparencyPage = lazy(() => import('./pages/TransparencyPage.tsx'));
import { WifiSlashIcon } from './components/icons/Icons.tsx';
import Button from './components/ui/Button.tsx';
const PrivacyTermsPage = lazy(() => import('./pages/PrivacyTermsPage.tsx'));

// Previously lazy loaded
const VendorHubPage = lazy(() => import('./pages/VendorHubPage.tsx'));
const MessagesPage = lazy(() => import('./pages/MessagesPage.tsx'));
const AdminPage = lazy(() => import('./pages/AdminPage.tsx'));
const ChatWidget = lazy(() => import('./components/chat/ChatWidget.tsx'));
const CallOverlay = lazy(() => import('./components/call/CallOverlay.tsx'));

const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { user, isLoading } = useAuth();
    
    if (isLoading) {
        return (
            <div className="flex justify-center items-center h-screen">
                <LoadingSpinner />
            </div>
        );
    }

    if (!user || user.role !== 'admin') {
        return <Navigate to="/login" replace />;
    }

    return <>{children}</>;
};

const PrivacyGuard: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { user, isLoading } = useAuth();
    const { hasConsented } = usePrivacy();
    const location = useLocation();

    if (isLoading) return null;

    if (user && !hasConsented && location.pathname !== '/privacy-terms') {
        return <Navigate to="/privacy-terms" replace />;
    }

    return <>{children}</>;
};

function AppRoutes() {
  return (
    <Suspense fallback={<div className="flex justify-center items-center h-screen"><LoadingSpinner /></div>}>
        <Routes>
          <Route path="/privacy-terms" element={<PrivacyTermsPage />} />
          <Route path="/" element={<HomePage />} />
          <Route path="/discover" element={<DiscoverPage />} />
          <Route path="/shop-hub" element={<ShopHubPage />} />
          <Route path="/shop" element={<ShopPage />} />
          <Route path="/edwaso" element={<EdwasoPage />} />
          <Route path="/automotive" element={<AutomotivePage />} />
          <Route path="/feel-afro" element={<FeelAfroPage />} />
          <Route path="/feel-afro/:id" element={<ServiceDetailPage />} />
          <Route path="/product/:id" element={<ProductDetailPage />} />
          <Route path="/invest" element={<ImpactPage />} />
          <Route path="/transparency" element={<TransparencyPage />} />
          <Route path="/login" element={<AuthPage />} />
          <Route path="/account" element={<AccountPage />} />
          <Route path="/user/:id" element={<UserProfilePage />} />
          <Route path="/hub" element={<WishlistPage />} />
          <Route path="/join/:role" element={<PartnerApplicationPage />} />
          <Route path="/vendor-hub" element={<VendorHubPage />} />
          <Route path="/vendor/:slug" element={<VendorStorePage />} />
          <Route path="/workman/:slug" element={<ProfessionalPublicProfilePage />} />
          <Route path="/travel/:slug" element={<TravelPartnerPage />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/checkout" element={<CheckoutPage />} />
          <Route path="/todo" element={<TodoPage />} />
          <Route path="/find-talent" element={<FindTalentHubPage />} />
          <Route path="/marketplace" element={<MarketplacePage />} />
          <Route path="/find-job" element={<FindJobPage />} />
          <Route path="/messages" element={<MessagesPage />} />
          <Route path="/messages/:conversationId" element={<MessagesPage />} />
          <Route path="/upgrade" element={<UpgradePage />} />
          <Route path="/pre-interview-test/:attemptId" element={<PreInterviewTestPage />} />
          <Route path="/live/:streamId" element={<LiveStreamPage />} />
          <Route path="/admin" element={
            <ProtectedRoute>
              <AdminPage />
            </ProtectedRoute>
          } />
        </Routes>
    </Suspense>
  );
}

const AppContent: React.FC = () => {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const location = useLocation();

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const isPrivacyPage = location.pathname === '/privacy-terms';

  return (
    <PrivacyGuard>
      {isOffline && (
        <div className="fixed top-0 left-0 right-0 bg-red-600 text-white z-[100] px-4 py-2 flex items-center justify-between shadow-md animate-fade-in-down">
            <div className="flex items-center gap-2 text-sm font-medium">
                <WifiSlashIcon className="w-5 h-5" />
                <span>You are currently offline. Some features may be unavailable.</span>
            </div>
            <Button size="sm" variant="outline" onClick={() => window.location.reload()} className="!text-white !border-white hover:!bg-white/20 !py-1">
                Retry
            </Button>
        </div>
      )}
      
      {isPrivacyPage ? (
          <AppRoutes />
      ) : (
          <Layout>
            <AppRoutes />
            <AppTour />
          </Layout>
      )}

      {!isPrivacyPage && (
          <Suspense fallback={null}>
              <CallOverlay />
              <ChatWidget />
          </Suspense>
      )}
      {!isLoading && !user && !isPrivacyPage && <SignupPromptModal />}
    </PrivacyGuard>
  );
};


function App() {
  return (
    <DataSyncProvider>
        <ThemeProvider>
        <AuthProvider>
            <LanguageProvider>
            <CurrencyProvider>
                <SecurityProvider>
                    <CartProvider>
                    <WishlistProvider>
                        <CallProvider>
                            <MonetizationProvider>
                                <PrivacyProvider>
                                    <HashRouter>
                                        <AppContent />
                                    </HashRouter>
                                </PrivacyProvider>
                            </MonetizationProvider>
                        </CallProvider>
                    </WishlistProvider>
                    </CartProvider>
                </SecurityProvider>
            </CurrencyProvider>
            </LanguageProvider>
        </AuthProvider>
        </ThemeProvider>
    </DataSyncProvider>
  );
}

export default App;
