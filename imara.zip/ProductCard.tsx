import React, { useState, useMemo, useEffect } from 'react';
import type { Product, EdwasoMarket } from './types.ts';
import { ProductCategory, VendorType } from './types.ts';
import { Link } from 'react-router-dom';
import Badge from './components/ui/Badge.tsx';
import Button from './components/ui/Button.tsx';
import { VerifiedIcon, GlobeIcon, LeafIcon, EyeIcon, UserGroupIcon } from './components/icons/Icons.tsx';
import { useIntersectionObserver } from './hooks/useIntersectionObserver.ts';
import { useCurrency } from './contexts/CurrencyContext.tsx';
import WishlistButton from './components/ui/WishlistButton.tsx';
import { mockVendors, mockEdwasoMarkets } from './data/mockData.ts';

interface ProductCardProps {
  product: Product;
  animationDelay?: number;
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onBookNow?: (product: Product) => void;
  compact?: boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, animationDelay = 75, onQuickView, onAddToCart, onBookNow, compact = false }) => {
  const [cardRef, isVisible] = useIntersectionObserver<HTMLDivElement>({ threshold: 0.1 });
  const [isAdded, setIsAdded] = useState(false);
  const [markets, setMarkets] = useState<EdwasoMarket[]>([]);
  const { formatCurrency } = useCurrency();
  
  useEffect(() => {
    try {
        const storedMarkets = localStorage.getItem('edwaso_markets');
        if (storedMarkets) {
            const parsedMarkets = JSON.parse(storedMarkets);
            if (Array.isArray(parsedMarkets)) {
                setMarkets(parsedMarkets);
            } else {
                setMarkets(mockEdwasoMarkets);
            }
        } else {
            setMarkets(mockEdwasoMarkets);
        }
    } catch(e) {
        console.error("Failed to parse 'edwaso_markets' from localStorage:", e);
        setMarkets(mockEdwasoMarkets);
    }
  }, []);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onAddToCart(product);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  const vendor = useMemo(() => mockVendors.find(v => v.brandName === product.vendor), [product.vendor]);
  const isEdwasoProduct = [ProductCategory.FOODSTUFF, ProductCategory.FRUITS_VEGETABLES, ProductCategory.PROTEINS].includes(product.category);
  const market = useMemo(() => isEdwasoProduct && product.marketId ? markets.find(m => m.id === product.marketId) : null, [product, isEdwasoProduct, markets]);

  const VendorBadge = () => {
    if (!isEdwasoProduct || !vendor) return null;

    if (vendor.vendorType === VendorType.FARMER) {
      return (
        <Badge className="bg-green-100 text-green-800" icon={<LeafIcon className="w-3 h-3" />}>
          Farmer
        </Badge>
      );
    }
    if (vendor.vendorType === VendorType.MARKET_WOMAN) {
       return (
        <Badge className="bg-orange-100 text-orange-800" icon={<UserGroupIcon className="w-4 h-4" />}>
          Market Woman
        </Badge>
      );
    }
    return null;
  };

  const renderCardButton = () => {
    const automotiveButtonClasses = 'font-display font-semibold rounded-md transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-brand-off-white dark:focus:ring-offset-gray-900 bg-brand-gold text-brand-navy-dark hover:bg-brand-gold-light focus:ring-brand-gold px-3 py-1.5 text-sm w-full text-center inline-block';

    switch (product.category) {
      case ProductCategory.AUTOMOTIVE:
        return (
          <Link to={`/product/${product.id}`} className={automotiveButtonClasses}>
            View Details
          </Link>
        );
      case ProductCategory.DRIVING_TEST:
        return (
          <Button
            variant="secondary"
            size="sm"
            className="w-full"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              if (onBookNow) onBookNow(product);
            }}
          >
            Book Now
          </Button>
        );
      default:
        return (
          <Button
            variant="primary"
            size="sm"
            className="w-full"
            onClick={handleAddToCart}
            disabled={isAdded}
          >
            {isAdded ? 'Added!' : 'Add to Cart'}
          </Button>
        );
    }
  };

  return (
    <div
      ref={cardRef}
      className={`bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden group transition-all duration-500 ease-out transform hover:-translate-y-1 flex flex-col ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
      }`}
      style={{ transitionDelay: `${animationDelay}ms` }}
    >
      <div className="relative">
        <img
          src={product.imageUrl}
          alt={product.name}
          className={`w-full ${compact ? 'h-48' : 'h-56'} object-cover cursor-pointer`}
          onClick={() => onQuickView(product)}
        />
        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <button
            onClick={() => onQuickView(product)}
            className="flex items-center gap-2 bg-white text-brand-navy-dark font-semibold py-2 px-4 rounded-md transform scale-90 group-hover:scale-100 transition-transform duration-300"
            aria-label={`Quick view ${product.name}`}
          >
            <EyeIcon className="w-5 h-5" />
            Quick View
          </button>
        </div>
        <div className="absolute top-3 left-3 z-10">
            <WishlistButton product={product} />
        </div>
        <div className="absolute top-3 right-3 flex items-center gap-2">
          {product.isVerified && !compact && (
            <Badge className="bg-brand-green/80 text-white backdrop-blur-sm" icon={<VerifiedIcon className="w-3 h-3"/>}>
              Verified
            </Badge>
          )}
        </div>
      </div>
      <div className="p-4 flex flex-col flex-grow">
        <Link to={`/product/${product.id}`} className="block">
          <div className={`flex justify-between items-start ${compact ? 'mb-1' : 'mb-2'}`}>
            <div>
              <div className="flex items-center gap-2">
                <p className="text-xs text-brand-gray dark:text-gray-400 uppercase tracking-wider">{product.vendor}</p>
                {vendor?.isVerified && <VerifiedIcon className="w-4 h-4 text-brand-gold" title="Verified Partner" />}
                <VendorBadge />
              </div>
              <h3 className={`font-display font-semibold group-hover:text-brand-gold transition-colors dark:text-white ${compact ? 'text-base leading-tight' : 'text-base'}`}>{product.name}</h3>
               {market && <p className="text-xs text-brand-green">{market.name}</p>}
            </div>
            <p className={`font-display font-bold text-brand-navy dark:text-gray-100 ${compact ? 'text-base' : 'text-base'}`}>{formatCurrency(product.price)}</p>
          </div>
        </Link>
        {!compact && (
            <div className="flex flex-wrap gap-2 mt-2 flex-grow">
            <Badge className="bg-emerald-100 text-emerald-800" icon={<LeafIcon className="w-3 h-3"/>}>
                {product.sustainabilityTags[0]}
            </Badge>
            <Badge className="bg-blue-100 text-blue-800" icon={<GlobeIcon className="w-3 h-3"/>}>
                {product.originCountry}
            </Badge>
            </div>
        )}
        <div className={`mt-auto ${compact ? 'pt-2' : 'pt-4 border-t border-gray-100 dark:border-gray-700'}`}>
          {renderCardButton()}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
