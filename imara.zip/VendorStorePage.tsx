import React, { useState, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { mockVendors, mockProducts, mockReviews } from './data/mockData.ts';
import type { Product, Review, Participant } from './types.ts';
import ProductCard from './components/shared/ProductCard.tsx';
import Button from './components/ui/Button.tsx';
import { GlobeIcon, EnvelopeIcon, VerifiedIcon, EllipsisHorizontalIcon } from './components/icons/Icons.tsx';
import { useCart } from './contexts/CartContext.tsx';
import QuickViewModal from './components/modals/QuickViewModal.tsx';
import BackButton from './components/ui/BackButton.tsx';
import { useAuth } from './contexts/AuthContext.tsx';
import ReviewSummary from './components/reviews/ReviewSummary.tsx';
import ReviewCard from './components/reviews/ReviewCard.tsx';
import ContactActionModal from './components/modals/ContactActionModal.tsx';

type VendorTab = 'products' | 'about' | 'reviews';

const VendorStorePage: React.FC = () => {
    const { slug } = useParams<{ slug: string }>();
    const { addToCart } = useCart();
    const { user, followUser, unfollowUser, isFollowing } = useAuth();
    const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
    const [activeTab, setActiveTab] = useState<VendorTab>('products');
    const [isContactModalOpen, setIsContactModalOpen] = useState(false);

    const vendor = mockVendors.find(v => v.storeSlug === slug);
    const vendorProducts = mockProducts.filter(p => p.vendor === vendor?.brandName);
    
    const vendorReviews = useMemo(() => {
        if (!vendor) return [];
        // In a real app, you'd fetch this. Here we filter mock data.
        // Let's also check localStorage for any newly added reviews.
        try {
            const storedReviews = localStorage.getItem('imara_reviews');
            // FIX: Cast result of JSON.parse to avoid 'any' type.
            const allReviews = storedReviews ? JSON.parse(storedReviews) as Review[] : mockReviews;
            return allReviews.filter((r: Review) => r.vendorId === vendor?.id);
        } catch(e) {
            // FIX: Add error logging to catch block.
            console.error("Failed to load reviews:", e);
            return mockReviews.filter(r => r.vendorId === vendor?.id);
        }
    }, [vendor]);

    if (!vendor) {
        return (
             <div className="container mx-auto px-6 py-20 text-center">
                <h1 className="text-3xl font-display font-bold text-brand-green-dark">Vendor Not Found</h1>
                <p className="mt-4 text-brand-gray">The store you are looking for does not exist.</p>
                <Link to="/shop" className="mt-6 inline-block">
                    <Button variant="primary" size="lg">Back to Shop</Button>
                </Link>
            </div>
        );
    }

    const isOwnProfile = user?.id === vendor.id;
    const following = user ? isFollowing(vendor.id) : false;
    const isFollowedBy = user?.followerIds?.includes(vendor.id) || false;

    const handleFollow = () => {
        if (!user) return;
        following ? unfollowUser(vendor.id) : followUser(vendor.id);
    };
    
    const getFollowButton = () => {
        if (isOwnProfile || !user) return null;

        if (following) {
            return <Button onClick={handleFollow} variant="outline" className="!text-white !border-white/80 hover:!bg-white/10">Following</Button>;
        }
        if (isFollowedBy) {
            return <Button onClick={handleFollow} variant="secondary">Follow Back</Button>;
        }
        return <Button onClick={handleFollow} variant="primary">Follow</Button>;
    };

    const participantForModal: Participant = {
        id: vendor.id,
        name: vendor.brandName,
        avatarUrl: vendor.brandLogoUrl || '',
        role: 'Vendor',
        profileLink: `/vendor/${vendor.storeSlug}`
    };

    const bannerUrl = vendor.coverImageUrl || `https://picsum.photos/seed/${vendor.storeSlug}-banner/1600/400`;

    const tabClass = (tabName: VendorTab) =>
        `px-4 py-2 text-sm font-medium rounded-md transition-colors ${
            activeTab === tabName
                ? 'bg-brand-navy-dark text-white'
                : 'text-gray-600 hover:bg-brand-off-white'
        }`;

    const renderTabContent = () => {
        switch (activeTab) {
            case 'products':
                return vendorProducts.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-8">
                        {vendorProducts.map((product) => (
                            <ProductCard 
                                key={product.id}
                                product={product}
                                onAddToCart={addToCart}
                                onQuickView={setQuickViewProduct}
                            />
                        ))}
                    </div>
                ) : (
                    <p className="text-center text-gray-500 py-16">This vendor has not listed any products yet.</p>
                );
            case 'about':
                return (
                    <div className="bg-brand-off-white dark:bg-gray-800 p-6 rounded-lg">
                        <h2 className="text-2xl font-display font-semibold text-brand-green-dark dark:text-white">About {vendor.brandName}</h2>
                        <p className="mt-4 text-gray-600 dark:text-gray-300 leading-relaxed whitespace-pre-line">{vendor.story}</p>
                    </div>
                );
            case 'reviews':
                return (
                    <div>
                        <ReviewSummary reviews={vendorReviews} />
                        <div className="mt-8">
                            {vendorReviews.length > 0 ? (
                                vendorReviews.map(review => <ReviewCard key={review.id} review={review} />)
                            ) : (
                                <p className="text-center text-gray-500 dark:text-gray-400 py-8">This vendor has no reviews yet.</p>
                            )}
                        </div>
                    </div>
                );
            default:
                return null;
        }
    }

    return (
        <>
            <div className="bg-white dark:bg-gray-900">
                {/* Banner and Header */}
                <div className="relative bg-brand-green h-48 md:h-64">
                    <img src={bannerUrl} alt={`${vendor.brandName} banner`} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-brand-green via-brand-green/70 to-transparent"></div>
                    <div className="absolute inset-x-0 bottom-0 container mx-auto px-6">
                        <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6">
                             <img src={vendor.brandLogoUrl} alt={`${vendor.brandName} logo`} className="w-24 h-24 sm:w-32 sm:h-32 rounded-full object-cover border-4 border-white bg-white shadow-lg -mb-12 sm:-mb-8" />
                             <div className="flex-grow text-center sm:text-left pt-12 sm:pt-0">
                                <div className="flex items-center gap-2 justify-center sm:justify-start">
                                    <h1 className="text-3xl sm:text-4xl font-display font-bold text-white">{vendor.brandName}</h1>
                                    {vendor.isVerified && <VerifiedIcon className="w-8 h-8 text-brand-gold" />}
                                </div>
                                <div className="flex items-center justify-center sm:justify-start gap-2 mt-2 text-brand-gold-light">
                                    <GlobeIcon className="w-5 h-5" />
                                    <span>{vendor.country}</span>
                                </div>
                             </div>
                             <div className="pt-12 sm:pt-0 sm:pb-8 flex-shrink-0 flex items-center gap-4">
                                <Link to={`/messages/new?recipientId=${vendor.id}&recipientName=${encodeURIComponent(vendor.brandName)}&recipientRole=Vendor&recipientAvatar=${encodeURIComponent(vendor.brandLogoUrl || '')}`}>
                                    <Button variant="secondary" className="flex items-center justify-center gap-2">
                                        <EnvelopeIcon className="w-5 h-5"/>
                                        Message
                                    </Button>
                                </Link>
                                {!isOwnProfile && user && getFollowButton()}
                                {!isOwnProfile && user && (
                                    <button onClick={() => setIsContactModalOpen(true)} className="p-2 rounded-full hover:bg-white/20">
                                        <EllipsisHorizontalIcon className="w-6 h-6 text-white" />
                                    </button>
                                )}
                             </div>
                        </div>
                    </div>
                </div>

                <div className="container mx-auto px-6 py-16 dark:text-white">
                    <BackButton text="Back to Shop" className="my-8" />

                     {/* Tabs */}
                    <div className="mb-8 border-b pb-2">
                        <div className="flex flex-wrap gap-2 p-2 bg-gray-100 dark:bg-gray-800 rounded-lg max-w-sm">
                            <button className={tabClass('products')} onClick={() => setActiveTab('products')}>Products</button>
                            <button className={tabClass('about')} onClick={() => setActiveTab('about')}>About</button>
                            <button className={tabClass('reviews')} onClick={() => setActiveTab('reviews')}>Reviews ({vendorReviews.length})</button>
                        </div>
                    </div>

                    <div>
                        {renderTabContent()}
                    </div>
                </div>
            </div>
            {quickViewProduct && (
                <QuickViewModal product={quickViewProduct} onClose={() => setQuickViewProduct(null)} />
            )}
            {isContactModalOpen && (
                <ContactActionModal participant={participantForModal} onClose={() => setIsContactModalOpen(false)} />
            )}
        </>
    );
};

export default VendorStorePage;
