import express from "express";
import path from "path";
import cors from "cors";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

// Load environment variables from .env.local and .env
dotenv.config({ path: '.env.local' });
dotenv.config();

// Initialize Express App
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Initialize Gemini Client
// We ensure it lazy-initializes only when required so it doesn't crash on startup if missing.
let aiClient: GoogleGenAI | null = null;
const getGeminiClient = () => {
    if (!aiClient) {
        const apiKey = process.env.GEMINI_API_KEY;
        if (!apiKey) {
            throw new Error("GEMINI_API_KEY environment variable is required.");
        }
        aiClient = new GoogleGenAI({ apiKey });
    }
    return aiClient;
};

// ==========================================
// AI Service API Routes
// ==========================================
app.post("/api/ai/chat", async (req, res) => {
    try {
        const { messages, userMessage, tool, location, systemInstruction } = req.body;
        
        const ai = getGeminiClient();

        if (tool === 'search') {
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: userMessage,
                config: { tools: [{ googleSearch: {} }] }
            });
            const text = response.text || "I couldn't find any information on that.";
            const grounding = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
            res.json({ text, grounding });
            return;
        }

        if (tool === 'maps') {
            const toolConfig = location ? {
                retrievalConfig: { latLng: location }
            } : undefined;
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: userMessage,
                config: { 
                    tools: [{ googleMaps: {} }],
                    toolConfig
                }
            });
            const text = response.text || "I couldn't find those places.";
            const grounding = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
            res.json({ text, grounding });
            return;
        }

        const chat = ai.chats.create({
            model: 'gemini-2.5-flash',
            config: {
                systemInstruction: systemInstruction,
                tools: [{ googleSearch: {} }],
            },
            history: messages || [],
        });
        
        const response = await chat.sendMessage({ message: userMessage });
        const text = response.text || "";
        const grounding = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
        res.json({ text, grounding });

    } catch (error: any) {
        console.error("AI Generation Error:", error);
        res.status(500).json({ error: error.message || "Failed to generate AI content" });
    }
});

// ==========================================
// Vite Middleware & Static Serving
// ==========================================
async function startServer() {
    if (process.env.NODE_ENV !== "production") {
        const vite = await createViteServer({
            server: { middlewareMode: true },
            appType: "spa",
        });
        app.use(vite.middlewares);
    } else {
        const distPath = path.join(process.cwd(), 'dist');
        app.use(express.static(distPath));
        app.get('*', (req, res) => {
            res.sendFile(path.join(distPath, 'index.html'));
        });
    }

    app.listen(PORT, "0.0.0.0", () => {
        console.log(`Server running on http://0.0.0.0:${PORT}`);
    });
}

startServer();
