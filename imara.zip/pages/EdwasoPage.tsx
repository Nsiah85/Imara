
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import ProductCard from '../components/shared/ProductCard.tsx';
import { mockProducts, mockEdwasoMarkets } from '../data/mockData.ts';
import { ProductCategory, type Product, type EdwasoMarket } from '../types.ts';
import QuickViewModal from '../components/modals/QuickViewModal.tsx';
import PaginationControls from '../components/shared/PaginationControls.tsx';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver.ts';
import { useCart } from '../contexts/CartContext.tsx';
import { useLanguage } from '../contexts/LanguageContext.tsx';
import BackButton from '../components/ui/BackButton.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';
import { SpeakerWaveIcon, ClockIcon, MapPinIcon, MicrophoneIcon } from '../components/icons/Icons.tsx';
/* FIX: Import missing useCurrency hook and Avatar component */
import { useCurrency } from '../contexts/CurrencyContext.tsx';
import Avatar from '../components/ui/Avatar.tsx';

const TraderCard: React.FC<{ product: Product, market: EdwasoMarket }> = ({ product, market }) => {
    const { formatCurrency } = useCurrency();
    const { addToCart } = useCart();
    
    return (
        <div className="bg-white dark:bg-gray-800 rounded-[32px] p-6 shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col gap-4 group">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <Avatar 
                        name={product.vendor} 
                        trustScore={100} 
                        className="w-12 h-12" 
                        hasRing={true} 
                    />
                    <div>
                        <h4 className="font-bold text-brand-navy-dark dark:text-white leading-tight">{product.vendor}</h4>
                        <p className="text-[10px] text-brand-green font-bold flex items-center gap-0.5"><ClockIcon className="w-2.5 h-2.5"/> {market.workingHours}</p>
                    </div>
                </div>
                {market.voiceIntroUrl && (
                    <button className="p-2.5 rounded-full bg-brand-gold/10 text-brand-gold hover:bg-brand-gold hover:text-brand-navy-dark transition-all shadow-inner" title="Hear Voice Intro">
                        <SpeakerWaveIcon className="w-5 h-5 animate-pulse" />
                    </button>
                )}
            </div>

            <div className="relative h-40 rounded-2xl overflow-hidden">
                <img src={product.imageUrl} className="w-full h-full object-cover group-hover:scale-105 transition-transform" alt=""/>
                <div className="absolute bottom-2 right-2 bg-white/90 px-3 py-1 rounded-full text-xs font-black text-brand-navy-dark shadow-lg">
                    {formatCurrency(product.price)}
                </div>
            </div>

            <div className="flex-grow">
                <h5 className="font-bold text-sm text-brand-navy-dark dark:text-white">{product.name}</h5>
                <p className="text-xs text-gray-500 mt-1 line-clamp-2">{product.description}</p>
            </div>

            <div className="flex gap-2">
                <button onClick={() => addToCart(product)} className="flex-1 bg-brand-green text-white py-2 rounded-full text-xs font-bold shadow-md hover:bg-brand-green-dark transition-colors">Order via Chat</button>
                <button className="p-2 bg-gray-100 rounded-full hover:bg-gray-200 transition-colors"><MicrophoneIcon className="w-4 h-4 text-gray-500"/></button>
            </div>
        </div>
    );
}

const EdwasoPage: React.FC = () => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const [activeMarketId, setActiveMarketId] = useState<string>(mockEdwasoMarkets[0].id);
    const { t } = useLanguage();
    const { addToCart } = useCart();
    
    const markets = mockEdwasoMarkets;
    const currentMarket = markets.find(m => m.id === activeMarketId)!;
    
    const marketProducts = useMemo(() => mockProducts.filter(p => 
        p.marketId === activeMarketId && 
        (p.category === ProductCategory.FOODSTUFF || p.category === ProductCategory.FRUITS_VEGETABLES)
    ), [activeMarketId]);

    if (!user) {
        useEffect(() => { navigate('/login', { state: { from: '/edwaso' } }); }, []);
        return null;
    }

    return (
        <div className="bg-[#FDFBF7] dark:bg-gray-900 min-h-screen pb-32">
            <div className="container mx-auto px-6 py-8">
                <BackButton className="mb-4" />
                
                <div className="flex flex-col md:flex-row justify-between items-end gap-6 mb-12">
                    <div className="max-w-xl">
                        <h1 className="text-4xl font-display font-black text-brand-navy-dark dark:text-white mb-2">Edwaso Local Markets</h1>
                        <p className="text-gray-600 dark:text-gray-400">Supporting local farmers and market women through direct cultural trade.</p>
                    </div>
                    
                    <div className="flex bg-white dark:bg-gray-800 p-2 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 gap-2 overflow-x-auto scrollbar-hide w-full md:w-auto">
                        {markets.map(m => (
                            <button 
                                key={m.id}
                                onClick={() => setActiveMarketId(m.id)}
                                className={`px-5 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition-all ${activeMarketId === m.id ? 'bg-brand-gold text-brand-navy-dark shadow-md' : 'text-gray-400 hover:text-brand-navy-dark dark:hover:text-white'}`}
                            >
                                {m.name}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="bg-brand-green/10 rounded-[40px] p-8 mb-12 flex flex-col md:flex-row items-center gap-8 border border-brand-green/20">
                     <div className="w-24 h-24 bg-white dark:bg-gray-800 rounded-full flex items-center justify-center text-brand-green shadow-xl border-4 border-brand-green/20">
                        <MapPinIcon className="w-10 h-10" />
                    </div>
                    <div>
                        <h2 className="text-2xl font-display font-bold text-brand-green-dark dark:text-white">{currentMarket.name} — {currentMarket.region}</h2>
                        <p className="text-sm text-brand-green font-medium">Currently: <span className="font-black uppercase">Open</span> &middot; {currentMarket.workingHours}</p>
                        <div className="flex gap-4 mt-4">
                            <div className="flex items-center gap-1.5"><div className="w-2 h-2 bg-green-500 rounded-full"></div> <span className="text-xs font-bold text-gray-500 uppercase">124 Verified Traders</span></div>
                            <div className="flex items-center gap-1.5"><div className="w-2 h-2 bg-brand-gold rounded-full"></div> <span className="text-xs font-bold text-gray-500 uppercase">Fresh Harvest Today</span></div>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                    {marketProducts.map((p) => (
                        <TraderCard key={p.id} product={p} market={currentMarket} />
                    ))}
                    {marketProducts.length === 0 && (
                        <div className="col-span-full py-20 text-center">
                            <p className="text-gray-400 italic">No traders listed in this market for the selected category.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default EdwasoPage;
