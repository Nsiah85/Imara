import React, { useState } from 'react';
import { mockLiveStream } from '../data/mockData';
import type { LiveComment } from '../types.ts';
import { useCart } from '../contexts/CartContext';
import { UserIcon } from '../components/icons/Icons';
import LiveProductCarousel from '../components/live/LiveProductCarousel';
import LiveCommentFeed from '../components/live/LiveCommentFeed';
import EmojiGiftTray from '../components/live/EmojiGiftTray';
import LiveFiltersPanel from '../components/live/LiveFiltersPanel';
import LiveMusicPlayer from '../components/live/LiveMusicPlayer';
import Avatar from '../components/ui/Avatar';

const LiveStreamPage: React.FC = () => {
    const { addToCart } = useCart();
    const [streamData] = useState(mockLiveStream);
    const [comments, setComments] = useState<LiveComment[]>(streamData.comments);
    const [filters, setFilters] = useState({
        brightness: 100,
        contrast: 100,
        overlay: '',
        overlayOpacity: 0.4,
    });
    
    const handleAddComment = (text: string) => {
        const newComment: LiveComment = {
            id: crypto.randomUUID(),
            authorName: 'You',
            authorAvatar: 'https://picsum.photos/seed/current-user/300/300',
            text,
        };
        setComments(prev => [...prev, newComment]);
    };

    const hostName = streamData.host.role === 'workman' ? streamData.host.name : streamData.host.brandName;
    const hostAvatar = streamData.host.role === 'workman' ? streamData.host.profileImageUrl : (streamData.host.brandLogoUrl || '');

    return (
        <div className="flex flex-col lg:flex-row h-[calc(100vh-64px)] bg-brand-navy-dark text-white">
            {/* Main Stream Content */}
            <main className="flex-1 flex flex-col relative overflow-hidden">
                {/* Mock Video Stream */}
                <div className="absolute inset-0 bg-black">
                     <div 
                        className="w-full h-full bg-cover bg-center" 
                        style={{ 
                            backgroundImage: 'url(https://picsum.photos/seed/live-bg/1280/720)',
                            filter: `brightness(${filters.brightness}%) contrast(${filters.contrast}%)`
                         }}
                     />
                     {filters.overlay && (
                        <div
                            className="absolute inset-0 w-full h-full bg-cover bg-center"
                            style={{ 
                                backgroundImage: `url(${filters.overlay})`,
                                opacity: filters.overlayOpacity, 
                                mixBlendMode: 'soft-light'
                            }}
                        />
                     )}
                </div>
                
                {/* Overlay UI */}
                <div className="absolute inset-0 flex flex-col p-4">
                    {/* Header */}
                    <header className="flex items-center justify-between">
                        <div className="flex items-center gap-3 bg-black/50 p-2 rounded-lg">
                            <Avatar 
                                imageUrl={hostAvatar}
                                name={hostName}
                                id={streamData.host.id}
                                className="w-12 h-12 rounded-full border-2 border-brand-gold"
                                textClassName="text-lg font-bold text-white"
                            />
                            <div>
                                <h1 className="font-bold text-lg">{hostName}</h1>
                                <p className="text-sm text-gray-300">{streamData.title}</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-4 text-sm bg-black/50 p-2 rounded-lg">
                             <div className="flex items-center gap-1"><UserIcon className="w-4 h-4 text-brand-gold"/> <span>{streamData.followers.toLocaleString()}</span></div>
                        </div>
                    </header>

                    {/* Interactive Elements at Bottom */}
                    <div className="mt-auto">
                        <LiveProductCarousel products={streamData.featuredProducts} onAddToCart={addToCart} />
                    </div>
                </div>
                 <EmojiGiftTray />
            </main>

            {/* Sidebar with Chat and Controls */}
            <aside className="w-full lg:w-96 bg-brand-navy-dark/80 backdrop-blur-sm border-l border-white/10 flex flex-col">
                <div className="flex-1 min-h-0">
                    <LiveCommentFeed comments={comments} onAddComment={handleAddComment} />
                </div>
                <div className="p-4 border-t border-white/10">
                    <LiveFiltersPanel currentFilters={filters} setFilters={setFilters} />
                </div>
                <div className="p-4 border-t border-white/10">
                    <LiveMusicPlayer tracks={streamData.backgroundMusic} />
                </div>
            </aside>
        </div>
    );
};

export default LiveStreamPage;