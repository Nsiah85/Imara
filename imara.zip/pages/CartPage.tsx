import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../contexts/CartContext.tsx';
import Button from '../components/ui/Button.tsx';
import CartItemRow from '../components/cart/CartItemRow.tsx';
import { ArrowRightIcon } from '../components/icons/Icons.tsx';
import { useCurrency } from '../contexts/CurrencyContext.tsx';
import BackButton from '../components/ui/BackButton.tsx';

const CartPage: React.FC = () => {
    const { cartItems, subtotal } = useCart();
    const { formatCurrency } = useCurrency();

    if (cartItems.length === 0) {
        return (
            <div className="container mx-auto px-6 py-20 text-center">
                <h1 className="text-3xl font-display font-bold text-brand-green-dark">Your Cart is Empty</h1>
                <p className="mt-4 text-brand-gray">Looks like you haven't added anything to your cart yet.</p>
                <Link to="/shop-hub" className="mt-6 inline-block">
                    <Button variant="primary" size="lg">Start Shopping</Button>
                </Link>
            </div>
        );
    }

    return (
        <div className="bg-brand-off-white min-h-screen">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <BackButton className="mb-4" text="Continue Shopping" />
                <h1 className="text-3xl font-display font-bold text-brand-green-dark mb-8">Your Shopping Cart</h1>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
                    <div className="lg:col-span-2 bg-white rounded-lg shadow-sm">
                        <ul role="list" className="divide-y divide-gray-200">
                           {cartItems.map(item => (
                               <CartItemRow key={item.id} item={item} />
                           ))}
                        </ul>
                    </div>
                    
                    {/* Order Summary */}
                    <div className="bg-white rounded-lg shadow-sm p-6 sticky top-24">
                        <h2 className="text-xl font-display font-semibold text-brand-green-dark mb-4">Order Summary</h2>
                        <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                                <p className="text-gray-600">Subtotal</p>
                                <p className="font-medium text-gray-800">{formatCurrency(subtotal)}</p>
                            </div>
                             <div className="flex justify-between">
                                <p className="text-gray-600">Shipping & Taxes</p>
                                <p className="font-medium text-gray-800">Calculated at checkout</p>
                            </div>
                        </div>
                        <div className="border-t pt-4 mt-4 flex justify-between text-base font-semibold">
                            <p className="text-brand-green-dark">Estimated Total</p>
                            <p className="text-brand-green-dark">{formatCurrency(subtotal)}</p>
                        </div>
                        <p className="mt-1 text-xs text-gray-500">Shipping costs and taxes are not final and will be updated during checkout.</p>
                        <Link to="/checkout" className="mt-6 block">
                           <Button size="lg" className="w-full flex items-center justify-center gap-2">
                                <span>Proceed to Checkout</span>
                                <ArrowRightIcon className="w-5 h-5" />
                           </Button>
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CartPage;
