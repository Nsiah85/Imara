import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { GoogleGenAI } from '@google/genai';
import { mockProfessionals } from '../data/mockData.ts';
import type { Professional, Participant } from '../types.ts';
import Button from '../components/ui/Button.tsx';
import { GlobeIcon, VerifiedBadgeIcon, BriefcaseIcon, DollarSignIcon, EnvelopeIcon, EllipsisHorizontalIcon, CheckCircleIcon } from '../components/icons/Icons.tsx';
import SkeletonLoader from '../components/ui/SkeletonLoader.tsx';
import { useCurrency } from '../contexts/CurrencyContext.tsx';
import BackButton from '../components/ui/BackButton.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';
import ContactActionModal from '../components/modals/ContactActionModal.tsx';
import Avatar from '../components/ui/Avatar.tsx';

const ProfessionalPublicProfilePage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const professional = mockProfessionals.find(p => p.storeSlug === slug);
  const { user: loggedInUser, followUser, unfollowUser, isFollowing } = useAuth();
  
  const [bio, setBio] = useState<string>('');
  const [isBioLoading, setIsBioLoading] = useState(true);
  const { formatCurrency } = useCurrency();
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('work');

  const getWageText = (wageRange: [number, number], wageType: string) => {
    const typeText = wageType === 'hourly' ? '/hr' : wageType === 'daily' ? '/day' : '/project';
    const formattedRange = wageRange.map(w => formatCurrency(w, { minimumFractionDigits: 0 }));
    if (wageRange[0] === wageRange[1]) return `${formattedRange[0]}${typeText}`;
    return `${formattedRange[0]} - ${formattedRange[1]}${typeText}`;
  };

  useEffect(() => {
    if (!professional) return;
    
    const generateBio = async () => {
      setIsBioLoading(true);
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const prompt = `Generate a short, professional bio for: ${professional.name}, a ${professional.professionalRole} in ${professional.location}. Skills: ${professional.skills.join(', ')}.`;
        const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
        setBio(response.text || '');
      } catch (error) {
        setBio(`Dedicated ${professional.professionalRole} based in ${professional.location}.`);
      } finally {
        setIsBioLoading(false);
      }
    };
    generateBio();
  }, [professional]);

  if (!professional) return <div className="p-20 text-center">Profile Not Found</div>;

  const isOwnProfile = loggedInUser?.id === professional.id;
  const following = loggedInUser ? isFollowing(professional.id) : false;
  const participantForModal: Participant = { id: professional.id, name: professional.name, avatarUrl: professional.profileImageUrl, role: professional.professionalRole, profileLink: `/workman/${professional.storeSlug}` };

  return (
    <div className="bg-gray-50 dark:bg-gray-900 min-h-screen pb-20">
        <BackButton className="absolute top-4 left-4 z-20 text-white mix-blend-difference" />
        
        {/* Modern Header Style (Image 2 inspired) */}
        <div className="w-full max-w-5xl mx-auto bg-white dark:bg-brand-navy-dark shadow-2xl rounded-b-[40px] overflow-hidden">
            
            {/* Banner */}
            <div className="h-48 md:h-64 w-full bg-gradient-to-r from-brand-navy-dark to-brand-green relative overflow-hidden">
                {professional.coverImageUrl ? (
                    <img src={professional.coverImageUrl} alt="Cover" className="w-full h-full object-cover opacity-60" />
                ) : (
                    <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
                )}
            </div>

            <div className="px-6 pb-8 relative">
                <div className="flex flex-col md:flex-row items-start gap-6 -mt-12">
                    {/* Avatar */}
                    <div className="relative z-10">
                         <Avatar 
                            imageUrl={professional.profileImageUrl} 
                            name={professional.name} 
                            className="w-32 h-32 md:w-40 md:h-40 rounded-full border-4 border-white dark:border-brand-navy-dark shadow-lg bg-white"
                        />
                         {professional.isVerified && (
                            <div className="absolute bottom-2 right-2 bg-white dark:bg-brand-navy-dark rounded-full p-1.5 shadow-sm">
                                <VerifiedBadgeIcon className="w-6 h-6 text-brand-gold" />
                            </div>
                        )}
                    </div>

                    {/* Info & Actions */}
                    <div className="flex-grow pt-14 md:pt-16 flex flex-col md:flex-row justify-between items-start w-full gap-4">
                        <div>
                            <h1 className="text-3xl font-display font-bold text-brand-navy-dark dark:text-white">{professional.name}</h1>
                            <p className="text-brand-green dark:text-brand-gold-light font-medium text-lg">{professional.professionalRole}</p>
                            <div className="flex items-center gap-2 mt-1 text-sm text-gray-500 dark:text-gray-400">
                                <GlobeIcon className="w-4 h-4"/> {professional.location} &middot; {professional.industry}
                            </div>
                        </div>

                        <div className="flex gap-3 w-full md:w-auto">
                             {!isOwnProfile && (
                                <>
                                    <Button onClick={() => { if(loggedInUser) following ? unfollowUser(professional.id) : followUser(professional.id) }} variant={following ? 'outline' : 'primary'} className="rounded-full px-6">
                                        {following ? 'Following' : 'Follow'}
                                    </Button>
                                    <Button onClick={() => setIsContactModalOpen(true)} variant="secondary" className="rounded-full px-6">
                                        Hire Me
                                    </Button>
                                </>
                            )}
                             <button className="p-2.5 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-200">
                                <EllipsisHorizontalIcon className="w-6 h-6"/>
                            </button>
                        </div>
                    </div>
                </div>

                {/* Stats Row */}
                <div className="flex gap-8 mt-8 border-t border-gray-100 dark:border-gray-700 pt-6">
                     <div className="text-center">
                         <span className="block font-bold text-xl text-brand-navy-dark dark:text-white">2.1K</span>
                         <span className="text-xs text-gray-500 uppercase tracking-wider">Followers</span>
                     </div>
                     <div className="text-center">
                         <span className="block font-bold text-xl text-brand-navy-dark dark:text-white">180</span>
                         <span className="text-xs text-gray-500 uppercase tracking-wider">Following</span>
                     </div>
                     <div className="text-center">
                         <span className="block font-bold text-xl text-brand-navy-dark dark:text-white">{getWageText(professional.wageRange, professional.wageType)}</span>
                         <span className="text-xs text-gray-500 uppercase tracking-wider">Rate</span>
                     </div>
                </div>
            </div>
        </div>

        {/* Tabbed Content */}
        <div className="w-full max-w-5xl mx-auto mt-8 px-4">
            <div className="flex gap-6 border-b border-gray-200 dark:border-gray-700 mb-6 overflow-x-auto scrollbar-hide">
                {['work', 'about', 'services'].map(tab => (
                    <button 
                        key={tab}
                        onClick={() => setActiveTab(tab)}
                        className={`pb-3 px-2 text-sm font-bold uppercase tracking-wider transition-all relative ${activeTab === tab ? 'text-brand-navy-dark dark:text-white' : 'text-gray-400 hover:text-gray-600'}`}
                    >
                        {tab}
                        {activeTab === tab && <span className="absolute bottom-0 left-0 w-full h-1 bg-brand-gold rounded-t-full"></span>}
                    </button>
                ))}
            </div>

            <div className="min-h-[300px]">
                {activeTab === 'work' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        {professional.portfolioImageUrls?.map((url, i) => (
                             <div key={i} className="group relative aspect-[4/3] rounded-2xl overflow-hidden shadow-md cursor-pointer">
                                <img src={url} alt="Portfolio" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
                                    <p className="text-white font-bold">Project {i+1}</p>
                                    <p className="text-white/80 text-xs">View details</p>
                                </div>
                            </div>
                        ))}
                        {!professional.portfolioImageUrls?.length && <p className="text-gray-500 col-span-full text-center">No portfolio items yet.</p>}
                    </div>
                )}

                {activeTab === 'about' && (
                     <div className="bg-white dark:bg-brand-navy-dark p-8 rounded-3xl shadow-sm">
                         <h3 className="text-xl font-bold text-brand-navy-dark dark:text-white mb-4">About {professional.name}</h3>
                         <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-6">{isBioLoading ? <SkeletonLoader className="h-20 w-full"/> : bio}</p>
                         
                         <h4 className="font-bold text-brand-navy-dark dark:text-white mb-3">Skills</h4>
                         <div className="flex flex-wrap gap-2">
                             {professional.skills.map(skill => (
                                 <span key={skill} className="px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 rounded-full text-sm font-medium">{skill}</span>
                             ))}
                         </div>
                     </div>
                )}
            </div>
        </div>

        {isContactModalOpen && <ContactActionModal participant={participantForModal} onClose={() => setIsContactModalOpen(false)} />}
    </div>
  );
};

export default ProfessionalPublicProfilePage;