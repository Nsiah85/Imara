
import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { mockGistPosts, mockGistStatuses, mockCulturalImpactEntries, mockTravelServices } from '../data/mockData.ts';
import { collection, onSnapshot, query, orderBy, limit, db, setDoc, doc } from '../firebase/firestore.ts';
import { logUserInteraction } from '../services/dataService.ts';
import type { GistPost, GistStatus, TravelService } from '../types.ts';
import GistPostCard from '../components/gist/GistPostCard.tsx';
import GistOnboarding from '../components/gist/GistOnboarding.tsx';
import CommentModal from '../components/gist/CommentModal.tsx';
import StatusBar from '../components/gist/StatusBar.tsx';
import StatusViewerModal from '../components/gist/StatusViewerModal.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';
import { useCart } from '../contexts/CartContext.tsx';
import PaymentModal from '../components/modals/PaymentModal.tsx';
import BookingModal from '../components/modals/BookingModal.tsx';
import TrendingGists from '../components/gist/TrendingGists.tsx';
import CreateGistPost from '../components/gist/CreateGistPost.tsx';
import ToastComposerModal from '../components/gist/ToastComposerModal.tsx'; 
import { useMonetization } from '../contexts/MonetizationContext.tsx';
// Added CheckCircleIcon to the imported icons
import { SparklesIcon, CheckCircleIcon } from '../components/icons/Icons.tsx';
import TheaterModal from '../components/gist/TheaterModal.tsx';
import LoadingSpinner from '../components/ui/LoadingSpinner.tsx';
import AddStatusModal from '../components/gist/AddStatusModal.tsx';
import SEO from '../components/seo/SEO.tsx';
import { getLocalizedWelcome } from '../utils/localization.ts';
import ImpactSnapCard from '../components/shared/ImpactSnapCard.tsx';

const HomePage: React.FC = () => {
  const { user } = useAuth();
  const { addToCart } = useCart();
  const { addEngagement } = useMonetization();
  const navigate = useNavigate();
  const location = useLocation();
  
  // Data State
  const [posts, setPosts] = useState<GistPost[]>([]);
  const [statuses, setStatuses] = useState<GistStatus[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [hasMore, setHasMore] = useState(true);
  const [page, setPage] = useState(1);
  
  // Modal Visibility State
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [isToastComposerOpen, setIsToastComposerOpen] = useState(false);
  const [toastComposerInitialTab, setToastComposerInitialTab] = useState<'text' | 'media'>('text');
  const [isStatusCreatorOpen, setIsStatusCreatorOpen] = useState(false);
  
  // Interaction State
  const [commentingPostId, setCommentingPostId] = useState<string | null>(null); 
  const [activeTrend, setActiveTrend] = useState<string | null>(null);

  // Viewers
  const [viewedStatusIds, setViewedStatusIds] = useState<string[]>([]);
  const [viewingStatusIndex, setViewingStatusIndex] = useState<number | null>(null);
  const [isTheaterMode, setIsTheaterMode] = useState(false);
  const [theaterStartIndex, setTheaterStartIndex] = useState(0);

  // Modals for Post Actions
  const [bookingService, setBookingService] = useState<TravelService | null>(null);
  const [donatingCauseId, setDonatingCauseId] = useState<string | null>(null);

  // Infinite Scroll Observer
  const loaderRef = useRef<HTMLDivElement>(null);
  const observer = useRef<IntersectionObserver | null>(null);

  const welcomeMessage = useMemo(() => getLocalizedWelcome(user), [user]);

  // Load Statuses
  useEffect(() => {
    const storedStatuses = localStorage.getItem('imara_gist_statuses');
    setStatuses(storedStatuses ? JSON.parse(storedStatuses) : mockGistStatuses);
    
    const storedViewed = localStorage.getItem('viewedStatusIds');
    if (storedViewed) setViewedStatusIds(JSON.parse(storedViewed));

    const hasSeenOnboarding = localStorage.getItem('gist_onboarding_seen');
    if (!hasSeenOnboarding) setShowOnboarding(true);
  }, []);

  // Listen for 'refresh-toast-feed'
  useEffect(() => {
     const handleRefresh = () => {
         window.scrollTo({ top: 0, behavior: 'smooth' });
         setIsLoading(true);
         setTimeout(() => setIsLoading(false), 500); 
     };
     window.addEventListener('refresh-toast-feed', handleRefresh);
     return () => window.removeEventListener('refresh-toast-feed', handleRefresh);
  }, []);

  // Fetch more posts logic
  const loadMorePosts = useCallback(() => {
    if (!hasMore || isLoading && page > 1) return;

    // Simulate API delay
    setTimeout(() => {
        // Generate mock "paged" data by reusing mock posts with fresh IDs
        const morePosts = mockGistPosts.map(p => ({
            ...p,
            id: `${p.id}-p${page}-${Math.random().toString(36).substr(2, 9)}`,
            timestamp: new Date(Date.now() - (page * 3600000)).toISOString()
        }));

        setPosts(prev => [...prev, ...morePosts]);
        setPage(prev => prev + 1);
        
        // Stop after 5 pages for the demo
        if (page > 5) setHasMore(false);
        setIsLoading(false);
    }, 1200);
  }, [page, hasMore, isLoading]);

  // Initial Load & Realtime Listener
  useEffect(() => {
    setIsLoading(true);
    
    // Realtime listener using Firebase
    const q = query(collection(db, 'toasts'), orderBy('timestamp', 'desc'), limit(50));
    const unsubscribe = onSnapshot(q, (snapshot) => {
        const realtimePosts = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as GistPost));
        
        // Inject system post if needed
        const impactSnap = mockCulturalImpactEntries[0];
        const impactPost: GistPost = {
            id: 'cultural_impact_snap_initial',
            creator: { id: 'imara_brand', name: 'Imara Cultural Council', avatarUrl: '', profileLink: '/invest', role: 'admin', isVerified: true },
            timestamp: new Date().toISOString(),
            content: {
                text: `Celebrating ${impactSnap.artistName}. Vision building legacy. %CulturalImpact`,
                type: 'cultural_snap',
                impactSnap
            },
            tags: ['%Legacy', '%Heritage'],
            engagement: { likes: 120, commentsCount: 5, shares: 10, saves: 20, rating: 5, ratingCount: 1 },
            comments: []
        };

        setPosts([impactPost, ...realtimePosts]);
        setIsLoading(false);
    }, (error) => {
        console.warn("Firebase listener warning (Check Firestore Rules):", error.message);
        // Fallback for offline usage only
        const storedPosts = localStorage.getItem('imara_gist_posts');
        if (storedPosts) {
            setPosts(JSON.parse(storedPosts));
        } else {
            setPosts([]);
        }
        setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Setup Observer for Endless Scroll
  useEffect(() => {
    if (isLoading) return;
    
    const options = { root: null, rootMargin: '20px', threshold: 0.1 };
    
    observer.current = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting && hasMore) {
            loadMorePosts();
        }
    }, options);

    if (loaderRef.current) {
        observer.current.observe(loaderRef.current);
    }

    return () => {
        if (observer.current) observer.current.disconnect();
    };
  }, [isLoading, hasMore, loadMorePosts]);

  const handleLikePost = (postId: string) => {
      const targetPost = posts.find(p => p.id === postId);
      if (!targetPost) return;
      
      const currentlyLiked = targetPost.likedByMe;
      if (!currentlyLiked && user && targetPost.creator.id !== user.id) {
          addEngagement('engagement_given', { targetUserId: targetPost.creator.id, postId: targetPost.id }); // Reward as active engagement
          logUserInteraction(user.id, targetPost.id, 'like').catch(console.error);
      }
      
      const updatedPost = { 
          ...targetPost, 
          likedByMe: !currentlyLiked, 
          engagement: { 
              ...targetPost.engagement, 
              likes: currentlyLiked ? targetPost.engagement.likes - 1 : targetPost.engagement.likes + 1 
          } 
      };
      
      // Update in Firebase (optimistic UI update is handled by onSnapshot eventually, but we update db here)
      setDoc(doc(db, 'toasts', postId), updatedPost, { merge: true }).catch(console.error);
  };

  const handleSavePost = (postId: string) => {
      const targetPost = posts.find(p => p.id === postId);
      if (!targetPost || !user) return;
      
      const newSavesCount = (targetPost.engagement.saves || 0) + 1;
      const updatedPost = {
          ...targetPost,
          engagement: { ...targetPost.engagement, saves: newSavesCount }
      };
      
      setDoc(doc(db, 'toasts', postId), updatedPost, { merge: true }).catch(console.error);
      logUserInteraction(user.id, targetPost.id, 'save').catch(console.error);
  };

  const handleGiftPost = (postId: string) => {
      const targetPost = posts.find(p => p.id === postId);
      if (!targetPost || !user) return;
      
      // In a real app, this would open a modal to select a gift and deduct balance
      // For now, we simulate sending a standard gift and creating a gift_celebration comment
      const newGiftCount = (targetPost.engagement.ratingCount || 0) + 1; // reusing ratingCount as gift counter for simplicity or add a new field
      
      const newComment = {
          id: `gift-${Date.now()}`,
          author: { id: user.id, name: user.fullName, avatarUrl: user.profileImageUrl || '' },
          text: "Sent a 🎁 Heart of Gold!",
          timestamp: new Date().toISOString(),
          isGift: true
      };

      const updatedPost = {
          ...targetPost,
          comments: [...(targetPost.comments || []), newComment],
          engagement: { 
              ...targetPost.engagement, 
              commentsCount: (targetPost.engagement.commentsCount || 0) + 1,
              ratingCount: newGiftCount
          }
      };
      
      setDoc(doc(db, 'toasts', postId), updatedPost, { merge: true }).catch(console.error);
      // @ts-ignore
      logUserInteraction(user.id, targetPost.id, 'gift').catch(console.error);
      alert("Gift sent secretly! 🎁");
  };

  const handlePostCreated = async (newPost: GistPost) => {
      // Optimistic update + local cache
      const storedPosts = localStorage.getItem('imara_gist_posts');
      let currentPosts = storedPosts ? JSON.parse(storedPosts) : mockGistPosts.map(p => ({ ...p, originalPostId: p.id }));
      const updatedPosts = [newPost, ...currentPosts];
      localStorage.setItem('imara_gist_posts', JSON.stringify(updatedPosts));
      setPosts(prev => [newPost, ...prev]);
      setIsToastComposerOpen(false);

      // Create in Firebase
      try {
          await setDoc(doc(db, 'toasts', newPost.id), newPost);
      } catch (e) {
          console.error("Firebase save failed, but retained in local fallback", e);
      }
  };

  const sortedStatuses = useMemo(() => {
      const unviewed = statuses.filter(s => !viewedStatusIds.includes(s.id));
      const viewed = statuses.filter(s => viewedStatusIds.includes(s.id));
      return [...unviewed, ...viewed];
  }, [statuses, viewedStatusIds]);

  const [feedMode, setFeedMode] = useState<'all' | 'live'>('all');

  const filteredPosts = useMemo(() => {
    if (feedMode === 'all') return posts;
    return posts.filter(post => post.content.type === 'cultural_snap' || post.tags.includes('%Live') || post.tags.includes('%Festival'));
  }, [posts, feedMode]);

  return (
    <div className="min-h-screen bg-brand-off-white dark:bg-gray-900 pb-20 relative">
        <SEO title="Imara - Toast" description="The heartbeat of African commerce." />
        
        <div className="container mx-auto px-0 sm:px-4 max-w-4xl relative z-10">
            
            <div className="z-30 bg-brand-off-white/95 dark:bg-gray-900/95 backdrop-blur-md pt-2">
                <StatusBar 
                    statuses={sortedStatuses} 
                    viewedStatusIds={viewedStatusIds} 
                    currentUser={user} 
                    onViewStatus={(index) => setViewingStatusIndex(index)} 
                    onAddGist={() => setIsStatusCreatorOpen(true)} 
                />
            </div>

            <div className="flex gap-6 mt-6 px-4 sm:px-0">
                <div className="flex-1 w-full max-w-xl mx-auto">
                    {user && (
                        <div className="mb-4">
                            <p className="text-[10px] font-black text-brand-gold uppercase tracking-[0.2em] mb-2">
                                {welcomeMessage}, {user.fullName.split(' ')[0]}
                            </p>
                            <CreateGistPost onOpen={(type) => { setToastComposerInitialTab(type); setIsToastComposerOpen(true); }} />
                        </div>
                    )}
                    
                    <div className="flex bg-gray-200 dark:bg-gray-800 p-1 rounded-full mb-6 max-w-xs mx-auto">
                        <button 
                            onClick={() => setFeedMode('all')}
                            className={`flex-1 py-2 text-sm font-bold rounded-full transition-all ${feedMode === 'all' ? 'bg-white dark:bg-gray-700 shadow-sm text-brand-navy-dark dark:text-white' : 'text-gray-500 hover:text-gray-700'}`}
                        >
                            Global
                        </button>
                        <button 
                            onClick={() => setFeedMode('live')}
                            className={`flex-1 py-2 text-sm font-bold rounded-full transition-all flex items-center justify-center gap-1 ${feedMode === 'live' ? 'bg-white dark:bg-gray-700 shadow-sm text-red-500 dark:text-red-400' : 'text-gray-500 hover:text-red-400'}`}
                        >
                            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
                            Live & Festivals
                        </button>
                    </div>

                    <div className="space-y-6 pb-10">
                        {filteredPosts.length === 0 ? (
                            <div className="text-center py-12">
                                <p className="text-gray-500">No events found in this view.</p>
                            </div>
                        ) : filteredPosts.map((post, index) => (
                            post.content.type === 'cultural_snap' && post.content.impactSnap ? (
                                <div key={post.id} className="mb-6 animate-fade-in">
                                     <div className="flex items-center gap-2 mb-3">
                                        <div className="p-1 bg-brand-gold/10 rounded-lg"><SparklesIcon className="w-4 h-4 text-brand-gold"/></div>
                                        <span className="text-[10px] font-black text-brand-navy-dark dark:text-white uppercase tracking-widest">Legacy Spotlight</span>
                                     </div>
                                     <ImpactSnapCard entry={post.content.impactSnap} />
                                </div>
                            ) : (
                                <GistPostCard 
                                    key={post.id}
                                    post={post}
                                    onCommentClick={() => setCommentingPostId(post.id)}
                                    onAddToCart={addToCart}
                                    onBookService={(id) => {
                                        const service = mockTravelServices.find(s => s.id === id);
                                        if(service) setBookingService(service);
                                    }}
                                    onDonateNow={(id) => setDonatingCauseId(id)}
                                    onLearnMore={() => navigate('/invest')}
                                    onTheaterMode={() => { setTheaterStartIndex(index); setIsTheaterMode(true); }}
                                    onLike={() => handleLikePost(post.id)}
                                    onSave={() => handleSavePost(post.id)}
                                    onGift={() => handleGiftPost(post.id)}
                                />
                            )
                        ))}
                        
                        {/* Endless Scroll Loader Target */}
                        <div ref={loaderRef} className="py-10 flex justify-center">
                            {hasMore ? (
                                <div className="flex flex-col items-center gap-3">
                                    <LoadingSpinner className="w-8 h-8" />
                                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest animate-pulse">Sourcing more culture...</p>
                                </div>
                            ) : (
                                <div className="text-center p-8 bg-white dark:bg-gray-800 rounded-3xl border border-dashed border-gray-200 dark:border-gray-700">
                                    <CheckCircleIcon className="w-8 h-8 text-brand-green mx-auto mb-2" />
                                    <p className="text-sm font-bold text-brand-navy-dark dark:text-white">You've reached the origin.</p>
                                    <p className="text-xs text-gray-500 mt-1">Refining your feed for the next cycle.</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                <div className="hidden lg:block w-80 sticky top-24 h-[calc(100vh-120px)]">
                    <TrendingGists onTrendClick={(trend) => { setActiveTrend(trend); window.scrollTo({ top: 0, behavior: 'smooth' }); }} activeTrend={activeTrend} />
                </div>
            </div>
        </div>
        
        {/* Modals for various interactions */}
        {isToastComposerOpen && <ToastComposerModal onClose={() => setIsToastComposerOpen(false)} onPost={handlePostCreated} initialTab={toastComposerInitialTab} />}
        {isStatusCreatorOpen && <AddStatusModal onClose={() => setIsStatusCreatorOpen(false)} onAddStatus={(newStatus) => {
            const updatedStatuses = [newStatus, ...statuses];
            setStatuses(updatedStatuses);
            localStorage.setItem('imara_gist_statuses', JSON.stringify(updatedStatuses));
        }} />}
        
        {commentingPostId && <CommentModal post={posts.find(p => p.id === commentingPostId)!} onClose={() => setCommentingPostId(null)} onAddComment={(comment) => {
            const targetPost = posts.find(p => p.id === commentingPostId);
            if (targetPost) {
                const updatedPost = { 
                    ...targetPost, 
                    comments: [...(targetPost.comments || []), comment],
                    engagement: { 
                        ...targetPost.engagement, 
                        commentsCount: (targetPost.engagement.commentsCount || 0) + 1 
                    } 
                };
                setDoc(doc(db, 'toasts', targetPost.id), updatedPost, { merge: true }).catch(console.error);
                if (user) {
                    logUserInteraction(user.id, targetPost.id, 'comment').catch(console.error);
                }
            }
        }} />}
        {isTheaterMode && <TheaterModal posts={posts} startIndex={theaterStartIndex} onClose={() => setIsTheaterMode(false)} onAddToCart={addToCart} onBookService={() => {}} onDonateNow={() => {}} onLearnMore={() => {}} />}
        {bookingService && <BookingModal service={bookingService} onClose={() => setBookingService(null)} />}
        {donatingCauseId && <PaymentModal item={{ id: donatingCauseId, type: 'donation', title: 'Cause', recipient: 'Org', imageUrl: '' }} onClose={() => setDonatingCauseId(null)} onSuccess={() => setDonatingCauseId(null)} />}
        {showOnboarding && <GistOnboarding onClose={() => { setShowOnboarding(false); localStorage.setItem('gist_onboarding_seen', 'true'); }} />}

        {viewingStatusIndex !== null && (
            <StatusViewerModal statuses={sortedStatuses} startIndex={viewingStatusIndex} onClose={() => setViewingStatusIndex(null)} onViewed={(id) => setViewedStatusIds(prev => [...prev, id])} />
        )}
    </div>
  );
};

export default HomePage;
