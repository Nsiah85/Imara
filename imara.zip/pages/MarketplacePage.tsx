import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { mockProfessionals } from '../data/mockData.ts';
import { ProfessionalIndustry, type Professional } from '../types.ts';
import ProfessionalCard from '../components/marketplace/ProfessionalCard.tsx';
import ProfessionalListCard from '../components/marketplace/ProfessionalListCard.tsx';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver.ts';
import Button from '../components/ui/Button.tsx';
import ViewSwitcher, { type ViewMode } from '../components/ui/ViewSwitcher.tsx';
import { useLanguage } from '../contexts/LanguageContext.tsx';
import BackButton from '../components/ui/BackButton.tsx';

const MarketplacePage: React.FC = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedIndustry, setSelectedIndustry] = useState<ProfessionalIndustry | null>(null);
    const [sortBy, setSortBy] = useState('relevance');
    const [viewMode, setViewMode] = useState<ViewMode>('grid');
    const { t } = useLanguage();

    const [filtersRef, areFiltersVisible] = useIntersectionObserver<HTMLDivElement>({ threshold: 0.2 });
    const [gridRef, isGridVisible] = useIntersectionObserver<HTMLDivElement>({ threshold: 0.1 });

    const handleIndustryToggle = (industry: ProfessionalIndustry) => {
        setSelectedIndustry(prev => (prev === industry ? null : industry));
    };

    const sortedProfessionals = useMemo(() => {
        const filtered = mockProfessionals.filter(prof => {
            const lowerCaseSearch = searchTerm.toLowerCase();
            const matchesSearch =
                prof.name.toLowerCase().includes(lowerCaseSearch) ||
                prof.professionalRole.toLowerCase().includes(lowerCaseSearch) ||
                prof.skills.some(skill => skill.toLowerCase().includes(lowerCaseSearch));
            
            const matchesIndustry = !selectedIndustry || prof.industry === selectedIndustry;
    
            return matchesSearch && matchesIndustry;
        });

        const sorted = [...filtered];

        switch (sortBy) {
            case 'name_asc':
                sorted.sort((a, b) => a.name.localeCompare(b.name));
                break;
            case 'rate_asc':
                sorted.sort((a, b) => {
                    const rateA = a.wageType === 'hourly' ? a.wageRange[0] : Infinity;
                    const rateB = b.wageType === 'hourly' ? b.wageRange[0] : Infinity;
                    return rateA - rateB;
                });
                break;
            default:
                break;
        }
        return sorted;
    }, [searchTerm, selectedIndustry, sortBy]);


    return (
        <div className="bg-transparent">
            <div className="container mx-auto px-6 py-8">
                <BackButton className="mb-4" />
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-display font-bold text-brand-green-dark dark:text-white">{t('findTalent.title')}</h1>
                    <p className="mt-2 text-brand-gray dark:text-gray-400 max-w-xl mx-auto">{t('findTalent.subtitle')}</p>
                </div>

                <div
                    ref={filtersRef}
                    className={`mb-8 p-6 bg-white dark:bg-gray-800 rounded-lg shadow-sm transition-all duration-700 ease-out ${
                        areFiltersVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                    }`}
                >
                    <div className="flex flex-col gap-6">
                        <div className="flex flex-col md:flex-row gap-4">
                            <div className="relative w-full md:flex-grow">
                                <input
                                    type="text"
                                    placeholder={t('findTalent.filters.searchPlaceholder')}
                                    className="w-full p-3 border border-brand-green rounded-md focus:ring-brand-gold focus:border-brand-gold bg-brand-green-dark text-white placeholder:text-gray-400"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    autoComplete="off"
                                />
                            </div>
                            <div className="flex items-center gap-4 w-full md:w-auto">
                                <select
                                    value={sortBy}
                                    onChange={(e) => setSortBy(e.target.value)}
                                    className="w-full md:w-auto p-3 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:ring-brand-gold focus:border-brand-gold bg-white"
                                    aria-label="Sort professionals by"
                                >
                                    <option value="relevance">{t('findTalent.filters.sortBy')}: {t('findTalent.filters.sort.relevance')}</option>
                                    <option value="name_asc">{t('findTalent.filters.sort.name')}</option>
                                    <option value="rate_asc">{t('findTalent.filters.sort.rate')}</option>
                                </select>
                                <ViewSwitcher viewMode={viewMode} setViewMode={setViewMode} />
                            </div>
                        </div>
                        <div>
                            <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3">{t('findTalent.filters.industry')}</h3>
                            <div className="flex flex-wrap gap-2">
                                {(Object.values(ProfessionalIndustry) as ProfessionalIndustry[]).map(industry => (
                                    <button
                                        key={industry}
                                        onClick={() => handleIndustryToggle(industry)}
                                        className={`px-3 py-1 text-sm rounded-full border-2 transition-colors ${
                                            selectedIndustry === industry
                                                ? 'bg-brand-green text-white border-brand-green'
                                                : 'bg-transparent text-gray-600 dark:text-gray-300 border-gray-300 dark:border-gray-600 hover:border-brand-green dark:hover:border-brand-green'
                                        }`}
                                    >
                                        {industry}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>

                 <div className="my-10 text-center p-8 bg-brand-green/5 dark:bg-brand-green/20 rounded-lg">
                    <h2 className="text-2xl font-display font-bold text-brand-green-dark dark:text-white">{t('findTalent.cta.title')}</h2>
                    <p className="mt-2 text-brand-gray dark:text-gray-400 max-w-xl mx-auto">{t('findTalent.cta.subtitle')}</p>
                    <Link to="/join/workman">
                        <Button variant="primary" size="lg" className="mt-6">{t('findTalent.cta.button')}</Button>
                    </Link>
                </div>

                <div
                    ref={gridRef}
                    className={`transition-all duration-700 ease-out ${
                        isGridVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                    }`}
                >
                    {sortedProfessionals.length > 0 ? (
                         <>
                            {viewMode === 'list' ? (
                                <div className="space-y-4">
                                    {sortedProfessionals.map((prof) => (
                                        <ProfessionalListCard key={prof.id} professional={prof} />
                                    ))}
                                </div>
                            ) : (
                                <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8' : 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4'}`}>
                                    {sortedProfessionals.map((prof, index) => (
                                        <ProfessionalCard
                                            key={prof.id}
                                            professional={prof}
                                            animationDelay={index * 75}
                                            compact={viewMode === 'tile'}
                                        />
                                    ))}
                                </div>
                            )}
                        </>
                    ) : (
                        <div className="text-center py-20">
                            <h2 className="text-2xl font-display font-semibold text-brand-green-dark dark:text-white">{t('findTalent.noProfessionalsFound')}</h2>
                            <p className="mt-2 text-brand-gray dark:text-gray-400">{t('feelAfro.noServicesMessage')}</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default MarketplacePage;