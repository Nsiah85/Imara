
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import type { PartnerApplication, Partner, UserProfile } from '../types.ts';
import ApplicationReviewModal from '../components/modals/ApplicationReviewModal.tsx';
import AdminContentManager from '../components/admin/AdminContentManager.tsx';
import AdminSubscriptionManager from '../components/admin/AdminSubscriptionManager.tsx';
import AdminPartnerManager from '../components/admin/AdminPartnerManager.tsx';
import { mockVendors, mockProfessionals, mockTravelPartners, mockUsers } from '../data/mockData.ts';
import PayoutSettings from '../components/admin/PayoutSettings.tsx';
import FundsFlowCard from '../components/admin/FundsFlowCard.tsx';
import AdminProfileSettings from '../components/admin/AdminProfileSettings.tsx';
import AdminGiftCardManager from '../components/admin/AdminGiftCardManager.tsx';
import AdminEdwasoMarketManager from '../components/admin/AdminEdwasoMarketManager.tsx';
import SocialMediaManager from '../components/admin/SocialMediaManager.tsx';
import AdminLiveEventManager from '../components/admin/AdminLiveEventManager.tsx';
import AdminGossipPulseManager from '../components/admin/AdminGossipPulseManager.tsx';
import AdminPaymentGatewayManager from '../components/admin/AdminPaymentGatewayManager.tsx';
import AdminPackageGovernance from '../components/admin/AdminPackageGovernance.tsx';
import AdminGiftManager from '../components/admin/AdminGiftManager.tsx';
import GlobalUIConfig from '../components/admin/GlobalUIConfig.tsx';
import AdminCitizenManager from '../components/admin/AdminCitizenManager.tsx';
import AdminProductManager from '../components/admin/AdminProductManager.tsx';
import AdminOrderManager from '../components/admin/AdminOrderManager.tsx';
import AdminQuickActionModal from '../components/admin/AdminQuickActionModal.tsx';
import AdminAdsManager from '../components/admin/AdminAdsManager.tsx';
import AdminMonkixCi from '../components/admin/AdminMonkixCi.tsx';
import Button from '../components/ui/Button.tsx';
import { useCurrency } from '../contexts/CurrencyContext.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';
import Avatar from '../components/ui/Avatar.tsx';
import LoadingSpinner from '../components/ui/LoadingSpinner.tsx';
import { 
    EyeIcon, ChartBarIcon, UserGroupIcon, 
    Cog6ToothIcon, VideoCameraIcon, 
    ShoppingBagIcon, CheckCircleIcon, Bars3Icon, 
    ArrowLeftIcon, SparklesIcon, BoltIcon, 
    ShieldCheckIcon, GlobeIcon, ExclamationTriangleIcon,
    UsersIcon, HandCoinIcon, WhatsAppIcon, CreditCardIcon, GiftIcon
} from '../components/icons/Icons.tsx';

type AdminTab = 'command_center' | 'citizenship' | 'moderation' | 'market_ops' | 'impact_studio' | 'live_manager' | 'ads_growth' | 'governance' | 'monkix_ci';

const CommandCenterOverview: React.FC<{ citizens: UserProfile[], partners: Partner[] }> = ({ citizens, partners }) => {
    const [showLogs, setShowLogs] = useState(false);
    return (
        <div className="space-y-10 animate-fade-in">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <FundsFlowCard title="Active Imarans" amount={citizens.length} period="vs Live" change="+45" changeType="positive" />
                <FundsFlowCard title="Trade Volume" amount={20000.00} period="vs Today" change="+12%" changeType="positive" />
                <FundsFlowCard title="Security Score" amount={99} period="vs Health" change="Optimal" changeType="positive" />
                <FundsFlowCard title="Market Reach" amount={partners.length} period="vs Index" change="+3" changeType="positive" />
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                    <GlobalUIConfig />
                </div>
                <div className="bg-white dark:bg-gray-800 p-8 rounded-[40px] border border-gray-100 dark:border-gray-700 flex flex-col justify-between shadow-sm">
                    <div>
                        <SparklesIcon className="w-12 h-12 text-brand-gold mb-4" />
                        <h4 className="text-2xl font-display font-black text-brand-navy-dark dark:text-white leading-tight">System Pulse <br/>Active</h4>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-4 leading-relaxed">System performance is at 99.9%. All regional hubs connected and reporting data in real-time.</p>
                    </div>
                    <Button className="w-full mt-8" variant="outline" onClick={() => setShowLogs(!showLogs)}>View Detailed Logs</Button>
                    {showLogs && (
                        <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-mono text-gray-500 overflow-y-auto max-h-40">
                            <p>[{new Date().toISOString()}] SYSTEM ORBIT - ALL PLATFORMS NOMINAL</p>
                            <p>[{new Date().toISOString()}] SYNC STATE: OPTIMAL</p>
                            <p>[{new Date().toISOString()}] GOSSIP PULSE OVERSEER: GREEN</p>
                            <p>WAITING FOR NEW LOGS...</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const AdminPage: React.FC = () => {
    const [activeTab, setActiveTab] = useState<AdminTab>('command_center');
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);
    const [isQuickActionOpen, setIsQuickActionOpen] = useState(false);
    const [showLogs, setShowLogs] = useState(false);
    const { user, isLoading } = useAuth();
    const { formatCurrency } = useCurrency();
    const navigate = useNavigate();
    const [applications, setApplications] = useState<PartnerApplication[]>([]);
    const [selectedApplication, setSelectedApplication] = useState<PartnerApplication | null>(null);
    const [partners, setPartners] = useState<Partner[]>([]);
    const [citizens, setCitizens] = useState<UserProfile[]>([]);

    useEffect(() => {
        if (!user && !isLoading) return;
        
        try {
            const storedApps = localStorage.getItem('imara_partner_applications');
            const parsedApps: PartnerApplication[] = storedApps ? JSON.parse(storedApps) : [];
            setApplications(parsedApps.filter((app) => app.status === 'pending'));

            const storedPartners = localStorage.getItem('partners');
            const approvedPartners: Partner[] = storedPartners ? JSON.parse(storedPartners) : [];
            const allPartners = [...mockVendors, ...mockProfessionals, ...mockTravelPartners, ...approvedPartners];
            setPartners(Array.from(new Map(allPartners.map(p => [p.id, p])).values()));

            const storedUsers = localStorage.getItem('imara_all_users');
            setCitizens(storedUsers ? JSON.parse(storedUsers) : mockUsers);
        } catch (error) {
            setPartners([...mockVendors, ...mockProfessionals, ...mockTravelPartners]);
        }
    }, [user, isLoading]);

    const handleApplicationDecision = (appId: string, decision: 'approved' | 'rejected') => {
        setApplications(prev => prev.filter(app => app.id !== appId));
        setSelectedApplication(null);
    };

    const NavItem = ({ id, icon, label }: { id: AdminTab; icon: React.ReactNode; label: string }) => (
        <button 
            onClick={() => setActiveTab(id)}
            className={`flex items-center gap-3 w-full p-4 rounded-2xl transition-all duration-300 ${activeTab === id ? 'bg-brand-gold text-brand-navy-dark shadow-xl scale-105' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
        >
            <div className="flex-shrink-0">{icon}</div>
            {isSidebarOpen && <span className="text-sm font-black uppercase tracking-widest whitespace-nowrap">{label.replace('_', ' ')}</span>}
        </button>
    );

    const renderTabContent = () => {
        switch (activeTab) {
            case 'command_center':
                return <CommandCenterOverview citizens={citizens} partners={partners} />;
            case 'citizenship':
                return (
                    <div className="space-y-10 animate-fade-in">
                        <AdminCitizenManager />
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                             <AdminSubscriptionManager />
                             <AdminGiftManager />
                        </div>
                    </div>
                );
            case 'moderation':
                return (
                    <div className="space-y-8 animate-fade-in">
                        <div className="bg-brand-navy-dark p-10 rounded-[40px] text-white relative overflow-hidden">
                            <div className="absolute top-0 right-0 w-64 h-64 bg-brand-gold/10 rounded-full blur-3xl"></div>
                            <div className="relative z-10">
                                <h2 className="text-3xl font-display font-black mb-4">AI Safety Engine</h2>
                                <p className="text-gray-400 max-w-xl mb-6">Monitoring 1.2k active Toasts. 98.4% accuracy on localized dialect flagging across all integrated African regions.</p>
                                <div className="flex gap-4">
                                    <div className="bg-white/10 px-4 py-2 rounded-2xl border border-white/10">
                                        <span className="block text-xs font-bold text-gray-500 uppercase">Flags Handled</span>
                                        <span className="text-xl font-mono font-bold">4.5k</span>
                                    </div>
                                    <div className="bg-white/10 px-4 py-2 rounded-2xl border border-white/10">
                                        <span className="block text-xs font-bold text-gray-500 uppercase">Health Score</span>
                                        <span className="text-xl font-mono font-bold">99%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="bg-white dark:bg-gray-800 p-8 rounded-[40px] border border-gray-100 dark:border-gray-700 shadow-sm">
                             <h3 className="text-xl font-display font-black mb-6">Partner Application Queue</h3>
                             {applications.length > 0 ? (
                                <ul className="space-y-3">
                                    {applications.map(app => (
                                        <li key={app.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl group hover:bg-gray-100 dark:hover:bg-black transition-all">
                                            <div>
                                                <p className="font-bold text-brand-navy-dark dark:text-white">{app.fullName} ({app.role})</p>
                                                <p className="text-xs text-gray-500 font-bold uppercase">{app.brandName || app.industry}</p>
                                            </div>
                                            <Button size="sm" onClick={() => setSelectedApplication(app)}>Review Application</Button>
                                        </li>
                                    ))}
                                </ul>
                            ) : (
                                <div className="text-center py-10 text-gray-400">
                                    <CheckCircleIcon className="w-12 h-12 mx-auto mb-4 opacity-20"/>
                                    <p className="font-bold">No pending applications</p>
                                </div>
                            )}
                        </div>
                    </div>
                );
            case 'market_ops':
                return (
                    <div className="space-y-8 animate-fade-in">
                         <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div className="p-6 bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700">
                                <p className="text-xs font-black text-gray-400 uppercase mb-2">Awaiting Onboarding</p>
                                <p className="text-4xl font-display font-black text-brand-navy-dark dark:text-white">{applications.length}</p>
                                <p className="text-xs text-brand-green font-bold mt-2 flex items-center gap-1"><BoltIcon className="w-3 h-3"/> +{applications.length} new apps</p>
                            </div>
                            <div className="p-6 bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700">
                                <p className="text-xs font-black text-gray-400 uppercase mb-2">Pending Payouts</p>
                                <p className="text-4xl font-display font-black text-brand-navy-dark dark:text-white">{formatCurrency(14500)}</p>
                                <p className="text-xs text-gray-400 font-bold mt-2">Next cycle in 48h</p>
                            </div>
                            <div className="p-6 bg-white dark:bg-gray-800 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700">
                                <p className="text-xs font-black text-gray-400 uppercase mb-2">Active Disputes</p>
                                <p className="text-4xl font-display font-black text-red-600">3</p>
                                <p className="text-xs text-gray-400 font-bold mt-2">Resolving avg 4h</p>
                            </div>
                        </div>
                        <AdminPartnerManager />
                        <AdminProductManager />
                        <AdminEdwasoMarketManager />
                        <div className="mt-8">
                            <h3 className="text-2xl font-display font-black text-brand-navy-dark dark:text-white capitalize mb-4">Order Management</h3>
                            <AdminOrderManager />
                        </div>
                    </div>
                );
            case 'governance':
                return (
                    <div className="space-y-10 animate-fade-in">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <AdminPackageGovernance />
                            <AdminPaymentGatewayManager />
                        </div>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <AdminGossipPulseManager />
                            <div className="space-y-8">
                                <AdminProfileSettings />
                                <SocialMediaManager />
                            </div>
                        </div>
                    </div>
                );
            case 'impact_studio':
                return <AdminContentManager />;
            case 'live_manager':
                return <AdminLiveEventManager />;
            case 'ads_growth':
                return <AdminAdsManager />;
            case 'monkix_ci':
                return <AdminMonkixCi />
            default:
                return <CommandCenterOverview citizens={citizens} partners={partners} />;
        }
    };

    if (isLoading) return <div className="h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900"><LoadingSpinner /></div>;
    if (!user || user.role !== 'admin') return <div className="h-screen flex flex-col items-center justify-center p-8 bg-gray-50 text-center dark:bg-gray-900"><ExclamationTriangleIcon className="w-20 h-20 text-red-600 mb-4"/><h1 className="text-3xl font-black text-brand-navy-dark dark:text-white mb-4 uppercase">Restricted Access</h1><p className="text-gray-500 mb-8">Access to this sector is reserved for Platform Overseers only.</p><Button onClick={() => navigate('/')}>Return to Civilian Access</Button></div>;

    return (
        <div className="min-h-screen bg-[#F8FAFC] dark:bg-gray-950 flex font-sans">
            {/* Sidebar */}
            <aside className={`bg-brand-navy-dark text-white flex-shrink-0 transition-all duration-500 ${isSidebarOpen ? 'w-80' : 'w-24'} fixed h-full z-50 hidden lg:flex flex-col`}>
                 <div className="p-8 flex justify-between items-center border-b border-white/5">
                     {isSidebarOpen && (
                         <div className="flex items-center gap-3">
                            <ShieldCheckIcon className="w-8 h-8 text-brand-gold"/>
                            <div className="font-display font-black text-2xl tracking-tighter">IMARA<span className="text-brand-gold">.OPS</span></div>
                         </div>
                     )}
                     <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 rounded-xl bg-white/5 hover:bg-white/10">
                        {isSidebarOpen ? <ArrowLeftIcon className="w-4 h-4"/> : <Bars3Icon className="w-6 h-6"/>}
                     </button>
                 </div>
                 
                 <nav className="p-6 flex-grow space-y-2">
                     <NavItem id="command_center" icon={<ChartBarIcon className="w-6 h-6"/>} label="Command Center" />
                     <NavItem id="citizenship" icon={<UsersIcon className="w-6 h-6"/>} label="Citizenship" />
                     <NavItem id="moderation" icon={<ShieldCheckIcon className="w-6 h-6"/>} label="Culture Safety" />
                     <NavItem id="market_ops" icon={<ShoppingBagIcon className="w-6 h-6"/>} label="Market Ops" />
                     <NavItem id="ads_growth" icon={<GlobeIcon className="w-6 h-6"/>} label="Ads & Growth" />
                     <NavItem id="impact_studio" icon={<HandCoinIcon className="w-6 h-6"/>} label="Impact Studio" />
                     <NavItem id="live_manager" icon={<VideoCameraIcon className="w-6 h-6"/>} label="Live Control" />
                     
                     <div className="my-10 border-t border-white/5 pt-10">
                        <NavItem id="governance" icon={<Cog6ToothIcon className="w-6 h-6"/>} label="Governance" />
                        <NavItem id="monkix_ci" icon={<SparklesIcon className="w-6 h-6"/>} label="Monkix CI Admin" />
                     </div>
                 </nav>

                 <div className="p-6 border-t border-white/5 bg-black/20">
                     <div className="flex items-center gap-4">
                         <Avatar name={user.fullName} id={user.id} imageUrl={user.profileImageUrl} className="w-12 h-12 rounded-2xl border-2 border-brand-gold" />
                         {isSidebarOpen && (
                             <div>
                                 <p className="text-sm font-black text-white">{user.fullName}</p>
                                 <p className="text-[10px] text-brand-gold font-bold uppercase tracking-widest">Platform Overseer</p>
                             </div>
                         )}
                     </div>
                 </div>
            </aside>

            {/* Main Content */}
            <main className={`flex-1 transition-all duration-500 ${isSidebarOpen ? 'lg:ml-80' : 'lg:ml-24'} p-4 md:p-10`}>
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-6">
                    <div>
                        <h1 className="text-4xl font-display font-black text-brand-navy-dark dark:text-white capitalize">{activeTab.replace('_', ' ')}</h1>
                        <p className="text-gray-400 dark:text-gray-500 font-bold uppercase tracking-[0.2em] text-[10px] mt-1">Authenticated: {user.fullName} &middot; Imara Platform Governance</p>
                    </div>
                    <div className="flex gap-3">
                        <Button variant="outline" onClick={() => setActiveTab('command_center')} className="!rounded-2xl !px-6 flex items-center gap-2 !border-brand-green !text-brand-green"><EyeIcon className="w-4 h-4"/> System View</Button>
                        <Button onClick={() => setIsQuickActionOpen(true)} className="!rounded-2xl !px-6 !bg-brand-navy-dark !border-none flex items-center gap-2 shadow-xl"><BoltIcon className="w-4 h-4 text-brand-gold"/> Quick Action</Button>
                    </div>
                </div>

                <div className="max-w-7xl mx-auto pb-32">
                    {renderTabContent()}
                </div>
            </main>

            {/* Mobile Bottom Navigation Override for Admin */}
            <div className="lg:hidden fixed bottom-[20px] left-0 right-0 z-50 bg-white/80 dark:bg-gray-900/80 backdrop-blur-xl border-t border-gray-100 dark:border-gray-800 p-2 flex justify-around shadow-2xl overflow-x-auto pb-4 custom-scrollbar">
                 <button onClick={() => setActiveTab('command_center')} className={`p-3 rounded-2xl flex-shrink-0 ${activeTab === 'command_center' ? 'bg-brand-gold text-brand-navy-dark' : 'text-gray-400'}`}><ChartBarIcon className="w-6 h-6"/></button>
                 <button onClick={() => setActiveTab('citizenship')} className={`p-3 rounded-2xl flex-shrink-0 ${activeTab === 'citizenship' ? 'bg-brand-gold text-brand-navy-dark' : 'text-gray-400'}`}><UsersIcon className="w-6 h-6"/></button>
                 <button onClick={() => setActiveTab('moderation')} className={`p-3 rounded-2xl flex-shrink-0 ${activeTab === 'moderation' ? 'bg-brand-gold text-brand-navy-dark' : 'text-gray-400'}`}><ShieldCheckIcon className="w-6 h-6"/></button>
                 <button onClick={() => setActiveTab('market_ops')} className={`p-3 rounded-2xl flex-shrink-0 ${activeTab === 'market_ops' ? 'bg-brand-gold text-brand-navy-dark' : 'text-gray-400'}`}><ShoppingBagIcon className="w-6 h-6"/></button>
                 <button onClick={() => setActiveTab('ads_growth')} className={`p-3 rounded-2xl flex-shrink-0 ${activeTab === 'ads_growth' ? 'bg-brand-gold text-brand-navy-dark' : 'text-gray-400'}`}><GlobeIcon className="w-6 h-6"/></button>
                 <button onClick={() => setActiveTab('governance')} className={`p-3 rounded-2xl flex-shrink-0 ${activeTab === 'governance' ? 'bg-brand-gold text-brand-navy-dark' : 'text-gray-400'}`}><Cog6ToothIcon className="w-6 h-6"/></button>
            </div>

            {selectedApplication && (
                <ApplicationReviewModal
                    application={selectedApplication}
                    onClose={() => setSelectedApplication(null)}
                    onApprove={() => handleApplicationDecision(selectedApplication.id, 'approved')}
                    onReject={() => handleApplicationDecision(selectedApplication.id, 'rejected')}
                />
            )}
            
            {isQuickActionOpen && (
                <AdminQuickActionModal onClose={() => setIsQuickActionOpen(false)} />
            )}
        </div>
    );
};

export default AdminPage;
