import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { mockAllUsersAndPartners, mockGistPosts, mockProducts, mockTravelServices, mockCauses } from '../data/mockData.ts';
import type { UserProfile, GistPost, Product, TravelService, Cause } from '../types.ts';
import Button from '../components/ui/Button.tsx';
import { GlobeIcon, EllipsisHorizontalIcon, VerifiedBadgeIcon, HandHeartIcon } from '../components/icons/Icons.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';
import Avatar from '../components/ui/Avatar.tsx';
import ContactActionModal from '../components/modals/ContactActionModal.tsx';
import GistPostCard from '../components/gist/GistPostCard.tsx';
import { useCart } from '../contexts/CartContext.tsx';
import CommentModal from '../components/gist/CommentModal.tsx';
import BookingModal from '../components/modals/BookingModal.tsx';
import LoadingSpinner from '../components/ui/LoadingSpinner.tsx';
import CreateGistPost from '../components/gist/CreateGistPost.tsx';
import ToastComposerModal from '../components/gist/ToastComposerModal.tsx';
import ProductCard from '../components/shared/ProductCard.tsx';
import ServiceCard from '../components/shared/ServiceCard.tsx';
import BackButton from '../components/ui/BackButton.tsx';

const UserProfilePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user: loggedInUser, followUser, unfollowUser, isFollowing } = useAuth();
  const [profileUser, setProfileUser] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [userPosts, setUserPosts] = useState<GistPost[]>([]);
  const [activeTab, setActiveTab] = useState('posts');
  const [isComposerOpen, setIsComposerOpen] = useState(false);
  const { addToCart } = useCart();
  const navigate = useNavigate();

  // Modal states
  const [commentingPost, setCommentingPost] = useState<GistPost | null>(null);
  const [bookingService, setBookingService] = useState<TravelService | null>(null);

  useEffect(() => {
    setIsLoading(true);
    setTimeout(() => {
        const user = mockAllUsersAndPartners.find(u => u.id === id);
        if (user) {
            const fullProfile = {
                ...user,
                fullName: user.name,
                profileImageUrl: user.avatarUrl,
                country: 'Imara Official', 
                email: '', followerIds: Array(1200), followingIds: Array(50),
                bio: user.bio || "Community Member",
                role: user.role?.toLowerCase().includes('vendor') ? 'vendor' : user.role?.toLowerCase().includes('travel') ? 'travel' : 'user',
                coverImageUrl: (user as any).coverImageUrl || `https://picsum.photos/seed/${user.id}_cover/1200/400`
            } as unknown as UserProfile;
            setProfileUser(fullProfile);
            setUserPosts(mockGistPosts.filter(p => p.creator.id === id));
        }
        setIsLoading(false);
    }, 500);
  }, [id]);

  const handlePostCreated = (newPost: GistPost) => setUserPosts(prev => [newPost, ...prev]);
  
  if (isLoading) return <div className="min-h-screen flex items-center justify-center"><LoadingSpinner /></div>;
  if (!profileUser) return <div className="text-center py-20">User Not Found</div>;

  const isOwnProfile = loggedInUser?.id === profileUser.id;
  const following = loggedInUser ? isFollowing(profileUser.id) : false;

  return (
    <div className="bg-gray-50 dark:bg-gray-900 min-h-screen pb-20">
        <BackButton className="absolute top-4 left-4 z-20 text-white mix-blend-difference" />
        
        {/* Header */}
        <div className="w-full max-w-5xl mx-auto bg-white dark:bg-brand-navy-dark shadow-2xl rounded-b-[40px] overflow-hidden">
            <div className="h-48 md:h-64 bg-brand-navy-dark relative">
                <img src={profileUser.coverImageUrl} className="w-full h-full object-cover opacity-60" alt="Cover"/>
            </div>
            <div className="px-6 pb-8 relative">
                <div className="flex flex-col md:flex-row items-start gap-6 -mt-12">
                    <div className="relative z-10">
                        <Avatar imageUrl={profileUser.profileImageUrl} name={profileUser.fullName} className="w-32 h-32 md:w-40 md:h-40 rounded-full border-4 border-white dark:border-brand-navy-dark shadow-lg bg-white" />
                        {profileUser.isVerified && <div className="absolute bottom-2 right-2 bg-white p-1 rounded-full shadow-sm"><VerifiedBadgeIcon className="w-6 h-6 text-brand-gold"/></div>}
                    </div>
                    <div className="flex-grow pt-14 md:pt-16 flex flex-col md:flex-row justify-between items-start w-full gap-4">
                        <div>
                            <h1 className="text-3xl font-display font-bold text-brand-navy-dark dark:text-white">{profileUser.fullName}</h1>
                            <div className="flex items-center gap-2 mt-1 text-sm text-gray-500"><GlobeIcon className="w-4 h-4"/> {profileUser.country}</div>
                        </div>
                        <div className="flex gap-3">
                             {!isOwnProfile && (
                                <>
                                    <Button onClick={() => { if(loggedInUser) following ? unfollowUser(profileUser.id) : followUser(profileUser.id) }} variant={following ? 'outline' : 'primary'} className="rounded-full px-6">{following ? 'Following' : 'Follow'}</Button>
                                    <Button onClick={() => setIsContactModalOpen(true)} variant="secondary" className="rounded-full px-6">Contact</Button>
                                </>
                             )}
                             {isOwnProfile && <Button onClick={() => navigate('/account')} variant="outline" className="rounded-full">Edit Profile</Button>}
                        </div>
                    </div>
                </div>
                 {/* Stats */}
                 <div className="flex gap-8 mt-8 border-t border-gray-100 dark:border-gray-700 pt-6">
                     <div className="text-center"><span className="block font-bold text-xl text-brand-navy-dark dark:text-white">{profileUser.followerIds?.length || 0}</span><span className="text-xs text-gray-500 uppercase">Followers</span></div>
                     <div className="text-center"><span className="block font-bold text-xl text-brand-navy-dark dark:text-white">{userPosts.length}</span><span className="text-xs text-gray-500 uppercase">Toasts</span></div>
                </div>
            </div>
        </div>

        {/* Content */}
        <div className="w-full max-w-5xl mx-auto mt-8 px-4">
             <div className="flex gap-6 border-b border-gray-200 dark:border-gray-700 mb-6 overflow-x-auto scrollbar-hide">
                {['posts', 'about', 'impact'].concat(profileUser.role === 'vendor' ? ['products'] : profileUser.role === 'travel' ? ['services'] : []).map(tab => (
                    <button key={tab} onClick={() => setActiveTab(tab)} className={`pb-3 px-2 text-sm font-bold uppercase tracking-wider relative ${activeTab === tab ? 'text-brand-navy-dark dark:text-white' : 'text-gray-400'}`}>
                        {tab}
                        {activeTab === tab && <span className="absolute bottom-0 left-0 w-full h-1 bg-brand-gold rounded-t-full"></span>}
                    </button>
                ))}
            </div>
            
            <div>
                {activeTab === 'posts' && (
                    <div className="max-w-2xl mx-auto space-y-6">
                        {isOwnProfile && <CreateGistPost onOpenCreator={() => setIsComposerOpen(true)} />}
                        {userPosts.map(post => (
                            <GistPostCard key={post.id} post={post} onCommentClick={() => setCommentingPost(post)} onAddToCart={addToCart} onBookService={(id) => {}} onDonateNow={() => {}} onLearnMore={() => {}} />
                        ))}
                        {userPosts.length === 0 && <p className="text-center py-10 text-gray-500">No posts yet.</p>}
                    </div>
                )}
                {activeTab === 'about' && (
                    <div className="bg-white dark:bg-brand-navy-dark p-8 rounded-3xl shadow-sm max-w-2xl mx-auto">
                        <h3 className="font-bold text-xl mb-4 dark:text-white">Bio</h3>
                        <p className="text-gray-600 dark:text-gray-300">{profileUser.bio}</p>
                    </div>
                )}
                 {activeTab === 'products' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                         {mockProducts.filter(p => p.vendor === profileUser.fullName).map(p => <ProductCard key={p.id} product={p} onAddToCart={addToCart} onQuickView={() => {}} />)}
                    </div>
                )}
            </div>
        </div>

        {isContactModalOpen && <ContactActionModal participant={{...profileUser, id: profileUser.id, name: profileUser.fullName, avatarUrl: profileUser.profileImageUrl}} onClose={() => setIsContactModalOpen(false)} />}
        {isComposerOpen && <ToastComposerModal onClose={() => setIsComposerOpen(false)} onPost={handlePostCreated} />}
        {commentingPost && <CommentModal post={commentingPost} onClose={() => setCommentingPost(null)} onAddComment={() => {}} />}
    </div>
  );
};

export default UserProfilePage;