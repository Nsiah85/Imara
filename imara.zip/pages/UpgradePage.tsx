
import React, { useState } from 'react';
import BackButton from '../components/ui/BackButton';
import { mockVendorSubscriptionPlans, mockWorkmanSubscriptionPlans } from '../data/mockData';
import SubscriptionCard from '../components/subscriptions/SubscriptionCard';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import { CheckCircleIcon } from '../components/icons/Icons';
import Button from '../components/ui/Button';

const UpgradePage: React.FC = () => {
    const { user, updateUser } = useAuth();
    const navigate = useNavigate();
    const [isProcessing, setIsProcessing] = useState(false);
    const [success, setSuccess] = useState(false);
    const [selectedPlanName, setSelectedPlanName] = useState('');
    const [confirmPlanId, setConfirmPlanId] = useState<string | null>(null);

    const handleSelectPlan = (planId: string, planName: string) => {
        if (!user) {
            navigate('/login', { state: { from: '/upgrade' } });
            return;
        }
        setConfirmPlanId(planId);
        setSelectedPlanName(planName);
    };
    
    const confirmUpgrade = () => {
        if (!confirmPlanId) return;
        setIsProcessing(true);
        setTimeout(() => {
            updateUser({ subscriptionPlanId: confirmPlanId });
            setIsProcessing(false);
            setSuccess(true);
            setConfirmPlanId(null);
        }, 2000);
    }

    if (success) {
        return (
            <div className="min-h-screen flex flex-col items-center justify-center bg-brand-off-white dark:bg-gray-900 p-6 text-center">
                <div className="bg-white dark:bg-brand-navy-dark p-8 rounded-2xl shadow-xl max-w-md w-full border-2 border-brand-gold animate-fade-in-up">
                    <CheckCircleIcon className="w-20 h-20 text-brand-gold mx-auto mb-4 animate-bounce" />
                    <h2 className="text-3xl font-display font-bold text-brand-navy-dark dark:text-white">Upgrade Successful!</h2>
                    <p className="mt-4 text-gray-600 dark:text-gray-300">
                        You are now on the <span className="font-bold text-brand-green">{selectedPlanName}</span>. Your benefits have been updated immediately.
                    </p>
                    <Button size="lg" onClick={() => navigate('/account')} className="mt-8 w-full">
                        Go to Dashboard
                    </Button>
                </div>
            </div>
        );
    }

    return (
        <div className="bg-brand-off-white dark:bg-gray-900 min-h-screen relative">
            {/* Confirmation Modal */}
            {confirmPlanId && (
                <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
                    <div className="bg-white dark:bg-brand-navy-dark p-8 rounded-2xl shadow-2xl max-w-sm w-full text-center">
                        {isProcessing ? (
                            <div className="py-8">
                                <LoadingSpinner className="mx-auto mb-4"/>
                                <p className="text-lg font-bold dark:text-white">Processing payment...</p>
                            </div>
                        ) : (
                            <>
                                <h3 className="text-2xl font-bold mb-4 dark:text-white">Confirm Upgrade</h3>
                                <p className="mb-8 text-gray-600 dark:text-gray-300">
                                    You are upgrading to <strong>{selectedPlanName}</strong>. 
                                    By clicking confirm, your payment method will be charged.
                                </p>
                                <div className="flex gap-4">
                                    <Button variant="outline" onClick={() => setConfirmPlanId(null)} className="flex-1">Cancel</Button>
                                    <Button onClick={confirmUpgrade} className="flex-1">Confirm</Button>
                                </div>
                            </>
                        )}
                    </div>
                </div>
            )}

            <div className="container mx-auto px-6 py-12">
                <BackButton className="mb-4" />
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-display font-bold text-brand-navy-dark dark:text-white">Choose Your Tier</h1>
                    <p className="mt-2 text-brand-gray dark:text-gray-400 max-w-2xl mx-auto">
                        Scale your impact and earnings with the right plan.
                    </p>
                </div>
                
                <div className="space-y-16">
                    {/* Vendor/Business Plans */}
                    <div>
                        <h2 className="text-3xl font-display font-bold text-brand-navy-dark dark:text-white mb-8 text-center">For Vendors & Businesses</h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 items-stretch max-w-5xl mx-auto">
                            {mockVendorSubscriptionPlans.map(plan => (
                                <SubscriptionCard 
                                    key={plan.id}
                                    plan={plan}
                                    onSelect={() => handleSelectPlan(plan.id, plan.name)}
                                />
                            ))}
                        </div>
                    </div>

                    {/* Professional/Workman Plans */}
                    <div>
                        <h2 className="text-3xl font-display font-bold text-brand-navy-dark dark:text-white mb-8 text-center">For Professionals & Talents</h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch max-w-3xl mx-auto">
                            {mockWorkmanSubscriptionPlans.map(plan => (
                                <SubscriptionCard 
                                    key={plan.id}
                                    plan={plan}
                                    onSelect={() => handleSelectPlan(plan.id, plan.name)}
                                />
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default UpgradePage;
