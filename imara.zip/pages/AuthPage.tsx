
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Button from '../components/ui/Button.tsx';
import { ArrowLeftIcon, BriefcaseIcon, UserIcon, GoogleIcon, FacebookIcon, TikTokIcon, ImaraDiskIcon, ShieldCheckIcon } from '../components/icons/Icons.tsx';
import { useCurrency } from '../contexts/CurrencyContext.tsx';
import { countries, getCurrencyForCountry } from '../utils/currency.ts';
import { useAuth } from '../contexts/AuthContext.tsx';
import { useSecurity } from '../contexts/SecurityContext.tsx';
import PasswordStrengthIndicator from '../components/ui/PasswordStrengthIndicator.tsx';
import { useLanguage } from '../contexts/LanguageContext.tsx';

const AuthPage: React.FC = () => {
    const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
    const [signupRole, setSignupRole] = useState<'customer' | 'partner' | null>(null);
    const { setCurrency } = useCurrency();
    const navigate = useNavigate();
    const { login, loginWithGoogleProvider } = useAuth();
    const { registerDevice } = useSecurity();
    const { t } = useLanguage();
    
    // Form state
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [fullName, setFullName] = useState('');
    const [dateOfBirth, setDateOfBirth] = useState('');
    const [guardianName, setGuardianName] = useState('');
    const [guardianEmail, setGuardianEmail] = useState('');
    const [guardianPhone, setGuardianPhone] = useState('');
    const [country, setCountry] = useState('Ghana');
    const [region, setRegion] = useState('');
    const [isPasswordValid, setIsPasswordValid] = useState(false);
    const [agreedToTerms, setAgreedToTerms] = useState(false);
    const [isUnderAge, setIsUnderAge] = useState(false);
    const [errors, setErrors] = useState({
        login: '',
        signup: '',
        fullName: '',
        email: '',
        guardian: '',
    });
    const [isLoading, setIsLoading] = useState(false);

    const inputClass = (name: keyof typeof errors, baseClasses: string) => 
        `${baseClasses} ${errors[name] ? 'border-red-500 focus:ring-red-500' : 'border-brand-navy focus:ring-brand-gold'}`;
    const baseInputClass = "block w-full bg-brand-navy-dark text-brand-gold-light border rounded-md shadow-sm py-3 px-4 focus:outline-none focus:ring-2 focus:border-transparent placeholder:text-gray-400";
    const baseSelectClass = `${baseInputClass} appearance-none`;

    useEffect(() => {
        if (dateOfBirth) {
            const birthDate = new Date(dateOfBirth);
            const today = new Date();
            let age = today.getFullYear() - birthDate.getFullYear();
            const m = today.getMonth() - birthDate.getMonth();
            if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                age--;
            }
            setIsUnderAge(age < 16);
        }
    }, [dateOfBirth]);

    const validateField = (name: string, value: string): string => {
        switch (name) {
            case 'fullName':
                if (!/^[a-zA-Z\s'-]{2,}$/.test(value)) return 'Please enter a valid name (letters, spaces, \', -).';
                return '';
            case 'email':
                // Strict Email Regex: Standard format + avoids common typos if needed
                const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
                if (!value) return 'Email is required.';
                if (!emailRegex.test(value)) return 'Please enter a valid email address (e.g., user@example.com).';
                return '';
            default:
                return '';
        }
    };

    const handleAuthModeChange = (mode: 'login' | 'signup') => {
        setAuthMode(mode);
        setSignupRole(null);
        setErrors({ login: '', signup: '', fullName: '', email: '', guardian: '' });
        setIsUnderAge(false);
    };

    const handleCountryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const countryName = e.target.value;
        setCountry(countryName);
        const currency = getCurrencyForCountry(countryName);
        setCurrency(currency);
    };

    const handleSocialLogin = async (provider: 'google' | 'facebook' | 'tiktok') => {
        setIsLoading(true);
        if (provider === 'google') {
            const loggedInUser = await loginWithGoogleProvider();
            setIsLoading(false);
            if (loggedInUser) {
                registerDevice();
                navigate('/', { replace: true });
            }
            return;
        }
        
        // Fallback for others
        const mockDetails = {
            google: { email: 'user@google.com', fullName: 'Google User' },
            facebook: { email: 'user@facebook.com', fullName: 'Facebook User' },
            tiktok: { email: 'user@tiktok.com', fullName: 'TikTok User' },
        };
        const details = mockDetails[provider];
        const loggedInUser = await login(details.email, 'social_login_mock_password', { fullName: details.fullName, country: 'United States' });
        setIsLoading(false);
        if (loggedInUser) {
            registerDevice(); // Trigger identity lock check
            navigate('/', { replace: true });
        }
    };
    
    const handleLoginSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setErrors(prev => ({ ...prev, login: '' }));
        setIsLoading(true);
        const loggedInUser = await login(email, password);
        setIsLoading(false);
        if (loggedInUser) {
            registerDevice(); // Trigger identity lock check
            if (loggedInUser.role === 'admin') {
                navigate('/admin', { replace: true });
            } else {
                navigate('/', { replace: true });
            }
        } else {
            setErrors(prev => ({ ...prev, login: "Invalid email or password." }));
        }
    };

    const handleSignupSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setErrors(prev => ({ ...prev, signup: '' }));
        
        // 1. Check strict validations before submission
        const emailError = validateField('email', email);
        const nameError = validateField('fullName', fullName);

        if (emailError || nameError) {
            setErrors(prev => ({ ...prev, email: emailError, fullName: nameError }));
            return;
        }

        if (isUnderAge && (!guardianName || !guardianEmail || !guardianPhone)) {
             setErrors(prev => ({ ...prev, signup: "Guardian details are required for users under 16." }));
             return;
        }

        if (!isPasswordValid || !agreedToTerms || !dateOfBirth) {
            setErrors(prev => ({ ...prev, signup: "Please fix errors and complete all fields." }));
            return;
        }
        
        const guardianDetails = isUnderAge ? { name: guardianName, email: guardianEmail, phone: guardianPhone } : undefined;

        setIsLoading(true);
        const signedUpUser = await login(email, password, { fullName, country, region, dateOfBirth, guardianDetails });
        setIsLoading(false);
         if (signedUpUser) {
            registerDevice(); // Register device for new user
            navigate('/', { replace: true });
        } else {
            setErrors(prev => ({ ...prev, signup: "An error occurred during signup." }));
        }
    };

    // ... (rest of render logic matches existing file)
    const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        const error = validateField(name, value);
        setErrors(prev => ({ ...prev, [name]: error }));
    };

    const isSignupFormInvalid = !isPasswordValid || !!errors.fullName || !!errors.email || !fullName || !email || !country || !agreedToTerms || !dateOfBirth || isLoading;

    const renderLoginForm = () => (
        <div className="animate-fade-in">
            <form className="space-y-6" onSubmit={handleLoginSubmit}>
                <div>
                    <label htmlFor="email-login" className="block text-sm font-medium text-gray-700">Email Address</label>
                    <input type="email" name="email" id="email-login" required className={`mt-1 ${baseInputClass}`} value={email} onChange={e => setEmail(e.target.value)} />
                </div>
                <div>
                    <label htmlFor="password-login" className="block text-sm font-medium text-gray-700">Password</label>
                    <input type="password" name="password" id="password-login" required className={`mt-1 ${baseInputClass}`} value={password} onChange={e => setPassword(e.target.value)} />
                </div>
                {errors.login && <p className="text-sm text-red-600">{errors.login}</p>}
                <div className="flex items-center justify-between">
                    <a href="#" className="text-sm text-brand-navy hover:text-brand-gold">Forgot your password?</a>
                </div>
                <div>
                    <Button type="submit" size="lg" className="w-full" disabled={isLoading}>{isLoading ? 'Signing In...' : 'Sign In'}</Button>
                </div>
                
                <div className="relative my-6">
                    <div className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-gray-300"></div>
                    </div>
                    <div className="relative flex justify-center text-sm">
                        <span className="px-2 bg-brand-off-white dark:bg-gray-900 text-gray-500">Or continue with</span>
                    </div>
                </div>

                <div>
                    <Button type="button" size="lg" variant="outline" className="w-full flex items-center justify-center gap-2" disabled={isLoading} onClick={async () => {
                        setIsLoading(true);
                        const googleUser = await loginWithGoogleProvider();
                        setIsLoading(false);
                        if (googleUser) {
                            registerDevice();
                            navigate('/', { replace: true });
                        } else {
                            setErrors(prev => ({ ...prev, login: "Google Sign In failed." }));
                        }
                    }}>
                        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                            <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                            <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                            <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                        </svg>
                        Google
                    </Button>
                </div>
            </form>

        </div>
    );


    const renderConsumerSignupForm = () => (
        <div className="animate-fade-in">
            <button onClick={() => setSignupRole(null)} className="flex items-center gap-2 text-sm text-brand-navy hover:text-brand-gold font-semibold mb-4">
                <ArrowLeftIcon className="w-4 h-4" />
                Back
            </button>
            <div className="text-center mb-6">
                 <span className="text-5xl" role="img" aria-label="Shopping bag">🛒</span>
                <h3 className="mt-4 text-xl font-display font-semibold text-brand-navy-dark">Create Your Consumer/User Account</h3>
                <p className="mt-1 text-sm text-gray-600">Track your impact and save your favorite artisans.</p>
            </div>
            <form className="space-y-4" onSubmit={handleSignupSubmit}>
                 <div>
                    <label htmlFor="fullName-signup" className="block text-sm font-medium text-gray-700">Full Name</label>
                    <input type="text" name="fullName" id="fullName-signup" required className={`mt-1 ${inputClass('fullName', baseInputClass)}`} value={fullName} onChange={e => setFullName(e.target.value)} onBlur={handleBlur} />
                    {errors.fullName && <p className="mt-1 text-xs text-red-500">{errors.fullName}</p>}
                </div>
                <div>
                    <label htmlFor="email-signup" className="block text-sm font-medium text-gray-700">Email Address</label>
                    <input type="email" name="email" id="email-signup" required className={`mt-1 ${inputClass('email', baseInputClass)}`} value={email} onChange={e => setEmail(e.target.value)} onBlur={handleBlur} />
                    {errors.email && <p className="mt-1 text-xs text-red-500">{errors.email}</p>}
                </div>
                <div>
                    <label htmlFor="dob-signup" className="block text-sm font-medium text-gray-700">Date of Birth</label>
                    <input type="date" name="dateOfBirth" id="dob-signup" required className={`mt-1 ${baseInputClass}`} value={dateOfBirth} onChange={e => setDateOfBirth(e.target.value)} />
                </div>

                {isUnderAge && (
                    <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4 animate-fade-in">
                        <div className="flex items-center gap-2 mb-2 text-yellow-800">
                             <ShieldCheckIcon className="w-5 h-5" />
                             <span className="font-bold text-sm">Age Protection Active</span>
                        </div>
                        <p className="text-xs text-yellow-700 mb-3">Since you are under 16, we require guardian consent to create this account.</p>
                        <div className="space-y-3">
                            <input type="text" placeholder="Guardian Name" required value={guardianName} onChange={e => setGuardianName(e.target.value)} className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-brand-gold focus:border-brand-gold sm:text-sm p-2" />
                            <input type="email" placeholder="Guardian Email" required value={guardianEmail} onChange={e => setGuardianEmail(e.target.value)} className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-brand-gold focus:border-brand-gold sm:text-sm p-2" />
                            <input type="tel" placeholder="Guardian Phone" required value={guardianPhone} onChange={e => setGuardianPhone(e.target.value)} className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-brand-gold focus:border-brand-gold sm:text-sm p-2" />
                        </div>
                    </div>
                )}

                 <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="country-signup" className="block text-sm font-medium text-gray-700">Country</label>
                        <select name="country" id="country-signup" required className={`mt-1 ${baseSelectClass}`} onChange={handleCountryChange} value={country}>
                            <option value="" disabled>Select your country</option>
                            {countries.map(c => <option key={c.code} value={c.name}>{c.name}</option>)}
                        </select>
                    </div>
                     <div>
                        <label htmlFor="region-signup" className="block text-sm font-medium text-gray-700">Region / State</label>
                        <input type="text" name="region" id="region-signup" required className={`mt-1 ${baseInputClass}`} value={region} onChange={e => setRegion(e.target.value)} placeholder="e.g. Greater Accra, Lagos" />
                    </div>
                </div>
                <div>
                    <label htmlFor="password-signup" className="block text-sm font-medium text-gray-700">Password</label>
                    <input type="password" name="password" id="password-signup" required className={`mt-1 ${baseInputClass}`} value={password} onChange={e => setPassword(e.target.value)} />
                    <PasswordStrengthIndicator password={password} onValidityChange={setIsPasswordValid} />
                </div>
                <div className="flex items-start">
                    <div className="flex h-6 items-center">
                        <input id="terms" name="terms" type="checkbox" checked={agreedToTerms} onChange={(e) => setAgreedToTerms(e.target.checked)} className="h-4 w-4 rounded border-gray-300 text-brand-gold focus:ring-brand-gold"/>
                    </div>
                    <div className="ml-3 text-sm leading-6">
                        <label htmlFor="terms" className="font-medium text-gray-900">I agree to the <a href="#" className="text-brand-navy hover:text-brand-gold">Terms and Conditions</a></label>
                    </div>
                </div>
                {errors.signup && <p className="text-sm text-red-600">{errors.signup}</p>}
                <div>
                    <Button type="submit" size="lg" className="w-full mt-4" disabled={isSignupFormInvalid}>Create Account</Button>
                </div>
                
                <div className="relative my-6 text-center">
                    <div className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-gray-300"></div>
                    </div>
                    <div className="relative flex justify-center text-sm">
                        <span className="px-2 bg-brand-off-white dark:bg-gray-900 text-gray-500">Or sign up with</span>
                    </div>
                </div>

                <div>
                    <Button type="button" size="lg" variant="outline" className="w-full flex items-center justify-center gap-2" disabled={isLoading} onClick={async () => {
                        setIsLoading(true);
                        const googleUser = await loginWithGoogleProvider();
                        setIsLoading(false);
                        if (googleUser) {
                            registerDevice();
                            navigate('/', { replace: true });
                        } else {
                            setErrors(prev => ({ ...prev, signup: "Google Sign Up failed." }));
                        }
                    }}>
                        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                            <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                            <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                            <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                        </svg>
                        Google
                    </Button>
                </div>
            </form>

        </div>
    );
    
    const renderPartnerSignupInfo = () => (
         <div className="animate-fade-in">
            <button onClick={() => setSignupRole(null)} className="flex items-center gap-2 text-sm text-brand-navy hover:text-brand-gold font-semibold mb-4">
                <ArrowLeftIcon className="w-4 h-4" />
                Back
            </button>
            <div className="text-center p-6 border-2 border-dashed border-gray-200 rounded-lg">
                <BriefcaseIcon className="w-12 h-12 mx-auto text-brand-gold" />
                <h3 className="mt-4 font-bold text-xl text-brand-navy-dark">Join as a Partner</h3>
                <p className="mt-1 text-sm text-gray-600">Join a thriving community of creators and grow your business with us.</p>
                <div className="mt-6 flex flex-col sm:flex-row gap-4 justify-center">
                    <Link to="/join/vendor">
                        <Button variant="secondary" className="w-full">{t('auth.signup.partner.vendorButton')}</Button>
                    </Link>
                    <Link to="/join/afrotalent">
                        <Button variant="outline" className="w-full">{t('auth.signup.partner.workerButton').replace('Professional', 'AfroTalent')}</Button>
                    </Link>
                </div>
            </div>
        </div>
    );

    const renderSignupSelection = () => (
        <div className="text-center animate-fade-in">
            <h3 className="text-xl font-display font-semibold text-brand-navy-dark mb-6">{t('auth.signup.selectionTitle')}</h3>
            <div className="space-y-4">
                <button onClick={() => setSignupRole('customer')} className="w-full text-left p-6 border-2 rounded-lg hover:border-brand-gold transition-colors flex items-start gap-4 shadow-sm">
                    <UserIcon className="w-10 h-10 text-brand-gold flex-shrink-0" />
                    <div>
                        <h4 className="font-bold text-lg text-brand-navy-dark">{t('auth.signup.customer.title')}</h4>
                        <p className="text-sm text-gray-600">{t('auth.signup.customer.subtitle')}</p>
                    </div>
                </button>
                <button onClick={() => setSignupRole('partner')} className="w-full text-left p-6 border-2 rounded-lg hover:border-brand-gold transition-colors flex items-start gap-4 shadow-sm">
                    <BriefcaseIcon className="w-10 h-10 text-brand-gold flex-shrink-0" />
                    <div>
                        <h4 className="font-bold text-lg text-brand-navy-dark">{t('auth.signup.partner.title')}</h4>
                        <p className="text-sm text-gray-600">{t('auth.signup.partner.subtitle')}</p>
                    </div>
                </button>
            </div>
            
            <div className="relative my-6 text-center">
                <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-gray-300"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                    <span className="px-2 bg-white text-gray-500">Or quickly sign up with</span>
                </div>
            </div>

            <div>
                <Button type="button" size="lg" variant="outline" className="w-full flex items-center justify-center gap-2 shadow-sm" disabled={isLoading} onClick={async () => {
                    setIsLoading(true);
                    const googleUser = await loginWithGoogleProvider();
                    setIsLoading(false);
                    if (googleUser) {
                        registerDevice();
                        navigate('/', { replace: true });
                    } else {
                        setErrors(prev => ({ ...prev, signup: "Google Sign Up failed." }));
                    }
                }}>
                    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                    </svg>
                    Continue with Google
                </Button>
            </div>
            {errors.signup && <p className="text-sm text-red-600 mt-4">{errors.signup}</p>}
        </div>
    );

    const tabClass = (mode: 'login' | 'signup') => `w-1/2 pb-3 font-bold text-center border-b-4 transition-colors ${authMode === mode ? 'border-brand-gold text-brand-navy-dark' : 'border-gray-200 text-gray-500 hover:border-brand-gold/50'}`;

    return (
        <div className="min-h-screen bg-brand-off-white flex items-center justify-center p-4">
            <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 space-y-6">
                <div className="flex justify-center mb-4">
                    <Link to="/" className="flex items-center gap-2 font-display font-extrabold text-4xl tracking-wider">
                        <ImaraDiskIcon className="w-10 h-10" />
                        <div>
                            <span className="text-brand-navy-dark">Ima</span>
                            <span className="text-brand-gold">ra</span>
                        </div>
                    </Link>
                </div>

                <div className="flex justify-center border-b">
                    <button onClick={() => handleAuthModeChange('login')} className={tabClass('login')}>
                        {t('auth.login.button')}
                    </button>
                    <button onClick={() => handleAuthModeChange('signup')} className={tabClass('signup')}>
                        {t('auth.signup.button')}
                    </button>
                </div>
                
                <h2 className="text-2xl font-bold text-center text-brand-navy-dark">
                    {authMode === 'login' ? t('auth.login.title') : t('auth.signup.title')}
                </h2>

                {authMode === 'login' && renderLoginForm()}
                {authMode === 'signup' && (
                    <>
                        {signupRole === null && renderSignupSelection()}
                        {signupRole === 'customer' && renderConsumerSignupForm()}
                        {signupRole === 'partner' && renderPartnerSignupInfo()}
                    </>
                )}
            </div>
        </div>
    );
};

export default AuthPage;
