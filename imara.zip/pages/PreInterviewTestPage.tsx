import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import type { PreInterviewTest, ApplicantTestAttempt, TestQuestion, ApplicantAnswer, JobApplicant } from '../types.ts';
import Button from '../components/ui/Button.tsx';
import { CheckCircleIcon } from '../components/icons/Icons.tsx';

const PreInterviewTestPage: React.FC = () => {
    const { attemptId } = useParams<{ attemptId: string }>();
    const navigate = useNavigate();

    const [test, setTest] = useState<PreInterviewTest | null>(null);
    const [attempt, setAttempt] = useState<ApplicantTestAttempt | null>(null);
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [answers, setAnswers] = useState<ApplicantAnswer[]>([]);
    const [timeLeft, setTimeLeft] = useState(0);
    const [stage, setStage] = useState<'loading' | 'instructions' | 'active' | 'completed'>('loading');
    
    const [permissionsGranted, setPermissionsGranted] = useState(false);
    const [permissionError, setPermissionError] = useState<string | null>(null);
    const videoRef = useRef<HTMLVideoElement>(null);
    const [warnings, setWarnings] = useState<string[]>([]);

    useEffect(() => {
        try {
            // Fix: Added type assertions to multiple JSON.parse calls to ensure type safety for test data loaded from localStorage.
            // FIX: Add type assertion for JSON.parse results.
            const allTests: PreInterviewTest[] = JSON.parse(localStorage.getItem('imara_tests') || '[]') as PreInterviewTest[];
            const allAttempts: ApplicantTestAttempt[] = JSON.parse(localStorage.getItem('imara_test_attempts') || '[]') as ApplicantTestAttempt[];
            
            const currentAttempt = allAttempts.find(a => a.id === attemptId);
            if (currentAttempt) {
                const associatedTest = allTests.find(t => t.id === currentAttempt.testId);
                if (associatedTest) {
                    setAttempt(currentAttempt);
                    setTest({ ...associatedTest, questions: [...associatedTest.questions].sort(() => Math.random() - 0.5) }); // Randomize questions
                    setTimeLeft(associatedTest.timeLimitMinutes * 60);
                    setStage('instructions');
                }
            } else {
                setStage('completed'); // Or an error stage
            }
        } catch (e) { console.error(e); }
    }, [attemptId]);

    const requestPermissions = useCallback(async () => {
        setPermissionError(null);
        if (!test || (!test.useCameraMonitoring && !test.useMicrophoneMonitoring)) {
            setPermissionsGranted(true);
            return;
        }
        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                video: test.useCameraMonitoring,
                audio: test.useMicrophoneMonitoring,
            });
            if (videoRef.current && test.useCameraMonitoring) {
                videoRef.current.srcObject = stream;
            }
            setPermissionsGranted(true);
        } catch (error) {
            console.error("Permission error:", error);
            setPermissionError("Permissions for camera and/or microphone are required. Please grant access in your browser's site settings and refresh the page to proceed.");
            setPermissionsGranted(false);
        }
    }, [test]);

    // Anti-cheat listeners
    useEffect(() => {
        if (stage !== 'active') return;

        const preventContext = (e: Event) => e.preventDefault();
        const preventCopy = (e: ClipboardEvent) => {
            e.preventDefault();
            setWarnings(prev => [...prev, `Copy/paste is disabled. [${new Date().toLocaleTimeString()}]`]);
        };
        const handleVisibilityChange = () => {
            if (document.hidden) {
                setWarnings(prev => [...prev, `Left the test tab. [${new Date().toLocaleTimeString()}]`]);
            }
        };

        document.addEventListener('contextmenu', preventContext);
        document.addEventListener('copy', preventCopy);
        document.addEventListener('paste', preventCopy);
        document.addEventListener('visibilitychange', handleVisibilityChange);

        return () => {
            document.removeEventListener('contextmenu', preventContext);
            document.removeEventListener('copy', preventCopy);
            document.removeEventListener('paste', preventCopy);
            document.removeEventListener('visibilitychange', handleVisibilityChange);
        };
    }, [stage]);

    // Timer logic
    useEffect(() => {
        if (stage === 'active' && timeLeft > 0) {
            const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
            return () => clearTimeout(timer);
        } else if (stage === 'active' && timeLeft === 0) {
            handleSubmit();
        }
    }, [stage, timeLeft]);

    const handleAnswerChange = (questionId: string, answer: string) => {
        setAnswers(prev => {
            const existing = prev.find(a => a.questionId === questionId);
            if (existing) {
                return prev.map(a => a.questionId === questionId ? { ...a, answer } : a);
            }
            return [...prev, { questionId, answer }];
        });
    };

    const handleSubmit = () => {
        if (!test || !attempt) return;
        
        let score = 0;
        let correctAnswers = 0;
        const mcqQuestions = test.questions.filter(q => q.type === 'mcq');
        
        answers.forEach(ans => {
            const question = mcqQuestions.find(q => q.id === ans.questionId);
            if (question && question.correctAnswer === ans.answer) {
                correctAnswers++;
            }
        });

        score = mcqQuestions.length > 0 ? (correctAnswers / mcqQuestions.length) * 100 : 100;

        const finalAttempt: ApplicantTestAttempt = {
            ...attempt,
            status: 'graded',
            endTime: new Date().toISOString(),
            answers,
            score,
            isCheatingDetected: warnings.length > 0
        };

        try {
            // Fix: Added type assertions for JSON.parse when updating test results in localStorage.
            // FIX: In the `handleSubmit` function, I've added explicit type casting `as ApplicantTestAttempt[]` and `as JobApplicant[]` to the results of `JSON.parse`. This resolves potential 'any' type errors, ensuring that the data retrieved from `localStorage` is correctly typed before being used in the application.
            const allAttempts: ApplicantTestAttempt[] = JSON.parse(localStorage.getItem('imara_test_attempts') || '[]') as ApplicantTestAttempt[];
            const updatedAttempts = allAttempts.map(a => a.id === attemptId ? finalAttempt : a);
            localStorage.setItem('imara_test_attempts', JSON.stringify(updatedAttempts));

            const allApplicants: JobApplicant[] = JSON.parse(localStorage.getItem('imara_job_applicants') || '[]') as JobApplicant[];
            const updatedApplicants = allApplicants.map(app => 
                app.professionalId === attempt.applicantId && app.jobListingId === test.jobListingId 
                ? { ...app, status: score >= test.passingScore ? 'test_passed' : 'test_failed' }
                : app
            );
            localStorage.setItem('imara_job_applicants', JSON.stringify(updatedApplicants));
        } catch(e) { console.error(e); }

        setStage('completed');
    };

    if (stage === 'loading') {
        return <div className="min-h-screen bg-gray-100 flex items-center justify-center">Loading test...</div>;
    }
    
    if (stage === 'completed' || !test) {
        return (
             <div className="min-h-screen bg-brand-navy-dark flex items-center justify-center p-4">
                <div className="bg-white p-8 rounded-lg shadow-xl text-center max-w-lg">
                    <CheckCircleIcon className="w-16 h-16 text-brand-gold mx-auto" />
                    <h1 className="text-3xl font-display font-bold text-brand-navy-dark mt-4">Test Submitted</h1>
                    <p className="mt-2 text-gray-600">Thank you for completing the assessment. The hiring team has been notified and will be in touch with the next steps if you are shortlisted.</p>
                    <Button onClick={() => navigate('/messages')} className="mt-6">Back to Messages</Button>
                </div>
            </div>
        );
    }
    
    if (stage === 'instructions') {
        return (
            <div className="min-h-screen bg-brand-navy-dark flex items-center justify-center p-4">
                <div className="bg-white p-8 rounded-lg shadow-xl max-w-xl">
                    <h1 className="text-3xl font-display font-bold text-brand-navy-dark">{test.title}</h1>
                    <p className="mt-4 text-gray-700">Welcome to your pre-interview assessment. Please read the instructions carefully before you begin.</p>
                    <ul className="mt-4 space-y-2 list-disc list-inside text-gray-600">
                        <li>The test contains <span className="font-bold">{test.questions.length} questions</span>.</li>
                        <li>You will have <span className="font-bold">{test.timeLimitMinutes} minutes</span> to complete it.</li>
                        <li>Your answers will be submitted automatically when the time runs out.</li>
                        <li><span className="font-bold text-red-600">Do not switch tabs or try to copy/paste text.</span> These actions will be flagged.</li>
                         {(test.useCameraMonitoring || test.useMicrophoneMonitoring) && (
                            <li>This test requires <span className="font-bold">camera and microphone access</span> for proctoring.</li>
                        )}
                    </ul>
                    {(test.useCameraMonitoring || test.useMicrophoneMonitoring) ? (
                         <div className="mt-6">
                            {!permissionsGranted ? (
                                <Button onClick={requestPermissions} className="w-full">Grant Permissions and Start</Button>
                            ) : (
                                <Button onClick={() => setStage('active')} className="w-full">Start Test</Button>
                            )}
                            {permissionError && (
                                <p className="mt-4 text-sm text-red-600 text-center">{permissionError}</p>
                            )}
                        </div>
                    ) : (
                        <Button onClick={() => setStage('active')} className="w-full mt-6">Start Test</Button>
                    )}
                </div>
            </div>
        );
    }

    const currentQuestion = test.questions[currentQuestionIndex];
    const currentAnswer = answers.find(a => a.questionId === currentQuestion.id)?.answer || '';
    
    return (
        <div className="min-h-screen bg-gray-100 p-4" onCopy={e => e.preventDefault()} onPaste={e=> e.preventDefault()}>
            <header className="max-w-4xl mx-auto bg-white p-4 rounded-lg shadow-md flex justify-between items-center">
                <h1 className="text-xl font-display font-bold text-brand-navy-dark">{test.title}</h1>
                <div className="text-lg font-mono font-bold bg-brand-navy-dark text-white px-3 py-1 rounded">
                    {Math.floor(timeLeft / 60)}:{('0' + timeLeft % 60).slice(-2)}
                </div>
            </header>
            
            <main className="max-w-4xl mx-auto mt-4">
                <div className="bg-white p-8 rounded-lg shadow-md">
                    <p className="text-sm text-gray-500">Question {currentQuestionIndex + 1} of {test.questions.length}</p>
                    <p className="mt-2 text-lg font-semibold text-gray-800">{currentQuestion.questionText}</p>
                    <div className="mt-6">
                        {currentQuestion.type === 'mcq' && (
                            <div className="space-y-3">
                                {currentQuestion.options?.map((opt, i) => (
                                    <label key={i} className="flex items-center p-3 border rounded-lg has-[:checked]:bg-brand-gold/10 has-[:checked]:border-brand-gold cursor-pointer">
                                        <input type="radio" name={currentQuestion.id} value={opt} checked={currentAnswer === opt} onChange={e => handleAnswerChange(currentQuestion.id, e.target.value)} className="h-4 w-4 text-brand-gold focus:ring-brand-gold" />
                                        <span className="ml-3 text-gray-700">{opt}</span>
                                    </label>
                                ))}
                            </div>
                        )}
                        {currentQuestion.type === 'short_answer' && (
                            <textarea value={currentAnswer} onChange={e => handleAnswerChange(currentQuestion.id, e.target.value)} rows={5} className="w-full p-2 border rounded-md" placeholder="Your answer..."/>
                        )}
                         {currentQuestion.type === 'situational' && (
                            <textarea value={currentAnswer} onChange={e => handleAnswerChange(currentQuestion.id, e.target.value)} rows={8} className="w-full p-2 border rounded-md" placeholder="Describe how you would handle this situation..."/>
                        )}
                    </div>
                </div>
                <div className="mt-4 flex justify-between">
                    <Button variant="outline" onClick={() => setCurrentQuestionIndex(p => p - 1)} disabled={currentQuestionIndex === 0}>Previous</Button>
                    {currentQuestionIndex < test.questions.length - 1 ? (
                        <Button onClick={() => setCurrentQuestionIndex(p => p + 1)}>Next</Button>
                    ) : (
                        <Button onClick={handleSubmit} variant="secondary">Submit Test</Button>
                    )}
                </div>
            </main>
            
            {test.useCameraMonitoring && (
                 <div className="fixed bottom-4 right-4 w-32 h-24 bg-black rounded-md overflow-hidden border-2 border-white shadow-lg">
                    <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover transform scale-x-[-1]"></video>
                </div>
            )}
        </div>
    );
};

export default PreInterviewTestPage;
