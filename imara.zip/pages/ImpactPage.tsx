
import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { mockInvestments, mockCauses, mockCulturalImpactEntries } from '../data/mockData.ts';
import PaymentModal from '../components/modals/PaymentModal.tsx';
import ImpactQuickViewModal from '../components/modals/ImpactQuickViewModal.tsx';
import type { Investment, Cause, PaymentItem, GiftCard, CulturalImpactEntry } from '../types.ts';
import { useLanguage } from '../contexts/LanguageContext.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';
import { useCurrency } from '../contexts/CurrencyContext.tsx';
import { BanknotesIcon, UsersIcon, HeartIcon, CheckCircleIcon, ArrowRightIcon, HomeIcon, SparklesIcon, GlobeIcon, TreeIcon } from '../components/icons/Icons.tsx';
import ProgressBar from '../components/ui/ProgressBar.tsx';
import ImpactSnapCard from '../components/shared/ImpactSnapCard.tsx';
import Button from '../components/ui/Button.tsx';

// Helper component for counting up animation
const CountUp = ({ end, duration = 2000, prefix = '', suffix = '' }: { end: number, duration?: number, prefix?: string, suffix?: string }) => {
    const [count, setCount] = useState(0);

    useEffect(() => {
        let startTime: number | null = null;
        const animate = (currentTime: number) => {
            if (!startTime) startTime = currentTime;
            const progress = currentTime - startTime;
            const percentage = Math.min(progress / duration, 1);
            const ease = 1 - Math.pow(1 - percentage, 4);
            setCount(Math.floor(ease * end));
            if (progress < duration) {
                requestAnimationFrame(animate);
            }
        };
        requestAnimationFrame(animate);
    }, [end, duration]);

    return <span>{prefix}{count.toLocaleString()}{suffix}</span>;
};

const ImpactPage: React.FC = () => {
  const [paymentItem, setPaymentItem] = useState<PaymentItem | null>(null);
  const [quickViewItem, setQuickViewItem] = useState<any>(null);
  const { t } = useLanguage();
  const { user, updateUser } = useAuth();
  const { formatCurrency } = useCurrency();
  
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [causes, setCauses] = useState<Cause[]>([]);
  const [culturalEntries, setCulturalEntries] = useState<CulturalImpactEntry[]>([]);
  const [showAllPrograms, setShowAllPrograms] = useState(false);
  
  useEffect(() => {
    try {
        const storedInvestments = localStorage.getItem('investments');
        const parsedInvestments = storedInvestments ? JSON.parse(storedInvestments) : null;
        setInvestments(Array.isArray(parsedInvestments) ? parsedInvestments : mockInvestments);
        
        const storedCauses = localStorage.getItem('causes');
        const parsedCauses = storedCauses ? JSON.parse(storedCauses) : null;
        setCauses(Array.isArray(parsedCauses) ? parsedCauses : mockCauses);

        setCulturalEntries(mockCulturalImpactEntries);
    } catch (error) {
        setInvestments(mockInvestments);
        setCauses(mockCauses);
        setCulturalEntries(mockCulturalImpactEntries);
    }
  }, []);

  const allPrograms = useMemo(() => {
      const combined = [...investments, ...causes];
      return combined.sort((a, b) => {
          const aFeatured = 'isTopPriority' in a ? (a as Investment).isTopPriority : ('isFeatured' in a ? (a as Cause).isFeatured : false);
          const bFeatured = 'isTopPriority' in b ? (b as Investment).isTopPriority : ('isFeatured' in b ? (b as Cause).isFeatured : false);
          if (bFeatured && !aFeatured) return 1;
          if (aFeatured && !bFeatured) return -1;
          return 0;
      });
  }, [investments, causes]);

  const displayedPrograms = showAllPrograms ? allPrograms : allPrograms.slice(0, 3);

  const handlePledgeNow = (investment: Investment) => {
    setPaymentItem({
      id: investment.id,
      type: 'investment',
      title: investment.title,
      recipient: investment.vendorName,
      imageUrl: investment.imageUrl,
    });
  };
  
  const handleDonateNow = (cause: Cause) => {
    setPaymentItem({
      id: cause.id,
      type: 'donation',
      title: cause.title,
      recipient: cause.organization,
      imageUrl: cause.imageUrl,
    });
  };

  const handleCloseModal = () => setPaymentItem(null);

  const handleSuccess = (amount: number) => {
    if (!paymentItem) return;
    if(paymentItem.type === 'investment') {
        const updatedInvestments = investments.map(inv => 
            inv.id === paymentItem.id ? { ...inv, raised: inv.raised + amount } : inv
        );
        setInvestments(updatedInvestments);
        localStorage.setItem('investments', JSON.stringify(updatedInvestments));
    } else if (paymentItem.type === 'donation') {
        const updatedCauses = causes.map(c => 
            c.id === paymentItem.id ? { ...c, raised: (c.raised || 0) + amount } : c
        );
        setCauses(updatedCauses);
        localStorage.setItem('causes', JSON.stringify(updatedCauses));
    }
    handleCloseModal();
  };

  return (
    <>
      <div className="bg-white dark:bg-gray-900 min-h-screen pb-32">
          <div className="container mx-auto px-4 sm:px-6 pt-6 flex justify-between items-center">
             <Link to="/" className="flex items-center gap-2 p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors text-gray-500" title="Back to Feed">
                 <HomeIcon className="w-5 h-5" />
                 <span className="text-sm font-bold uppercase tracking-widest">Feed</span>
             </Link>
          </div>

          <div className="container mx-auto px-4 sm:px-6 py-8">
             <div className="text-center mb-12 animate-fade-in">
                <h1 className="text-4xl md:text-5xl font-display font-black text-brand-navy-dark dark:text-white">Make an Impact</h1>
                <p className="mt-4 text-gray-500 dark:text-gray-400 max-w-xl mx-auto text-lg leading-relaxed">
                    Your support creates ripples of change. Support entrepreneurs or donate to causes that empower communities.
                </p>
             </div>

            {/* Stats Bar */}
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 p-4 mb-20 overflow-x-auto no-scrollbar">
                <div className="flex items-center min-w-[800px] justify-between divide-x divide-gray-100 dark:divide-gray-700">
                    <div className="flex items-center gap-4 px-8 flex-1">
                        <div className="p-2.5 bg-green-50 dark:bg-green-900/30 rounded-full text-green-600 dark:text-green-400" title="Total Funds Raised">
                            <BanknotesIcon className="w-6 h-6" />
                        </div>
                        <div>
                            <p className="text-xl font-display font-black text-brand-navy-dark dark:text-white leading-none">
                                <CountUp end={15} prefix="$" suffix="M Raised" />
                            </p>
                            <div className="w-12 h-1 bg-brand-gold mt-1.5 rounded-full"></div>
                        </div>
                    </div>

                    <div className="flex items-center gap-4 px-8 flex-1">
                        <div className="p-2.5 bg-blue-50 dark:bg-blue-900/30 rounded-full text-blue-600 dark:text-blue-400" title="Total Lives Impacted">
                            <UsersIcon className="w-6 h-6" />
                        </div>
                        <div>
                            <p className="text-xl font-display font-black text-brand-navy-dark dark:text-white leading-none">
                                <CountUp end={10000} suffix="+" />
                            </p>
                            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Lives Impacted</p>
                        </div>
                    </div>

                    <div className="flex items-center gap-4 px-8 flex-1">
                        <div className="p-2.5 bg-purple-50 dark:bg-purple-900/30 rounded-full text-purple-600 dark:text-purple-400" title="Total Communities Supported">
                            <HeartIcon className="w-6 h-6" />
                        </div>
                        <div>
                            <p className="text-xl font-display font-black text-brand-navy-dark dark:text-white leading-none">
                                <CountUp end={500} suffix="+" />
                            </p>
                            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Communities</p>
                        </div>
                    </div>

                    <div className="flex items-center gap-4 px-8 flex-1">
                        <div className="p-2.5 bg-orange-50 dark:bg-orange-900/30 rounded-full text-orange-600 dark:text-orange-400" title="Verified Projects">
                            <CheckCircleIcon className="w-6 h-6" />
                        </div>
                        <div>
                            <p className="text-xl font-display font-black text-brand-navy-dark dark:text-white leading-none">
                                <CountUp end={100} suffix="%" />
                            </p>
                            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Verified Projects</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Featured Programs Section - REFLECTING READINGS - MOVED TO TOP */}
            <div className="mb-20">
                <div className="flex justify-between items-end mb-10">
                     <div>
                        <h2 className="text-3xl font-display font-black text-brand-navy-dark dark:text-white flex items-center gap-3">
                            Reading-Reflective Programs
                        </h2>
                        <p className="text-gray-500 font-bold uppercase tracking-widest text-xs mt-1">High-impact projects contributing to platform milestones</p>
                     </div>
                     <button 
                        className="text-sm font-black text-brand-green hover:text-brand-navy-dark transition-colors uppercase tracking-widest border-b-2 border-brand-green pb-1"
                        onClick={() => setShowAllPrograms(!showAllPrograms)}
                        title={showAllPrograms ? "Show fewer programs" : "Show all available programs"}
                     >
                         {showAllPrograms ? 'Show Fewer' : 'View All Projects'}
                     </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                    {displayedPrograms.map((program) => {
                         const isInvestment = 'vendorName' in program;
                         const target = isInvestment ? (program as Investment).goal : (program as Cause).goal || 5000;
                         const current = isInvestment ? (program as Investment).raised : (program as Cause).raised || 0;
                         const percentage = Math.round((current/target)*100);
                         
                         const readingImpact = isInvestment ? "Contributes to $15M Raised" : "Contributes to 10k+ Lives Impacted";
                         const readingColor = isInvestment ? "text-green-600 bg-green-50" : "text-blue-600 bg-blue-50";
                         const readingIcon = isInvestment ? <BanknotesIcon className="w-3 h-3"/> : <UsersIcon className="w-3 h-3"/>;

                         return (
                            <div key={program.id} className="bg-white dark:bg-gray-800 rounded-[32px] shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden flex flex-col group hover:shadow-xl transition-all duration-500 hover:-translate-y-2 animate-fade-in h-full">
                                <div className="relative h-64 overflow-hidden">
                                    <img src={program.imageUrl} alt={program.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[10000ms]" />
                                    <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-full text-[10px] font-black text-brand-navy-dark uppercase tracking-widest shadow-lg">
                                        {isInvestment ? 'Partner Biz' : 'Social Cause'}
                                    </div>
                                    <div className="absolute bottom-4 left-4 right-4">
                                         <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-[0.1em] shadow-sm ${readingColor}`}>
                                            {readingIcon} {readingImpact}
                                         </div>
                                    </div>
                                </div>
                                <div className="p-6 flex flex-col flex-grow">
                                    <p className="text-[10px] text-gray-400 uppercase tracking-[0.2em] font-black mb-1 truncate">
                                        {isInvestment ? (program as Investment).vendorName : (program as Cause).organization}
                                    </p>
                                    <h3 className="font-display font-black text-xl text-brand-navy-dark dark:text-white mb-4 line-clamp-2 leading-tight group-hover:text-brand-green transition-colors">{program.title}</h3>
                                    
                                    <div className="mt-auto">
                                        <div className="flex justify-between items-center text-[11px] mb-2 font-black uppercase tracking-widest">
                                            <span className="text-gray-400">Progression</span>
                                            <span className="text-brand-navy-dark dark:text-brand-gold">{percentage}%</span>
                                        </div>
                                        <ProgressBar value={current} max={target} />
                                        
                                        <div className="flex justify-between items-center mt-3 text-sm">
                                            <span className="font-bold text-brand-green">{formatCurrency(current)}</span>
                                            <span className="text-gray-400 font-mono text-xs">Target: {formatCurrency(target)}</span>
                                        </div>
                                        
                                        <div className="mt-6 flex gap-3">
                                            {isInvestment ? (
                                                <button onClick={() => handlePledgeNow(program as Investment)} className="flex-1 py-3 px-4 text-xs font-black uppercase tracking-widest bg-brand-navy-dark text-white rounded-2xl hover:bg-brand-green transition-colors shadow-md" title="Pledge an investment to this project">Invest</button>
                                            ) : (
                                                <button onClick={() => handleDonateNow(program as Cause)} className="flex-1 py-3 px-4 text-xs font-black uppercase tracking-widest bg-brand-green text-white rounded-2xl hover:bg-brand-navy-dark transition-colors shadow-md" title="Donate funds to this cause">Donate</button>
                                            )}
                                            <button onClick={() => setQuickViewItem(program)} className="p-3 bg-gray-50 dark:bg-gray-700 rounded-2xl text-gray-400 hover:text-brand-gold transition-colors" title="View program highlights">
                                                <SparklesIcon className="w-5 h-5"/>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                         );
                    })}
                </div>
            </div>

            {/* Cultural Impact Section */}
            <div className="mb-20">
                <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-3">
                        <div className="p-3 bg-brand-gold/10 rounded-2xl">
                            <SparklesIcon className="w-8 h-8 text-brand-gold" title="Cultural Legacy Highlights"/>
                        </div>
                        <div>
                            <h2 className="text-3xl font-display font-black text-brand-navy-dark dark:text-white">Voices of the Continent</h2>
                            <p className="text-sm text-gray-500 font-bold uppercase tracking-wider">Spotlighting creators building cultural legacy</p>
                        </div>
                    </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {culturalEntries.map(entry => (
                        <ImpactSnapCard key={entry.id} entry={entry} />
                    ))}
                </div>
            </div>

            {/* Transparency Section */}
            <div className="container mx-auto px-4 max-w-4xl">
                 <div className="bg-brand-navy-dark rounded-[40px] p-10 md:p-16 text-white relative overflow-hidden shadow-2xl text-center">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-brand-green/20 rounded-full blur-[80px]"></div>
                    <div className="absolute bottom-0 left-0 w-64 h-64 bg-brand-gold/10 rounded-full blur-[80px]"></div>
                    <div className="relative z-10">
                        <CheckCircleIcon className="w-16 h-16 text-brand-gold mx-auto mb-6" title="Audit and Transparency Certified" />
                        <h2 className="text-3xl md:text-4xl font-display font-black mb-6">Transparency First</h2>
                        <p className="text-lg text-gray-300 leading-relaxed mb-10 max-w-2xl mx-auto">
                            Trust is the core of our cultural trade system. Every dollar is tracked, verified, and audited to ensure it directly supports the creators and causes you care about.
                        </p>
                        <Link to="/transparency">
                            <Button size="lg" variant="primary" className="!rounded-full px-12 font-black uppercase tracking-widest shadow-gold-glow" title="View detailed transparency reports">View Audit Reports</Button>
                        </Link>
                    </div>
                </div>
            </div>

          </div>
      </div>

      {paymentItem && (
        <PaymentModal
          item={paymentItem}
          onClose={handleCloseModal}
          onSuccess={(amount) => handleSuccess(amount)}
        />
      )}
      
      {quickViewItem && (
          <ImpactQuickViewModal 
              program={quickViewItem}
              onClose={() => setQuickViewItem(null)}
              onAction={(program) => {
                  setQuickViewItem(null);
                  if ('vendorName' in program) {
                      handlePledgeNow(program as Investment);
                  } else {
                      handleDonateNow(program as Cause);
                  }
              }}
          />
      )}
    </>
  );
};

export default ImpactPage;
