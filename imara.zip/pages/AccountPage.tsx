
import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Button from '../components/ui/Button.tsx';
import ImpactSummary from '../components/account/ImpactSummary.tsx';
import { mockTravelServices, mockAllUsersAndPartners, mockUserOrders, mockReviews, mockGistPosts } from '../data/mockData.ts';
import { useCurrency } from '../contexts/CurrencyContext.tsx';
import ProfileEditModal from '../components/modals/ProfileEditModal.tsx';
import { UserProfile, Booking, ImpactData, UserOrder, CartItem, Review, GistPost } from '../types.ts';
import { useAuth } from '../contexts/AuthContext.tsx';
import { UserIcon, CheckCircleIcon, HeartIcon, Cog6ToothIcon, ShieldCheckIcon, BookmarkIcon, UsersIcon, UserGroupIcon, ArrowUpTrayIcon, DocumentTextIcon, WhatsAppIcon, ShoppingBagIcon, ChatDotsIcon, PencilSquareIcon, SparklesIcon } from '../components/icons/Icons.tsx';
import RatingModal from '../components/modals/RatingModal.tsx';
import LanguageSwitcher from '../components/ui/LanguageSwitcher.tsx';
import { useLanguage } from '../contexts/LanguageContext.tsx';
import UserGiftCards from '../components/account/UserGiftCards.tsx';
import ThemeToggle from '../components/ui/ThemeToggle.tsx';
import { useWishlist } from '../contexts/WishlistContext.tsx';
import ProductCard from '../components/shared/ProductCard.tsx';
import { useCart } from '../contexts/CartContext.tsx';
import SavedPostsList from '../components/account/SavedPostsList.tsx';
import UserConnectionsList from '../components/account/UserConnectionsList.tsx';
import ToggleSwitch from '../components/ui/ToggleSwitch.tsx';
import Avatar from '../components/ui/Avatar.tsx';
import ReviewModal from '../components/modals/ReviewModal.tsx';
import EarningsDashboard from '../components/monetization/EarningsDashboard.tsx';

import GistPostCard from '../components/gist/GistPostCard.tsx';
import PrivacySettingsModal from '../components/modals/PrivacySettingsModal.tsx';
import ShareLinkCard from '../components/shared/ShareLinkCard.tsx';
import MonkixSettingsPanel from '../components/account/MonkixSettingsPanel.tsx';

import SyncContactsPanel from '../components/account/SyncContactsPanel.tsx';
import OrderHistoryTab from '../components/account/OrderHistoryTab.tsx';

type AccountTab = 'toasts' | 'bookings' | 'orders' | 'savedItems' | 'savedPosts' | 'following' | 'followers' | 'settings' | 'contacts';

const AccountPage: React.FC = () => {
    const { formatCurrency } = useCurrency();
    const navigate = useNavigate();
    const { user, logout, updateUser, unsavePost } = useAuth();
    const { wishlistItems } = useWishlist();
    const { addToCart } = useCart();
    const { t } = useLanguage();

    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [isWhatsAppModalOpen, setIsWhatsAppModalOpen] = useState(false);
    const [isPrivacyModalOpen, setIsPrivacyModalOpen] = useState(false);
    const [userBookings, setUserBookings] = useState<Booking[]>([]);
    const [userOrders, setUserOrders] = useState<UserOrder[]>([]);
    const [userToasts, setUserToasts] = useState<GistPost[]>([]);
    const [impactData, setImpactData] = useState<ImpactData>({ treesPlanted: 0, schoolDaysFunded: 0, artisansSupported: 0 });
    const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
    const [reviewingItem, setReviewingItem] = useState<CartItem | null>(null);
    const [activeTab, setActiveTab] = useState<AccountTab>('settings');

    useEffect(() => {
        if (user) {
            try {
                const allBookings: Booking[] = JSON.parse(localStorage.getItem('imara_bookings') || '[]') as Booking[];
                setUserBookings(allBookings.filter(b => b.userId === user.id).sort((a, b) => new Date(b.bookingDate).getTime() - new Date(a.bookingDate).getTime()));
                
                const storageKey = `imara_orders_${user.id}`;
                const storedOrders: UserOrder[] = JSON.parse(localStorage.getItem(storageKey) || '[]') as UserOrder[];
                setUserOrders(storedOrders);

                const storedPosts: GistPost[] = JSON.parse(localStorage.getItem('imara_gist_posts') || '[]') as GistPost[];
                const allPosts = [...storedPosts, ...mockGistPosts];
                setUserToasts(allPosts.filter(p => p.creator.id === user.id));

                setImpactData(JSON.parse(localStorage.getItem(`imara_impact_${user.id}`) || '{"treesPlanted":0,"schoolDaysFunded":0,"artisansSupported":0}') as ImpactData);
            } catch (error) {
                 setUserOrders([]);
            }
        }
    }, [user]);

    const handleLogout = () => { logout(); navigate('/'); };
    const handleProfileUpdate = (updatedProfile: UserProfile) => { updateUser(updatedProfile); setIsEditModalOpen(false); };
    const handleSettingChange = (key: keyof UserProfile, value: any) => { if (!user) return; updateUser({ [key]: value }); };
    
    const handleReviewSubmit = (review: Review) => {
        try {
            const storedReviews = localStorage.getItem('imara_reviews');
            const allReviews = storedReviews ? JSON.parse(storedReviews) as Review[] : mockReviews;
            localStorage.setItem('imara_reviews', JSON.stringify([review, ...allReviews]));
        } catch (e) { console.error(e); }

        setUserOrders(prevOrders =>
            prevOrders.map(order => ({
                ...order,
                items: order.items.map(item =>
                    item.id === review.productId ? { ...item, reviewed: true } : item
                ),
            }))
        );
        setReviewingItem(null);
    };

    if (!user) {
        return (
             <div className="container mx-auto px-6 py-12 text-center h-screen flex flex-col justify-center">
                <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <UserIcon className="w-10 h-10 text-gray-400" />
                </div>
                <h1 className="text-3xl font-display font-black text-brand-navy-dark">Welcome to Imara</h1>
                <p className="mt-4 text-gray-500 max-w-xs mx-auto">Please log in to manage your orders, track impact, and connect with artisans.</p>
                <Button onClick={() => navigate('/login')} className="mt-8 mx-auto px-12">Log In or Sign Up</Button>
            </div>
        );
    }

    const tabClass = (tabName: AccountTab) => `px-6 py-2.5 text-xs font-black uppercase tracking-widest rounded-full transition-all flex items-center gap-2 ${activeTab === tabName ? 'bg-brand-navy-dark text-white shadow-lg' : 'text-gray-500 hover:text-brand-navy-dark hover:bg-gray-100'}`;

    const renderTabContent = () => {
        switch (activeTab) {
            case 'toasts': return userToasts.length > 0 ? ( <div className="space-y-6 animate-fade-in"> {userToasts.map(post => ( <GistPostCard key={post.id} post={post} onCommentClick={() => {}} onAddToCart={addToCart} onBookService={() => {}} onDonateNow={() => {}} onLearnMore={() => {}} /> ))} </div> ) : <div className="text-center py-20 text-gray-400 bg-white rounded-3xl border border-dashed border-gray-200 animate-fade-in"><p className="font-bold">No Toasts yet</p></div>;
            case 'bookings': return userBookings.length > 0 ? ( <div className="space-y-4 animate-fade-in"> {userBookings.map(booking => ( <div key={booking.id} className="flex items-center gap-4 p-4 rounded-2xl bg-white border border-gray-100 shadow-sm"> <img src={mockTravelServices.find(s => s.id === booking.serviceId)?.imageUrl || ''} alt={booking.serviceTitle} className="w-16 h-16 rounded-xl object-cover"/> <div className="flex-grow"> <p className="font-bold text-brand-navy-dark">{booking.serviceTitle}</p> <p className="text-xs text-gray-400 font-mono">ID: {booking.id}</p> <p className="text-xs text-brand-green font-bold mt-1">Booked: {new Date(booking.bookingDate).toLocaleDateString()}</p> </div> <span className={`px-3 py-1 text-[10px] font-black uppercase tracking-wider rounded-full ${booking.status === 'confirmed' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{booking.status}</span> </div> ))} </div> ) : <div className="text-center py-20 text-gray-400 bg-white rounded-3xl border border-dashed border-gray-200 animate-fade-in"><p className="font-bold">No bookings found</p></div>;
            case 'orders': return <OrderHistoryTab userOrders={userOrders} setReviewingItem={setReviewingItem} />;
            case 'savedItems': return wishlistItems.length > 0 ? ( <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 animate-fade-in"> {wishlistItems.map(item => <ProductCard key={item.id} product={item} onAddToCart={addToCart} onQuickView={() => {}} />)} </div> ) : <div className="text-center py-20 text-gray-400 bg-white rounded-3xl border border-dashed border-gray-200 animate-fade-in"><HeartIcon className="w-10 h-10 mx-auto mb-4 opacity-20"/><p className="font-bold">No saved treasures</p></div>;
            case 'savedPosts': return <div className="animate-fade-in"><SavedPostsList postIds={user.savedPostIds || []} onUnsave={unsavePost} /></div>;
            case 'following': return <div className="animate-fade-in"><UserConnectionsList userIds={user.followingIds || []} allUsers={mockAllUsersAndPartners} type="following" /></div>;
            case 'followers': return <div className="animate-fade-in"><UserConnectionsList userIds={user.followerIds || []} allUsers={mockAllUsersAndPartners} type="followers" /></div>;
            case 'contacts': return <div className="animate-fade-in"><SyncContactsPanel /></div>;
            
            case 'settings':
                return (
                     <div className="space-y-8 animate-fade-in">
                        {/* Unique Profile Link */}
                        <ShareLinkCard 
                            title="Your Profile Link" 
                            description="Share your Imara profile with friends to show off your collection and impact."
                            urlPath={`/user/${user.id}`}
                            variant="profile"
                        />

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div className="bg-white p-8 rounded-[40px] shadow-sm border border-gray-100 flex flex-col justify-between">
                                <div>
                                    <h3 className="text-xl font-display font-black text-brand-navy-dark mb-6 flex items-center gap-2">
                                        <ChatDotsIcon className="w-6 h-6 text-[#7E57C2]"/> Gossip Pulse
                                    </h3>
                                    <p className="text-sm text-gray-500 mb-6 leading-relaxed">
                                        Link your Imara experience with Monkix Core Intelligence. Get real-time updates and concierge support directly in Gossip.
                                    </p>
                                    {user.trustScore && user.trustScore >= 50 ? (
                                        <div className="bg-green-50 p-4 rounded-2xl flex items-center gap-3 text-green-700 text-xs font-bold mb-6">
                                            <CheckCircleIcon className="w-5 h-5"/> Trusted Imaran Status Active
                                        </div>
                                    ) : (
                                        <div className="bg-gray-50 p-4 rounded-2xl text-gray-400 text-xs font-bold mb-6">
                                            Complete your first purchase to unlock Core intelligence.
                                        </div>
                                    )}
                                </div>
                                <Button onClick={() => navigate('/messages/monkix')} variant="secondary" className="w-full !rounded-2xl !bg-[#7E57C2] !border-none text-white shadow-xl hover:scale-105 transition-transform flex items-center justify-center gap-2">
                                    <SparklesIcon className="w-5 h-5"/> Connect to Gossip
                                </Button>
                            </div>

                            <div className="bg-white p-8 rounded-[40px] shadow-sm border border-gray-100">
                                <h3 className="text-xl font-display font-black text-brand-navy-dark mb-6">Accessibility & Region</h3>
                                <div className="space-y-6">
                                    <div className="flex items-center justify-between">
                                        <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Interface Tongue</label>
                                        <LanguageSwitcher />
                                    </div>
                                    <div className="flex items-center justify-between">
                                        <p className="text-xs font-black text-gray-400 uppercase tracking-widest">Atmosphere</p>
                                        <ThemeToggle />
                                    </div>
                                    <div className="flex items-center justify-between">
                                        <p className="text-xs font-black text-gray-400 uppercase tracking-widest">Privacy Shield</p>
                                        <Button variant="outline" size="sm" onClick={() => setIsPrivacyModalOpen(true)} className="!text-[10px] !px-4 !py-2 !rounded-xl">Manage Data</Button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="bg-white p-8 rounded-[40px] shadow-sm border border-gray-100">
                             <h3 className="text-xl font-display font-black text-brand-navy-dark mb-8 flex items-center gap-2">
                                <Cog6ToothIcon className="w-6 h-6 text-brand-gold"/> Account Configuration
                             </h3>
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-6">
                                <div className="flex items-center justify-between py-2 border-b border-gray-50">
                                    <span className="text-sm font-bold text-gray-600">Profile Visibility</span>
                                    <select value={user.profileVisibility || 'public'} onChange={(e) => handleSettingChange('profileVisibility', e.target.value)} className="bg-gray-50 border-none rounded-lg text-xs font-bold text-brand-navy-dark p-2">
                                        <option value="public">Public</option>
                                        <option value="followers_only">Followers Only</option>
                                    </select>
                                </div>
                                <div className="flex items-center justify-between py-2 border-b border-gray-50">
                                    <span className="text-sm font-bold text-gray-600">Secure 2FA</span>
                                    <ToggleSwitch enabled={!!user.twoFactorEnabled} setEnabled={(val) => handleSettingChange('twoFactorEnabled', val)} label="2FA" />
                                </div>
                                <div className="flex items-center justify-between py-2 border-b border-gray-50">
                                    <span className="text-sm font-bold text-gray-600">Native Name Display</span>
                                    <ToggleSwitch enabled={!!user.showNativeName} setEnabled={(val) => handleSettingChange('showNativeName', val)} label="Native Name" />
                                </div>
                             </div>
                        </div>

                        <MonkixSettingsPanel user={user} onUpdate={handleSettingChange} />
                    </div>
                );
            default: return null;
        }
    };

    return (
        <div className="bg-brand-off-white dark:bg-gray-900 min-h-screen pb-32">
            <div className="container mx-auto px-4 md:px-8 py-10">
                <div className="bg-brand-navy-dark rounded-[48px] p-8 md:p-12 mb-12 flex flex-col md:flex-row items-center gap-8 relative overflow-hidden shadow-2xl">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-brand-gold/10 rounded-full blur-[80px]"></div>
                    <div className="absolute bottom-0 left-0 w-64 h-64 bg-brand-green/5 rounded-full blur-[80px]"></div>
                    
                    <Avatar 
                        imageUrl={user.profileImageUrl}
                        name={user.fullName}
                        id={user.id}
                        trustScore={user.trustScore}
                        className="w-32 h-32 md:w-44 md:h-44 rounded-full border-4 border-brand-gold bg-white relative z-10"
                        textClassName="text-5xl font-bold"
                    />
                    
                    <div className="flex-grow text-center md:text-left relative z-10">
                        <div className="flex items-center justify-center md:justify-start gap-3 mb-2">
                            <h1 className="text-4xl md:text-5xl font-display font-black text-white leading-tight uppercase tracking-tighter">{user.fullName}</h1>
                            {user.isVerified && <ShieldCheckIcon className="w-8 h-8 text-brand-gold" title="Verified Imaran" />}
                        </div>
                        <p className="text-brand-gold font-bold uppercase tracking-[0.2em] text-xs">{user.email}</p>
                        
                        <div className="mt-8 flex flex-wrap gap-3 justify-center md:justify-start">
                            <Button variant="primary" onClick={() => setIsEditModalOpen(true)} className="!rounded-2xl !px-8 shadow-gold-glow">Edit Profile</Button>
                            <Button variant="outline" onClick={handleLogout} className="!text-white !border-white/20 hover:!bg-white/10 !rounded-2xl !px-8">Log Out</Button>
                        </div>
                    </div>
                    
                    <div className="flex flex-col md:flex-row gap-8 text-center bg-white/5 backdrop-blur-md p-6 rounded-3xl border border-white/10 relative z-10">
                        <div>
                            <p className="text-3xl font-display font-black text-white">{user.followerIds?.length || 0}</p>
                            <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest mt-1">Followers</p>
                        </div>
                        <div className="hidden md:block w-px h-10 bg-white/10 self-center"></div>
                        <div>
                            <p className="text-3xl font-display font-black text-white">{user.followingIds?.length || 0}</p>
                            <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest mt-1">Following</p>
                        </div>
                    </div>
                </div>

                <EarningsDashboard />
                <ImpactSummary impactData={impactData} />

                <div className="mb-10 overflow-x-auto scrollbar-hide">
                    <div className="flex gap-4 min-w-max p-2 bg-white/50 backdrop-blur-md dark:bg-gray-800/50 rounded-3xl border border-gray-100 dark:border-gray-700">
                        <button className={tabClass('settings')} onClick={() => setActiveTab('settings')}>Settings</button>
                        <button className={tabClass('orders')} onClick={() => setActiveTab('orders')}>Orders</button>
                        <button className={tabClass('toasts')} onClick={() => setActiveTab('toasts')}>My Toasts</button>
                        <button className={tabClass('bookings')} onClick={() => setActiveTab('bookings')}>Bookings</button>
                        <button className={tabClass('savedItems')} onClick={() => setActiveTab('savedItems')}>Saved Hub</button>
                        <button className={tabClass('following')} onClick={() => setActiveTab('following')}>Following</button>
                        <button className={tabClass('followers')} onClick={() => setActiveTab('followers')}>Followers</button>
                        <button className={tabClass('contacts')} onClick={() => setActiveTab('contacts')}>Find Friends</button>
                    </div>
                </div>
                
                <div className="max-w-5xl mx-auto">
                    {renderTabContent()}
                </div>
            </div>

            {isEditModalOpen && <ProfileEditModal user={user} onClose={() => setIsEditModalOpen(false)} onSave={handleProfileUpdate} />}
            {isWhatsAppModalOpen && <WhatsAppConnectModal onClose={() => setIsWhatsAppModalOpen(false)} />}
            {isPrivacyModalOpen && <PrivacySettingsModal onClose={() => setIsPrivacyModalOpen(false)} />}
            {reviewingItem && <ReviewModal product={reviewingItem} onClose={() => setReviewingItem(null)} onSubmit={handleReviewSubmit} />}
        </div>
    );
};

export default AccountPage;
