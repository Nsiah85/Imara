import React, { useState } from 'react';
import { mockCauses } from '../data/mockData.ts';
import CauseCard from '../components/shared/CauseCard.tsx';
import PaymentModal from '../components/modals/PaymentModal.tsx';
import type { Cause, PaymentItem } from '../types.ts';

const DonatePage: React.FC = () => {
  const [paymentItem, setPaymentItem] = useState<PaymentItem | null>(null);

  const handleDonateNow = (cause: Cause) => {
    setPaymentItem({
      id: cause.id,
      type: 'donation',
      title: cause.title,
      recipient: cause.organization,
      imageUrl: cause.imageUrl,
    });
  };

  const handleCloseModal = () => {
    setPaymentItem(null);
  };

  return (
    <>
      <div className="container mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-display font-bold text-brand-green-dark">Support a Cause</h1>
          <p className="mt-2 text-brand-gray max-w-2xl mx-auto">
            Contribute to initiatives that create lasting change in the communities we partner with. 100% of your donation goes directly to the cause.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {mockCauses.map(cause => (
            <CauseCard 
              key={cause.id} 
              cause={cause} 
              onDonateNow={handleDonateNow}
            />
          ))}
        </div>
      </div>
      {paymentItem && (
        <PaymentModal
          item={paymentItem}
          onClose={handleCloseModal}
          onSuccess={() => {
            console.log('Donation successful!');
            handleCloseModal();
          }}
        />
      )}
    </>
  );
};

export default DonatePage;