
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { mockProducts, mockVendors, mockReviews } from '../data/mockData.ts';
import Badge from '../components/ui/Badge.tsx';
import Button from '../components/ui/Button.tsx';
import { 
    GlobeIcon, LeafIcon, SparklesIcon, CheckCircleIcon, ShieldCheckIcon,
    FacebookIcon, TwitterXIcon, WhatsAppIcon, PinterestIcon, LinkIcon, CheckIcon, EnvelopeIcon 
} from '../components/icons/Icons.tsx';
import { useCart } from '../contexts/CartContext.tsx';
import { useCurrency } from '../contexts/CurrencyContext.tsx';
import ProductCard from '../components/shared/ProductCard.tsx';
import QuickViewModal from '../components/modals/QuickViewModal.tsx';
import type { Product, Review } from '../types.ts';
import { ProductCategory } from '../types.ts';
import WishlistButton from '../components/ui/WishlistButton.tsx';
import { useLanguage } from '../contexts/LanguageContext.tsx';
import BackButton from '../components/ui/BackButton.tsx';
import ReviewSummary from '../components/reviews/ReviewSummary.tsx';
import ReviewCard from '../components/reviews/ReviewCard.tsx';
import ReviewModal from '../components/modals/ReviewModal.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';
import SEO from '../components/seo/SEO.tsx';
import OptimizedImage from '../components/ui/OptimizedImage.tsx';

const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const product = mockProducts.find(p => p.id === id);
  const vendor = mockVendors.find(v => v.brandName === product?.vendor);
  const { user } = useAuth();
  const { addToCart } = useCart();
  const { formatCurrency } = useCurrency();
  const { t } = useLanguage();
  const [isAdded, setIsAdded] = useState(false);
  const [isLinkCopied, setIsLinkCopied] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);

  useEffect(() => {
    try {
        const storedReviews = localStorage.getItem('imara_reviews');
        // FIX: Add type assertion for JSON.parse result.
        const allReviews = storedReviews ? JSON.parse(storedReviews) as Review[] : mockReviews;
        setReviews(allReviews.filter((r: Review) => r.productId === id));
    } catch (e) {
        console.error("Failed to load reviews:", e);
        setReviews(mockReviews.filter(r => r.productId === id));
    }
  }, [id]);

  if (!product) {
    return (
      <div className="container mx-auto px-6 py-8 text-center">
        <SEO title="Product Not Found - Imara" description="The product you are looking for does not exist." />
        <h1 className="text-3xl font-display">Product not found</h1>
      </div>
    );
  }
  
  const handleReviewSubmit = (newReview: Review) => {
    setReviews(prev => [newReview, ...prev]);
    try {
        const storedReviews = localStorage.getItem('imara_reviews');
        // FIX: Add type assertion for JSON.parse result.
        const allReviews = storedReviews ? JSON.parse(storedReviews) as Review[] : mockReviews;
        localStorage.setItem('imara_reviews', JSON.stringify([newReview, ...allReviews]));
    } catch (e) { console.error(e); }
    setIsReviewModalOpen(false);
  };

  const isAutomotive = product.category === ProductCategory.AUTOMOTIVE;

  const handleAddToCart = () => {
    if (product) {
      addToCart(product);
      setIsAdded(true);
      setTimeout(() => setIsAdded(false), 2000);
    }
  };

  const handleOpenQuickView = (product: Product) => {
    setQuickViewProduct(product);
  };

  const handleCloseQuickView = () => {
    setQuickViewProduct(null);
  };
  
  const handleShareClick = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href).then(() => {
        setIsLinkCopied(true);
        setTimeout(() => setIsLinkCopied(false), 2000);
    });
  };

  const productUrl = window.location.href;
  const shareText = `Check out this amazing product: ${product.name} from Imara!`;
  const encodedUrl = encodeURIComponent(productUrl);
  const encodedText = encodeURIComponent(shareText);
  const encodedDescription = encodeURIComponent(`${product.name} - ${product.description}`);
  const encodedImageUrl = encodeURIComponent(product.imageUrl);

  const shareLinks = {
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
    twitter: `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedText}`,
    whatsapp: `https://api.whatsapp.com/send?text=${encodedText}%20${encodedUrl}`,
    pinterest: `https://pinterest.com/pin/create/button/?url=${encodedUrl}&media=${encodedImageUrl}&description=${encodedDescription}`
  };

  const relatedProducts = mockProducts.filter(p => 
    p.id !== product.id &&
    (p.category === product.category || p.sustainabilityTags.some(tag => product.sustainabilityTags.includes(tag)))
  )
  .sort(() => 0.5 - Math.random()) // Randomize for variety
  .slice(0, 4);

  return (
    <>
      <SEO 
        title={`${product.name} | Imara`} 
        description={product.description.substring(0, 160)}
        image={product.imageUrl}
      />
      
      <div className="container mx-auto px-6 py-12">
        <BackButton className="mb-6" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <OptimizedImage src={product.imageUrl} alt={product.name} className="w-full rounded-lg shadow-lg object-cover aspect-square" />
          </div>
          <div>
            {vendor ? (
              <Link to={`/vendor/${vendor.storeSlug}`}>
                <p className="text-sm uppercase tracking-widest text-brand-gray hover:text-brand-gold transition-colors">{product.vendor}</p>
              </Link>
            ) : (
              <p className="text-sm uppercase tracking-widest text-brand-gray">{product.vendor}</p>
            )}
            <h1 className="text-4xl font-display font-bold text-brand-navy-dark mt-2">{product.name}</h1>
            <p className="text-3xl font-display font-semibold text-brand-navy mt-4">{formatCurrency(product.price)}</p>
            <div className="mt-6 border-t pt-6">
              <p className="text-gray-700 leading-relaxed">{product.description}</p>
            </div>
            <div className="mt-6 flex flex-wrap gap-3">
              {product.sustainabilityTags.map(tag => (
                  <Badge key={tag} className="bg-emerald-100 text-emerald-800" icon={<LeafIcon className="w-4 h-4"/>}>{tag}</Badge>
              ))}
              <Badge className="bg-blue-100 text-blue-800" icon={<GlobeIcon className="w-4 h-4"/>}>{product.originCountry}</Badge>
            </div>

            <div className="mt-6 bg-green-50/50 border border-green-200 text-green-900 p-4 rounded-lg flex items-start gap-4">
              <SparklesIcon className="w-8 h-8 text-brand-gold flex-shrink-0 mt-1" />
              <div>
                  <h4 className="font-bold">{t('product.yourImpact')}</h4>
                  <p className="text-sm">{product.impactPerPurchase}</p>
              </div>
            </div>
            
            <div className="mt-8 flex items-stretch gap-4">
              {isAutomotive ? (
                <Link to={`/messages/new?recipientId=${encodeURIComponent(vendor?.id || '')}&recipientName=${encodeURIComponent(product.vendor)}&recipientAvatar=${encodeURIComponent(vendor?.brandLogoUrl || product.imageUrl)}&recipientRole=Vendor`} className="flex-grow">
                  <Button size="lg" className="w-full h-full flex items-center justify-center gap-2">
                    <EnvelopeIcon className="w-5 h-5" />
                    Contact Dealer
                  </Button>
                </Link>
              ) : (
                <>
                  <Button size="lg" className="flex-grow" onClick={handleAddToCart} disabled={isAdded}>
                    {isAdded ? t('product.addedToCart') : t('product.addToCart')}
                  </Button>
                   <Link to={`/messages/new?recipientId=${encodeURIComponent(vendor?.id || '')}&recipientName=${encodeURIComponent(product.vendor)}&recipientAvatar=${encodeURIComponent(vendor?.brandLogoUrl || product.imageUrl)}&recipientRole=Vendor`} className="flex-grow">
                    <Button size="lg" variant="outline" className="w-full h-full">
                      {t('product.messageVendor')}
                    </Button>
                  </Link>
                </>
              )}
              <WishlistButton product={product} className="border-2 border-brand-navy dark:border-brand-gold-light rounded-md flex-shrink-0 bg-white" />
            </div>

            <div className="mt-8 space-y-4 text-sm text-gray-600">
              <div className="flex items-center gap-3">
                  <CheckCircleIcon className="w-5 h-5 text-brand-green" />
                  <span>{product.isVerified ? "Verified Artisan" : "Artisan Partner"}</span>
              </div>
              <div className="flex items-center gap-3">
                  <ShieldCheckIcon className="w-5 h-5 text-brand-green" />
                  <span>Secure Checkout with Stripe, Paystack & Flutterwave</span>
              </div>
            </div>
            
            <div className="mt-8 pt-6 border-t border-gray-200">
                <h4 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">Share this product</h4>
                <div className="flex items-center gap-3">
                    <button onClick={() => handleShareClick(shareLinks.facebook)} aria-label="Share on Facebook" className="w-10 h-10 rounded-full bg-gray-100 text-gray-600 hover:bg-[#1877F2] hover:text-white flex items-center justify-center transition-colors"><FacebookIcon className="w-5 h-5"/></button>
                    <button onClick={() => handleShareClick(shareLinks.twitter)} aria-label="Share on Twitter" className="w-10 h-10 rounded-full bg-gray-100 text-gray-600 hover:bg-black hover:text-white flex items-center justify-center transition-colors"><TwitterXIcon className="w-5 h-5"/></button>
                    <button onClick={() => handleShareClick(shareLinks.whatsapp)} aria-label="Share on WhatsApp" className="w-10 h-10 rounded-full bg-gray-100 text-gray-600 hover:bg-[#25D366] hover:text-white flex items-center justify-center transition-colors"><WhatsAppIcon className="w-5 h-5"/></button>
                    <button onClick={() => handleShareClick(shareLinks.pinterest)} aria-label="Share on Pinterest" className="w-10 h-10 rounded-full bg-gray-100 text-gray-600 hover:bg-[#E60023] hover:text-white flex items-center justify-center transition-colors"><PinterestIcon className="w-5 h-5"/></button>
                    <button onClick={handleCopyLink} aria-label="Copy link" className={`w-10 h-10 rounded-full bg-gray-100 text-gray-600 flex items-center justify-center transition-all ${isLinkCopied ? 'bg-brand-green text-white' : 'hover:bg-brand-navy hover:text-white'}`}>
                        {isLinkCopied ? <CheckIcon className="w-5 h-5"/> : <LinkIcon className="w-5 h-5"/>}
                    </button>
                    {isLinkCopied && <span className="text-sm text-brand-green animate-fade-in">Link Copied!</span>}
                </div>
            </div>
          </div>
        </div>

        {/* Reviews Section */}
        <div className="mt-20 pt-12 border-t border-gray-200 dark:border-gray-700">
          <ReviewSummary reviews={reviews} />
          <div className="mt-8">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-display font-bold text-brand-navy-dark dark:text-white">
                Showing {reviews.length} reviews
              </h3>
              {user && <Button variant="secondary" onClick={() => setIsReviewModalOpen(true)}>Write a Review</Button>}
            </div>
            {reviews.length > 0 ? (
              reviews.map(review => <ReviewCard key={review.id} review={review} />)
            ) : (
              <p className="text-center text-gray-500 dark:text-gray-400 py-8">No reviews yet. Be the first to share your thoughts!</p>
            )}
          </div>
        </div>

        {/* You Might Also Like Section */}
        {relatedProducts.length > 0 && (
            <div className="mt-20 pt-12 border-t border-gray-200">
              <h2 className="text-2xl md:text-3xl font-display font-bold text-brand-navy-dark mb-8 text-center">{t('product.youMightLike')}</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                  {relatedProducts.map((relatedProduct, index) => (
                      <ProductCard 
                        key={relatedProduct.id} 
                        product={relatedProduct} 
                        animationDelay={index * 75} 
                        onQuickView={handleOpenQuickView}
                        onAddToCart={addToCart}
                      />
                  ))}
              </div>
            </div>
        )}
      </div>
      {quickViewProduct && (
        <QuickViewModal product={quickViewProduct} onClose={handleCloseQuickView} />
      )}
      {isReviewModalOpen && user && (
        <ReviewModal product={product} onClose={() => setIsReviewModalOpen(false)} onSubmit={handleReviewSubmit} />
      )}
    </>
  );
};

export default ProductDetailPage;
