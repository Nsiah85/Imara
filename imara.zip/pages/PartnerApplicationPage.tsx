
import React, { useState, useEffect, useMemo } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import type { PartnerApplication, Product, ShopProfile, Professional, EdwasoMarket } from '../types.ts';
import { ProfessionalIndustry, ServiceType, VendorType } from '../types.ts';
import Button from '../components/ui/Button.tsx';
import ApplicationStatusTracker from '../components/vendor/ApplicationStatusTracker.tsx';
import { PhotoIcon, UserCircleIcon, CheckCircleIcon } from '../components/icons/Icons.tsx';
import VendorOnboardingGuide from '../components/vendor/VendorOnboardingGuide.tsx';
import { useCurrency } from '../contexts/CurrencyContext.tsx';
import { useDataSync } from '../contexts/DataSyncContext.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';
import { countries, getCurrencyForCountry } from '../utils/currency.ts';
import PayoutSetupModal from '../components/modals/PayoutSetupModal.tsx';
import PoliciesModal from '../components/modals/PoliciesModal.tsx';
import WorkmanOnboardingGuide from '../components/workman/WorkmanOnboardingGuide.tsx';
import EditWorkmanProfileModal from '../components/modals/EditWorkmanProfileModal.tsx';
import AddPortfolioModal from '../components/modals/AddPortfolioModal.tsx';
import SubscriptionSelector from '../components/subscriptions/SubscriptionSelector.tsx';
import { mockVendorSubscriptionPlans, mockWorkmanSubscriptionPlans, mockEdwasoMarkets } from '../data/mockData.ts';
import PasswordStrengthIndicator from '../components/ui/PasswordStrengthIndicator.tsx';
import { db, collection, addDoc, serverTimestamp, setDoc, doc } from '../firebase/firestore.ts';

const usePartnerApplications = () => {
    const [applications, setApplications] = useState<PartnerApplication[]>([]);
    const { getData } = useDataSync();

    useEffect(() => {
        // Read applications from Firebase is generally an admin task, but for UI feedback, we can fetch
        // Or we don't need to load all of them if they are just submitting.
        // We'll leave the array empty for now to save reads if not needed for submission.
    }, []);

    const addApplication = async (app: Omit<PartnerApplication, 'id' | 'status' | 'submittedAt'>) => {
        // Check auto verification
        let isAutoVerified = false;
        try {
            const storedConfig = getData('system/governance');
            if (storedConfig && storedConfig.autoVerification !== undefined) {
                isAutoVerified = storedConfig.autoVerification;
            } else {
                const ls = localStorage.getItem('imara_package_governance');
                if (ls) {
                    const parsed = JSON.parse(ls);
                    if (parsed.autoVerification !== undefined) {
                        isAutoVerified = parsed.autoVerification;
                    }
                }
            }
        } catch (e) {
            console.error('Failed to read config', e);
        }

        const newApplication: PartnerApplication = {
            ...app,
            id: crypto.randomUUID(), // Temporarily set to UUID, will be overwritten by firestore ID if using addDoc, but let's use setDoc with this UUID
            status: isAutoVerified ? 'approved' : 'pending', 
            submittedAt: new Date().toISOString(),
        };
        try {
            await setDoc(doc(db, 'partner_applications', newApplication.id), {
                ...newApplication,
                createdAt: serverTimestamp()
            });
            setApplications(prev => [...prev, newApplication]);
            
            if (isAutoVerified) {
                // To keep mock data in sync if we want it to be visible in admin immediately
                const existingPartners = localStorage.getItem('partners');
                if (existingPartners) {
                    const parsed = JSON.parse(existingPartners);
                    parsed.push({
                        id: newApplication.id,
                        name: newApplication.fullName,
                        email: newApplication.email,
                        role: newApplication.role,
                        brandName: newApplication.brandName || newApplication.fullName,
                        industry: newApplication.industry || 'Other',
                        isVerified: true,
                        subscriptionPlanId: newApplication.subscriptionPlanId || 'basic'
                    });
                    localStorage.setItem('partners', JSON.stringify(parsed));
                }
            }
            
        } catch (error) {
            console.error("Failed to save application to Firebase", error);
            throw error;
        }
        return newApplication;
    };

    return { addApplication };
};

const PartnerApplicationForm: React.FC<{
    role: 'vendor' | 'workman' | 'travel',
    onSubmit: (data: any) => Promise<void>
}> = ({ role, onSubmit }) => {
    const { setCurrency } = useCurrency();
    const [edwasoMarkets, setEdwasoMarkets] = useState<EdwasoMarket[]>([]);
    const [imagePreview, setImagePreview] = useState('');
    const [coverPreview, setCoverPreview] = useState('');
    
    const [formData, setFormData] = useState({
        role,
        fullName: '',
        email: '',
        password: '',
        country: '',
        brandName: '',
        story: '',
        industry: ProfessionalIndustry.TRADES,
        skills: '',
        serviceTypes: [] as ServiceType[],
        vendorType: VendorType.ARTISAN,
        marketId: '',
        companyLogoUrl: '',
        coverImageUrl: '',
    });
    const [errors, setErrors] = useState({
        fullName: '',
        email: '',
        story: '',
    });
    const [isPasswordValid, setIsPasswordValid] = useState(false);
    
    useEffect(() => {
        try {
            const storedMarkets = localStorage.getItem('edwaso_markets');
            if (storedMarkets) {
                setEdwasoMarkets(JSON.parse(storedMarkets));
            } else {
                setEdwasoMarkets(mockEdwasoMarkets);
            }
        } catch (error) {
            console.error("Failed to load Edwaso markets", error);
            setEdwasoMarkets(mockEdwasoMarkets);
        }
    }, []);

    const isEdwasoVendor = formData.vendorType === VendorType.MARKET_WOMAN || formData.vendorType === VendorType.FARMER;
    const wordCount = useMemo(() => formData.story.trim().split(/\s+/).filter(Boolean).length, [formData.story]);
    
    const filteredMarkets = useMemo(() => {
        if (!formData.country) return edwasoMarkets;
        return edwasoMarkets.filter(market => market.country === formData.country);
    }, [edwasoMarkets, formData.country]);

    const validateField = (name: string, value: string): string => {
        switch (name) {
            case 'fullName':
                return /^[a-zA-Z\s'-]{2,}$/.test(value) ? '' : 'Please enter a valid name.';
            case 'email':
                return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) ? '' : 'Please enter a valid email address.';
            case 'story':
                if (role === 'vendor' && !isEdwasoVendor && wordCount < 50) {
                    return `Your story must be at least 50 words. (Current: ${wordCount})`;
                }
                return '';
            default:
                return '';
        }
    };
    
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
        if (errors[name as keyof typeof errors] !== undefined) {
             setErrors(prev => ({ ...prev, [name]: validateField(name, value) }));
        }
    };

    const [logoFile, setLogoFile] = useState<File | null>(null);
    const [coverFile, setCoverFile] = useState<File | null>(null);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'logo' | 'cover') => {
      if (e.target.files && e.target.files[0]) {
        const file = e.target.files[0];
        const url = URL.createObjectURL(file);
        if (type === 'logo') {
            setImagePreview(url);
            setLogoFile(file);
            // Temp URL for preview
            setFormData(prev => ({ ...prev, companyLogoUrl: url }));
        } else {
            setCoverPreview(url);
            setCoverFile(file);
            setFormData(prev => ({ ...prev, coverImageUrl: url }));
        }
      }
    };

    const handleServiceTypeChange = (serviceType: ServiceType) => {
        setFormData(prev => {
            const newServiceTypes = prev.serviceTypes.includes(serviceType)
                ? prev.serviceTypes.filter(st => st !== serviceType)
                : [...prev.serviceTypes, serviceType];
            return { ...prev, serviceTypes: newServiceTypes };
        });
    };

    const handleBlur = (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        if (errors[name as keyof typeof errors] !== undefined) {
          setErrors(prev => ({ ...prev, [name]: validateField(name, value) }));
        }
    };
    
     useEffect(() => {
        // Re-validate story when vendor type changes
        setErrors(prev => ({ ...prev, story: validateField('story', formData.story) }));
        if (!isEdwasoVendor) {
            setFormData(prev => ({ ...prev, marketId: '' }));
        }
    }, [formData.vendorType, formData.story]);


    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        
        let hasErrors = false;
        const validationErrors = {
            fullName: validateField('fullName', formData.fullName),
            email: validateField('email', formData.email),
            story: validateField('story', formData.story),
        };

        if (Object.values(validationErrors).some(Boolean)) {
            hasErrors = true;
            setErrors(validationErrors);
        }
        
        if (hasErrors || !isPasswordValid) {
            return;
        }

        setIsSubmitting(true);
        let finalData = { ...formData };

        try {
            const { uploadFile } = await import('../firebase/storage.ts');
            if (logoFile) {
                const url = await uploadFile(logoFile, `applications/logos/${Date.now()}`);
                finalData.companyLogoUrl = url;
            }
            if (coverFile) {
                const url = await uploadFile(coverFile, `applications/covers/${Date.now()}`);
                finalData.coverImageUrl = url;
            }
        } catch (error) {
            console.error("Failed to upload application files", error);
        }

        try {
            await onSubmit(finalData);
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleCountryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const countryName = e.target.value;
        setFormData(prev => ({ ...prev, country: countryName }));
        setCurrency(getCurrencyForCountry(countryName));
    };
    
    // HIGH CONTRAST STYLING
    const baseInputClass = "mt-1 block w-full bg-brand-navy-dark text-brand-gold border border-brand-gold/50 rounded-md shadow-sm py-3 px-4 focus:outline-none focus:ring-2 focus:ring-brand-gold focus:border-transparent placeholder:text-brand-gold/40 transition-all";
    const inputClass = (name: keyof typeof errors) => 
        `${baseInputClass} ${errors[name] ? 'border-red-500 focus:ring-red-500' : ''}`;

    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            <h2 className="text-2xl font-display font-bold text-brand-navy-dark dark:text-white">
                Join as {role === 'workman' ? 'AfroTalent' : role.charAt(0).toUpperCase() + role.slice(1)}
            </h2>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Full Name</label>
                    <input type="text" name="fullName" id="fullName" value={formData.fullName} onChange={handleChange} onBlur={handleBlur} required className={inputClass('fullName')} placeholder="e.g. Kwame Osei" />
                    {errors.fullName && <p className="mt-1 text-xs text-red-500">{errors.fullName}</p>}
                </div>
                <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Email Address</label>
                    <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} onBlur={handleBlur} required className={inputClass('email')} placeholder="e.g. kwame@example.com" />
                    {errors.email && <p className="mt-1 text-xs text-red-500">{errors.email}</p>}
                </div>
             </div>
              <div>
                <label htmlFor="password-signup" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Password</label>
                <input type="password" name="password" id="password-signup" required className={baseInputClass} value={formData.password} onChange={handleChange} />
                <PasswordStrengthIndicator password={formData.password} onValidityChange={setIsPasswordValid} />
            </div>

            {role === 'vendor' && (
                 <div>
                    <label htmlFor="vendorType" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Business Type</label>
                    <select name="vendorType" id="vendorType" value={formData.vendorType} onChange={handleChange} required className={baseInputClass}>
                        {Object.values(VendorType).map(type => <option key={type} value={type}>{type}</option>)}
                    </select>
                </div>
            )}
            
            {role === 'travel' && (
                <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Services Offered</label>
                     <div className="mt-2 grid grid-cols-2 sm:grid-cols-3 gap-2">
                         {Object.values(ServiceType).map(type => (
                            <label key={type} className={`flex items-center gap-2 p-3 border border-brand-gold rounded-md cursor-pointer bg-brand-navy-dark hover:bg-brand-navy transition-colors`}>
                                <input type="checkbox" checked={formData.serviceTypes.includes(type)} onChange={() => handleServiceTypeChange(type)} className="h-4 w-4 rounded text-brand-gold focus:ring-brand-gold bg-brand-navy border-brand-gold" />
                                <span className="text-sm font-medium text-brand-gold">{type}</span>
                            </label>
                         ))}
                    </div>
                </div>
            )}

             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {(role === 'vendor' || role === 'travel') && (
                    <div>
                        <label htmlFor="brandName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Brand / Business Name</label>
                        <input type="text" name="brandName" id="brandName" value={formData.brandName} onChange={handleChange} required className={baseInputClass} placeholder="Your Business Name" />
                    </div>
                )}
                 <div>
                    <label htmlFor="country" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Country of Operation</label>
                    <select name="country" id="country" value={formData.country} onChange={handleCountryChange} required className={baseInputClass}>
                        <option value="" disabled className="text-gray-400">Select a country</option>
                        {countries.map(c => <option key={c.code} value={c.name}>{c.name}</option>)}
                    </select>
                </div>
            </div>
            
            {/* Image Uploads for Vendor/Travel */}
            {(role === 'vendor' || role === 'travel') && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Company Logo</label>
                        <div className="flex items-center gap-4">
                            <div className="h-20 w-20 rounded-full overflow-hidden border-2 border-brand-gold bg-brand-navy-dark flex items-center justify-center">
                                {imagePreview ? <img src={imagePreview} alt="Logo Preview" className="h-full w-full object-cover" /> : <UserCircleIcon className="h-12 w-12 text-brand-gold/50" />}
                            </div>
                            <label className="cursor-pointer bg-brand-gold text-brand-navy-dark font-bold py-2 px-4 rounded-full hover:bg-brand-gold-light transition-colors">
                                Upload Logo
                                <input type="file" className="sr-only" onChange={e => handleImageChange(e, 'logo')} accept="image/*" />
                            </label>
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Cover Image</label>
                        <div className="relative h-20 w-full rounded-md overflow-hidden border-2 border-brand-gold bg-brand-navy-dark flex items-center justify-center group">
                            {coverPreview ? (
                                <img src={coverPreview} alt="Cover Preview" className="h-full w-full object-cover" />
                            ) : (
                                <span className="text-brand-gold/50 text-sm">Background Banner</span>
                            )}
                            <label className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer text-white font-semibold">
                                Upload Cover
                                <input type="file" className="sr-only" onChange={e => handleImageChange(e, 'cover')} accept="image/*" />
                            </label>
                        </div>
                    </div>
                </div>
            )}
            
            {isEdwasoVendor && (
                <div className="animate-fade-in">
                    <label htmlFor="marketId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Primary Market</label>
                    <select name="marketId" id="marketId" value={formData.marketId} onChange={handleChange} required={isEdwasoVendor} className={baseInputClass}>
                       <option value="" disabled>Select your primary market</option>
                       {filteredMarkets.length > 0 ? (
                           filteredMarkets.map(market => <option key={market.id} value={market.id}>{market.name}, {market.region}</option>)
                       ) : (
                           <option value="" disabled>No major markets found for {formData.country || 'selected country'}</option>
                       )}
                    </select>
                </div>
            )}


            {role === 'vendor' && !isEdwasoVendor && (
                 <div className="animate-fade-in">
                    <label htmlFor="story" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Your Story</label>
                    <textarea name="story" id="story" rows={5} value={formData.story} onChange={handleChange} onBlur={handleBlur} required className={inputClass('story')} placeholder="Tell us about your craft..."></textarea>
                     <p className={`mt-1 text-xs ${errors.story ? 'text-red-500' : 'text-gray-500 dark:text-gray-400'}`}>
                        Minimum 50 words. ({wordCount}/50)
                    </p>
                </div>
            )}
            
            {role === 'workman' && (
                <>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label htmlFor="industry" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Industry</label>
                            <select name="industry" id="industry" value={formData.industry} onChange={handleChange} required className={baseInputClass}>
                                {Object.values(ProfessionalIndustry).map(ind => <option key={ind} value={ind}>{ind}</option>)}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="skills" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Top Skills (comma-separated)</label>
                            <input type="text" name="skills" id="skills" value={formData.skills} onChange={handleChange} required className={baseInputClass} placeholder="e.g. Plumbing, Design, Driving" />
                        </div>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Profile Photo</label>
                        <div className="mt-2 flex items-center gap-4">
                            <span className="inline-block h-16 w-16 rounded-full overflow-hidden bg-brand-navy-dark border-2 border-brand-gold">
                                {imagePreview ? <img src={imagePreview} alt="Preview" className="h-full w-full object-cover" /> : <PhotoIcon className="h-full w-full text-brand-gold p-3" />}
                            </span>
                            <label className="cursor-pointer bg-brand-gold text-brand-navy-dark font-bold py-2 px-4 rounded-full hover:bg-brand-gold-light transition-colors">
                                <span>Upload Photo</span>
                                <input type="file" className="sr-only" onChange={e => handleImageChange(e, 'logo')} accept="image/*" />
                            </label>
                        </div>
                    </div>
                </>
            )}

            <Button type="submit" size="lg" className="w-full mt-6" disabled={!isPasswordValid || Object.values(errors).some(Boolean) || isSubmitting}>
                {isSubmitting ? 'Uploading...' : 'Submit Application'}
            </Button>
        </form>
    );
};

const PartnerApplicationPage: React.FC = () => {
    // Map generic routes to internal roles if needed, but handle 'afrotalent' param mapping
    const { role: paramRole } = useParams<{ role: string }>();
    
    const role = useMemo(() => {
        if (paramRole === 'afrotalent') return 'workman';
        return paramRole as 'vendor' | 'workman' | 'travel';
    }, [paramRole]);

    const [application, setApplication] = useState<PartnerApplication | null>(null);
    const { addApplication } = usePartnerApplications();
    const { login } = useAuth();
    const [isSuccess, setIsSuccess] = useState(false);
    const navigate = useNavigate();

    // If role is invalid, redirect or show error
    if (!role || !['vendor', 'workman', 'travel'].includes(role)) {
        return (
            <div className="min-h-screen flex flex-col items-center justify-center gap-4">
                <p className="text-xl text-red-600">Invalid application type.</p>
                <Link to="/"><Button>Go Home</Button></Link>
            </div>
        );
    }

    const handleApplicationSubmit = async (data: any) => {
        try {
            // Check auto verification
            let isAutoVerified = false;
            try {
                const ls = localStorage.getItem('imara_package_governance');
                if (ls) {
                    const parsed = JSON.parse(ls);
                    if (parsed.autoVerification !== undefined) {
                        isAutoVerified = parsed.autoVerification;
                    }
                }
            } catch (e) {}

            let userProfile = null;
            // Automatically log them in so they can access the platform
            if (data.password) {
                userProfile = await login(data.email, data.password, {
                    fullName: data.fullName,
                    country: data.country,
                    role: data.role,
                    isVerified: isAutoVerified
                });
            }

            // Create application as authenticated user
            data.id = userProfile?.id; // Optional: Link to user ID 
            const newApp = await addApplication(data);
            setApplication(newApp);

            setIsSuccess(true);
        } catch (error) {
            console.error("Submission failed", error);
        }
    };
    
    if (isSuccess && application) {
        return (
             <div className="min-h-screen bg-brand-off-white dark:bg-gray-900 flex items-center justify-center p-4">
                <div className="max-w-md w-full bg-white dark:bg-brand-navy-dark rounded-2xl shadow-2xl p-8 text-center border-4 border-brand-gold">
                    <CheckCircleIcon className="w-20 h-20 text-brand-gold mx-auto mb-4 animate-bounce" />
                    <h2 className="text-3xl font-display font-bold text-brand-green-dark dark:text-white">Application Received!</h2>
                    <p className="mt-4 text-gray-600 dark:text-gray-300">
                        Thank you for applying to become a partner. Your application is currently <strong>{application.status === 'approved' ? 'Approved' : 'Pending Review'}</strong>.
                    </p>
                    <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                        {application.status === 'approved' 
                            ? "Your account has been automatically verified based on current platform settings! You can now access the partner hub."
                            : "You have been automatically signed in. Our admin team will review your application for full partner privileges."}
                    </p>
                    <Link to="/vendor-hub">
                        <Button size="lg" className="mt-8 w-full">
                            Go to Dashboard
                        </Button>
                    </Link>
                </div>
            </div>
        )
    }

    return (
        <div className="min-h-screen bg-brand-off-white dark:bg-gray-900 py-12 px-4">
            <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 p-8 rounded-lg shadow-xl border-t-4 border-brand-gold">
                 <div className="text-center mb-8">
                    <Link to="/" className="font-display font-extrabold text-3xl tracking-wider">
                        <div>
                            <span className="text-brand-navy-dark dark:text-white">Ima</span>
                            <span className="text-brand-gold">ra</span>
                        </div>
                    </Link>
                    <p className="text-sm text-gray-500 mt-2">Partner Registration</p>
                </div>
                <PartnerApplicationForm role={role} onSubmit={handleApplicationSubmit} />
            </div>
        </div>
    );
};

export default PartnerApplicationPage;
