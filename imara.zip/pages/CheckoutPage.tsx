
import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import type { ShippingAddress, ShippingMethod, GiftCard, DeliveryDetails, UserOrder, ImpactData } from '../types.ts';
import StepIndicator from '../components/checkout/StepIndicator.tsx';
import ShippingForm from '../components/checkout/ShippingForm.tsx';
import ShippingMethodSelector from '../components/checkout/ShippingMethodSelector.tsx';
import PaymentGateway from '../components/checkout/PaymentForm.tsx';
import OrderReview from '../components/checkout/OrderReview.tsx';
import OrderSuccess from '../components/checkout/OrderSuccess.tsx';
import { useCart } from '../contexts/CartContext.tsx';
import Button from '../components/ui/Button.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';
import DeliveryScheduler from '../components/checkout/DeliveryScheduler.tsx';
import { generateTransactionId } from '../utils/transaction.ts';
import { mockGiftCards } from '../data/mockData.ts';
import { saveOrderDetails, updateImpactData } from '../services/dataService.ts';

const mockShippingMethods: ShippingMethod[] = [
    { id: 'standard', name: 'Standard Shipping', price: 10.00, estimatedDelivery: '5-7 business days' },
    { id: 'express', name: 'Express Shipping', price: 25.00, estimatedDelivery: '1-3 business days' },
    { id: 'international', name: 'International Shipping', price: 50.00, estimatedDelivery: '10-15 business days' },
];

type CheckoutStep = 'shipping' | 'method' | 'delivery' | 'payment' | 'review' | 'success';

const CheckoutPage: React.FC = () => {
    const { user } = useAuth();
    const [step, setStep] = useState<CheckoutStep>('shipping');
    const [shippingDetails, setShippingDetails] = useState<ShippingAddress | null>(null);
    const [deliveryDetails, setDeliveryDetails] = useState<DeliveryDetails | null>(null);
    const [selectedMethod, setSelectedMethod] = useState<ShippingMethod>(mockShippingMethods[0]);
    const { cartItems, clearCart } = useCart();
    
    const [couponCode, setCouponCode] = useState('');
    const [appliedCoupon, setAppliedCoupon] = useState<GiftCard | null>(null);
    const [couponError, setCouponError] = useState<string | null>(null);
    const [generatedOrderNumber, setGeneratedOrderNumber] = useState('');

    const isLocalDelivery = shippingDetails?.country === 'Ghana' || shippingDetails?.country === 'Nigeria';

    const subtotal = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);
    const shippingCost = subtotal > 0 ? selectedMethod.price : 0;
    
    let discount = 0;
    if (appliedCoupon) {
        if (appliedCoupon.type === 'fixed') {
            discount = appliedCoupon.value;
        } else { // percentage
            discount = subtotal * (appliedCoupon.value / 100);
        }
    }
    const total = Math.max(0, subtotal + shippingCost - discount);

    const handleApplyCoupon = () => {
        setCouponError(null);
        try {
            // Check mock coupons from data/mockData.ts
            const allAvailableCards = [...mockGiftCards, ...(user?.giftCards || [])];
            const card = allAvailableCards.find(c => c.code.toLowerCase() === couponCode.toLowerCase());

            if (!card) {
                setCouponError('Invalid coupon code.');
                return;
            }
            if (!card.isActive) {
                setCouponError('This coupon is not active.');
                return;
            }
            if (new Date(card.expiryDate) < new Date()) {
                setCouponError('This coupon has expired.');
                return;
            }

            setAppliedCoupon(card);
            setCouponCode('');
        } catch(e) {
            console.error(e);
            setCouponError("Could not validate coupon.");
        }
    };

    const handleRemoveCoupon = () => {
        setAppliedCoupon(null);
    };

    const handleShippingSubmit = (data: ShippingAddress) => {
        setShippingDetails(data);
        setStep('method');
    };

    const handleMethodSubmit = () => {
        if (isLocalDelivery) {
            setStep('delivery');
        } else {
            setDeliveryDetails(null); // Clear delivery details if not local
            setStep('payment');
        }
    };
    
    const handleDeliverySubmit = (data: DeliveryDetails) => {
        setDeliveryDetails(data);
        setStep('payment');
    };

    const handlePaymentSubmit = () => {
        setStep('review');
    };

    const handlePlaceOrder = async () => {
        if (user) {
            try {
                // Determine main vendor name from first item
                const mainVendor = cartItems.length > 0 ? cartItems[0].vendor : 'Imara';
                
                // Get existing orders to determine sequence (We can't get sequence synchronously from firestore easily without a read, fallback to timestamp for now or use transactionId without sequence)
                // Generate formatted ID
                const orderId = generateTransactionId(mainVendor, Math.floor(Math.random() * 1000), 'order');
                setGeneratedOrderNumber(orderId);

                const newOrder = {
                    orderId,
                    date: new Date().toISOString().split('T')[0],
                    items: cartItems,
                    total: total,
                };
                
                await saveOrderDetails(user.id, newOrder);

                // Update Impact Data
                const uniqueVendors = new Set(cartItems.map(item => item.vendor));
                await updateImpactData(user.id, { artisansSupported: uniqueVendors.size });
                
            } catch (error) {
                console.error("Failed to save order or impact data:", error);
                setGeneratedOrderNumber(`IMR-${Date.now()}`); // Fallback
            }
        } else {
             // Guest checkout fallback ID
             setGeneratedOrderNumber(`IMR-${Date.now()}`);
        }

        clearCart();
        setStep('success');
    };

    const steps = useMemo(() => {
        const baseSteps = ['Shipping', 'Method'];
        if (isLocalDelivery) {
            baseSteps.push('Delivery');
        }
        baseSteps.push('Payment', 'Review');
        return baseSteps;
    }, [isLocalDelivery]);

    const currentStepIndex = useMemo(() => {
        const stepMap: { [key in CheckoutStep]?: number } = {
            'shipping': 0,
            'method': 1,
            'delivery': isLocalDelivery ? 2 : -1,
            'payment': isLocalDelivery ? 3 : 2,
            'review': isLocalDelivery ? 4 : 3,
        };
        return stepMap[step] ?? -1;
    }, [step, isLocalDelivery]);


    if (cartItems.length === 0 && step !== 'success') {
        return (
            <div className="container mx-auto px-6 py-20 text-center">
                <h1 className="text-3xl font-display font-bold text-brand-navy-dark">Your Cart is Empty</h1>
                <p className="mt-4 text-brand-gray">Looks like you haven't added anything to your cart yet.</p>
                <Link to="/shop">
                    <Button variant="primary" size="lg">Start Shopping</Button>
                </Link>
            </div>
        )
    }

    return (
        <div className="bg-brand-off-white/80 dark:bg-gray-800/20">
            <div className="container mx-auto px-4 sm:px-6 py-8 md:py-12 responsive-checkout-padding">
                {step !== 'success' && (
                    <div className="max-w-3xl mx-auto mb-8">
                        <StepIndicator steps={steps} currentStep={currentStepIndex} />
                    </div>
                )}
                <div className="max-w-3xl mx-auto">
                    {step === 'shipping' && <ShippingForm onSubmit={handleShippingSubmit} />}
                    {step === 'method' && (
                        <ShippingMethodSelector
                            methods={mockShippingMethods}
                            selectedMethod={selectedMethod}
                            onSelect={setSelectedMethod}
                            onSubmit={handleMethodSubmit}
                            onBack={() => setStep('shipping')}
                        />
                    )}
                    {step === 'delivery' && isLocalDelivery && (
                        <DeliveryScheduler
                            onSubmit={handleDeliverySubmit}
                            onBack={() => setStep('method')}
                        />
                    )}
                    {step === 'payment' && (
                        <PaymentGateway 
                            onSubmit={handlePaymentSubmit} 
                            onBack={() => setStep(isLocalDelivery ? 'delivery' : 'method')} 
                            totalAmount={total}
                        />
                    )}
                    {step === 'review' && shippingDetails && (
                        <OrderReview
                            shippingDetails={shippingDetails}
                            shippingMethod={selectedMethod}
                            deliveryDetails={deliveryDetails}
                            cartItems={cartItems}
                            subtotal={subtotal}
                            shippingCost={shippingCost}
                            total={total}
                            onPlaceOrder={handlePlaceOrder}
                            onBack={() => setStep('payment')}
                            appliedCoupon={appliedCoupon}
                            discount={discount}
                            onApplyCoupon={handleApplyCoupon}
                            onRemoveCoupon={handleRemoveCoupon}
                            couponError={couponError}
                            couponCode={couponCode}
                            setCouponCode={setCouponCode}
                        />
                    )}
                    {step === 'success' && <OrderSuccess orderNumber={generatedOrderNumber} />}
                </div>
            </div>
        </div>
    );
};

export default CheckoutPage;
