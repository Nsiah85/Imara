
import React, { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { usePrivacy } from '../contexts/PrivacyContext';
import { useAuth } from '../contexts/AuthContext';
import Button from '../components/ui/Button';
import { ImaraDiskIcon, ShieldCheckIcon, DocumentTextIcon, LockClosedIcon } from '../components/icons/Icons';

const PrivacyTermsPage: React.FC = () => {
    const { acceptTerms, hasConsented } = usePrivacy();
    const { user } = useAuth();
    
    const [readPrivacy, setReadPrivacy] = useState(false);
    const [readTerms, setReadTerms] = useState(false);
    const [accepted, setAccepted] = useState(false);

    // If user is already consented, redirect to home
    if (hasConsented) {
        return <Navigate to="/" replace />;
    }

    const handleAccept = () => {
        if (accepted) {
            acceptTerms();
        }
    };

    return (
        <div className="min-h-screen bg-brand-navy-dark text-white flex flex-col items-center justify-center p-6">
            <div className="max-w-2xl w-full bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl shadow-2xl overflow-hidden">
                {/* Header */}
                <div className="p-8 text-center border-b border-white/10">
                    <div className="inline-block p-4 rounded-full bg-brand-gold/10 mb-4">
                        <ImaraDiskIcon className="w-16 h-16" />
                    </div>
                    <h1 className="text-3xl font-display font-bold text-brand-gold">Imara Data Privacy</h1>
                    <p className="text-gray-300 mt-2">
                        We believe in transparency. Before you continue, please review how we handle your data in our Hybrid Storage System.
                    </p>
                </div>

                {/* Content */}
                <div className="p-8 space-y-8 max-h-[50vh] overflow-y-auto custom-scrollbar">
                    
                    {/* Hybrid Architecture Explanation */}
                    <div className="flex gap-4">
                        <div className="flex-shrink-0 mt-1"><LockClosedIcon className="w-6 h-6 text-brand-green" /></div>
                        <div>
                            <h3 className="font-bold text-lg text-white mb-2">1. Hybrid Data Storage</h3>
                            <p className="text-sm text-gray-400 leading-relaxed">
                                Imara uses a split-storage model. Your <strong>personal heavy media (photos, videos)</strong> are stored locally on your device for privacy and speed. Only essential interaction data (likes, comments, orders) is synced to our Cloud servers.
                            </p>
                        </div>
                    </div>

                    <div className="flex gap-4">
                        <div className="flex-shrink-0 mt-1"><ShieldCheckIcon className="w-6 h-6 text-brand-gold" /></div>
                        <div>
                            <h3 className="font-bold text-lg text-white mb-2">2. Your Data, Your Control</h3>
                            <p className="text-sm text-gray-400 leading-relaxed">
                                You have full control. You can clear your local data, request a copy of your cloud data, or delete your account at any time from the Settings menu. We do not sell your personal data to third parties.
                            </p>
                        </div>
                    </div>

                    <div className="p-4 bg-black/30 rounded-lg border border-white/5">
                        <h4 className="font-bold text-sm text-brand-gold mb-2">Summary of Key Points:</h4>
                        <ul className="list-disc list-inside text-xs text-gray-300 space-y-1">
                            <li>We collect usage data to improve the ShopHub experience.</li>
                            <li>Payment data is processed securely by Stripe/Paystack/Momo (we don't store raw card info).</li>
                            <li>You must be at least 18 years old or have guardian consent to use Imara.</li>
                        </ul>
                    </div>

                </div>

                {/* Action Footer */}
                <div className="p-8 bg-black/20 border-t border-white/10">
                    <div className="space-y-4 mb-6">
                        <label className="flex items-center gap-3 cursor-pointer group">
                            <input 
                                type="checkbox" 
                                checked={readPrivacy} 
                                onChange={(e) => setReadPrivacy(e.target.checked)} 
                                className="w-5 h-5 rounded border-gray-500 bg-transparent text-brand-gold focus:ring-offset-0 focus:ring-brand-gold"
                            />
                            <span className="text-sm text-gray-300 group-hover:text-white transition-colors">
                                I have read the <button className="text-brand-gold underline">Privacy Policy</button>
                            </span>
                        </label>

                        <label className="flex items-center gap-3 cursor-pointer group">
                            <input 
                                type="checkbox" 
                                checked={readTerms} 
                                onChange={(e) => setReadTerms(e.target.checked)} 
                                className="w-5 h-5 rounded border-gray-500 bg-transparent text-brand-gold focus:ring-offset-0 focus:ring-brand-gold"
                            />
                            <span className="text-sm text-gray-300 group-hover:text-white transition-colors">
                                I agree to the <button className="text-brand-gold underline">Terms of Service</button>
                            </span>
                        </label>
                        
                        <div className={`transition-opacity duration-300 ${readPrivacy && readTerms ? 'opacity-100' : 'opacity-50 pointer-events-none'}`}>
                             <label className="flex items-center gap-3 cursor-pointer group">
                                <input 
                                    type="checkbox" 
                                    checked={accepted} 
                                    onChange={(e) => setAccepted(e.target.checked)} 
                                    className="w-5 h-5 rounded border-gray-500 bg-transparent text-brand-green focus:ring-offset-0 focus:ring-brand-green"
                                />
                                <span className="text-sm font-bold text-white group-hover:text-brand-green transition-colors">
                                    I Accept & Continue
                                </span>
                            </label>
                        </div>
                    </div>

                    <Button 
                        onClick={handleAccept} 
                        disabled={!accepted} 
                        className={`w-full py-4 text-lg font-bold ${accepted ? 'bg-brand-gold text-brand-navy-dark hover:bg-white' : 'bg-gray-700 text-gray-400 cursor-not-allowed'}`}
                    >
                        Enter Imara
                    </Button>
                </div>
            </div>
        </div>
    );
};

export default PrivacyTermsPage;
