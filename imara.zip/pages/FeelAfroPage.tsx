import React, { useState, useMemo } from 'react';
import { mockTravelServices } from '../data/mockData';
import { ServiceType, TravelService } from '../types';
import ServiceCard from '../components/shared/ServiceCard';
import BookingModal from '../components/modals/BookingModal';
import { TicketIcon, BuildingOfficeIcon, TruckIcon, FireIcon, SunIcon, StarIcon, SparklesIcon, CalendarDaysIcon } from '../components/icons/Icons';
import { useCart } from '../contexts/CartContext';
import Button from '../components/ui/Button';
import { useCurrency } from '../contexts/CurrencyContext';
import { useLanguage } from '../contexts/LanguageContext';
import BackButton from '../components/ui/BackButton';

const serviceTypeIcons: { [key in ServiceType]: React.ReactNode } = {
    [ServiceType.FLIGHT]: <TicketIcon className="w-6 h-6" />,
    [ServiceType.HOTEL]: <BuildingOfficeIcon className="w-6 h-6" />,
    [ServiceType.RIDE]: <TruckIcon className="w-6 h-6" />,
    [ServiceType.MEAL]: <FireIcon className="w-6 h-6" />,
    [ServiceType.RESORT]: <SunIcon className="w-6 h-6" />,
    [ServiceType.EXPERIENCE]: <SparklesIcon className="w-6 h-6" />,
    [ServiceType.EVENT]: <CalendarDaysIcon className="w-6 h-6" />,
};

const hotelAmenities = ['Pool', 'Spa', 'Gym', 'Wi-Fi', 'Beach Access'];
const flightClasses = ['Business Class', 'First Class'];

const FeelAfroPage: React.FC = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedType, setSelectedType] = useState<ServiceType | null>(null);
    const [bookingService, setBookingService] = useState<TravelService | null>(null);
    const [priceRange, setPriceRange] = useState({ min: '', max: '' });
    const [minRating, setMinRating] = useState(0);
    const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);
    const [selectedClasses, setSelectedClasses] = useState<string[]>([]);
    const { addToCart } = useCart();
    const { currency } = useCurrency();
    const { t } = useLanguage();

    const handleAmenityToggle = (amenity: string) => {
        setSelectedAmenities(prev =>
            prev.includes(amenity) ? prev.filter(a => a !== amenity) : [...prev, amenity]
        );
    };

    const handleClassToggle = (cls: string) => {
        setSelectedClasses(prev =>
            prev.includes(cls) ? prev.filter(c => c !== cls) : [...prev, cls]
        );
    };
    
    const resetFilters = () => {
        setSearchTerm('');
        setSelectedType(null);
        setPriceRange({ min: '', max: '' });
        setMinRating(0);
        setSelectedAmenities([]);
        setSelectedClasses([]);
    };

    const filteredServices = useMemo(() => {
        return mockTravelServices.filter(service => {
            const lowerCaseSearch = searchTerm.toLowerCase();
            const matchesSearch =
                service.title.toLowerCase().includes(lowerCaseSearch) ||
                service.providerName.toLowerCase().includes(lowerCaseSearch) ||
                service.location.toLowerCase().includes(lowerCaseSearch);

            const matchesType = !selectedType || service.type === selectedType;

            const minPrice = parseFloat(priceRange.min) || 0;
            const maxPrice = parseFloat(priceRange.max) || Infinity;
            const matchesPrice = service.price >= minPrice && service.price <= maxPrice;

            const matchesRating = service.rating >= minRating;
            
            const matchesAmenities = (selectedType !== ServiceType.HOTEL && selectedType !== ServiceType.RESORT) || selectedAmenities.length === 0 || 
                                     selectedAmenities.every(amenity => service.amenities?.includes(amenity));

            const matchesClasses = selectedType !== ServiceType.FLIGHT || selectedClasses.length === 0 ||
                                   selectedClasses.every(cls => service.classes?.includes(cls));


            return matchesSearch && matchesType && matchesPrice && matchesRating && matchesAmenities && matchesClasses;
        });
    }, [searchTerm, selectedType, priceRange, minRating, selectedAmenities, selectedClasses]);

    return (
        <>
            <div className="container mx-auto px-6 py-8">
                <BackButton className="mb-4" />
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-display font-bold text-brand-green-dark dark:text-white">{t('feelAfro.title')}</h1>
                    <p className="mt-2 text-brand-gray dark:text-gray-400 max-w-xl mx-auto">{t('feelAfro.subtitle')}</p>
                </div>

                <div className="mb-8 p-6 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <div className="lg:col-span-4">
                            <label htmlFor="search" className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t('general.search')}</label>
                            <input
                                type="text"
                                id="search"
                                placeholder={t('feelAfro.filters.searchPlaceholder')}
                                className="mt-1 w-full p-2 border border-brand-green rounded-md focus:ring-brand-gold focus:border-brand-gold bg-brand-green-dark text-brand-gold-light placeholder:text-gray-400"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>

                        <div className="lg:col-span-2">
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t('feelAfro.filters.priceRange')} ({currency})</label>
                            <div className="flex items-center gap-2 mt-1">
                                <input type="number" placeholder="Min" value={priceRange.min} onChange={e => setPriceRange(p => ({ ...p, min: e.target.value }))} className="w-full p-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md"/>
                                <span className="text-gray-500 dark:text-gray-400">-</span>
                                <input type="number" placeholder="Max" value={priceRange.max} onChange={e => setPriceRange(p => ({ ...p, max: e.target.value }))} className="w-full p-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md"/>
                            </div>
                        </div>

                         <div className="lg:col-span-2">
                             <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t('feelAfro.filters.rating')}</label>
                             <div className="flex items-center gap-2 mt-1">
                                {[4, 3, 0].map(rating => (
                                    <button key={rating} onClick={() => setMinRating(rating)} className={`flex-1 p-2 text-sm rounded-md border transition-colors ${minRating === rating ? 'bg-brand-gold text-white border-brand-gold' : 'bg-white dark:bg-gray-700 dark:border-gray-600 dark:text-white hover:border-brand-gold'}`}>
                                        {rating > 0 ? `${rating}★ & up` : t('feelAfro.filters.anyRating')}
                                    </button>
                                ))}
                             </div>
                        </div>
                        
                        <div className="lg:col-span-4">
                            <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('feelAfro.filters.serviceType')}</h3>
                            <div className="flex flex-wrap gap-3">
                                {Object.values(ServiceType).map(type => (
                                    <button
                                        key={type}
                                        onClick={() => setSelectedType(prev => prev === type ? null : type)}
                                        className={`flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-full border-2 transition-colors ${
                                            selectedType === type ? 'bg-brand-green text-white border-brand-green' : 'bg-transparent text-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-600 hover:border-brand-green'
                                        }`}
                                    >
                                        {serviceTypeIcons[type]}
                                        <span>{type}</span>
                                    </button>
                                ))}
                            </div>
                        </div>
                        
                        {/* Conditional Filters */}
                        {(selectedType === ServiceType.HOTEL || selectedType === ServiceType.RESORT) && (
                             <div className="lg:col-span-4 animate-fade-in">
                                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('feelAfro.filters.amenities')}</h3>
                                <div className="flex flex-wrap gap-3">
                                    {hotelAmenities.map(amenity => (
                                        <button key={amenity} onClick={() => handleAmenityToggle(amenity)} className={`px-3 py-1.5 text-sm rounded-md border ${selectedAmenities.includes(amenity) ? 'bg-brand-green text-white border-brand-green' : 'bg-white dark:bg-gray-700 dark:border-gray-600 dark:text-white hover:border-brand-green'}`}>
                                            {amenity}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}
                        {selectedType === ServiceType.FLIGHT && (
                            <div className="lg:col-span-4 animate-fade-in">
                                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('feelAfro.filters.flightClass')}</h3>
                                <div className="flex flex-wrap gap-3">
                                    {flightClasses.map(cls => (
                                         <button key={cls} onClick={() => handleClassToggle(cls)} className={`px-3 py-1.5 text-sm rounded-md border ${selectedClasses.includes(cls) ? 'bg-brand-green text-white border-brand-green' : 'bg-white dark:bg-gray-700 dark:border-gray-600 dark:text-white hover:border-brand-green'}`}>
                                            {cls}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}

                        <div className="lg:col-span-4 flex justify-end">
                            <Button variant="outline" onClick={resetFilters}>{t('feelAfro.filters.reset')}</Button>
                        </div>
                    </div>
                </div>

                 {filteredServices.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
                        {filteredServices.map((service) => (
                            <ServiceCard
                                key={service.id}
                                service={service}
                                onBookNow={() => setBookingService(service)}
                                onAddToCart={addToCart}
                            />
                        ))}
                    </div>
                 ) : (
                    <div className="text-center py-20">
                        <h2 className="text-2xl font-display font-semibold text-brand-green-dark dark:text-white">{t('feelAfro.noServicesFound')}</h2>
                        <p className="mt-2 text-brand-gray dark:text-gray-400">{t('feelAfro.noServicesMessage')}</p>
                    </div>
                 )}
            </div>

            {bookingService && (
                <BookingModal
                    service={bookingService}
                    onClose={() => setBookingService(null)}
                />
            )}
        </>
    );
};

export default FeelAfroPage;