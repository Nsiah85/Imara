
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
    BriefcaseIcon, GlobeIcon, CarIcon, BasketIcon, SearchIcon, 
    ShoppingBagIcon, HomeIcon, SparklesIcon, FireIcon, ImaraDiskIcon 
} from '../components/icons/Icons.tsx';
import { useLanguage } from '../contexts/LanguageContext.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';
import { usePersonalizedRecommendations } from '../hooks/usePersonalizedRecommendations.ts';
import ShowcaseCard from '../components/shared/ShowcaseCard.tsx';
import SkeletonLoader from '../components/ui/SkeletonLoader.tsx';
import Avatar from '../components/ui/Avatar.tsx';
import { mockProducts } from '../data/mockData.ts';
import ProductCard from '../components/shared/ProductCard.tsx';
import { useCart } from '../contexts/CartContext.tsx';
import Button from '../components/ui/Button.tsx';

const DEFAULT_HERO = "https://picsum.photos/seed/market-vibe/1600/600";

const HubCard: React.FC<{ 
    to: string; 
    title: string; 
    subtitle: string;
    description: string;
    bgColor: string;
    icon: React.ReactNode;
    stats?: string;
}> = ({ to, title, subtitle, description, bgColor, icon, stats }) => (
    <Link to={to} className={`relative block overflow-hidden rounded-[40px] p-8 h-80 shadow-lg hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 group ${bgColor}`}>
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3 group-hover:scale-150 transition-transform duration-700"></div>
        
        <div className="relative z-10 flex flex-col h-full justify-between">
            <div className="flex justify-between items-start">
                <div className="p-4 bg-white/10 backdrop-blur-md rounded-3xl text-white">
                    {icon}
                </div>
                {stats && (
                    <div className="px-3 py-1 bg-black/20 backdrop-blur-md rounded-full text-[10px] font-bold text-white uppercase tracking-widest">
                        {stats}
                    </div>
                )}
            </div>

            <div>
                <div className="flex items-baseline gap-2 mb-2">
                    <h2 className="text-3xl font-display font-black text-white">{title}</h2>
                    <span className="text-sm font-medium text-white/70">{subtitle}</span>
                </div>
                <p className="text-sm text-white/80 leading-relaxed max-w-[200px]">{description}</p>
            </div>
        </div>
    </Link>
);

const ShopHubPage: React.FC = () => {
    const { user } = useAuth();
    const { addToCart } = useCart();
    const { recommendations, isLoading: isRecLoading } = usePersonalizedRecommendations(user);
    const [userRegion, setUserRegion] = useState('Accra');
    const [heroImage, setHeroImage] = useState(DEFAULT_HERO);
    const [afromallCount, setAfromallCount] = useState<number>(0);

    useEffect(() => {
        // Load hero image from system config
        let unsubscribeConfig: () => void;
        import('../firebase/firestore.ts').then(({ db, doc, onSnapshot }) => {
             unsubscribeConfig = onSnapshot(doc(db, 'system', 'config'), (snapshot) => {
                 if (snapshot.exists()) {
                     const data = snapshot.data();
                     if (data.shopHubHeroUrl) {
                        setHeroImage(data.shopHubHeroUrl);
                     }
                 }
             });
        });

        if (user?.region) {
            setUserRegion(user.region);
        }

        let unsubscribeProducts: () => void;
        import('../firebase/firestore.ts').then(({ db, collection, onSnapshot }) => {
            // Count using onSnapshot (this could be expensive for large collections, but fine for scale-up)
            unsubscribeProducts = onSnapshot(collection(db, 'products'), (snapshot) => {
                setAfromallCount(snapshot.size);
            });
        });

        return () => {
            if (unsubscribeConfig) unsubscribeConfig();
            if (unsubscribeProducts) unsubscribeProducts();
        }
    }, [user]);

    return (
        <div className="bg-brand-off-white dark:bg-gray-900 min-h-screen pb-32 relative">
            
            {/* Top Corner Toast Link */}
            <div className="absolute top-6 right-6 z-40">
                <Link 
                    to="/" 
                    className="p-3.5 bg-white/90 dark:bg-brand-navy-dark/80 hover:bg-brand-gold dark:hover:bg-brand-gold rounded-full shadow-2xl backdrop-blur-md transition-all hover:scale-110 group border border-brand-gold/30"
                    title="Go to Toast Feed"
                >
                    <HomeIcon className="w-7 h-7 text-brand-navy-dark dark:text-brand-gold group-hover:text-brand-navy-dark group-hover:rotate-6 transition-all" />
                </Link>
            </div>

            <div className="container mx-auto px-6 py-12">
                
                {/* Dynamic Cultural Hero Section */}
                <div className="relative rounded-[48px] overflow-hidden mb-16 shadow-2xl bg-brand-navy-dark">
                    <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/30 to-transparent z-10"></div>
                    <img 
                        src={heroImage} 
                        className="absolute inset-0 w-full h-full object-cover opacity-70 transition-opacity duration-1000" 
                        alt="Cultural Hero"
                        onError={() => setHeroImage(DEFAULT_HERO)}
                    />
                    
                    <div className="relative z-20 p-6 md:p-16 flex flex-col justify-center h-full min-h-[300px] md:min-h-[400px]">
                        <div className="inline-flex items-center gap-3 px-4 py-2 md:px-5 md:py-2.5 bg-gradient-to-r from-brand-gold to-yellow-400 text-brand-navy-dark rounded-full mb-6 md:mb-8 w-fit animate-fade-in-down transition-all transform hover:scale-105 shadow-[0_0_20px_rgba(255,215,0,0.5)] cursor-default group">
                            <div className="relative">
                                <FireIcon className="w-5 h-5 text-brand-navy-dark animate-pulse" />
                                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-red-600 rounded-full animate-ping"></span>
                            </div>
                            <span className="text-[10px] md:text-[11px] font-black uppercase tracking-[0.15em]">Live Trends in {userRegion}</span>
                            <div className="p-1 bg-brand-navy-dark/10 rounded-full group-hover:translate-x-1 transition-transform">
                                <SparklesIcon className="w-3 h-3" />
                            </div>
                        </div>
                        
                        <h1 className="text-4xl lg:text-7xl xl:text-8xl font-display font-black text-white leading-[1.1] mb-4 md:mb-6 max-w-3xl">
                            The heartbeat of <br/>
                            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-gold via-yellow-200 to-white drop-shadow-sm">African Commerce.</span>
                        </h1>
                        
                        <p className="text-xl text-white/80 max-w-xl mb-10 leading-relaxed font-medium">
                            Experience cultural depth and trusted logistics. Discover the finest products and services vetted for quality and authenticity.
                        </p>
                        
                        <div className="flex flex-wrap gap-4">
                            <Link 
                                to="/shop" 
                                className="inline-flex items-center justify-center font-display font-semibold rounded-full transition-all duration-300 bg-brand-gold text-brand-navy-dark hover:bg-brand-gold-light hover:shadow-gold-glow px-10 h-14 text-lg"
                            >
                                Shop Local Now
                            </Link>
                            <Link 
                                to="/feel-afro" 
                                className="inline-flex items-center justify-center font-display font-semibold rounded-full transition-all duration-300 border-2 border-white/50 text-white hover:bg-white/10 backdrop-blur-md px-10 h-14 text-lg"
                            >
                                Experiences
                            </Link>
                        </div>
                    </div>
                </div>

                {/* The Four Worlds */}
                <div className="flex items-center gap-4 mb-8">
                    <div className="h-px flex-grow bg-gray-200 dark:bg-gray-800"></div>
                    <h2 className="text-xs font-black text-gray-400 uppercase tracking-[0.4em] whitespace-nowrap">Marketplace Worlds</h2>
                    <div className="h-px flex-grow bg-gray-200 dark:bg-gray-800"></div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-24">
                    <HubCard 
                        to="/shop"
                        title="AfroMall"
                        subtitle="The Mall"
                        description="Premium fashion, luxury goods, and verified artisan boutiques."
                        bgColor="bg-[#1B2C4A]"
                        icon={<BriefcaseIcon className="w-8 h-8"/>}
                        stats={afromallCount > 0 ? `${afromallCount > 999 ? (afromallCount/1000).toFixed(1) + 'k' : afromallCount} Items` : "0 Items"}
                    />
                    <HubCard 
                        to="/feel-afro"
                        title="FeelAfro"
                        subtitle="Travel & Life"
                        description="Vibrant experiences, boutique stays, and authentic African dining."
                        bgColor="bg-brand-green-dark"
                        icon={<GlobeIcon className="w-8 h-8"/>}
                        stats="Hot Deals"
                    />
                    <HubCard 
                        to="/automotive"
                        title="BuyMotor"
                        subtitle="Mobility"
                        description="Verified vehicle trade, safety diagnostics, and African mobility."
                        bgColor="bg-black"
                        icon={<CarIcon className="w-8 h-8 text-brand-gold"/>}
                        stats="98% Trust"
                    />
                    <HubCard 
                        to="/edwaso"
                        title="Edwaso"
                        subtitle="Local Markets"
                        description="Farm-to-table produce and daily essentials direct from market women."
                        bgColor="bg-[#D4AF37]"
                        icon={<BasketIcon className="w-8 h-8 text-brand-navy-dark"/>}
                        stats="Fresh Daily"
                    />
                </div>

                {/* Personalized Discoveries */}
                <div className="mb-24">
                    <div className="flex items-end justify-between mb-10">
                        <div>
                            <h3 className="text-4xl font-display font-black text-brand-navy-dark dark:text-white flex items-center gap-3">
                                Curated for You <SparklesIcon className="w-8 h-8 text-brand-gold animate-spin-slow" />
                            </h3>
                            <p className="text-sm text-gray-500 mt-2 uppercase tracking-widest font-bold">Discover culture aligned with your {user?.country || 'region'}</p>
                        </div>
                        <Link to="/discover" className="text-brand-green font-black hover:text-brand-navy-dark transition-colors uppercase text-xs tracking-widest mb-1 flex items-center gap-2">
                            See All Suggestions <span>&rarr;</span>
                        </Link>
                    </div>

                    {isRecLoading ? (
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                            {[1,2,3,4].map(i => <SkeletonLoader key={i} className="h-80 rounded-[40px]" />)}
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                            {recommendations.slice(0, 4).map((item, i) => (
                                <ShowcaseCard key={item.id} item={item} />
                            ))}
                        </div>
                    )}
                </div>

                {/* Seen in Toast Section */}
                <div className="bg-white dark:bg-gray-800/40 p-10 rounded-[60px] border border-gray-100 dark:border-gray-800">
                    <div className="flex items-center justify-between mb-10">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-brand-gold/20 rounded-2xl">
                                <SparklesIcon className="w-8 h-8 text-brand-gold"/>
                            </div>
                            <div>
                                <h3 className="text-3xl font-display font-black text-brand-navy-dark dark:text-white">Voted by Creators</h3>
                                <p className="text-sm text-gray-500 font-bold uppercase tracking-wider">Top items trending in the Toast Feed</p>
                            </div>
                        </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                        {mockProducts.filter(p => p.seenInToast).slice(0, 3).map((product, i) => (
                            <ProductCard 
                                key={product.id} 
                                product={product} 
                                onAddToCart={addToCart} 
                                onQuickView={() => {}} 
                                animationDelay={i * 100}
                            />
                        ))}
                    </div>
                </div>

            </div>
        </div>
    );
};

export default ShopHubPage;
