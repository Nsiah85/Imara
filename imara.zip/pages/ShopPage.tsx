
import React, { useState, useEffect, useMemo } from 'react';
import ProductCard from '../components/shared/ProductCard.tsx';
import ProductListCard from '../components/shared/ProductListCard.tsx';
import { mockProducts } from '../data/mockData.ts';
import { SustainabilityTag, type Product, ProductCategory } from '../types.ts';
import QuickViewModal from '../components/modals/QuickViewModal.tsx';
import PaginationControls from '../components/shared/PaginationControls.tsx';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver.ts';
import { useCart } from '../contexts/CartContext.tsx';
import ViewSwitcher, { type ViewMode } from '../components/ui/ViewSwitcher.tsx';
import { useLanguage } from '../contexts/LanguageContext.tsx';
import BackButton from '../components/ui/BackButton.tsx';
import SkeletonProductCard from '../components/ui/SkeletonProductCard.tsx';
import SkeletonProductListCard from '../components/ui/SkeletonProductListCard.tsx';
import DrivingTestModal from '../components/modals/DrivingTestModal.tsx';
import LoadingSpinner from '../components/ui/LoadingSpinner.tsx';
import SEO from '../components/seo/SEO.tsx';

const PRODUCTS_PER_PAGE = 12;

const afroMallCategories = [
    ProductCategory.FASHION,
    ProductCategory.BEAUTY,
    ProductCategory.HOME_DECOR,
    ProductCategory.ELECTRONICS,
    ProductCategory.BOOKS,
    ProductCategory.HOME_APPLIANCES,
];

// FIX: The 'allSustainabilityTags' constant is correctly defined with explicit enum members.
// This prevents potential type mismatch errors when mapping over the tags,
// which can occur when using Object.values() with string enums without proper casting.
const allSustainabilityTags: SustainabilityTag[] = [SustainabilityTag.HANDMADE, SustainabilityTag.FAIR_TRADE, SustainabilityTag.RECYCLED, SustainabilityTag.ORGANIC];

const ShopPage: React.FC = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedTags, setSelectedTags] = useState<SustainabilityTag[]>([]);
    const [selectedCountry, setSelectedCountry] = useState<string | null>(null);
    const [suggestions, setSuggestions] = useState<string[]>([]);
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [viewMode, setViewMode] = useState<ViewMode>('grid');
    const [sortBy, setSortBy] = useState('relevance');
    const { addToCart } = useCart();
    const { t } = useLanguage();
    const [isDrivingTestModalOpen, setIsDrivingTestModalOpen] = useState(false);
    
    const [paginatedProducts, setPaginatedProducts] = useState<Product[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [totalPages, setTotalPages] = useState(0);

    const [filtersRef, areFiltersVisible] = useIntersectionObserver<HTMLDivElement>({ threshold: 0.2 });
    const [gridRef, isGridVisible] = useIntersectionObserver<HTMLDivElement>({ threshold: 0.1 });
    
    const afroMallProducts = useMemo(() => mockProducts.filter(p => afroMallCategories.includes(p.category)), []);


    useEffect(() => {
        if (searchTerm.length < 2) {
            setSuggestions([]);
            setShowSuggestions(false);
            return;
        }

        const lowerCaseSearchTerm = searchTerm.toLowerCase();
        const suggestionSet = new Set<string>();

        afroMallProducts.forEach(product => {
            if (product.name.toLowerCase().includes(lowerCaseSearchTerm)) {
                suggestionSet.add(product.name);
            }
            if (product.vendor.toLowerCase().includes(lowerCaseSearchTerm)) {
                suggestionSet.add(product.vendor);
            }
        });

        const newSuggestions = Array.from(suggestionSet).slice(0, 10);
        setSuggestions(newSuggestions);
        setShowSuggestions(newSuggestions.length > 0);

    }, [searchTerm, afroMallProducts]);

    useEffect(() => {
        setCurrentPage(1);
    }, [searchTerm, selectedTags, selectedCountry, sortBy]);
    
    useEffect(() => {
        setIsLoading(true);
        const timer = setTimeout(() => {
            const filtered = afroMallProducts.filter(product => {
                const lowerCaseSearchTerm = searchTerm.toLowerCase();
                const matchesSearch = product.name.toLowerCase().includes(lowerCaseSearchTerm) || 
                                      product.vendor.toLowerCase().includes(lowerCaseSearchTerm) ||
                                      product.description.toLowerCase().includes(lowerCaseSearchTerm);
                const matchesTags = selectedTags.length === 0 || selectedTags.every(tag => product.sustainabilityTags.includes(tag));
                const matchesCountry = !selectedCountry || product.originCountry === selectedCountry;
                return matchesSearch && matchesTags && matchesCountry;
            });

            const sorted = [...filtered];
            switch (sortBy) {
                case 'price_asc':
                    sorted.sort((a, b) => a.price - b.price);
                    break;
                case 'price_desc':
                    sorted.sort((a, b) => b.price - a.price);
                    break;
                case 'name_asc':
                    sorted.sort((a, b) => a.name.localeCompare(b.name));
                    break;
                default: // relevance
                    break;
            }
            
            setTotalPages(Math.ceil(sorted.length / PRODUCTS_PER_PAGE));
            setPaginatedProducts(sorted.slice(
                (currentPage - 1) * PRODUCTS_PER_PAGE,
                currentPage * PRODUCTS_PER_PAGE
            ));
            setIsLoading(false);
        }, 500);

        return () => clearTimeout(timer);
    }, [searchTerm, selectedTags, selectedCountry, sortBy, currentPage, afroMallProducts]);

    const handleTagToggle = (tag: SustainabilityTag) => {
        setSelectedTags(prev => 
            prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]
        );
    };
    
    const handleCountrySelect = (country: string) => {
        setSelectedCountry(prev => (prev === country ? null : country));
    };

    const handleSuggestionClick = (suggestion: string) => {
        setSearchTerm(suggestion);
        setShowSuggestions(false);
    };
    
    const handleOpenQuickView = (product: Product) => {
        setQuickViewProduct(product);
    };

    const handleCloseQuickView = () => {
        setQuickViewProduct(null);
    };

    const handleBookNow = (product: Product) => {
        setIsDrivingTestModalOpen(true);
    };

    const allCountries = [...new Set(afroMallProducts.map(p => p.originCountry))].sort();
    
    const handlePageChange = (page: number) => {
        setCurrentPage(page);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    return (
        <div className="container mx-auto px-6 py-8">
            <SEO 
                title="Imara ShopHub - AfroMall" 
                description="Browse authentic, handcrafted goods from verified artisans across Africa. Find fashion, beauty, electronics, and more on Imara's AfroMall."
            />
            
            <BackButton className="mb-4" />
            <div className="text-center mb-12">
                <h1 className="text-4xl font-display font-bold text-brand-navy-dark dark:text-white">{t('shop.title')}</h1>
                <p className="mt-2 text-brand-gray dark:text-gray-400 max-w-xl mx-auto">{t('shop.subtitle')}</p>
            </div>

            <div
                ref={filtersRef}
                className={`mb-8 p-6 bg-white dark:bg-gray-800 rounded-lg shadow-sm transition-all duration-700 ease-out ${
                    areFiltersVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
            >
                <div className="flex flex-col gap-6">
                    <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                        <div className="relative w-full md:flex-grow">
                            <input
                                type="text"
                                placeholder={t('shop.searchPlaceholder')}
                                className="w-full p-3 border border-brand-navy rounded-md focus:ring-brand-gold focus:border-brand-gold bg-brand-navy-dark text-brand-gold-light placeholder:text-gray-400"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                onFocus={() => { if (suggestions.length > 0) setShowSuggestions(true); }}
                                onBlur={() => { setTimeout(() => setShowSuggestions(false), 200); }}
                                autoComplete="off"
                            />
                             {showSuggestions && suggestions.length > 0 && (
                                <ul 
                                    className="absolute z-20 w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-md mt-1 shadow-lg max-h-60 overflow-y-auto"
                                    role="listbox"
                                    aria-label="Search suggestions"
                                >
                                    {suggestions.map((suggestion: string, index: number) => (
                                        <li key={`${suggestion}-${index}`} className="px-4 py-2 hover:bg-brand-off-white dark:hover:bg-gray-700 cursor-pointer text-gray-800 dark:text-gray-200" onMouseDown={() => handleSuggestionClick(suggestion)} role="option">
                                            {suggestion}
                                        </li>
                                    ))}
                                </ul>
                            )}
                        </div>
                        <div className="flex items-center gap-4 w-full md:w-auto">
                           <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="w-full md:w-auto p-3 border border-gray-300 dark:border-gray-600 rounded-md focus:ring-brand-gold focus:border-brand-gold bg-white dark:bg-gray-700 dark:text-white" aria-label="Sort products by">
                                <option value="relevance">{t('shop.sortBy')}: {t('shop.sort.relevance')}</option>
                                <option value="price_asc">{t('shop.sort.priceAsc')}</option>
                                <option value="price_desc">{t('shop.sort.priceDesc')}</option>
                                <option value="name_asc">{t('shop.sort.nameAsc')}</option>
                           </select>
                           <ViewSwitcher viewMode={viewMode} setViewMode={setViewMode} />
                        </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4 pt-4 border-t dark:border-gray-700">
                        <div>
                            <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3">{t('shop.filters.sustainability')}</h3>
                            <div className="flex flex-wrap gap-2">
                                {allSustainabilityTags.map((tag) => (
                                    <button key={tag} onClick={() => handleTagToggle(tag)} className={`px-3 py-1 text-sm rounded-full border-2 transition-colors ${selectedTags.includes(tag) ? 'bg-brand-green text-white border-brand-green' : 'bg-transparent text-gray-600 dark:text-gray-300 border-gray-300 dark:border-gray-600 hover:border-brand-green'}`}>
                                        {tag}
                                    </button>
                                ))}
                            </div>
                        </div>
                         <div>
                            <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3">{t('shop.filters.origin')}</h3>
                             <div className="flex flex-wrap gap-2">
                                {allCountries.map((country: string) => (
                                     <button key={country} onClick={() => handleCountrySelect(country)} className={`px-3 py-1 text-sm rounded-full border-2 transition-colors ${selectedCountry === country ? 'bg-brand-green text-white border-brand-green' : 'bg-transparent text-gray-600 dark:text-gray-300 border-gray-300 dark:border-gray-600 hover:border-brand-green'}`}>
                                        {country}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div
                ref={gridRef}
                className={`transition-all duration-700 ease-out ${
                    (isGridVisible as boolean) ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
            >
                {isLoading ? (
                    viewMode === 'list' ? (
                        <div className="space-y-4">
                            {Array.from({ length: 6 }).map((_, index) => <SkeletonProductListCard key={index} />)}
                        </div>
                    ) : (
                        <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8' : 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4'}`}>
                            {Array.from({ length: PRODUCTS_PER_PAGE }).map((_, index) => (
                                <SkeletonProductCard key={index} compact={viewMode === 'tile'} />
                            ))}
                        </div>
                    )
                ) : paginatedProducts.length > 0 ? (
                    <>
                        {viewMode === 'list' ? (
                            <div className="space-y-4">
                                {paginatedProducts.map((product) => (
                                    <ProductListCard key={product.id} product={product} onAddToCart={addToCart} onQuickView={handleOpenQuickView} />
                                ))}
                            </div>
                        ) : (
                            <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8' : 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4'}`}>
                                {paginatedProducts.map((product, index) => (
                                    <ProductCard 
                                        key={product.id} 
                                        product={product} 
                                        animationDelay={index * 75}
                                        onQuickView={handleOpenQuickView}
                                        onAddToCart={addToCart}
                                        onBookNow={handleBookNow}
                                        compact={viewMode === 'tile'}
                                    />
                                ))}
                            </div>
                        )}

                        {totalPages > 1 && (
                            <PaginationControls 
                                currentPage={currentPage}
                                totalPages={totalPages}
                                onPageChange={handlePageChange}
                            />
                        )}
                    </>
                ) : (
                    <div className="text-center py-20">
                        <h2 className="text-2xl font-display font-semibold text-brand-green-dark dark:text-white">{t('shop.noProductsFound')}</h2>
                        <p className="mt-2 text-brand-gray dark:text-gray-400">{t('shop.noProductsMessage')}</p>
                    </div>
                )}
            </div>

            {quickViewProduct && (
                <QuickViewModal product={quickViewProduct} onClose={handleCloseQuickView} />
            )}
            {isDrivingTestModalOpen && <DrivingTestModal onClose={() => setIsDrivingTestModalOpen(false)} />}
        </div>
    );
};

export default ShopPage;
