import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { mockTravelServices, mockTravelPartners } from '../data/mockData';
import { useCurrency } from '../contexts/CurrencyContext';
import Button from '../components/ui/Button';
import Badge from '../components/ui/Badge';
import { StarIcon, GlobeIcon, CalendarDaysIcon, ShieldCheckIcon, EnvelopeIcon } from '../components/icons/Icons';
import ServiceCard from '../components/shared/ServiceCard';
import BookingModal from '../components/modals/BookingModal';
import type { TravelService } from '../types';
import { useCart } from '../contexts/CartContext';
import { useLanguage } from '../contexts/LanguageContext';
import BackButton from '../components/ui/BackButton';


const ServiceDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const service = mockTravelServices.find(s => s.id === id);
  const provider = mockTravelPartners.find(p => p.brandName === service?.providerName);
  const { formatCurrency } = useCurrency();
  const [bookingService, setBookingService] = useState<TravelService | null>(null);
  const { addToCart } = useCart();
  const { t } = useLanguage();

  if (!service) {
    return (
      <div className="container mx-auto px-6 py-8 text-center">
        <h1 className="text-3xl font-display">{t('service.notFound')}</h1>
        <p className="mt-2 text-gray-600">The service you are looking for does not exist.</p>
        <Link to="/feel-afro">
            <Button className="mt-6">{t('general.back')} to FeelAfro</Button>
        </Link>
      </div>
    );
  }

  const relatedServices = mockTravelServices.filter(s => 
    s.id !== service.id && s.type === service.type
  ).slice(0, 4);

  return (
    <>
      <div className="container mx-auto px-6 py-12">
        <BackButton className="mb-6" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Image Column */}
          <div>
            <img src={service.imageUrl} alt={service.title} className="w-full rounded-lg shadow-lg object-cover aspect-video" />
          </div>
          
          {/* Details Column */}
          <div>
            <p className="text-sm uppercase tracking-widest text-brand-gray">
              {service.type} {t('general.by')}{' '}
              {provider ? (
                <Link to={`/travel/${provider.storeSlug}`} className="hover:text-brand-gold transition-colors">{service.providerName}</Link>
              ) : (
                service.providerName
              )}
            </p>
            <h1 className="text-4xl font-display font-bold text-brand-green-dark mt-2">{service.title}</h1>
            
            <div className="flex items-center gap-4 mt-4">
                <Badge className="bg-brand-gold text-brand-green-dark flex items-center gap-1.5 text-base py-1.5 px-3">
                    <StarIcon className="w-5 h-5" />
                    <span className="font-bold">{service.rating.toFixed(1)}</span>
                </Badge>
                <div className="flex items-center gap-2 text-gray-600">
                    <GlobeIcon className="w-5 h-5" />
                    <span>{service.location}</span>
                </div>
            </div>

            <p className="text-3xl font-display font-semibold text-brand-green mt-6">
                {formatCurrency(service.price)}
                <span className="text-lg font-normal text-gray-500"> / {service.priceUnit}</span>
            </p>
            
            <div className="mt-6 border-t pt-6">
              <p className="text-gray-700 leading-relaxed">{service.description}</p>
            </div>
            
            <div className="mt-8 space-y-4">
                 <Button size="lg" className="w-full flex items-center justify-center gap-2" onClick={() => setBookingService(service)}>
                    <CalendarDaysIcon className="w-6 h-6" />
                    {t('service.bookNow')}
                 </Button>
                 <Link 
                    to={`/messages/new?recipientId=${provider?.id}&recipientName=${encodeURIComponent(service.providerName)}&recipientRole=Travel Partner&recipientAvatar=${encodeURIComponent(provider?.brandLogoUrl || service.imageUrl)}`} 
                    className="block text-center text-sm text-brand-green hover:text-brand-gold font-semibold flex items-center justify-center gap-2"
                 >
                    <EnvelopeIcon className="w-4 h-4" />
                    <span>{t('service.messageProvider')}</span>
                </Link>
            </div>

            <div className="mt-8 space-y-4 text-sm text-gray-600">
              <div className="flex items-center gap-3">
                  <ShieldCheckIcon className="w-5 h-5 text-brand-green" />
                  <span>Secure Booking & Verified Partners</span>
              </div>
            </div>
          </div>
        </div>

        {/* Related Services Section */}
        {relatedServices.length > 0 && (
            <div className="mt-20 pt-12 border-t border-gray-200">
              <h2 className="text-2xl md:text-3xl font-display font-bold text-brand-green-dark mb-8 text-center">{t('service.similarExperiences')}</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                  {relatedServices.map((relatedService) => (
                      <ServiceCard 
                        key={relatedService.id} 
                        service={relatedService} 
                        onBookNow={setBookingService}
                        onAddToCart={addToCart}
                      />
                  ))}
              </div>
            </div>
        )}
      </div>
      {bookingService && (
        <BookingModal 
            service={bookingService} 
            onClose={() => setBookingService(null)} 
        />
      )}
    </>
  );
};

export default ServiceDetailPage;