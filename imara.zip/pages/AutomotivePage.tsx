
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import ProductCard from '../components/shared/ProductCard.tsx';
import ProductListCard from '../components/shared/ProductListCard.tsx';
import { mockProducts } from '../data/mockData.ts';
import { type Product } from '../types.ts';
import QuickViewModal from '../components/modals/QuickViewModal.tsx';
import PaginationControls from '../components/shared/PaginationControls.tsx';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver.ts';
import { useCart } from '../contexts/CartContext.tsx';
import ViewSwitcher, { type ViewMode } from '../components/ui/ViewSwitcher.tsx';
import { useLanguage } from '../contexts/LanguageContext.tsx';
import BackButton from '../components/ui/BackButton.tsx';
import SkeletonProductCard from '../components/ui/SkeletonProductCard.tsx';
import SkeletonProductListCard from '../components/ui/SkeletonProductListCard.tsx';
import DrivingTestModal from '../components/modals/DrivingTestModal.tsx';
import Button from '../components/ui/Button.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';

const PRODUCTS_PER_PAGE = 12;

const AutomotivePage: React.FC = () => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const [searchTerm, setSearchTerm] = useState('');
    const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [viewMode, setViewMode] = useState<ViewMode>('grid');
    const [sortBy, setSortBy] = useState('relevance');
    const { addToCart } = useCart();
    const { t } = useLanguage();
    const [isDrivingTestModalOpen, setIsDrivingTestModalOpen] = useState(false);
    
    const [paginatedProducts, setPaginatedProducts] = useState<Product[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [totalPages, setTotalPages] = useState(0);

    const [filtersRef, areFiltersVisible] = useIntersectionObserver<HTMLDivElement>({ threshold: 0.2 });
    const [gridRef, isGridVisible] = useIntersectionObserver<HTMLDivElement>({ threshold: 0.1 });

    const automotiveProducts = useMemo(() => mockProducts.filter(p => p.category === 'Automotive'), []);

    useEffect(() => {
        setCurrentPage(1);
    }, [searchTerm, sortBy]);
    
    useEffect(() => {
        setIsLoading(true);
        const timer = setTimeout(() => {
            const filtered = automotiveProducts.filter(product => {
                const lowerCaseSearchTerm = searchTerm.toLowerCase();
                return product.name.toLowerCase().includes(lowerCaseSearchTerm) || 
                       product.vendor.toLowerCase().includes(lowerCaseSearchTerm) ||
                       product.description.toLowerCase().includes(lowerCaseSearchTerm);
            });

            const sorted = [...filtered];
            switch (sortBy) {
                case 'price_asc':
                    sorted.sort((a, b) => a.price - b.price);
                    break;
                case 'price_desc':
                    sorted.sort((a, b) => b.price - a.price);
                    break;
                case 'name_asc':
                    sorted.sort((a, b) => a.name.localeCompare(b.name));
                    break;
                default: // relevance
                    break;
            }
            
            setTotalPages(Math.ceil(sorted.length / PRODUCTS_PER_PAGE));
            setPaginatedProducts(sorted.slice(
                (currentPage - 1) * PRODUCTS_PER_PAGE,
                currentPage * PRODUCTS_PER_PAGE
            ));
            setIsLoading(false);
        }, 500);

        return () => clearTimeout(timer);
    }, [searchTerm, sortBy, currentPage, automotiveProducts]);
    
    const handleBookTestClick = () => {
        if (user) {
            setIsDrivingTestModalOpen(true);
        } else {
            navigate('/login', { state: { from: '/automotive' } });
        }
    };

    const handleOpenQuickView = (product: Product) => {
        setQuickViewProduct(product);
    };

    const handleCloseQuickView = () => {
        setQuickViewProduct(null);
    };
    
    const handlePageChange = (page: number) => {
        setCurrentPage(page);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    return (
        <div className="container mx-auto px-6 py-8">
            <BackButton className="mb-4" />
            <div className="text-center mb-12">
                <h1 className="text-5xl font-display font-extrabold text-black dark:text-white tracking-tight">BuyMotor</h1>
                <p className="mt-2 text-brand-gray max-w-xl mx-auto">Discover premium and locally manufactured vehicles from trusted dealerships.</p>
            </div>

            <div className="my-12 p-8 bg-black dark:bg-gray-800 text-white rounded-2xl shadow-xl flex flex-col md:flex-row items-center justify-between gap-6 border border-gray-800">
                <div>
                    <h2 className="text-3xl font-display font-bold text-brand-gold">{t('automotive.bookTest.title')}</h2>
                    <p className="mt-2 text-gray-300 max-w-2xl">{t('automotive.bookTest.subtitle')}</p>
                </div>
                <Button variant="primary" size="lg" className="flex-shrink-0" onClick={handleBookTestClick}>
                    {t('automotive.bookTest.button')}
                </Button>
            </div>

            <div
                ref={filtersRef}
                className={`mb-8 p-6 bg-white dark:bg-gray-800 rounded-lg shadow-sm transition-all duration-700 ease-out ${
                    areFiltersVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
            >
                <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                    <div className="relative w-full md:flex-grow">
                        <input
                            type="text"
                            placeholder="Search by make, model, or year..."
                            className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-md focus:ring-brand-gold focus:border-brand-gold bg-white dark:bg-gray-700 text-black dark:text-white placeholder:text-gray-400"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            autoComplete="off"
                        />
                    </div>
                    <div className="flex items-center gap-4 w-full md:w-auto">
                       <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="w-full md:w-auto p-3 border border-gray-300 dark:border-gray-600 rounded-md focus:ring-brand-gold focus:border-brand-gold bg-white dark:bg-gray-700 text-black dark:text-white" aria-label="Sort vehicles by">
                            <option value="relevance">Sort by: Relevance</option>
                            <option value="price_asc">Price: Low to High</option>
                            <option value="price_desc">Price: High to Low</option>
                            <option value="name_asc">Name: A to Z</option>
                       </select>
                       <ViewSwitcher viewMode={viewMode} setViewMode={setViewMode} />
                    </div>
                </div>
            </div>

            <div
                ref={gridRef}
                className={`transition-all duration-700 ease-out ${
                    isGridVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
            >
                {isLoading ? (
                    viewMode === 'list' ? (
                        <div className="space-y-4">
                            {Array.from({ length: 2 }).map((_, index) => <SkeletonProductListCard key={index} />)}
                        </div>
                    ) : (
                        <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8' : 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4'}`}>
                            {Array.from({ length: 4 }).map((_, index) => (
                                <SkeletonProductCard key={index} compact={viewMode === 'tile'} />
                            ))}
                        </div>
                    )
                ) : paginatedProducts.length > 0 ? (
                    <>
                        {viewMode === 'list' ? (
                            <div className="space-y-4">
                                {paginatedProducts.map((product) => (
                                    <ProductListCard key={product.id} product={product} onAddToCart={addToCart} onQuickView={handleOpenQuickView} />
                                ))}
                            </div>
                        ) : (
                            <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8' : 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4'}`}>
                                {paginatedProducts.map((product, index) => (
                                    <ProductCard 
                                        key={product.id} 
                                        product={product} 
                                        animationDelay={index * 75}
                                        onQuickView={handleOpenQuickView}
                                        onAddToCart={addToCart}
                                        compact={viewMode === 'tile'}
                                    />
                                ))}
                            </div>
                        )}

                        {totalPages > 1 && (
                            <PaginationControls 
                                currentPage={currentPage}
                                totalPages={totalPages}
                                onPageChange={handlePageChange}
                            />
                        )}
                    </>
                ) : (
                    <div className="text-center py-20">
                        <h2 className="text-2xl font-display font-semibold text-brand-green-dark">No Vehicles Found</h2>
                        <p className="mt-2 text-brand-gray">Try adjusting your search criteria.</p>
                    </div>
                )}
            </div>

            {quickViewProduct && (
                <QuickViewModal product={quickViewProduct} onClose={handleCloseQuickView} />
            )}
            {isDrivingTestModalOpen && <DrivingTestModal onClose={() => setIsDrivingTestModalOpen(false)} />}
        </div>
    );
};

export default AutomotivePage;
