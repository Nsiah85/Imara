// This file is deprecated. Please use components/shared/PaginationControls.tsx instead.
