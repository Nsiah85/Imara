
import React from 'react';
import BackButton from '../components/ui/BackButton';
import { BanknotesIcon, CheckCircleIcon, ShieldCheckIcon, ChartBarIcon } from '../components/icons/Icons';

const TransparencyPage: React.FC = () => {
  return (
    <div className="bg-brand-off-white dark:bg-gray-900 min-h-screen">
        <div className="container mx-auto px-6 py-12">
            <BackButton className="mb-6" />
            
            <div className="text-center max-w-3xl mx-auto mb-16">
                <h1 className="text-4xl font-display font-bold text-brand-navy-dark dark:text-white mb-4">Transparency Report</h1>
                <p className="text-lg text-gray-600 dark:text-gray-300">
                    Trust is the currency of impact. We believe in complete openness about how your contributions are managed and delivered.
                </p>
            </div>

            {/* 100% Promise Section */}
            <div className="bg-brand-green dark:bg-green-900 rounded-2xl p-8 md:p-12 text-white shadow-xl mb-12">
                <div className="flex flex-col md:flex-row items-center gap-8">
                    <div className="flex-shrink-0 bg-white/20 p-6 rounded-full backdrop-blur-sm">
                        <ShieldCheckIcon className="w-20 h-20 text-brand-gold" />
                    </div>
                    <div>
                        <h2 className="text-3xl font-bold mb-4">The 100% Promise</h2>
                        <p className="text-lg opacity-90 leading-relaxed">
                            We ensure that 100% of your donation reaches the beneficiary after standard third-party processing fees. Imara does not take a cut from charitable donations. Our operations are funded separately through our marketplace commissions and partner subscriptions.
                        </p>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
                {/* Fee Breakdown */}
                <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
                    <div className="flex items-center gap-3 mb-6">
                        <BanknotesIcon className="w-8 h-8 text-brand-navy-dark dark:text-white" />
                        <h3 className="text-2xl font-bold text-brand-navy-dark dark:text-white">Where the Money Goes</h3>
                    </div>
                    <div className="space-y-6">
                        <div className="relative pt-6">
                            <div className="flex justify-between mb-2 font-semibold text-gray-700 dark:text-gray-300">
                                <span>Beneficiary Receives</span>
                                <span>~96.5%</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-4 overflow-hidden">
                                <div className="bg-brand-green h-full w-[96.5%]"></div>
                            </div>
                        </div>
                        <div className="relative">
                            <div className="flex justify-between mb-2 text-sm font-medium text-gray-600 dark:text-gray-400">
                                <span>Payment Processing (Stripe/Momo)</span>
                                <span>~2.9% + $0.30</span>
                            </div>
                             <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                                <div className="bg-gray-400 h-full w-[3.5%]"></div>
                            </div>
                        </div>
                         <div className="relative">
                            <div className="flex justify-between mb-2 text-sm font-medium text-gray-600 dark:text-gray-400">
                                <span>Imara Platform Fee</span>
                                <span>0%</span>
                            </div>
                             <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                                <div className="bg-brand-gold h-full w-0"></div>
                            </div>
                        </div>
                        <p className="text-xs text-gray-500 mt-4 italic">
                            *Processing fees vary slightly by payment provider (e.g., Mobile Money vs Credit Card) and country.
                        </p>
                    </div>
                </div>

                {/* Verification Process */}
                <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
                    <div className="flex items-center gap-3 mb-6">
                        <CheckCircleIcon className="w-8 h-8 text-brand-navy-dark dark:text-white" />
                        <h3 className="text-2xl font-bold text-brand-navy-dark dark:text-white">Verification Process</h3>
                    </div>
                    <p className="text-gray-600 dark:text-gray-300 mb-6">
                        Every cause and vendor on Imara undergoes a rigorous 3-step vetting process before they can receive funds.
                    </p>
                    <ul className="space-y-4">
                        <li className="flex gap-4">
                            <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center font-bold text-sm flex-shrink-0">1</div>
                            <div>
                                <h4 className="font-bold text-gray-800 dark:text-white">Identity Check</h4>
                                <p className="text-sm text-gray-500">Government-issued ID and business registration verification.</p>
                            </div>
                        </li>
                         <li className="flex gap-4">
                            <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center font-bold text-sm flex-shrink-0">2</div>
                            <div>
                                <h4 className="font-bold text-gray-800 dark:text-white">Community Validation</h4>
                                <p className="text-sm text-gray-500">Reference checks with local community leaders and past partners.</p>
                            </div>
                        </li>
                         <li className="flex gap-4">
                            <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center font-bold text-sm flex-shrink-0">3</div>
                            <div>
                                <h4 className="font-bold text-gray-800 dark:text-white">Impact Audit</h4>
                                <p className="text-sm text-gray-500">Quarterly reviews of fund usage and project progress reports.</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

            {/* Impact Metrics */}
            <div className="bg-brand-navy-dark text-white rounded-2xl p-8 shadow-lg">
                <div className="flex items-center justify-center gap-3 mb-8">
                    <ChartBarIcon className="w-6 h-6 text-brand-gold" />
                    <h3 className="text-2xl font-bold text-center">Real-Time Tracking</h3>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                    <div>
                        <p className="text-4xl font-display font-bold text-brand-gold">100%</p>
                        <p className="text-sm text-gray-400 mt-1">Verified Beneficiaries</p>
                    </div>
                     <div>
                        <p className="text-4xl font-display font-bold text-brand-gold">0%</p>
                        <p className="text-sm text-gray-400 mt-1">Platform Fees</p>
                    </div>
                     <div>
                        <p className="text-4xl font-display font-bold text-brand-gold">24h</p>
                        <p className="text-sm text-gray-400 mt-1">Avg. Fund Transfer Time</p>
                    </div>
                     <div>
                        <p className="text-4xl font-display font-bold text-brand-gold">500+</p>
                        <p className="text-sm text-gray-400 mt-1">Projects Funded</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

export default TransparencyPage;
