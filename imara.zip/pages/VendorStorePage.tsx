import React, { useState, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { mockVendors, mockProducts, mockReviews } from '../data/mockData.ts';
import type { Product, Review, Participant } from '../types.ts';
import ProductCard from '../components/shared/ProductCard.tsx';
import Button from '../components/ui/Button.tsx';
import { GlobeIcon, EnvelopeIcon, VerifiedBadgeIcon, EllipsisHorizontalIcon, ExclamationTriangleIcon } from '../components/icons/Icons.tsx';
import { useCart } from '../contexts/CartContext.tsx';
import QuickViewModal from '../components/modals/QuickViewModal.tsx';
import BackButton from '../components/ui/BackButton.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';
import ReviewSummary from '../components/reviews/ReviewSummary.tsx';
import ReviewCard from '../components/reviews/ReviewCard.tsx';
import ContactActionModal from '../components/modals/ContactActionModal.tsx';
import Avatar from '../components/ui/Avatar.tsx';

const VendorStorePage: React.FC = () => {
    const { slug } = useParams<{ slug: string }>();
    const { addToCart } = useCart();
    const { user, followUser, unfollowUser, isFollowing } = useAuth();
    const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
    const [activeTab, setActiveTab] = useState('products');
    const [isContactModalOpen, setIsContactModalOpen] = useState(false);

    const vendor = mockVendors.find(v => v.storeSlug === slug);
    const vendorProducts = mockProducts.filter(p => p.vendor === vendor?.brandName);
    
    const vendorReviews = useMemo(() => {
        if (!vendor) return [];
        try {
            const storedReviews = localStorage.getItem('imara_reviews');
            const allReviews = storedReviews ? JSON.parse(storedReviews) as Review[] : mockReviews;
            return allReviews.filter((r: Review) => r.vendorId === vendor?.id);
        } catch(e) { return mockReviews.filter(r => r.vendorId === vendor?.id); }
    }, [vendor]);

    if (!vendor) return <div className="p-20 text-center">Vendor Not Found</div>;

    const isOwnProfile = user?.id === vendor.id;
    const following = user ? isFollowing(vendor.id) : false;
    const participantForModal: Participant = { id: vendor.id, name: vendor.brandName, avatarUrl: vendor.brandLogoUrl || '', role: 'Vendor', profileLink: `/vendor/${vendor.storeSlug}` };

    return (
        <div className="bg-gray-50 dark:bg-gray-900 min-h-screen pb-20">
             <BackButton className="absolute top-4 left-4 z-20 text-white mix-blend-difference" />
             
             {/* Modern Header */}
             <div className="w-full max-w-5xl mx-auto bg-white dark:bg-brand-navy-dark shadow-2xl rounded-b-[40px] overflow-hidden">
                {/* Banner */}
                <div className="h-48 md:h-64 w-full bg-gradient-to-r from-brand-green to-brand-navy relative overflow-hidden">
                    <img src={vendor.coverImageUrl || `https://picsum.photos/seed/${vendor.storeSlug}-banner/1600/400`} alt="Cover" className="w-full h-full object-cover opacity-80" />
                    <div className="absolute inset-0 bg-black/20"></div>
                </div>

                <div className="px-6 pb-8 relative">
                    <div className="flex flex-col md:flex-row items-start gap-6 -mt-12">
                        <div className="relative z-10">
                             <Avatar 
                                imageUrl={vendor.brandLogoUrl} 
                                name={vendor.brandName} 
                                className="w-32 h-32 md:w-40 md:h-40 rounded-full border-4 border-white dark:border-brand-navy-dark shadow-lg bg-white"
                            />
                             {vendor.isVerified && (
                                <div className="absolute bottom-2 right-2 bg-white dark:bg-brand-navy-dark rounded-full p-1.5 shadow-sm">
                                    <VerifiedBadgeIcon className="w-6 h-6 text-brand-gold" />
                                </div>
                            )}
                        </div>

                        <div className="flex-grow pt-14 md:pt-16 flex flex-col md:flex-row justify-between items-start w-full gap-4">
                             <div>
                                <h1 className="text-3xl font-display font-bold text-brand-navy-dark dark:text-white">{vendor.brandName}</h1>
                                <div className="flex items-center gap-2 mt-1 text-sm text-gray-500 dark:text-gray-400">
                                    <GlobeIcon className="w-4 h-4"/> {vendor.country}
                                </div>
                            </div>
                            <div className="flex gap-3 w-full md:w-auto">
                                <Link to={`/messages/new?recipientId=${vendor.id}&recipientName=${encodeURIComponent(vendor.brandName)}&recipientRole=Vendor`}>
                                    <Button variant="secondary" className="rounded-full px-6 flex items-center gap-2"><EnvelopeIcon className="w-4 h-4"/> Message</Button>
                                </Link>
                                {!isOwnProfile && (
                                    <Button onClick={() => { if(user) following ? unfollowUser(vendor.id) : followUser(vendor.id) }} variant={following ? 'outline' : 'primary'} className="rounded-full px-6">
                                        {following ? 'Following' : 'Follow'}
                                    </Button>
                                )}
                                <button onClick={() => setIsContactModalOpen(true)} className="p-2.5 rounded-full bg-gray-100 dark:bg-gray-800 hover:bg-gray-200"><EllipsisHorizontalIcon className="w-6 h-6 dark:text-white"/></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Content */}
            <div className="w-full max-w-5xl mx-auto mt-8 px-4">
                 <div className="flex gap-6 border-b border-gray-200 dark:border-gray-700 mb-6 overflow-x-auto scrollbar-hide">
                    {['products', 'about', 'reviews'].map(tab => (
                        <button 
                            key={tab}
                            onClick={() => setActiveTab(tab)}
                            className={`pb-3 px-2 text-sm font-bold uppercase tracking-wider transition-all relative ${activeTab === tab ? 'text-brand-navy-dark dark:text-white' : 'text-gray-400 hover:text-gray-600'}`}
                        >
                            {tab}
                            {activeTab === tab && <span className="absolute bottom-0 left-0 w-full h-1 bg-brand-gold rounded-t-full"></span>}
                        </button>
                    ))}
                </div>

                <div>
                    {activeTab === 'products' && (
                        vendorProducts.length > 0 ? (
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                                {vendorProducts.map((product, i) => (
                                    <ProductCard key={product.id} product={product} onAddToCart={addToCart} onQuickView={setQuickViewProduct} animationDelay={i*50} />
                                ))}
                            </div>
                        ) : <p className="text-center py-16 text-gray-500">No products listed.</p>
                    )}

                    {activeTab === 'about' && (
                        <div className="bg-white dark:bg-brand-navy-dark p-8 rounded-3xl shadow-sm">
                            <h3 className="text-xl font-bold text-brand-navy-dark dark:text-white mb-4">Our Story</h3>
                            <p className="text-gray-600 dark:text-gray-300 leading-relaxed whitespace-pre-line">{vendor.story}</p>
                        </div>
                    )}

                     {activeTab === 'reviews' && (
                        <div>
                            <ReviewSummary reviews={vendorReviews} />
                            <div className="mt-8 space-y-4">
                                {vendorReviews.map(review => <ReviewCard key={review.id} review={review} />)}
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {quickViewProduct && <QuickViewModal product={quickViewProduct} onClose={() => setQuickViewProduct(null)} />}
            {isContactModalOpen && <ContactActionModal participant={participantForModal} onClose={() => setIsContactModalOpen(false)} />}
        </div>
    );
};

export default VendorStorePage;