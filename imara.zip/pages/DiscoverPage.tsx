
import React, { useState, useEffect } from 'react';
import { SearchIcon, FireIcon, MusicNoteIcon, DocumentTextIcon, ShoppingBagIcon, FilmIcon, SparklesIcon, PlayIcon, CheckCircleIcon } from '../components/icons/Icons';
import { mockSounds, mockProducts } from '../data/mockData';
import { useLanguage } from '../contexts/LanguageContext';
import BackButton from '../components/ui/BackButton';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import { useNavigate } from 'react-router-dom';

const categories = [
    { id: 'trending', name: 'Trending', icon: <FireIcon className="w-5 h-5"/> },
    { id: 'sounds', name: 'Sounds', icon: <MusicNoteIcon className="w-5 h-5"/> },
    { id: 'products', name: 'Products', icon: <ShoppingBagIcon className="w-5 h-5"/> },
    { id: 'templates', name: 'Templates', icon: <DocumentTextIcon className="w-5 h-5"/> },
];

const mockTemplates = [
    { id: 1, title: "Day in the Life", used: "12k uses", bg: "bg-gradient-to-br from-purple-600 to-indigo-800" },
    { id: 2, title: "OOTD Check", used: "8.5k uses", bg: "bg-gradient-to-br from-pink-600 to-rose-700" },
    { id: 3, title: "Artisan Showcase", used: "5k uses", bg: "bg-gradient-to-br from-amber-600 to-orange-700" },
    { id: 4, title: "Travel Vlog", used: "20k uses", bg: "bg-gradient-to-br from-cyan-600 to-blue-700" },
];

const DiscoverPage: React.FC = () => {
    const { t } = useLanguage();
    const navigate = useNavigate();
    const [activeTab, setActiveTab] = useState('trending');
    const [liveSounds, setLiveSounds] = useState(mockSounds);
    const [isLoading, setIsLoading] = useState(true);

    // Simulate real-time data updates
    useEffect(() => {
        // Initial load
        setTimeout(() => setIsLoading(false), 1000);

        const interval = setInterval(() => {
            setLiveSounds(prev => {
                // Shuffle array to simulate changing trends
                const shuffled = [...prev].sort(() => 0.5 - Math.random());
                return shuffled;
            });
        }, 5000); // Update every 5 seconds

        return () => clearInterval(interval);
    }, []);

    const handleCreateNow = () => {
        // Navigate to Home with state to open composer
        navigate('/', { state: { openComposer: true } });
    };

    return (
        <div className="min-h-screen bg-brand-off-white dark:bg-brand-navy-dark text-brand-navy-dark dark:text-white pb-20">
            {/* Header */}
            <div className="sticky top-0 z-10 bg-white/90 dark:bg-brand-navy-dark/90 backdrop-blur-md border-b border-gray-200 dark:border-white/10">
                <div className="container mx-auto px-4 py-4">
                    <div className="flex items-center gap-4 mb-4">
                        <BackButton />
                        <h1 className="text-xl font-display font-bold">Discover</h1>
                    </div>
                    
                    <div className="relative mb-4">
                        <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"/>
                        <input 
                            type="text" 
                            placeholder="Search for sounds, trends, products..." 
                            className="w-full bg-gray-100 dark:bg-white/10 rounded-full py-2.5 pl-10 pr-4 outline-none focus:ring-2 focus:ring-brand-gold text-brand-navy-dark dark:text-white placeholder:text-gray-500"
                        />
                    </div>

                    <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-2">
                        {categories.map(cat => (
                            <button 
                                key={cat.id}
                                onClick={() => setActiveTab(cat.id)}
                                className={`flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${activeTab === cat.id ? 'bg-brand-gold text-brand-navy-dark shadow-md' : 'bg-gray-200 dark:bg-white/10 text-gray-600 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-white/20'}`}
                            >
                                {cat.icon}
                                {cat.name}
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            {/* Content */}
            {isLoading ? (
                <div className="flex justify-center pt-20">
                    <LoadingSpinner />
                </div>
            ) : (
                <div className="container mx-auto px-4 py-6 space-y-10">
                    
                    {/* IMARA INTELLIGENCE BAR */}
                    <div className="relative rounded-xl overflow-hidden shadow-2xl border border-white/10">
                        {/* Animated Background */}
                        <div className="absolute inset-0 bg-gradient-to-r from-[#004d40] to-[#000000] z-0"></div>
                        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-gold/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3"></div>
                        
                        <div className="relative z-10 p-6 text-white">
                            <div className="flex items-center gap-2 mb-4">
                                <div className="p-1.5 bg-white/10 rounded-full backdrop-blur-md">
                                    <SparklesIcon className="w-5 h-5 text-brand-gold animate-spin-slow"/>
                                </div>
                                <h3 className="font-display font-bold text-lg tracking-wide">IMARA INTELLIGENCE</h3>
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                                    <p className="text-brand-gold text-xs uppercase font-bold mb-1">Trending Region</p>
                                    <p className="text-lg font-bold">Accra, Ghana 🇬🇭</p>
                                    <p className="text-xs text-gray-300">+25% engagement</p>
                                </div>
                                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                                    <p className="text-brand-gold text-xs uppercase font-bold mb-1">Viral Tag</p>
                                    <p className="text-lg font-bold text-brand-green-light">%AfroTech</p>
                                    <p className="text-xs text-gray-300">12k new posts</p>
                                </div>
                                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                                    <p className="text-brand-gold text-xs uppercase font-bold mb-1">Best Time to Post</p>
                                    <p className="text-lg font-bold">7:30 PM</p>
                                    <p className="text-xs text-gray-300">in your timezone</p>
                                </div>
                            </div>
                            
                            <div className="mt-4 pt-4 border-t border-white/10 flex justify-between items-center">
                                <p className="text-xs text-gray-300 italic">"Users are loving tech reviews right now. Try a Remix!"</p>
                                <button onClick={handleCreateNow} className="text-xs font-bold bg-brand-gold text-brand-navy-dark px-4 py-2 rounded-full hover:bg-white transition-colors">
                                    Create Now &rarr;
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* Viral Sounds */}
                    <section>
                        <div className="flex justify-between items-center mb-4">
                            <h2 className="text-xl font-display font-bold flex items-center gap-2 text-brand-navy-dark dark:text-white">
                                Viral Sounds <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
                            </h2>
                            <button className="text-sm text-brand-green dark:text-brand-gold hover:underline">See all</button>
                        </div>
                        <div className="space-y-3">
                            {liveSounds.slice(0, 4).map((sound, i) => (
                                <div key={sound.id} className="flex items-center gap-4 p-3 bg-white dark:bg-white/5 rounded-2xl shadow-sm border border-gray-100 dark:border-white/5 hover:border-brand-gold/50 transition-all group">
                                    <div className="relative w-12 h-12 bg-brand-navy-dark rounded-xl flex items-center justify-center text-brand-gold font-bold text-lg shadow-inner flex-shrink-0 overflow-hidden group-hover:scale-105 transition-transform">
                                        <div className="absolute inset-0 bg-brand-gold/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                                        {i + 1}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <p className="font-bold text-sm truncate text-brand-navy-dark dark:text-white">{sound.title}</p>
                                        <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{sound.artist}</p>
                                    </div>
                                    <button className="p-2 bg-gray-100 dark:bg-white/10 rounded-full hover:bg-brand-green hover:text-white transition-colors">
                                        <PlayIcon className="w-4 h-4" />
                                    </button>
                                    <button className="px-3 py-1.5 bg-brand-gold/10 text-brand-navy-dark dark:text-brand-gold text-xs font-bold rounded-full hover:bg-brand-gold hover:text-brand-navy-dark transition-colors">
                                        Use Sound
                                    </button>
                                </div>
                            ))}
                        </div>
                    </section>

                    {/* Viral Templates */}
                    <section>
                        <h2 className="text-xl font-display font-bold mb-4 text-brand-navy-dark dark:text-white">Viral Templates</h2>
                        <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-4">
                            {mockTemplates.map(template => (
                                <div key={template.id} className={`w-36 h-56 ${template.bg} rounded-2xl flex-shrink-0 flex flex-col justify-between p-4 shadow-lg transform transition-transform hover:scale-105 cursor-pointer text-white relative overflow-hidden`}>
                                    <div className="absolute top-0 right-0 w-20 h-20 bg-white/10 rounded-full blur-xl"></div>
                                    <DocumentTextIcon className="w-6 h-6 opacity-90"/>
                                    <div>
                                        <p className="text-sm font-bold leading-tight mb-1">{template.title}</p>
                                        <p className="text--[10px] opacity-80">{template.used}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </section>

                    {/* Hot Suggestions (Products) */}
                    <section>
                        <h2 className="text-xl font-display font-bold mb-4 text-brand-navy-dark dark:text-white">Hot in ShopHub 🔥</h2>
                        <div className="grid grid-cols-2 gap-4">
                            {mockProducts.slice(0, 4).map(product => (
                                <div key={product.id} className="bg-white dark:bg-white/5 rounded-xl overflow-hidden shadow-md group border border-gray-100 dark:border-white/5">
                                    <div className="relative h-32 overflow-hidden">
                                        <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"/>
                                        <div className="absolute top-2 right-2 bg-white/90 dark:bg-black/50 text-[10px] font-bold px-2 py-1 rounded-full backdrop-blur-sm dark:text-white">
                                            ${product.price}
                                        </div>
                                    </div>
                                    <div className="p-3">
                                        <p className="font-bold text-sm truncate text-brand-navy-dark dark:text-white">{product.name}</p>
                                        <p className="text-xs text-gray-500 dark:text-gray-400 truncate mb-2">by {product.vendor}</p>
                                        <button onClick={() => navigate(`/product/${product.id}`)} className="w-full py-1.5 text-xs font-bold border border-brand-green text-brand-green rounded-lg hover:bg-brand-green hover:text-white transition-colors">
                                            View
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </section>
                </div>
            )}
        </div>
    );
};

export default DiscoverPage;
