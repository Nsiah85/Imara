
import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { mockInvestments, mockCauses } from '../data/mockData.ts';
import PaymentModal from '../components/modals/PaymentModal.tsx';
import type { Investment, Cause, PaymentItem, GiftCard } from '../types.ts';
import { useLanguage } from '../contexts/LanguageContext.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';
import { useCurrency } from '../contexts/CurrencyContext.tsx';
import { BanknotesIcon, UsersIcon, HeartIcon, CheckCircleIcon, ArrowRightIcon } from '../components/icons/Icons.tsx';
import ProgressBar from '../components/ui/ProgressBar.tsx';

// Helper component for counting up animation
const CountUp = ({ end, duration = 2000, prefix = '', suffix = '' }: { end: number, duration?: number, prefix?: string, suffix?: string }) => {
    const [count, setCount] = useState(0);

    useEffect(() => {
        let startTime: number | null = null;
        const animate = (currentTime: number) => {
            if (!startTime) startTime = currentTime;
            const progress = currentTime - startTime;
            const percentage = Math.min(progress / duration, 1);
            
            // Ease out quartic
            const ease = 1 - Math.pow(1 - percentage, 4);
            
            setCount(Math.floor(ease * end));

            if (progress < duration) {
                requestAnimationFrame(animate);
            }
        };
        requestAnimationFrame(animate);
    }, [end, duration]);

    return <span>{prefix}{count.toLocaleString()}{suffix}</span>;
};

// Type Guard
function isInvestment(item: Investment | Cause): item is Investment {
    return (item as Investment).vendorName !== undefined;
}

const InvestPage: React.FC = () => {
  const [paymentItem, setPaymentItem] = useState<PaymentItem | null>(null);
  const { t } = useLanguage();
  const { user, updateUser } = useAuth();
  const { formatCurrency } = useCurrency();
  const [showReward, setShowReward] = useState(false);
  
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [causes, setCauses] = useState<Cause[]>([]);
  const [showAllPrograms, setShowAllPrograms] = useState(false);
  
  useEffect(() => {
    try {
        const storedInvestments = localStorage.getItem('investments');
        const parsedInvestments = storedInvestments ? JSON.parse(storedInvestments) : null;
        setInvestments(Array.isArray(parsedInvestments) ? parsedInvestments : mockInvestments);
        
        const storedCauses = localStorage.getItem('causes');
        const parsedCauses = storedCauses ? JSON.parse(storedCauses) : null;
        setCauses(Array.isArray(parsedCauses) ? parsedCauses : mockCauses);
    } catch (error) {
        console.error("Failed to load content from localStorage, falling back to mock data.", error);
        setInvestments(mockInvestments);
        setCauses(mockCauses);
    }
  }, []);

  // Sort all programs by featured/priority first
  const allPrograms = useMemo(() => {
      const combined = [...investments, ...causes];
      return combined.sort((a, b) => {
          const aFeatured = isInvestment(a) ? a.isTopPriority : a.isFeatured;
          const bFeatured = isInvestment(b) ? b.isTopPriority : b.isFeatured;
          if (bFeatured && !aFeatured) return 1;
          if (aFeatured && !bFeatured) return -1;
          return 0;
      });
  }, [investments, causes]);

  // Hero Cards Logic: Select top 3 featured items, or default if none
  const { hero1, hero2, hero3 } = useMemo(() => {
      if (allPrograms.length === 0) return { hero1: null, hero2: null, hero3: null };
      // Pick top 3 from sorted list (prioritizes featured)
      return {
          hero1: allPrograms[0] || null,
          hero2: allPrograms[1] || null,
          hero3: allPrograms[2] || null
      };
  }, [allPrograms]);
  
  // Grid Display Logic: Show remaining or all items
  // If "View All" is off, show 2 items. If on, show all.
  const displayedPrograms = showAllPrograms ? allPrograms : allPrograms.slice(0, 2);

  const handlePledgeNow = (investment: Investment) => {
    setPaymentItem({
      id: investment.id,
      type: 'investment',
      title: investment.title,
      recipient: investment.vendorName,
      imageUrl: investment.imageUrl,
    });
  };
  
  const handleDonateNow = (cause: Cause) => {
    setPaymentItem({
      id: cause.id,
      type: 'donation',
      title: cause.title,
      recipient: cause.organization,
      imageUrl: cause.imageUrl,
    });
  };

  const handleCloseModal = () => setPaymentItem(null);

  const awardGiftCardOnImpact = (amount: number) => {
    if (!user) return;
    try {
        const totalImpactStr = localStorage.getItem(`impact_total_${user.id}`) || '0';
        const currentTotal = parseFloat(totalImpactStr);
        const newTotal = currentTotal + amount;
        localStorage.setItem(`impact_total_${user.id}`, String(newTotal));

        if (newTotal >= 100 && currentTotal < 100) {
            const newCard: GiftCard = {
                code: `IMPACT-${user.id.slice(0,4).toUpperCase()}`,
                type: 'fixed',
                value: 10,
                description: `A $10 reward for reaching the $100 Impact Milestone!`,
                expiryDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString(),
                isActive: true,
            };
            const userCards = user.giftCards || [];
            updateUser({ giftCards: [...userCards, newCard] });
            setShowReward(true);
            setTimeout(() => setShowReward(false), 5000);
        }
    } catch (error) { console.error(error); }
  };
  
  const handleSuccess = (amount: number) => {
    if (!paymentItem) return;
    
    if(paymentItem.type === 'investment') {
        const updatedInvestments = investments.map(inv => 
            inv.id === paymentItem.id ? { ...inv, raised: inv.raised + amount } : inv
        );
        setInvestments(updatedInvestments);
        localStorage.setItem('investments', JSON.stringify(updatedInvestments));
    } else if (paymentItem.type === 'donation') {
        const updatedCauses = causes.map(c => 
            c.id === paymentItem.id ? { ...c, raised: (c.raised || 0) + amount } : c
        );
        setCauses(updatedCauses);
        localStorage.setItem('causes', JSON.stringify(updatedCauses));
    }
    awardGiftCardOnImpact(amount);
    handleCloseModal();
  };

  // Helper component for Hero Cards
  const HeroCard = ({ 
    item, 
    type, 
    bgClass, 
    btnClass, 
    btnText,
    secondaryBtnText 
  }: { 
    item: Investment | Cause | null, 
    type: 'invest' | 'donate' | 'both', 
    bgClass: string, 
    btnClass: string, 
    btnText: string,
    secondaryBtnText?: string 
  }) => {
    if (!item) return null;
    
    const isInv = isInvestment(item);
    const goal = isInv ? item.goal : (item.goal || 10000);
    const raised = isInv ? item.raised : (item.raised || 0);
    const title = item.title;
    const imageUrl = item.imageUrl;
    const isFeatured = isInv ? item.isTopPriority : item.isFeatured;
    const vendorOrOrg = isInv ? item.vendorName : item.organization;

    return (
        <div className={`rounded-2xl overflow-hidden shadow-lg flex flex-col h-full ${bgClass} transition-transform hover:-translate-y-1`}>
            <div className="relative h-48">
                <img src={imageUrl} alt={title} className="w-full h-full object-cover opacity-90" />
                <div className={`absolute inset-0 bg-gradient-to-t ${bgClass.includes('white') ? 'from-white/0' : 'from-black/60'} to-transparent`}></div>
                {isFeatured && (
                     <div className="absolute top-3 left-3 bg-brand-gold text-brand-navy-dark text-[10px] font-bold px-2 py-1 rounded uppercase tracking-widest">
                        Featured
                    </div>
                )}
            </div>
            <div className="p-6 flex flex-col flex-grow">
                <h3 className={`text-2xl font-display font-bold mb-4 ${bgClass.includes('bg-brand-gold') ? 'text-brand-navy-dark' : 'text-white'}`}>{title}</h3>
                <p className={`text-xs uppercase tracking-widest mb-2 ${bgClass.includes('bg-brand-gold') ? 'text-brand-navy-dark/70' : 'text-white/70'}`}>
                    {vendorOrOrg}
                </p>
                
                <div className="mt-auto space-y-4">
                     {type !== 'both' && (
                         <div className="w-full bg-black/20 rounded-full h-1.5 overflow-hidden">
                            <div className="bg-white h-full rounded-full" style={{ width: `${Math.min((raised / goal) * 100, 100)}%` }}></div>
                        </div>
                     )}
                     
                     <div className="flex gap-3">
                        <button 
                            onClick={() => isInv ? handlePledgeNow(item) : handleDonateNow(item)}
                            className={`flex-1 py-3 px-4 rounded-full font-bold text-sm shadow-md transition-opacity hover:opacity-90 ${btnClass}`}
                        >
                            {btnText}
                        </button>
                        {type === 'both' && secondaryBtnText && (
                             <button 
                                onClick={() => handleDonateNow(item as Cause)} // Fallback casting, handled in logic
                                className="flex-1 py-3 px-4 rounded-full font-bold text-sm shadow-md transition-opacity hover:opacity-90 bg-brand-navy-dark text-white"
                            >
                                {secondaryBtnText}
                            </button>
                        )}
                     </div>
                </div>
            </div>
        </div>
    );
  };

  return (
    <>
      {showReward && (
        <div className="fixed top-24 right-6 z-[100] bg-brand-gold text-brand-navy-dark p-4 rounded-lg shadow-lg animate-fade-in-down border-2 border-white">
            <p className="font-bold">🎉 Milestone Reached!</p>
            <p className="text-sm">You've earned a reward for your impact. Check your account.</p>
        </div>
      )}
      
      <div className="bg-gray-50 dark:bg-gray-900 min-h-screen pb-20">
          <div className="container mx-auto px-4 sm:px-6 py-8">
             <div className="flex items-center justify-between mb-8">
                 <div className="w-10 h-10 hidden sm:block"></div> {/* Spacer */}
                 {user && (
                     <div className="hidden sm:block text-sm text-gray-500">
                         Balance: <span className="font-bold text-brand-navy-dark dark:text-white">{formatCurrency(0)}</span>
                     </div>
                 )}
             </div>

            {/* Hero Section Cards */}
            {hero1 && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
                    <HeroCard 
                        item={hero1} 
                        type="donate" 
                        bgClass="bg-brand-navy-dark" 
                        btnClass="bg-brand-gold text-brand-navy-dark" 
                        btnText="Invest Now" 
                    />
                    {hero2 && (
                        <HeroCard 
                            item={hero2} 
                            type="invest" 
                            bgClass="bg-brand-green" 
                            btnClass="bg-brand-gold text-brand-navy-dark" 
                            btnText="Donate Now" 
                        />
                    )}
                    {hero3 && (
                        <HeroCard 
                            item={hero3} 
                            type="both" 
                            bgClass="bg-brand-gold" 
                            btnClass="bg-brand-navy-dark text-white" 
                            btnText="Invest"
                            secondaryBtnText="Donate"
                        />
                    )}
                </div>
            )}

            {/* Real-Time Stats Bar */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-6 mb-12 flex flex-col md:flex-row justify-between items-center gap-6 divide-y md:divide-y-0 md:divide-x divide-gray-100 dark:divide-gray-700">
                <div className="flex items-center gap-4 px-4 w-full md:w-auto">
                    <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-full text-green-600 dark:text-green-400"><BanknotesIcon className="w-6 h-6"/></div>
                    <div>
                        <p className="text-2xl font-display font-bold text-brand-navy-dark dark:text-white">
                            <CountUp end={15} prefix="$" suffix="M Raised" />
                        </p>
                        <div className="w-24 h-1.5 bg-gray-200 rounded-full mt-1"><div className="w-full bg-brand-gold h-full rounded-full animate-[fill-progress_2s_ease-out]"></div></div>
                    </div>
                </div>
                <div className="flex items-center gap-4 px-4 w-full md:w-auto pt-4 md:pt-0">
                    <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-full text-blue-600 dark:text-blue-400"><UsersIcon className="w-6 h-6"/></div>
                    <div>
                        <p className="text-2xl font-display font-bold text-brand-navy-dark dark:text-white">
                            <CountUp end={10000} suffix="+" />
                        </p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Lives Impacted</p>
                    </div>
                </div>
                 <div className="flex items-center gap-4 px-4 w-full md:w-auto pt-4 md:pt-0">
                    <div className="p-3 bg-purple-100 dark:bg-purple-900/30 rounded-full text-purple-600 dark:text-purple-400"><HeartIcon className="w-6 h-6"/></div>
                    <div>
                        <p className="text-2xl font-display font-bold text-brand-navy-dark dark:text-white">
                            <CountUp end={500} suffix="+" />
                        </p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Communities</p>
                    </div>
                </div>
                <div className="flex items-center gap-4 px-4 w-full md:w-auto pt-4 md:pt-0">
                     <div className="p-3 bg-orange-100 dark:bg-orange-900/30 rounded-full text-orange-600 dark:text-orange-400"><CheckCircleIcon className="w-6 h-6"/></div>
                     <div>
                        <p className="text-2xl font-display font-bold text-brand-navy-dark dark:text-white">
                            <CountUp end={100} suffix="%" />
                        </p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Verified Projects</p>
                    </div>
                </div>
            </div>

            {/* Main Content Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
                
                {/* Left Column: How It Works */}
                <div className="lg:col-span-4">
                    <h2 className="text-2xl font-display font-bold text-brand-navy-dark dark:text-white mb-6">How Your Contribution Works</h2>
                    <div className="space-y-8">
                        {[
                            { id: 1, title: 'Choose a Cause', desc: 'Browse verified projects and select one that resonates with you.', color: 'bg-green-500' },
                            { id: 2, title: 'Invest or Donate', desc: 'Make a secure contribution via Mobile Money or Card.', color: 'bg-brand-gold' },
                            { id: 3, title: 'Track Impact', desc: 'Receive updates and see exactly how your funds are used.', color: 'bg-brand-navy-dark' }
                        ].map((step) => (
                            <div key={step.id} className="flex gap-4">
                                <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center text-white font-bold ${step.color}`}>
                                    {step.id}
                                </div>
                                <div>
                                    <h4 className="font-bold text-lg text-gray-800 dark:text-gray-200">{step.title}</h4>
                                    <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed mt-1">{step.desc}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                    
                    <div className="mt-10 bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
                        <h4 className="font-bold text-brand-navy-dark dark:text-white mb-2">Impact Guarantee</h4>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">We ensure 100% of your donation reaches the beneficiary after standard processing fees.</p>
                        <Link to="/transparency" className="text-brand-green font-semibold text-sm hover:underline flex items-center gap-1">
                            Read our transparency report <ArrowRightIcon className="w-3 h-3"/>
                        </Link>
                    </div>
                </div>

                {/* Right Column: Featured Programs */}
                <div className="lg:col-span-8">
                    <div className="flex justify-between items-end mb-6">
                         <h2 className="text-2xl font-display font-bold text-brand-navy-dark dark:text-white">Featured Programs</h2>
                         <button 
                            className="text-sm font-semibold text-brand-green hover:text-brand-navy-dark transition-colors"
                            onClick={() => setShowAllPrograms(!showAllPrograms)}
                         >
                             {showAllPrograms ? 'Show Less' : 'View All'}
                         </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        {displayedPrograms.map((program) => {
                             const isInv = isInvestment(program);
                             const target = isInv ? program.goal : (program as Cause).goal || 5000;
                             const current = isInv ? program.raised : (program as Cause).raised || 0;
                             const title = program.title;
                             const vendorOrOrg = isInv ? program.vendorName : (program as Cause).organization;
                             
                             return (
                                <div key={program.id} className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden flex flex-col group hover:shadow-md transition-shadow animate-fade-in">
                                    <div className="relative h-48 overflow-hidden">
                                        <img src={program.imageUrl} alt={title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                                        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-md px-2 py-1 rounded text-xs font-bold text-brand-navy-dark uppercase tracking-wider">
                                            {isInv ? 'Investment' : 'Cause'}
                                        </div>
                                    </div>
                                    <div className="p-5 flex flex-col flex-grow">
                                        <p className="text-xs text-gray-500 uppercase tracking-widest mb-1 truncate">
                                            {vendorOrOrg}
                                        </p>
                                        <h3 className="font-bold text-lg text-brand-navy-dark dark:text-white mb-2 line-clamp-1">{title}</h3>
                                        
                                        <div className="mt-auto">
                                            <div className="flex justify-between text-xs mb-1.5 text-gray-500 dark:text-gray-400">
                                                <span>Raised: <span className="font-bold text-brand-green">{formatCurrency(current)}</span></span>
                                                <span>{Math.round((current/target)*100)}%</span>
                                            </div>
                                            <ProgressBar value={current} max={target} />
                                            
                                            <div className="mt-4 flex gap-3">
                                                {isInv ? (
                                                    <button onClick={() => handlePledgeNow(program as Investment)} className="flex-1 py-2 text-sm font-bold bg-brand-navy-dark text-white rounded-lg hover:bg-opacity-90 transition-opacity">Invest</button>
                                                ) : (
                                                    <button onClick={() => handleDonateNow(program as Cause)} className="flex-1 py-2 text-sm font-bold bg-brand-green text-white rounded-lg hover:bg-opacity-90 transition-opacity">Donate</button>
                                                )}
                                                <button className="py-2 px-4 text-sm font-bold text-gray-500 border border-gray-200 rounded-lg hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700">Details</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                             );
                        })}
                    </div>
                </div>
            </div>

          </div>
      </div>

      {paymentItem && (
        <PaymentModal
          item={paymentItem}
          onClose={handleCloseModal}
          onSuccess={(amount) => handleSuccess(amount)}
        />
      )}
    </>
  );
};

export default InvestPage;
