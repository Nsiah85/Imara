import React, { useState, useMemo, useEffect } from 'react';
import { mockJobListings } from '../data/mockData.ts';
import { ProfessionalIndustry, type JobListing } from '../types.ts';
import JobListingCard from '../components/jobs/JobListingCard.tsx';
import JobDetailModal from '../components/modals/JobDetailModal.tsx';
import PaginationControls from '../components/shared/PaginationControls.tsx';
import { useLanguage } from '../contexts/LanguageContext.tsx';
import BackButton from '../components/ui/BackButton.tsx';
import { SearchIcon, GlobeIcon } from '../components/icons/Icons.tsx';

const JOBS_PER_PAGE = 8;

const FindJobPage: React.FC = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedIndustry, setSelectedIndustry] = useState<ProfessionalIndustry | null>(null);
    const [location, setLocation] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [selectedJob, setSelectedJob] = useState<JobListing | null>(null);

    useEffect(() => { setCurrentPage(1); }, [searchTerm, selectedIndustry, location]);

    const handleIndustryToggle = (industry: ProfessionalIndustry) => {
        setSelectedIndustry(prev => (prev === industry ? null : industry));
    };

    const filteredJobs = useMemo(() => {
        return mockJobListings.filter(job => {
            const lowerCaseSearch = searchTerm.toLowerCase();
            const matchesSearch =
                job.title.toLowerCase().includes(lowerCaseSearch) ||
                job.companyName.toLowerCase().includes(lowerCaseSearch) ||
                job.description.toLowerCase().includes(lowerCaseSearch) ||
                job.requirements.some(req => req.toLowerCase().includes(lowerCaseSearch));

            const matchesIndustry = !selectedIndustry || job.industry === selectedIndustry;
            const matchesLocation = !location || job.location.toLowerCase().includes(location.toLowerCase());
            return matchesSearch && matchesIndustry && matchesLocation;
        });
    }, [searchTerm, selectedIndustry, location]);

    const totalPages = Math.ceil(filteredJobs.length / JOBS_PER_PAGE);
    const paginatedJobs = filteredJobs.slice((currentPage - 1) * JOBS_PER_PAGE, currentPage * JOBS_PER_PAGE);

    return (
        <div className="bg-brand-off-white dark:bg-gray-900 min-h-screen">
            <div className="container mx-auto px-6 py-8">
                <BackButton className="mb-4" />
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-display font-bold text-brand-navy-dark dark:text-white">Find Your Next Opportunity</h1>
                    <p className="mt-2 text-brand-gray dark:text-gray-400 max-w-xl mx-auto">Browse roles from innovative companies across the continent.</p>
                </div>

                {/* New Rounded Search Bar Style */}
                <div className="mb-10 bg-white dark:bg-gray-800 rounded-full shadow-xl p-2 max-w-4xl mx-auto flex flex-col md:flex-row items-center border border-gray-100 dark:border-gray-700">
                    <div className="flex items-center px-4 flex-grow w-full md:w-auto border-b md:border-b-0 md:border-r border-gray-200 dark:border-gray-700 py-2 md:py-0">
                        <SearchIcon className="w-5 h-5 text-gray-400 mr-3" />
                        <input
                            type="text"
                            placeholder="Job title, keywords, or company"
                            className="w-full bg-transparent border-none focus:ring-0 text-gray-800 dark:text-white placeholder:text-gray-400"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <div className="flex items-center px-4 w-full md:w-1/3 py-2 md:py-0">
                        <GlobeIcon className="w-5 h-5 text-gray-400 mr-3" />
                        <input
                            type="text"
                            placeholder="Location (e.g. Lagos)"
                            className="w-full bg-transparent border-none focus:ring-0 text-gray-800 dark:text-white placeholder:text-gray-400"
                            value={location}
                            onChange={(e) => setLocation(e.target.value)}
                        />
                    </div>
                    <button className="bg-brand-green hover:bg-brand-green-dark text-white rounded-full px-8 py-3 font-bold shadow-md transition-transform hover:-translate-y-0.5 m-1 w-full md:w-auto">
                        Search
                    </button>
                </div>

                {/* Pill Filters */}
                <div className="mb-8 overflow-x-auto pb-4 scrollbar-hide text-center">
                    <div className="inline-flex gap-2">
                        <button 
                            onClick={() => setSelectedIndustry(null)}
                            className={`px-4 py-2 rounded-full text-sm font-semibold transition-all ${!selectedIndustry ? 'bg-brand-navy-dark text-white shadow-md' : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-100'}`}
                        >
                            All Industries
                        </button>
                        {Object.values(ProfessionalIndustry).map(industry => (
                            <button
                                key={industry}
                                onClick={() => handleIndustryToggle(industry)}
                                className={`px-4 py-2 rounded-full text-sm font-semibold transition-all whitespace-nowrap ${
                                    selectedIndustry === industry
                                        ? 'bg-brand-navy-dark text-white shadow-md'
                                        : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-100'
                                }`}
                            >
                                {industry}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="grid gap-4">
                    {paginatedJobs.length > 0 ? (
                        <>
                            {paginatedJobs.map((job) => (
                                <JobListingCard key={job.id} job={job} onViewDetails={setSelectedJob} />
                            ))}
                            {totalPages > 1 && (
                                <PaginationControls
                                    currentPage={currentPage}
                                    totalPages={totalPages}
                                    onPageChange={(page) => { setCurrentPage(page); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                                />
                            )}
                        </>
                    ) : (
                        <div className="text-center py-20 bg-white dark:bg-gray-800 rounded-3xl">
                            <h2 className="text-2xl font-display font-semibold text-brand-green-dark dark:text-white">No Jobs Found</h2>
                            <p className="mt-2 text-brand-gray dark:text-gray-400">Try adjusting your filters.</p>
                        </div>
                    )}
                </div>
            </div>
            {selectedJob && <JobDetailModal job={selectedJob} onClose={() => setSelectedJob(null)} />}
        </div>
    );
};

export default FindJobPage;