import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useWishlist } from '../contexts/WishlistContext';
import { useCart } from '../contexts/CartContext';
import Button from '../components/ui/Button';
import ProductCard from '../components/shared/ProductCard';
import QuickViewModal from '../components/modals/QuickViewModal';
import type { Product, Participant } from '../types';
import { HeartIcon, UsersIcon } from '../components/icons/Icons';
import BackButton from '../components/ui/BackButton';
import DrivingTestModal from '../components/modals/DrivingTestModal';
import { mockAllUsersAndPartners } from '../data/mockData';

const UserList: React.FC<{ userIds: string[], title: string }> = ({ userIds, title }) => {
    const users = mockAllUsersAndPartners.filter(u => userIds.includes(u.id));

    if (users.length === 0) {
        return <p className="text-center text-gray-500 py-8">No users to display here.</p>;
    }

    return (
        <div className="space-y-4">
            {users.map(user => (
                <div key={user.id} className="flex items-center justify-between p-3 bg-brand-off-white/60 rounded-md">
                    <div className="flex items-center gap-3">
                        <img src={user.avatarUrl} alt={user.name} className="w-12 h-12 rounded-full object-cover" />
                        <div>
                            <p className="font-semibold text-brand-navy-dark">{user.name}</p>
                            <p className="text-sm text-gray-500">{user.role}</p>
                        </div>
                    </div>
                    <Button variant="outline" size="sm">View Profile</Button>
                </div>
            ))}
        </div>
    );
};

const WishlistPage: React.FC = () => {
    const { user } = useAuth();
    const { wishlistItems } = useWishlist();
    const { addToCart } = useCart();
    const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
    const [isDrivingTestModalOpen, setIsDrivingTestModalOpen] = useState(false);
    const [activeTab, setActiveTab] = useState<'saved' | 'following' | 'followers'>('saved');

    const handleOpenQuickView = (product: Product) => {
        setQuickViewProduct(product);
    };

    const handleCloseQuickView = () => {
        setQuickViewProduct(null);
    };

    const handleBookNow = (product: Product) => {
        setIsDrivingTestModalOpen(true);
    };

    const tabClass = (tabName: typeof activeTab) =>
        `px-4 py-2 text-sm font-medium rounded-md transition-colors ${
            activeTab === tabName ? 'bg-brand-navy-dark text-white' : 'text-gray-600 hover:bg-brand-off-white'
        }`;

    if (!user) {
        return (
            <div className="container mx-auto px-6 py-20 text-center">
                <h1 className="text-3xl font-display font-bold text-brand-navy-dark">My Hub</h1>
                <p className="mt-4 text-brand-gray">Please log in to view your hub.</p>
                <Link to="/login" className="mt-6 inline-block">
                    <Button variant="primary" size="lg">Log In or Sign Up</Button>
                </Link>
            </div>
        );
    }

    return (
        <>
            <div className="container mx-auto px-6 py-12">
                <BackButton className="mb-4" />
                <h1 className="text-3xl font-display font-bold text-brand-navy-dark mb-2">My Hub</h1>
                <p className="text-brand-gray mb-8">Your central place for saved items, followers, and connections.</p>
                
                <div className="flex flex-wrap gap-2 mb-8 border-b pb-4">
                    <button className={tabClass('saved')} onClick={() => setActiveTab('saved')}>Saved Items ({wishlistItems.length})</button>
                    <button className={tabClass('following')} onClick={() => setActiveTab('following')}>Following ({user.followingIds?.length || 0})</button>
                    <button className={tabClass('followers')} onClick={() => setActiveTab('followers')}>Followers ({user.followerIds?.length || 0})</button>
                </div>
                
                <div>
                    {activeTab === 'saved' && (
                        wishlistItems.length === 0 ? (
                             <div className="text-center py-20">
                                <HeartIcon className="w-16 h-16 text-brand-gold mx-auto" />
                                <h2 className="text-2xl font-display font-semibold text-brand-navy-dark mt-4">No Saved Items</h2>
                                <p className="mt-2 text-brand-gray">Looks like you haven't added anything yet. Find something you love!</p>
                                <Link to="/shop-hub" className="mt-6 inline-block">
                                    <Button variant="primary" size="lg">Start Shopping</Button>
                                </Link>
                            </div>
                        ) : (
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
                                {wishlistItems.map((product, index) => (
                                    <ProductCard 
                                        key={product.id} 
                                        product={product} 
                                        animationDelay={index * 75}
                                        onQuickView={handleOpenQuickView}
                                        onAddToCart={addToCart}
                                        onBookNow={handleBookNow}
                                    />
                                ))}
                            </div>
                        )
                    )}

                    {activeTab === 'following' && <UserList userIds={user.followingIds || []} title="Following" />}
                    {activeTab === 'followers' && <UserList userIds={user.followerIds || []} title="Followers" />}
                </div>

            </div>
            {quickViewProduct && (
                <QuickViewModal product={quickViewProduct} onClose={handleCloseQuickView} />
            )}
            {isDrivingTestModalOpen && <DrivingTestModal onClose={() => setIsDrivingTestModalOpen(false)} />}
        </>
    );
};

export default WishlistPage;
