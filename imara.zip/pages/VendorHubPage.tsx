
import React, { useState, useEffect } from 'react';
import type { Product, ShopProfile, Partner, TravelService, GistPost } from '../types.ts';
import { ServiceType, VendorType } from '../types.ts';
import Button from '../components/ui/Button.tsx';
import VendorDashboard from '../components/vendor/VendorDashboard.tsx';
import TravelPartnerDashboard from '../components/vendor/TravelPartnerDashboard.tsx';
import AdvertiserDashboard from '../components/ads/AdvertiserDashboard.tsx';
import VendorOnboardingGuide from '../components/vendor/VendorOnboardingGuide.tsx';
import { mockProducts, mockTravelServices } from '../data/mockData.ts';
import AddProductModal from '../components/modals/AddProductModal.tsx';
import AddServiceModal from '../components/modals/AddServiceModal.tsx';
import ShopProfileModal from '../components/modals/ShopProfileModal.tsx';
import PayoutSetupModal from '../components/modals/PayoutSetupModal.tsx';
import PoliciesModal from '../components/modals/PoliciesModal.tsx';
import PostToGistModal from '../components/modals/PostToGistModal.tsx';
import { ChartBarIcon, StorefrontIcon, BriefcaseIcon } from '../components/icons/Icons.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';

const VendorHubPage: React.FC = () => {
    const { user } = useAuth();
    
    // Default to the mock partner if no user is found (or wait for user context to load)
    const activePartner = user ? {
        id: user.id,
        role: user.role,
        fullName: user.fullName,
        brandName: user.fullName,
        email: user.email,
        phone: '',
        joinedDate: new Date().toISOString(),
        isActive: true,
        story: 'Passionate partner of Imara.',
        storeSlug: user.fullName.toLowerCase().replace(/\s+/g, '-'),
        vendorType: 'Other',
        isVerified: user.isVerified || false,
        trustScore: user.trustScore || 50
    } as Partner : {
        id: 'vendor_mock_1',
        role: 'vendor',
        fullName: 'Adinkra Team',
        brandName: 'Adinkra Crafts',
        email: 'hello@adinkra.test',
        phone: '+233 55 000 0000',
        joinedDate: new Date().toISOString(),
        isActive: true,
        story: 'Authentic crafts from the heart of Accra.',
        storeSlug: 'adinkra-crafts',
        vendorType: 'Artisan',
        isVerified: true,
        trustScore: 95
    } as Partner;
    
    // States for different partner types
    const [vendorProducts, setVendorProducts] = useState<Product[]>(() => mockProducts.filter(p => p.vendor === activePartner.brandName));
    const [travelServices, setTravelServices] = useState<TravelService[]>(() => mockTravelServices.filter(s => s.providerName === 'Africa World Airlines'));
    const [scheduledPosts, setScheduledPosts] = useState<GistPost[]>([]);
    
    const [shopProfile, setShopProfile] = useState<ShopProfile>({
        brandName: 'Adinkra Crafts',
        story: 'We are dedicated to preserving the rich heritage of Ghanaian crafts...',
        logoUrl: 'https://picsum.photos/seed/adinkra-logo/200/200',
        bannerUrl: 'https://picsum.photos/seed/adinkra-banner/1200/400',
    });

    // View Toggle
    const [view, setView] = useState<'store' | 'ads' | 'jobs'>('store');

    // Modal states
    const [isAddProductModalOpen, setIsAddProductModalOpen] = useState(false);
    const [isAddServiceModalOpen, setIsAddServiceModalOpen] = useState(false);
    const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
    const [isPayoutModalOpen, setIsPayoutModalOpen] = useState(false);
    const [isPoliciesModalOpen, setIsPoliciesModalOpen] = useState(false);
    const [postingItem, setPostingItem] = useState<Product | TravelService | null>(null);

    const handleAddProduct = (newProductData: Omit<Product, 'id' | 'vendor' | 'isVerified' | 'impactPerPurchase'>) => {
        if (activePartner.role !== 'vendor') return;
        const newProduct: Product = {
            ...newProductData,
            id: crypto.randomUUID(),
            vendor: activePartner.brandName,
            isVerified: false,
            impactPerPurchase: 'Supports local craftsmanship',
            marketId: newProductData.marketId,
        };
        setVendorProducts(prev => [...prev, newProduct]);
        setIsAddProductModalOpen(false);
    };

    const handleBatchAddProducts = (products: any[]) => {
        if (activePartner.role !== 'vendor') return;
        const newProducts = products.map(p => ({
            ...p,
            id: crypto.randomUUID(),
            vendor: activePartner.brandName,
            isVerified: false,
            impactPerPurchase: 'Supports local craftsmanship',
        }));
        setVendorProducts(prev => [...prev, ...newProducts]);
    };

    const handleAddService = (newServiceData: Omit<TravelService, 'id' | 'providerName' | 'rating'>) => {
        if (activePartner.role !== 'travel') return;
        const newService: TravelService = {
            ...newServiceData,
            id: crypto.randomUUID(),
            providerName: activePartner.brandName,
            rating: 0, // New services can start with 0 rating
        };
        setTravelServices(prev => [...prev, newService]);
        setIsAddServiceModalOpen(false);
    };

    const handleProfileSave = (updatedProfile: ShopProfile) => {
        setShopProfile(updatedProfile);
        setIsProfileModalOpen(false);
    };

    const handlePostToGist = (post: GistPost) => {
        if (post.status === 'scheduled') {
            setScheduledPosts(prev => [...prev, post]);
            alert('Your post has been scheduled!');
        } else {
            try {
                const storedPosts = localStorage.getItem('imara_gist_posts');
                const currentPosts = storedPosts ? JSON.parse(storedPosts) : [];
                const newPosts = [post, ...currentPosts];
                localStorage.setItem('imara_gist_posts', JSON.stringify(newPosts));
                alert('Your post has been successfully added to the Gist feed!');
            } catch (error) {
                console.error("Failed to post to Gist:", error);
                alert('There was an error creating your post.');
            }
        }
    };

    const renderDashboard = () => {
        if (view === 'jobs') {
            return (
                <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100">
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-2xl font-display font-bold text-brand-navy-dark">Job Postings</h2>
                        <Button>Post New Job</Button>
                    </div>
                    <div className="text-center py-12 bg-gray-50 rounded-lg border-2 border-dashed border-gray-200">
                        <BriefcaseIcon className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                        <h3 className="text-lg font-bold text-gray-700">No Job Postings Yet</h3>
                        <p className="text-gray-500 mt-1 max-w-sm mx-auto">As a verified partner, you can post jobs to find the best talent across Africa.</p>
                    </div>
                </div>
            );
        }

        if (view === 'ads') {
            return <AdvertiserDashboard />;
        }

        switch (activePartner.role) {
            case 'vendor':
                return <VendorDashboard 
                            partner={activePartner}
                            products={vendorProducts}
                            onAddNewProduct={() => setIsAddProductModalOpen(true)}
                            onBatchAddProduct={handleBatchAddProducts}
                            onPostToGist={setPostingItem}
                            scheduledPosts={scheduledPosts}
                        />;
            case 'travel':
                return <TravelPartnerDashboard
                            partnerName={activePartner.brandName}
                            services={travelServices}
                            onAddNewService={() => setIsAddServiceModalOpen(true)}
                            onPostToGist={setPostingItem}
                        />;
            case 'workman':
                // Redirect to /workman or render workman dashboard
                return <p>Workman dashboard coming soon.</p>;
            default:
                return <p>Invalid partner type.</p>;
        }
    };

    return (
        <>
            <div className="container mx-auto px-6 py-12">
                <div className="max-w-7xl mx-auto">
                    <div className="flex justify-end mb-6">
                        <div className="bg-white p-1 rounded-lg shadow-sm flex gap-1">
                            <button 
                                onClick={() => setView('store')} 
                                className={`px-4 py-2 text-sm font-bold rounded-md flex items-center gap-2 transition-colors ${view === 'store' ? 'bg-brand-green-dark text-white' : 'text-gray-500 hover:bg-gray-100'}`}
                            >
                                <StorefrontIcon className="w-4 h-4" /> Store
                            </button>
                            <button 
                                onClick={() => setView('ads')} 
                                className={`px-4 py-2 text-sm font-bold rounded-md flex items-center gap-2 transition-colors ${view === 'ads' ? 'bg-brand-gold text-brand-navy-dark' : 'text-gray-500 hover:bg-gray-100'}`}
                            >
                                <ChartBarIcon className="w-4 h-4" /> Ads
                            </button>
                            {activePartner.isVerified && (
                                <button 
                                    onClick={() => setView('jobs')} 
                                    className={`px-4 py-2 text-sm font-bold rounded-md flex items-center gap-2 transition-colors ${view === 'jobs' ? 'bg-brand-navy-dark text-white' : 'text-gray-500 hover:bg-gray-100'}`}
                                >
                                    <BriefcaseIcon className="w-4 h-4" /> Jobs
                                </button>
                            )}
                        </div>
                    </div>

                    {!activePartner.isVerified && (
                        <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-700 rounded-xl p-4 mb-8 flex items-center justify-between">
                            <div>
                                <h3 className="text-yellow-800 dark:text-yellow-500 font-bold">Account Verification Pending</h3>
                                <p className="text-yellow-700 dark:text-yellow-600 text-sm mt-1">Your partner account is curently under review. You can set up your store and products, but they will not be visible to the public until approved by Imara admins.</p>
                            </div>
                        </div>
                    )}

                   {renderDashboard()}
                </div>
            </div>
            {isAddProductModalOpen && activePartner.role === 'vendor' && (
                <AddProductModal 
                    onClose={() => setIsAddProductModalOpen(false)}
                    onAddProduct={handleAddProduct}
                />
            )}
             {isAddServiceModalOpen && activePartner.role === 'travel' && (
                <AddServiceModal
                    onClose={() => setIsAddServiceModalOpen(false)}
                    onAddService={handleAddService}
                    allowedServices={activePartner.serviceTypes}
                />
            )}
            {isProfileModalOpen && shopProfile && (
                <ShopProfileModal
                    profile={shopProfile}
                    onClose={() => setIsProfileModalOpen(false)}
                    onSave={handleProfileSave}
                />
            )}
            {isPayoutModalOpen && (
                <PayoutSetupModal onClose={() => setIsPayoutModalOpen(false)} />
            )}
            {isPoliciesModalOpen && (
                <PoliciesModal onClose={() => setIsPoliciesModalOpen(false)} />
            )}
             {postingItem && (
                <PostToGistModal
                    item={postingItem}
                    partner={activePartner}
                    onClose={() => setPostingItem(null)}
                    onPost={handlePostToGist}
                />
            )}
        </>
    );
};

export default VendorHubPage;
