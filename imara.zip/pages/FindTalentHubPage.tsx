
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { UsersIcon, BriefcaseIcon, SearchIcon, GlobeIcon, CheckCircleIcon, SparklesIcon, StorefrontIcon, HomeIcon } from '../components/icons/Icons.tsx';
import { useLanguage } from '../contexts/LanguageContext.tsx';
import Button from '../components/ui/Button.tsx';

const CategoryPill: React.FC<{ icon: React.ReactNode; label: string; onClick?: () => void }> = ({ icon, label, onClick }) => (
    <div 
        onClick={onClick}
        className="flex flex-col items-center justify-center p-4 bg-white dark:bg-gray-800 rounded-2xl shadow-sm hover:shadow-md transition-all cursor-pointer hover:-translate-y-1 min-w-[100px]" 
        title={`Filter by ${label}`}
    >
        <div className="p-3 bg-brand-off-white dark:bg-gray-700 rounded-full mb-2 text-brand-navy-dark dark:text-brand-gold">
            {icon}
        </div>
        <span className="text-xs font-bold text-gray-700 dark:text-gray-300 text-center">{label}</span>
    </div>
);

const FindTalentHubPage: React.FC = () => {
    const { t } = useLanguage();
    const navigate = useNavigate();
    const [searchTerm, setSearchTerm] = useState('');

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        navigate(`/marketplace?search=${searchTerm}`);
    };

    return (
        <div className="min-h-[calc(100vh-64px)] bg-gradient-to-br from-[#F0F4F8] to-[#E2E8F0] dark:from-gray-900 dark:to-brand-navy-dark relative overflow-hidden font-sans">
            
            {/* Abstract Background Blobs */}
            <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
                <div className="absolute top-[-10%] left-[-5%] w-96 h-96 bg-blue-200/30 dark:bg-blue-900/20 rounded-full blur-3xl"></div>
                <div className="absolute bottom-[10%] right-[-5%] w-96 h-96 bg-purple-200/30 dark:bg-purple-900/20 rounded-full blur-3xl"></div>
            </div>

            {/* Home Button */}
            <Link 
                to="/" 
                className="absolute top-6 left-6 z-50 p-3 bg-white/80 dark:bg-black/30 hover:bg-white dark:hover:bg-black/50 rounded-full shadow-md backdrop-blur-md text-gray-600 dark:text-white transition-all"
                title="Back to Toast Feed"
            >
                <HomeIcon className="w-5 h-5" />
            </Link>

            <div className="container mx-auto px-4 py-12 relative z-10">
                
                {/* Hero Section */}
                <div className="text-center max-w-3xl mx-auto mb-12 pt-8">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/50 dark:bg-white/10 backdrop-blur-sm border border-white/20 mb-4 animate-fade-in-down">
                        <SparklesIcon className="w-4 h-4 text-brand-gold" />
                        <span className="text-xs font-bold text-brand-navy-dark dark:text-white">#1 Platform for African Professionals</span>
                    </div>
                    <h1 className="text-4xl md:text-6xl font-display font-extrabold text-brand-navy-dark dark:text-white leading-tight mb-4">
                        Connecting African <br/>
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-green to-brand-gold">Talent to the World</span>
                    </h1>
                    <p className="text-lg text-gray-600 dark:text-gray-300 mb-8">
                        Find the perfect professional for your project or discover your next career opportunity. Verified, skilled, and ready to work.
                    </p>

                    {/* Floating Search Bar (Pill Shape) */}
                    <form onSubmit={handleSearch} className="bg-white dark:bg-gray-800 p-2 rounded-full shadow-xl flex flex-col sm:flex-row items-center max-w-2xl mx-auto border border-gray-100 dark:border-gray-700">
                        <div className="flex items-center px-4 flex-grow w-full sm:w-auto mb-2 sm:mb-0">
                            <SearchIcon className="w-5 h-5 text-gray-400 mr-3" />
                            <input 
                                type="text" 
                                placeholder="Ex. Graphic Designer, Plumber..." 
                                className="w-full bg-transparent border-none focus:ring-0 text-gray-800 dark:text-white placeholder:text-gray-400"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>
                        <div className="hidden sm:block w-px h-8 bg-gray-200 dark:bg-gray-700 mx-2"></div>
                        <div className="flex items-center gap-2 w-full sm:w-auto">
                            <select className="bg-transparent text-sm font-semibold text-gray-600 dark:text-gray-300 focus:ring-0 border-none cursor-pointer" title="Search Category">
                                <option>Talent</option>
                                <option>Jobs</option>
                            </select>
                            <Button type="submit" className="rounded-full px-8 py-3 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all bg-brand-navy-dark text-white" title="Search Talent">
                                Search
                            </Button>
                        </div>
                    </form>
                </div>

                {/* Dual Action Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto mb-16">
                    
                    {/* Find Opportunity (Candidate) */}
                    <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 group relative overflow-hidden border border-gray-100 dark:border-gray-700 z-10">
                        <div className="absolute top-0 right-0 w-40 h-40 bg-blue-100 dark:bg-blue-900/30 rounded-full blur-3xl transform translate-x-10 -translate-y-10"></div>
                        <div className="relative z-30">
                            <div className="w-14 h-14 bg-blue-100 dark:bg-blue-900/50 rounded-2xl flex items-center justify-center mb-6 text-blue-600 dark:text-blue-400">
                                <BriefcaseIcon className="w-8 h-8" />
                            </div>
                            <h2 className="text-2xl font-display font-bold text-brand-navy-dark dark:text-white mb-2">Find Your Next Opportunity</h2>
                            <p className="text-gray-500 dark:text-gray-400 mb-8">Explore thousands of jobs from top companies across Africa and beyond.</p>
                            <Link to="/find-job">
                                <Button className="rounded-full w-full sm:w-auto bg-brand-navy-dark text-white hover:bg-blue-700" title="Browse Jobs">
                                    Search Jobs
                                </Button>
                            </Link>
                        </div>
                    </div>

                    {/* Build Team (Employer) */}
                    <div className="bg-[#FFF9F0] dark:bg-brand-navy-dark/50 rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 group relative overflow-hidden border border-orange-100 dark:border-gray-700 z-10">
                         <div className="absolute top-0 right-0 w-40 h-40 bg-orange-100 dark:bg-orange-900/30 rounded-full blur-3xl transform translate-x-10 -translate-y-10"></div>
                        <div className="relative z-30">
                            <div className="w-14 h-14 bg-orange-100 dark:bg-orange-900/50 rounded-2xl flex items-center justify-center mb-6 text-orange-600 dark:text-orange-400">
                                <UsersIcon className="w-8 h-8" />
                            </div>
                            <h2 className="text-2xl font-display font-bold text-brand-navy-dark dark:text-white mb-2">Build Your Dream Team</h2>
                            <p className="text-gray-500 dark:text-gray-400 mb-8">Hire verified professionals for projects, full-time roles, or gigs.</p>
                            <Link to="/marketplace">
                                <Button className="rounded-full w-full sm:w-auto !bg-green-600 hover:!bg-green-700 text-white border-none" title="Find Professionals">
                                    Hire Talent
                                </Button>
                            </Link>
                        </div>
                        <img src="https://cdn3d.iconscout.com/3d/premium/thumb/teamwork-3025714-2526912.png" className="absolute bottom-[-20px] right-[-20px] w-40 h-40 opacity-100 group-hover:scale-110 transition-all duration-500 z-20 pointer-events-none" alt="Team" />
                    </div>
                </div>

                {/* Categories / Trusted By */}
                <div className="max-w-4xl mx-auto mb-20">
                    <h3 className="text-center text-sm font-bold uppercase tracking-widest text-gray-400 mb-6">Popular Categories</h3>
                    <div className="flex flex-wrap justify-center gap-4">
                        <CategoryPill icon={<BriefcaseIcon className="w-5 h-5"/>} label="Business" />
                        <CategoryPill icon={<SparklesIcon className="w-5 h-5"/>} label="Creative" />
                        <CategoryPill icon={<GlobeIcon className="w-5 h-5"/>} label="Tech & IT" />
                        <CategoryPill icon={<StorefrontIcon className="w-5 h-5"/>} label="Traders" />
                    </div>
                </div>

            </div>
        </div>
    );
};

export default FindTalentHubPage;
