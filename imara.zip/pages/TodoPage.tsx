import React, { useState } from 'react';
import type { Todo } from '../types';
import Button from '../components/ui/Button.tsx';
import TodoItem from '../components/todo/TodoItem.tsx';
import { PlusIcon } from '../components/icons/Icons.tsx';

const TodoPage: React.FC = () => {
    const [todos, setTodos] = useState<Todo[]>([
        { id: '1', text: 'Review vendor applications', completed: false },
        { id: '2', text: 'Plan next marketing campaign', completed: false },
        { id: '3', text: 'Update product descriptions', completed: true },
    ]);
    const [inputText, setInputText] = useState('');

    const handleAddTask = (e: React.FormEvent) => {
        e.preventDefault();
        if (inputText.trim() === '') return;

        const newTodo: Todo = {
            id: crypto.randomUUID(),
            text: inputText,
            completed: false,
        };
        setTodos(prev => [...prev, newTodo]);
        setInputText('');
    };

    const handleToggleTodo = (id: string) => {
        setTodos(prev =>
            prev.map(todo =>
                todo.id === id ? { ...todo, completed: !todo.completed } : todo
            )
        );
    };

    const handleDeleteTodo = (id: string) => {
        setTodos(prev => prev.filter(todo => todo.id !== id));
    };

    const activeTasks = todos.filter(t => !t.completed).length;

    return (
        <div className="container mx-auto px-6 py-12">
            <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg p-8">
                <div className="flex justify-between items-center mb-6">
                    <div>
                        <h1 className="text-3xl font-display font-bold text-brand-green-dark">My Tasks</h1>
                        <p className="text-brand-gray mt-1">
                            You have {activeTasks} active task{activeTasks !== 1 ? 's' : ''} remaining.
                        </p>
                    </div>
                </div>

                <form onSubmit={handleAddTask} className="flex gap-3 mb-6">
                    <input
                        type="text"
                        value={inputText}
                        onChange={(e) => setInputText(e.target.value)}
                        placeholder="e.g. Finalize quarterly report"
                        className="flex-grow p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-brand-gold focus:border-brand-gold transition"
                        aria-label="New task input"
                    />
                    <Button type="submit" size="md" className="flex-shrink-0">
                        <PlusIcon className="w-5 h-5" />
                        <span className="sr-only">Add Task</span>
                    </Button>
                </form>

                <ul className="space-y-3">
                    {todos.map(todo => (
                        <TodoItem
                            key={todo.id}
                            todo={todo}
                            onToggle={handleToggleTodo}
                            onDelete={handleDeleteTodo}
                        />
                    ))}
                </ul>
            </div>
        </div>
    );
};

export default TodoPage;
