import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { mockTravelPartners, mockTravelServices } from '../data/mockData';
import type { TravelService } from '../types';
import ServiceCard from '../components/shared/ServiceCard';
import Button from '../components/ui/Button';
import { GlobeIcon } from '../components/icons/Icons';
import { useCart } from '../contexts/CartContext';
import BookingModal from '../components/modals/BookingModal';
import BackButton from '../components/ui/BackButton';

const TravelPartnerPage: React.FC = () => {
    const { slug } = useParams<{ slug: string }>();
    const { addToCart } = useCart();
    const [bookingService, setBookingService] = useState<TravelService | null>(null);

    const partner = mockTravelPartners.find(p => p.storeSlug === slug);
    const partnerServices = mockTravelServices.filter(s => s.providerName === partner?.brandName);
    
    if (!partner) {
        return (
             <div className="container mx-auto px-6 py-20 text-center">
                <h1 className="text-3xl font-display font-bold text-brand-green-dark">Partner Not Found</h1>
                <p className="mt-4 text-brand-gray">The travel partner you are looking for does not exist.</p>
                <Link to="/feel-afro" className="mt-6 inline-block">
                    <Button variant="primary" size="lg">Back to FeelAfro</Button>
                </Link>
            </div>
        );
    }
    
    const bannerUrl = `https://picsum.photos/seed/${partner.storeSlug}-banner/1600/400`;

    return (
        <>
            <div className="bg-white">
                {/* Banner and Header */}
                <div className="relative bg-brand-green h-48 md:h-64">
                    <img src={bannerUrl} alt={`${partner.brandName} banner`} className="w-full h-full object-cover opacity-20" />
                    <div className="absolute inset-0 bg-gradient-to-t from-brand-green to-transparent"></div>
                    <div className="absolute bottom-0 left-0 right-0 container mx-auto px-6 py-8">
                        <div className="flex flex-col sm:flex-row items-center gap-6">
                             <img src={partner.brandLogoUrl} alt={`${partner.brandName} logo`} className="w-32 h-32 rounded-full object-cover border-4 border-white bg-white shadow-lg -mb-16 sm:-mb-8" />
                             <div className="text-center sm:text-left pt-16 sm:pt-0">
                                <h1 className="text-4xl font-display font-bold text-white">{partner.brandName}</h1>
                                <div className="flex items-center justify-center sm:justify-start gap-2 mt-2 text-brand-gold-light">
                                    <GlobeIcon className="w-5 h-5" />
                                    <span>{partner.country}</span>
                                </div>
                             </div>
                        </div>
                    </div>
                </div>

                <div className="container mx-auto px-6 py-16">
                    <BackButton text="Back to FeelAfro" className="mb-8" />
                     <h2 className="text-2xl font-display font-semibold text-brand-green-dark mb-6">Services from {partner.brandName}</h2>
                     {partnerServices.length > 0 ? (
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                            {partnerServices.map((service) => (
                                <ServiceCard 
                                    key={service.id}
                                    service={service}
                                    onAddToCart={addToCart}
                                    onBookNow={setBookingService}
                                />
                            ))}
                        </div>
                     ) : (
                        <p className="text-center text-gray-500 py-16">This partner has not listed any services yet.</p>
                     )}
                </div>
            </div>
            {bookingService && (
                <BookingModal service={bookingService} onClose={() => setBookingService(null)} />
            )}
        </>
    );
};

export default TravelPartnerPage;