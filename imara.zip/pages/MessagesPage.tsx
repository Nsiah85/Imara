
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { mockAllUsersAndPartners } from '../data/mockData.ts';
import type { Conversation, DirectConversation, GroupConversation } from '../types.ts';
import ConversationList from '../components/messages/ConversationList.tsx';
import ChatView from '../components/messages/ChatView.tsx';
import ChatProfileSidebar from '../components/messages/ChatProfileSidebar.tsx';
import { ChatDotsIcon, Bars3Icon, XIcon, HomeIcon, PlusCircleIcon, SearchIcon } from '../components/icons/Icons.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';
import NewMessageModal from '../components/modals/NewMessageModal.tsx';
import CreateGroupModal from '../components/modals/CreateGroupModal.tsx';
import { useCall } from '../contexts/CallContext.tsx';
import LoadingSpinner from '../components/ui/LoadingSpinner.tsx';
import GoLiveModal from '../components/modals/GoLiveModal.tsx';
import { ChatSettings } from '../components/modals/ChatSettingsModal.tsx';
import Button from '../components/ui/Button.tsx';

const MessagesPage: React.FC = () => {
    const { user, isLoading, refreshGossipCount } = useAuth();
    const { startCall } = useCall();
    const [conversations, setConversations] = useState<Conversation[]>([]);
    const { conversationId } = useParams<{ conversationId?: string }>();
    const navigate = useNavigate();
    
    const [isNewGossipOpen, setIsNewGossipOpen] = useState(false);
    const [isCreateGroupModalOpen, setIsCreateGroupModalOpen] = useState(false);
    const [isGoLiveModalOpen, setIsGoLiveModalOpen] = useState(false);
    const [isTyping, setIsTyping] = useState(false);
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);

    // Lifted Chat Settings State
    const [chatSettings, setChatSettings] = useState<ChatSettings>({ wallpaper: 'default', bubbleColor: 'bg-brand-gold text-brand-navy-dark' });
    const [notification, setNotification] = useState<{ message: string; title: string } | null>(null);

    // Mock real-time listener for incoming messages
    useEffect(() => {
        const handleStorageChange = (e: StorageEvent) => {
            if (e.key === `imara_chats_${user?.id}` && e.newValue) {
                try {
                    const newChats = JSON.parse(e.newValue) as Conversation[];
                    const currentChatIds = new Set(conversations.map(c => c.id));
                    const newChat = newChats.find(c => !currentChatIds.has(c.id) || c.messages.length > (conversations.find(oc => oc.id === c.id)?.messages.length || 0));
                    
                    if (newChat) {
                        const latestMsg = newChat.messages[newChat.messages.length - 1];
                        // Don't notify if user is currently active in this chat and sending a message
                        if (newChat.id !== conversationId || latestMsg.senderId !== user?.id) {
                            setNotification({
                                title: newChat.type === 'direct' ? (newChat as DirectConversation).participant.name : newChat.id,
                                message: latestMsg.content.type === 'text' ? latestMsg.content.text : (latestMsg.content.type === 'image' ? 'Sent an image' : 'Sent an attachment')
                            });
                            // Auto dismiss notification
                            setTimeout(() => setNotification(null), 5000);
                        }
                    }
                    setConversations(newChats);
                } catch(error) {
                    // Ignore parsing errors
                }
            }
        };
        window.addEventListener('storage', handleStorageChange);
        return () => window.removeEventListener('storage', handleStorageChange);
    }, [user, conversations, conversationId]);

    useEffect(() => {
        if (!isLoading && !user) navigate('/login', { replace: true });
    }, [user, isLoading, navigate]);
    
    // Initialize conversations from LocalStorage
    useEffect(() => {
        if (user) {
            const key = `imara_chats_${user.id}`;
            const stored = localStorage.getItem(key);
            
            if (stored) {
                setConversations(JSON.parse(stored));
            } else {
                // NEW USER INITIALIZATION: Only System Chats
                const systemChats: Conversation[] = [
                     {
                        id: 'system_toast_feed',
                        type: 'direct',
                        isUnread: true,
                        participant: { 
                            id: 'system_toast_feed', 
                            name: 'Toast Feed', 
                            avatarUrl: '', // Will use Monkix icon in Avatar component via ID
                            role: 'System' 
                        },
                        messages: [
                            { 
                                id: 'sys_msg_1', 
                                senderId: 'system_toast_feed', 
                                content: { type: 'text', text: 'Welcome to your Toast Feed! Stay tuned for updates on your orders and community news.' }, 
                                timestamp: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) 
                            }
                        ]
                    },
                    {
                        id: 'imara_ai_chat',
                        type: 'direct',
                        isUnread: true,
                        participant: { 
                            id: 'imara_ai', 
                            name: 'Monkix AI', 
                            avatarUrl: '', // Will use Imara logo via ID
                            role: 'Assistant',
                            isVerified: true
                        },
                        messages: [
                            { 
                                id: 'ai_msg_1', 
                                senderId: 'imara_ai', 
                                content: { type: 'text', text: user.role === 'user' ? 'Hello! I can help you find products or track your impact.' : 'Hello Partner! I can help you optimize your store.' }, 
                                timestamp: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) 
                            }
                        ]
                    }
                ];
                
                setConversations(systemChats);
                localStorage.setItem(key, JSON.stringify(systemChats));
                refreshGossipCount(); // Update the header badge
            }
        }
    }, [user]);

    // Mark as read when opening a conversation
    useEffect(() => {
        if (conversationId && user && conversations.length > 0) {
            // Find if the current conversation is marked unread
            const targetConv = conversations.find(c => c.id === conversationId);
            
            // Only update state if it is actually unread to prevent loops/re-renders
            if (targetConv && targetConv.isUnread) {
                const updatedConversations = conversations.map(c => 
                    c.id === conversationId ? { ...c, isUnread: false } : c
                );
                
                setConversations(updatedConversations);
                localStorage.setItem(`imara_chats_${user.id}`, JSON.stringify(updatedConversations));
                refreshGossipCount();
            }
        }
    }, [conversationId, user, conversations, refreshGossipCount]);

    const activeConversation = conversations.find(c => c.id === conversationId);

    const handleArchive = (id: string) => {
        const updated = conversations.map(c => c.id === id ? { ...c, isArchived: true } : c);
        setConversations(updated);
        if (user) localStorage.setItem(`imara_chats_${user.id}`, JSON.stringify(updated));
    };

    const handleHide = (id: string) => {
        const updated = conversations.filter(c => c.id !== id);
        setConversations(updated);
        if (user) localStorage.setItem(`imara_chats_${user.id}`, JSON.stringify(updated));
    };

    const handleStartConversation = (participant: { id: string; name: string; avatarUrl: string; isOnline?: boolean }) => {
        const participantObj = {
            id: participant.id,
            name: participant.name,
            avatarUrl: participant.avatarUrl,
            isOnline: participant.isOnline,
            role: 'User'
        };
        const newConv: DirectConversation = {
            id: `direct_${Date.now()}`,
            type: 'direct',
            participant: participantObj,
            messages: [],
            isUnread: false
        };
        const updated = [newConv, ...conversations];
        setConversations(updated);
        if (user) localStorage.setItem(`imara_chats_${user.id}`, JSON.stringify(updated));
        setIsNewGossipOpen(false);
        navigate(`/messages/${newConv.id}`);
    };

    const handleCreateGroup = (groupData: { name: string; participants: { id: string; name: string; avatarUrl: string; role?: string }[] }) => {
        const newGroupConv: GroupConversation = {
            id: `group_${Date.now()}`,
            type: 'group',
            groupName: groupData.name,
            groupAvatarUrl: '', // Default group avatar
            participants: groupData.participants.map(p => ({
                id: p.id,
                name: p.name,
                avatarUrl: p.avatarUrl,
                role: p.role || 'User'
            })),
            adminIds: [],
            messages: [{
                id: `msg_${Date.now()}`,
                senderId: 'system',
                content: { type: 'text', text: `You created group "${groupData.name}"` },
                timestamp: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})
            }],
            isUnread: false
        };
        const updated = [newGroupConv, ...conversations];
        setConversations(updated);
        if (user) localStorage.setItem(`imara_chats_${user.id}`, JSON.stringify(updated));
        setIsCreateGroupModalOpen(false);
        navigate(`/messages/${newGroupConv.id}`);
    };

    if (isLoading || !user) {
        return <div className="flex items-center justify-center h-screen"><LoadingSpinner /></div>;
    }

    return (
        <>
            {/* Real-time Notification Overlay */}
            {notification && (
                <div className="fixed top-24 right-6 z-[60] animate-fade-in shadow-[0_10px_40px_rgba(0,0,0,0.5)] transition-all">
                    <div className="bg-brand-navy-dark text-white p-4 rounded-xl border border-brand-gold flex items-start gap-3 w-80">
                        <div className="bg-brand-gold/20 p-2 rounded-full text-brand-gold shrink-0">
                            <ChatDotsIcon className="w-5 h-5" />
                        </div>
                        <div className="flex-1 truncate">
                            <h4 className="font-bold text-sm text-brand-gold mb-0.5">{notification.title}</h4>
                            <p className="text-xs text-gray-300 truncate">{notification.message}</p>
                        </div>
                        <button onClick={() => setNotification(null)} className="text-gray-400 hover:text-white transition-colors shrink-0">
                            <XIcon className="w-4 h-4" />
                        </button>
                    </div>
                </div>
            )}

            {/* Desktop/Tablet Exit Button */}
            <Link 
                to="/" 
                className="fixed top-4 left-4 z-50 p-2.5 bg-black/20 hover:bg-black/40 text-white rounded-full backdrop-blur-md hidden lg:flex items-center justify-center transition-all shadow-lg" 
                title="Back to Home"
            >
                <XIcon className="w-5 h-5" />
            </Link>

            <div className="h-screen flex bg-gray-100 dark:bg-gray-900 overflow-hidden relative">
                
                {/* Left Column: Profile & Settings Sidebar */}
                {/* Desktop: Always visible. Mobile/Tablet: Drawer */}
                <div className={`
                    fixed inset-y-0 left-0 z-40 w-[320px] bg-brand-navy-dark transform transition-transform duration-300 ease-in-out border-r border-gray-800
                    lg:relative lg:translate-x-0 lg:block lg:flex-shrink-0
                    ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
                `}>
                    {/* Mobile Close Button */}
                    <div className="lg:hidden absolute top-4 right-4 z-50">
                        <button onClick={() => setIsSidebarOpen(false)} className="p-2 bg-white/10 rounded-full text-white hover:bg-white/20">
                            <XIcon className="w-5 h-5" />
                        </button>
                    </div>
                    <ChatProfileSidebar onSettingsChange={setChatSettings} currentSettings={chatSettings} />
                </div>
                
                {/* Mobile Sidebar Overlay */}
                {isSidebarOpen && (
                    <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={() => setIsSidebarOpen(false)}></div>
                )}

                {/* Middle Column: Conversation List */}
                <div className={`flex-col w-full md:w-[380px] bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 ${conversationId ? 'hidden md:flex' : 'flex'}`}>
                    {/* Mobile Sidebar Toggle Header */}
                    <div className="lg:hidden p-4 border-b border-gray-100 dark:border-gray-700 flex items-center gap-3 bg-brand-off-white dark:bg-gray-900">
                        <button onClick={() => setIsSidebarOpen(true)} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800 text-brand-navy-dark dark:text-white">
                            <Bars3Icon className="w-6 h-6" />
                        </button>
                        <span className="font-bold text-brand-navy-dark dark:text-white text-lg">Gossip</span>
                        <div className="ml-auto">
                            <Link to="/">
                                <button className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800 text-gray-500">
                                    <HomeIcon className="w-5 h-5" />
                                </button>
                            </Link>
                        </div>
                    </div>
                    
                    <ConversationList
                        conversations={conversations}
                        activeConversationId={conversationId}
                        onNewMessage={() => setIsNewGossipOpen(true)}
                        onCreateGroup={() => setIsCreateGroupModalOpen(true)}
                        onDeleteConversation={handleHide}
                    />
                </div>

                {/* Right Column: Active Chat View */}
                <div className={`flex-1 bg-brand-off-white dark:bg-gray-900 flex flex-col relative ${conversationId ? 'flex' : 'hidden md:flex'}`}>
                    {activeConversation ? (
                        <ChatView
                            conversation={activeConversation}
                            onSendMessage={() => {}}
                            isTyping={isTyping}
                            onInitiateCall={(type) => {
                                if (activeConversation.type === 'direct') {
                                    startCall(activeConversation.participant, type);
                                }
                            }}
                            settings={chatSettings}
                        />
                    ) : (
                        <div className="flex flex-col items-center justify-center h-full text-center text-gray-400 p-8">
                            <div className="w-32 h-32 bg-white dark:bg-gray-800 rounded-full flex items-center justify-center mb-6 shadow-lg animate-float">
                                <ChatDotsIcon className="w-16 h-16 text-brand-gold" />
                            </div>
                            <h2 className="text-2xl font-display font-bold text-brand-navy-dark dark:text-white">Select a conversation</h2>
                            <p className="text-md text-gray-500 mt-2 max-w-xs">Choose a chat from the list or start a new one to connect with your community.</p>
                            <Button className="mt-6" onClick={() => setIsNewGossipOpen(true)}>Start New Gossip</Button>
                        </div>
                    )}
                </div>
            </div>

            {isNewGossipOpen && <NewMessageModal allUsers={mockAllUsersAndPartners} onClose={() => setIsNewGossipOpen(false)} onStartConversation={handleStartConversation} />}
            {isCreateGroupModalOpen && <CreateGroupModal allUsers={mockAllUsersAndPartners} onClose={() => setIsCreateGroupModalOpen(false)} onCreateGroup={handleCreateGroup} />}
            {isGoLiveModalOpen && <GoLiveModal onClose={() => setIsGoLiveModalOpen(false)} />}
        </>
    );
};

export default MessagesPage;
