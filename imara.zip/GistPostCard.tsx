// This file is deprecated. Please use components/gist/GistPostCard.tsx instead.
