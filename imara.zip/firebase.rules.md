# Firebase Security Rules Examples

These rules are examples and should be tested and adapted for your specific application needs.

---

## Firestore Rules (`firestore.rules`)

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
  
    // Helper function to check if a user is authenticated
    function isAuthenticated() {
      return request.auth != null;
    }
    
    // Helper function to check if a user is an admin
    function isAdmin() {
      return isAuthenticated() && get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }

    // --- Users Collection ---
    match /users/{userId} {
      // Anyone can create their own user document (on signup)
      allow create: if isAuthenticated() && request.auth.uid == userId;
      // Any authenticated user can read public user profiles
      allow read: if isAuthenticated();
      // Users can only update their own profile; admins can update any
      allow update: if (isAuthenticated() && request.auth.uid == userId) || isAdmin();
    }
    
    // --- Toasts (Gist Posts) Collection ---
    match /toasts/{toastId} {
      // Any authenticated user can create a toast
      allow create: if isAuthenticated();
      // Any authenticated user can read toasts
      allow read: if isAuthenticated();
      // Users can only update/delete their own toasts; admins can manage any
      allow update, delete: if (isAuthenticated() && resource.data.creatorId == request.auth.uid) || isAdmin();
    }
    
    // --- Products Collection ---
    match /products/{productId} {
      // Anyone can read products
      allow read: if true;
      // Only admins or the partner who owns the product can create/update it
      // Assumes a 'partnerId' field on the product document
      allow create, update: if isAdmin() || (isAuthenticated() && request.resource.data.partnerId == request.auth.uid);
      // Only admins can delete products
      allow delete: if isAdmin();
    }
    
    // --- Orders Collection ---
    match /orders/{orderId} {
      // Users can read their own orders; admins can read any
      allow read: if (isAuthenticated() && resource.data.userId == request.auth.uid) || isAdmin();
      // Users can create their own orders
      allow create: if isAuthenticated() && request.resource.data.userId == request.auth.uid;
      // Partners can update the status of orders containing their products; admins can too
      // This is a complex rule and would need a more robust data model to implement safely
      allow update: if isAdmin(); // Simplified for example
    }
  }
}
```

---

## Storage Rules (`storage.rules`)

```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
  
    // Helper function
    function isAuthenticated() {
      return request.auth != null;
    }
    
    // By default, deny all reads and writes
    match /{allPaths=**} {
      allow read, write: if false;
    }

    // --- User Profile Pictures ---
    // Path: /users/{userId}/profile.jpg
    match /users/{userId}/{fileName} {
      // Anyone can read public profile pictures
      allow read: if true;
      // Only the authenticated user can upload/update their own profile picture
      allow write: if isAuthenticated() && request.auth.uid == userId;
    }

    // --- Toast Media ---
    // Path: /toasts/{toastId}/{fileName}
    match /toasts/{toastId}/{fileName} {
      // Authenticated users can read media for toasts
      allow read: if isAuthenticated();
      // Authenticated users can upload media.
      // For more security, you could check if a corresponding toast document is being created in Firestore.
      allow write: if isAuthenticated() 
                   && request.resource.size < 50 * 1024 * 1024 // 50MB limit
                   && request.resource.contentType.matches('image/.*|video/.*');
    }
  }
}
```
