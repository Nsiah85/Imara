import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Button from './components/ui/Button.tsx';
import ImpactSummary from './components/account/ImpactSummary.tsx';
import { mockTravelServices, mockAllUsersAndPartners, mockUserOrders, mockReviews } from './data/mockData.ts';
import { useCurrency } from './contexts/CurrencyContext.tsx';
import ProfileEditModal from './components/modals/ProfileEditModal.tsx';
import { UserProfile, Booking, Rating, ImpactData, UserOrder, CartItem, Review } from './types.ts';
import { useAuth } from './contexts/AuthContext.tsx';
import { HeartIcon, Cog6ToothIcon, SparklesIcon, BookmarkIcon, UsersIcon, UserGroupIcon, StorefrontIcon, ArrowUpTrayIcon, LinkIcon, FacebookIcon, TwitterXIcon, InstagramIcon, TikTokIcon, LinkedInIcon, PencilSquareIcon } from './components/icons/Icons.tsx';
import RatingModal from './components/modals/RatingModal.tsx';
import LanguageSwitcher from './components/ui/LanguageSwitcher.tsx';
import { useLanguage } from './contexts/LanguageContext.tsx';
import UserGiftCards from './components/account/UserGiftCards.tsx';
import ThemeToggle from './components/ui/ThemeToggle.tsx';
import { useWishlist } from './contexts/WishlistContext.tsx';
import ProductCard from './components/shared/ProductCard.tsx';
import { useCart } from './contexts/CartContext.tsx';
import SavedPostsList from './components/account/SavedPostsList.tsx';
import UserConnectionsList from './components/account/UserConnectionsList.tsx';
import ToggleSwitch from './components/ui/ToggleSwitch.tsx';
import Avatar from './components/ui/Avatar.tsx';
import ReviewModal from './components/modals/ReviewModal.tsx';

type AccountTab = 'bookings' | 'orders' | 'savedItems' | 'savedPosts' | 'following' | 'followers' | 'settings';

const AccountPage: React.FC = () => {
    const { formatCurrency } = useCurrency();
    const navigate = useNavigate();
    const { user, logout, updateUser, unsavePost } = useAuth();
    const { wishlistItems } = useWishlist();
    const { addToCart } = useCart();
    const { t } = useLanguage();

    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [userProfile, setUserProfile] = useState<UserProfile | null>(user);
    const [userBookings, setUserBookings] = useState<Booking[]>([]);
    const [userOrders, setUserOrders] = useState<UserOrder[]>([]);
    const [impactData, setImpactData] = useState<ImpactData>({ treesPlanted: 0, schoolDaysFunded: 0, artisansSupported: 0 });
    const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
    const [reviewingItem, setReviewingItem] = useState<CartItem | null>(null);
    const [activeTab, setActiveTab] = useState<AccountTab>('orders');

    useEffect(() => {
        setUserProfile(user);
        if (user) {
            try {
                // FIX: Add type assertion for JSON.parse result.
                const allBookings: Booking[] = JSON.parse(localStorage.getItem('imara_bookings') || '[]') as Booking[];
                setUserBookings(allBookings.filter(b => b.userId === user.id).sort((a, b) => new Date(b.bookingDate).getTime() - new Date(a.bookingDate).getTime()));
                
                // Load orders and check review status
                const storedReviews = localStorage.getItem('imara_reviews');
                // FIX: Add type assertion for JSON.parse result.
                const allReviews = storedReviews ? JSON.parse(storedReviews) as Review[] : mockReviews;
                const reviewedProductIds = allReviews.filter((r: Review) => r.userId === user.id).map((r: Review) => r.productId);

                const ordersWithReviewStatus = mockUserOrders.map(order => ({
                    ...order,
                    items: order.items.map(item => ({
                        ...item,
                        reviewed: item.reviewed || reviewedProductIds.includes(item.id)
                    }))
                }));
                setUserOrders(ordersWithReviewStatus);
                // FIX: Add type assertion for JSON.parse result.
                setImpactData(JSON.parse(localStorage.getItem(`imara_impact_${user.id}`) || '{"treesPlanted":0,"schoolDaysFunded":0,"artisansSupported":0}') as ImpactData);

            } catch (error) {
                console.error("Could not load user data from storage", error);
                 setUserOrders(mockUserOrders);
            }
        }
    }, [user]);

    const handleLogout = () => {
        logout();
        navigate('/');
    };
    
    const handleProfileUpdate = (updatedProfile: UserProfile) => {
        updateUser(updatedProfile);
        setIsEditModalOpen(false);
    };
    
    const handleSettingChange = (key: keyof UserProfile, value: any) => {
        if (!userProfile) return;
        const updatedProfile = { ...userProfile, [key]: value };
        updateUser(updatedProfile);
    }
    
    const handleReviewSubmit = (review: Review) => {
        // Add review to storage
        try {
            const storedReviews = localStorage.getItem('imara_reviews');
            // FIX: Add type assertion for JSON.parse result.
            const allReviews = storedReviews ? JSON.parse(storedReviews) as Review[] : mockReviews;
            localStorage.setItem('imara_reviews', JSON.stringify([review, ...allReviews]));
        } catch (e) { console.error(e); }

        // Update UI state
        setUserOrders(prevOrders =>
            prevOrders.map(order => ({
                ...order,
                items: order.items.map(item =>
                    item.id === review.productId ? { ...item, reviewed: true } : item
                ),
            }))
        );
        setReviewingItem(null);
    };

    if (!userProfile) {
        return (
             <div className="container mx-auto px-6 py-12 text-center">
                <h1 className="text-2xl">{t('account.loginPrompt.title')}</h1>
                <Button onClick={() => navigate('/login')} className="mt-4">{t('account.loginPrompt.button')}</Button>
            </div>
        );
    }

    const tabClass = (tabName: AccountTab) => `px-3 py-2 text-sm font-medium rounded-md transition-colors flex items-center gap-2 ${activeTab === tabName ? 'bg-brand-navy-dark text-white' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'}`;

    const renderTabContent = () => {
        switch (activeTab) {
            case 'bookings':
                return userBookings.length > 0 ? (
                    <div className="space-y-4">
                        {userBookings.map(booking => (
                             <div key={booking.id} className="flex items-center gap-4 p-3 rounded-md bg-gray-50 dark:bg-gray-700/50">
                                <img src={mockTravelServices.find(s => s.id === booking.serviceId)?.imageUrl || ''} alt={booking.serviceTitle} className="w-16 h-16 rounded-md object-cover"/>
                                <div className="flex-grow">
                                    <p className="font-semibold">{booking.serviceTitle}</p>
                                    <p className="text-sm text-gray-500">Booked: {new Date(booking.bookingDate).toLocaleDateString()}</p>
                                </div>
                                <span className={`px-2 py-1 text-xs font-medium rounded-full ${booking.status === 'confirmed' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{booking.status}</span>
                            </div>
                        ))}
                    </div>
                ) : <p className="text-center text-gray-500 py-8">You have no travel bookings.</p>;
            case 'orders':
                 return userOrders.length > 0 ? (
                    <div className="space-y-6">
                        {userOrders.map(order => (
                             <div key={order.id} className="p-4 rounded-md bg-gray-50 dark:bg-gray-700/50">
                                <div className="flex justify-between items-center mb-4 pb-2 border-b dark:border-gray-600">
                                    <div>
                                        <p className="font-semibold text-brand-navy-dark dark:text-white">Order #{order.orderId}</p>
                                        <p className="text-sm text-gray-500 dark:text-gray-400">Date: {order.date}</p>
                                    </div>
                                    <p className="font-semibold text-brand-navy-dark dark:text-white">{formatCurrency(order.total)}</p>
                                </div>
                                <div className="space-y-3">
                                    {order.items.map(item => (
                                        <div key={item.id} className="flex items-center gap-4">
                                            <img src={item.imageUrl} alt={item.name} className="w-12 h-12 rounded-md object-cover"/>
                                            <div className="flex-grow">
                                                <p className="font-semibold text-sm">{item.name}</p>
                                                <p className="text-xs text-gray-500">{item.vendor}</p>
                                            </div>
                                            {item.reviewed ? (
                                                <span className="text-sm text-green-600 font-semibold">Reviewed</span>
                                            ) : (
                                                <Button variant="outline" size="sm" onClick={() => setReviewingItem(item)} className="flex items-center gap-1.5">
                                                    <PencilSquareIcon className="w-4 h-4" /> Write a Review
                                                </Button>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>
                 ) : <p className="text-center text-gray-500 py-8">You have no past orders.</p>;
            case 'savedItems':
                return wishlistItems.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        {wishlistItems.map(item => <ProductCard key={item.id} product={item} onAddToCart={addToCart} onQuickView={() => {}} />)}
                    </div>
                ) : <p className="text-center text-gray-500 py-8">You have no saved items.</p>;
            case 'savedPosts':
                return <SavedPostsList postIds={userProfile.savedPostIds || []} onUnsave={unsavePost} />;
            case 'following':
                return <UserConnectionsList userIds={userProfile.followingIds || []} allUsers={mockAllUsersAndPartners} type="following" />;
            case 'followers':
                 return <UserConnectionsList userIds={userProfile.followerIds || []} allUsers={mockAllUsersAndPartners} type="followers" />;
            case 'settings':
                return (
                     <div className="space-y-8 max-w-4xl mx-auto">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            {/* Privacy & Security */}
                            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                                <h3 className="text-xl font-display font-semibold text-brand-navy-dark dark:text-white mb-4">Privacy & Security</h3>
                                <div className="space-y-4">
                                    <div className="flex items-center justify-between">
                                        <label htmlFor="visibility" className="font-semibold text-gray-700 dark:text-gray-300">Profile Visibility</label>
                                        <select id="visibility" value={userProfile.profileVisibility || 'public'} onChange={(e) => handleSettingChange('profileVisibility', e.target.value)} className="rounded-md border-gray-300 dark:bg-gray-700 dark:border-gray-600 text-sm">
                                            <option value="public">Public</option>
                                            <option value="followers_only">Followers Only</option>
                                        </select>
                                    </div>
                                    <div className="flex items-center justify-between">
                                        <p className="font-semibold text-gray-700 dark:text-gray-300">2-Factor Authentication</p>
                                        <ToggleSwitch enabled={!!userProfile.twoFactorEnabled} setEnabled={(val) => handleSettingChange('twoFactorEnabled', val)} label="2-Factor Authentication" />
                                    </div>
                                </div>
                            </div>
                            {/* Display & Language */}
                            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                                <h3 className="text-xl font-display font-semibold text-brand-navy-dark dark:text-white mb-4">Display & Language</h3>
                                <div className="space-y-4">
                                    <div className="flex items-center justify-between">
                                        <label className="font-semibold text-gray-700 dark:text-gray-300">Language</label>
                                        <LanguageSwitcher />
                                    </div>
                                    <div className="flex items-center justify-between">
                                        <p className="font-semibold text-gray-700 dark:text-gray-300">Theme</p>
                                        <ThemeToggle />
                                    </div>
                                </div>
                            </div>
                        </div>
                        {userProfile.giftCards && userProfile.giftCards.length > 0 && (
                            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                                <UserGiftCards cards={userProfile.giftCards} />
                            </div>
                        )}
                         {/* Subscription & Features */}
                        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                            <h3 className="text-xl font-display font-semibold text-brand-navy-dark dark:text-white mb-4">Subscription & Features</h3>
                            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                                <div>
                                    <p className="font-semibold text-gray-700 dark:text-gray-300">Current Plan: <span className="text-brand-gold">{userProfile.role === 'user' ? 'Imara Customer' : 'Partner Pro'}</span></p>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">Upgrade to a partner plan to unlock features like post scheduling.</p>
                                </div>
                                <Link to="/upgrade">
                                    <Button variant='secondary'>View Plans</Button>
                                </Link>
                            </div>
                        </div>
                    </div>
                );
            default: return null;
        }
    };

    return (
        <>
            <div className="bg-brand-off-white dark:bg-gray-900 min-h-screen">
                <div className="container mx-auto px-4 sm:px-6 py-12">
                    {/* Profile Header */}
                    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md mb-8 flex flex-col sm:flex-row items-center gap-6">
                        <Avatar 
                            imageUrl={userProfile.profileImageUrl}
                            name={userProfile.fullName}
                            id={userProfile.id}
                            className="w-32 h-32 rounded-full object-cover border-4 border-brand-gold"
                            textClassName="text-5xl font-bold text-white"
                        />
                        <div className="flex-grow text-center sm:text-left">
                            <h1 className="text-3xl font-display font-bold text-brand-navy-dark dark:text-white">{userProfile.fullName}</h1>
                            <p className="text-brand-gray dark:text-gray-400">{userProfile.email}</p>
                             <div className="mt-2 flex gap-4 justify-center sm:justify-start">
                                {userProfile.website && <a href={userProfile.website} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-brand-gold"><LinkIcon className="w-5 h-5"/></a>}
                                {userProfile.socialMediaLinks?.instagram && <a href={userProfile.socialMediaLinks.instagram} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-brand-gold"><InstagramIcon className="w-5 h-5"/></a>}
                                {userProfile.socialMediaLinks?.x && <a href={userProfile.socialMediaLinks.x} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-brand-gold"><TwitterXIcon className="w-5 h-5"/></a>}
                                {userProfile.socialMediaLinks?.facebook && <a href={userProfile.socialMediaLinks.facebook} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-brand-gold"><FacebookIcon className="w-5 h-5"/></a>}
                                {userProfile.socialMediaLinks?.tiktok && <a href={userProfile.socialMediaLinks.tiktok} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-brand-gold"><TikTokIcon className="w-5 h-5"/></a>}
                                {userProfile.socialMediaLinks?.linkedin && <a href={userProfile.socialMediaLinks.linkedin} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-brand-gold"><LinkedInIcon className="w-5 h-5"/></a>}
                            </div>
                            <div className="mt-4 flex gap-4 justify-center sm:justify-start">
                                <Button variant="primary" onClick={() => setIsEditModalOpen(true)}>Edit Profile</Button>
                                <Button variant="outline" onClick={handleLogout}>Logout</Button>
                            </div>
                        </div>
                         <div className="flex flex-col sm:flex-row gap-6 text-center">
                            <div><p className="text-2xl font-bold">{userProfile.followerIds?.length || 0}</p><p className="text-sm text-gray-500">Followers</p></div>
                            <div><p className="text-2xl font-bold">{userProfile.followingIds?.length || 0}</p><p className="text-sm text-gray-500">Following</p></div>
                        </div>
                    </div>

                    <ImpactSummary impactData={impactData} />

                    {/* Tabs */}
                    <div className="mb-8">
                        <div className="flex flex-wrap gap-2 p-2 bg-gray-200 dark:bg-gray-800 rounded-lg">
                            <button className={tabClass('orders')} onClick={() => setActiveTab('orders')}><ArrowUpTrayIcon className="w-5 h-5"/> Order History</button>
                            <button className={tabClass('bookings')} onClick={() => setActiveTab('bookings')}><StorefrontIcon className="w-5 h-5"/> My Bookings</button>
                            <button className={tabClass('savedItems')} onClick={() => setActiveTab('savedItems')}><HeartIcon className="w-5 h-5"/> Saved Items</button>
                            <button className={tabClass('savedPosts')} onClick={() => setActiveTab('savedPosts')}><BookmarkIcon className="w-5 h-5"/> Saved Posts</button>
                            <button className={tabClass('following')} onClick={() => setActiveTab('following')}><UsersIcon className="w-5 h-5"/> Following</button>
                            <button className={tabClass('followers')} onClick={() => setActiveTab('followers')}><UserGroupIcon className="w-5 h-5"/> Followers</button>
                            <button className={tabClass('settings')} onClick={() => setActiveTab('settings')}><Cog6ToothIcon className="w-5 h-5"/> Settings</button>
                        </div>
                    </div>
                    
                    {/* Tab Content */}
                    <div>
                        {renderTabContent()}
                    </div>
                </div>
            </div>
            {isEditModalOpen && (
                <ProfileEditModal
                    user={userProfile}
                    onClose={() => setIsEditModalOpen(false)}
                    onSave={handleProfileUpdate}
                />
            )}
            {selectedBooking && (
                <RatingModal
                    booking={selectedBooking}
                    onClose={() => setSelectedBooking(null)}
                    onSubmit={(ratingData) => { /* handleRatingSubmit logic here */ }}
                />
            )}
             {reviewingItem && (
                <ReviewModal
                    product={reviewingItem}
                    onClose={() => setReviewingItem(null)}
                    onSubmit={handleReviewSubmit}
                />
            )}
        </>
    );
};

export default AccountPage;
