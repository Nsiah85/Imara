# Firebase Integration Test Checklist

This checklist provides a set of manual tests to verify that the core Firebase integration is working correctly.

**Prerequisites:**
1.  You have created a Firebase project at [firebase.google.com](https://firebase.google.com).
2.  You have enabled **Authentication** (Email/Password and Google providers), **Firestore**, and **Storage**.
3.  You have copied your Firebase configuration details into a `.env.local` file in the project root, following the example in `firebase/config.ts`.
4.  You have uploaded the sample security rules from `firebase.rules.md` to your Firebase project's rules editor for both Firestore and Storage.

---

### ✅ 1. Authentication

-   [ ] **Email/Password Signup**:
    -   Go to the `/login` page and switch to the "Sign Up" tab.
    -   Create a new customer account using a valid email and a strong password.
    -   **Expected:** You are successfully logged in and redirected to the homepage. A new user document is created in the `users` collection in Firestore.

-   [ ] **Google OAuth Sign-In**:
    -   Go to the `/login` page.
    -   Click the "Sign in with Google" button.
    -   Complete the Google sign-in flow in the popup.
    -   **Expected:** You are successfully logged in and redirected to the homepage. A corresponding user document is created/updated in Firestore.

-   [ ] **Sign Out**:
    -   Navigate to the `/account` page.
    -   Click the "Logout" button.
    -   **Expected:** You are logged out and redirected to the homepage. The UI updates to show "Login" instead of "Account".

---

### ✅ 2. Firestore Read/Write

-   [ ] **Create a Toast (Write)**:
    -   Log in to the application.
    -   On the homepage (Toast feed), use the "Create Gist" component at the top.
    -   Write a message and click "Post Gist".
    -   **Expected:** The new post appears instantly at the top of the feed. A new document is created in the `toasts` collection in Firestore.

-   [ ] **Real-time Update (Listener)**:
    -   Open two browser tabs side-by-side, both on the homepage and logged in as the same user.
    -   Create a new Toast post in one tab.
    -   **Expected:** The new post should appear in the second tab automatically without needing a page refresh. *(Note: This requires uncommenting and adapting the `onSnapshot` listener stub in `HomePage.tsx`)*.

---

### ✅ 3. Firebase Storage

-   [ ] **Upload Media**:
    -   When creating a new Toast post, click the icon to add a photo or video.
    -   Select a valid media file from your computer.
    -   **Expected:** The file uploads successfully, and a preview appears in the post composer. After posting, check Firebase Storage to confirm the file exists in the correct path (e.g., `toasts/<toastId>/<fileName>`). The corresponding Firestore `toasts` document should contain the `gs://` or `https://` URL to the uploaded media. *(Note: This requires implementing the UI for file selection and connecting it to the `uploadFile` utility in `firebase/storage.ts`)*.
