
import React, { useState, useEffect, useMemo } from 'react';
import type { PartnerApplication, Vendor, Professional, SubscriptionPlan, PendingPayout, Partner, TravelPartner, JobApplicant } from './types.ts';
import { VendorType } from './types.ts';
import ApplicationReviewModal from './components/admin/ApplicationReviewModal.tsx';
import AdminContentManager from './components/admin/AdminContentManager.tsx';
import AdminSubscriptionManager from './components/admin/AdminSubscriptionManager.tsx';
import AdminPartnerManager from './components/admin/AdminPartnerManager.tsx';
import { mockVendors, mockProfessionals, mockPendingPayouts, mockTravelPartners, mockVendorOrders, mockInvestments, mockVendorSubscriptionPlans, mockWorkmanSubscriptionPlans, mockJobApplicants } from './data/mockData.ts';
import PayoutSettings from './components/admin/PayoutSettings.tsx';
import FundsFlowCard from './components/admin/FundsFlowCard.tsx';
import AdminProfileSettings from './components/admin/AdminProfileSettings.tsx';
import Button from './components/ui/Button.tsx';
import EditVendorModal from './components/modals/EditVendorModal.tsx';
import EditWorkmanProfileModal from './components/modals/EditWorkmanProfileModal.tsx';
import { useCurrency } from './contexts/CurrencyContext.tsx';
import AdminGiftCardManager from './components/admin/AdminGiftCardManager.tsx';
import AdminEdwasoMarketManager from './components/admin/AdminEdwasoMarketManager.tsx';
import SocialMediaManager from './components/admin/SocialMediaManager.tsx';
import JobApplicantsManager from './components/admin/JobApplicantsManager.tsx';
import AdminLiveEventManager from './components/admin/AdminLiveEventManager.tsx';

type AdminTab = 'dashboard' | 'applications' | 'applicants' | 'partners' | 'content' | 'subscriptions' | 'payouts' | 'giftcards' | 'edwasomarkets' | 'live' | 'settings';

const PayoutsManager: React.FC = () => {
    const [payouts, setPayouts] = useState<PendingPayout[]>(mockPendingPayouts);
    const { formatCurrency } = useCurrency();

    const handleApprove = (payoutId: string) => {
        // In a real app, this would trigger an API call.
        // For the demo, we just remove it from the list.
        setPayouts(prev => prev.filter(p => p.id !== payoutId));
    };
    
    return (
        <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-display font-semibold text-brand-navy-dark mb-4">Pending Payouts ({payouts.length})</h3>
            {payouts.length > 0 ? (
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3">Vendor</th>
                                <th scope="col" className="px-6 py-3">Date</th>
                                <th scope="col" className="px-6 py-3 text-right">Amount</th>
                                <th scope="col" className="px-6 py-3 text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {payouts.map(payout => (
                                <tr key={payout.id} className="bg-white border-b hover:bg-gray-50">
                                    <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">{payout.vendorName}</td>
                                    <td className="px-6 py-4">{payout.date}</td>
                                    <td className="px-6 py-4 font-semibold text-right">{formatCurrency(payout.amount)}</td>
                                    <td className="px-6 py-4 text-center">
                                        <Button size="sm" onClick={() => handleApprove(payout.id)}>Approve</Button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            ) : (
                <p className="text-center text-gray-500 py-8">All payouts are up to date!</p>
            )}
        </div>
    );
};

const AdminPage: React.FC = () => {
    const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');
    const [applications, setApplications] = useState<PartnerApplication[]>([]);
    const [jobApplicants, setJobApplicants] = useState<JobApplicant[]>([]);
    const [selectedApplication, setSelectedApplication] = useState<PartnerApplication | null>(null);
    const [partners, setPartners] = useState<Partner[]>([]);
    const [editingPartner, setEditingPartner] = useState<Partner | null>(null);

    // Load applications and partners from localStorage and mock data
    useEffect(() => {
        // Load pending applications
        try {
            const storedApps = localStorage.getItem('imara_partner_applications');
            const parsedApps: PartnerApplication[] = storedApps ? JSON.parse(storedApps) : [];
            setApplications(parsedApps.filter((app) => app.status === 'pending'));
        } catch (error) {
            console.error("Failed to load applications from localStorage", error);
        }

        // Load job applicants
        try {
            const storedApplicants = localStorage.getItem('imara_job_applicants');
            setJobApplicants(storedApplicants ? JSON.parse(storedApplicants) : mockJobApplicants);
        } catch (error) {
            console.error("Failed to load job applicants", error);
            setJobApplicants(mockJobApplicants);
        }

        // Load approved partners from localStorage and combine with mock data
        try {
            const storedPartners = localStorage.getItem('partners');
            const approvedPartners: Partner[] = storedPartners ? JSON.parse(storedPartners) : [];
            
            // Combine and remove duplicates based on ID to ensure approved partners override mocks
            const allPartners = [...mockVendors, ...mockProfessionals, ...mockTravelPartners, ...approvedPartners];
            const uniquePartners = Array.from(new Map(allPartners.map(p => [p.id, p])).values());
            setPartners(uniquePartners);

        } catch (error) {
            console.error("Failed to load partners from localStorage", error);
            setPartners([...mockVendors, ...mockProfessionals, ...mockTravelPartners]);
        }
    }, []);

    const handleApplicationDecision = (appId: string, decision: 'approved' | 'rejected') => {
        try {
            const storedApps: PartnerApplication[] = JSON.parse(localStorage.getItem('imara_partner_applications') || '[]');
            let processedApp: PartnerApplication | undefined;
            const updatedApps = storedApps.map(app => {
                if (app.id === appId) {
                    processedApp = { ...app, status: decision };
                    return processedApp;
                }
                return app;
            });
            localStorage.setItem('imara_partner_applications', JSON.stringify(updatedApps));
            setApplications(prev => prev.filter(app => app.id !== appId));

            if (decision === 'approved' && processedApp) {
                const storedPartners: Partner[] = JSON.parse(localStorage.getItem('partners') || '[]');
                let newPartner: Partner;

                if (processedApp.role === 'vendor') {
                    newPartner = {
                        id: processedApp.id,
                        role: 'vendor',
                        fullName: processedApp.fullName,
                        brandName: processedApp.brandName || 'New Vendor',
                        email: processedApp.email,
                        country: processedApp.country,
                        story: processedApp.story || '',
                        storeSlug: (processedApp.brandName || 'new-vendor').toLowerCase().replace(/\s+/g, '-'),
                        brandLogoUrl: 'https://picsum.photos/seed/new-logo/200/200',
                        vendorType: processedApp.vendorType || VendorType.ARTISAN,
                        marketId: processedApp.marketId,
                        isVerified: false,
                        /* FIX: Adding missing required trustScore property */
                        trustScore: 0,
                    };
                } else if (processedApp.role === 'workman') {
                    newPartner = {
                        id: processedApp.id,
                        role: 'workman',
                        name: processedApp.fullName,
                        email: processedApp.email,
                        industry: processedApp.industry!,
                        professionalRole: 'Professional',
                        location: processedApp.country,
                        skills: processedApp.skills?.split(',').map(s => s.trim()) || [],
                        profileImageUrl: `https://picsum.photos/seed/${processedApp.email}/300/300`,
                        isVerified: false,
                        /* FIX: Adding missing required trustScore property */
                        trustScore: 0,
                        wageRange: [0, 0],
                        wageType: 'hourly',
                        storeSlug: processedApp.fullName.toLowerCase().replace(/\s+/g, '-'),
                    };
                } else if (processedApp.role === 'travel') {
                     newPartner = {
                        id: processedApp.id,
                        role: 'travel',
                        brandName: processedApp.brandName || 'New Travel Partner',
                        serviceTypes: processedApp.serviceTypes || [],
                        email: processedApp.email,
                        country: processedApp.country,
                        storeSlug: (processedApp.brandName || 'new-travel-partner').toLowerCase().replace(/\s+/g, '-'),
                        brandLogoUrl: 'https://picsum.photos/seed/new-travel-logo/200/200',
                        isVerified: false,
                        /* FIX: Adding missing required trustScore property */
                        trustScore: 0,
                    };
                } else {
                    console.error("Tried to approve an application with an unknown role:", processedApp.role);
                    return; 
                }
                
                const updatedPartners = [...storedPartners.filter(p => p.id !== newPartner.id), newPartner];
                localStorage.setItem('partners', JSON.stringify(updatedPartners));
                setPartners(prev => [...prev.filter(p => p.id !== newPartner.id), newPartner]);
            }
        } catch (error) {
            console.error("Failed to update application status", error);
        }
        setSelectedApplication(null);
    };
    
    // Modal handlers for editing partners
    const handleEditPartner = (partner: Partner) => {
        setEditingPartner(partner);
    };
    
    const handleToggleVerification = (partnerId: string) => {
        const updatedPartners = partners.map(p => 
            p.id === partnerId ? { ...p, isVerified: !p.isVerified } : p
        );
        setPartners(updatedPartners);
        const partnersToStore = updatedPartners.filter(p => !p.id.includes('mock'));
        try {
            localStorage.setItem('partners', JSON.stringify(partnersToStore));
        } catch (error) {
            console.error("Failed to save partner verification status", error);
        }
    };

    const handleSavePartner = (updatedPartner: Partner) => {
        const updatedPartners = partners.map(p => p.id === updatedPartner.id ? updatedPartner : p);
        setPartners(updatedPartners);

        // Separate localStorage partners from mock partners for saving
        const partnersToStore = updatedPartners.filter(p => !p.id.includes('mock'));
        try {
            localStorage.setItem('partners', JSON.stringify(partnersToStore));
        } catch (error) {
            console.error("Failed to save partners to localStorage", error);
        }
        setEditingPartner(null);
    };
    
    const handleCloseModal = () => {
        setEditingPartner(null);
    };

    // Dashboard calculations
    const totalPlatformRevenue = useMemo(() => {
        const allPlans = [...mockVendorSubscriptionPlans, ...mockWorkmanSubscriptionPlans];
        
        const subscriptionRevenue = partners.reduce((sum, partner) => {
            if (partner.subscriptionPlanId) {
                const plan = allPlans.find(p => p.id === partner.subscriptionPlanId);
                if (plan && plan.billingCycle === 'monthly') {
                    return sum + plan.price;
                }
            }
            return sum;
        }, 0);

        const transactionFees = mockVendorOrders.reduce((sum, order) => {
            const vendor = mockVendors.find(v => v.id === order.vendorId);
            const plan = mockVendorSubscriptionPlans.find(p => p.id === vendor?.subscriptionPlanId);
            const feePercentage = plan?.name === 'Business Partner' ? 0.02 : 0.05;
            return sum + (order.total * feePercentage);
        }, 0);

        return subscriptionRevenue + transactionFees;
    }, [partners]);

    const totalVendorPayouts = useMemo(() => {
        return mockPendingPayouts.reduce((sum, payout) => sum + payout.amount, 0);
    }, []);

    const totalDonationsAndInvestments = useMemo(() => {
        return mockInvestments.reduce((sum, investment) => sum + investment.raised, 0);
    }, []);


    const tabClass = (tabName: AdminTab) =>
        `px-4 py-2 text-sm font-medium rounded-md transition-colors ${
            activeTab === tabName
                ? 'bg-brand-gold text-brand-navy-dark'
                : 'text-gray-600 hover:bg-brand-off-white'
        }`;

    const renderContent = () => {
        switch (activeTab) {
            case 'dashboard':
                return (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                         <FundsFlowCard title="Total Platform Revenue" amount={totalPlatformRevenue} period="All Time" change="+8.2%" changeType="positive" />
                        <FundsFlowCard title="Vendor Payouts" amount={totalVendorPayouts} period="Pending" change="" changeType="negative" />
                        <FundsFlowCard title="Donations & Investments" amount={totalDonationsAndInvestments} period="All Time" change="+15.0%" changeType="positive" />
                    </div>
                );
            case 'applications':
                return (
                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <h3 className="text-xl font-display font-semibold text-brand-navy-dark mb-4">Pending Applications ({applications.length})</h3>
                        {applications.length > 0 ? (
                            <ul className="space-y-3">
                                {applications.map(app => (
                                    <li key={app.id} className="flex items-center justify-between p-3 bg-brand-off-white/60 rounded-md">
                                        <div>
                                            <p className="font-semibold text-brand-navy-dark">{app.fullName} ({app.role})</p>
                                            <p className="text-sm text-gray-500">{app.brandName || app.industry}</p>
                                        </div>
                                        <Button size="sm" onClick={() => setSelectedApplication(app)}>Review</Button>
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <p className="text-center text-gray-500 py-8">No pending applications.</p>
                        )}
                    </div>
                );
            case 'applicants':
                return <JobApplicantsManager applicants={jobApplicants} setApplicants={setJobApplicants} />;
            case 'partners':
                return <AdminPartnerManager partners={partners} onEditPartner={handleEditPartner} onToggleVerification={handleToggleVerification} />;
            case 'content':
                return <AdminContentManager />;
            case 'subscriptions':
                return <AdminSubscriptionManager />;
            case 'payouts':
                return <PayoutsManager />;
            case 'giftcards':
                return <AdminGiftCardManager />;
            case 'edwasomarkets':
                return <AdminEdwasoMarketManager />;
            case 'live':
                return <AdminLiveEventManager />;
            case 'settings':
                return (
                    <div className="space-y-8">
                        <AdminProfileSettings />
                        <PayoutSettings />
                        <SocialMediaManager />
                    </div>
                );
            default:
                return null;
        }
    };

    return (
        <>
            <div className="container mx-auto px-6 py-12">
                <h1 className="text-4xl font-display font-bold text-brand-navy-dark mb-8">Admin Dashboard</h1>
                <div className="flex flex-wrap gap-2 mb-8 border-b pb-4">
                    <button className={tabClass('dashboard')} onClick={() => setActiveTab('dashboard')}>Dashboard</button>
                    <button className={tabClass('applications')} onClick={() => setActiveTab('applications')}>Partner Applications</button>
                    <button className={tabClass('applicants')} onClick={() => setActiveTab('applicants')}>Job Applicants</button>
                    <button className={tabClass('partners')} onClick={() => setActiveTab('partners')}>Partners</button>
                    <button className={tabClass('content')} onClick={() => setActiveTab('content')}>Content</button>
                    <button className={tabClass('subscriptions')} onClick={() => setActiveTab('subscriptions')}>Subscriptions</button>
                    <button className={tabClass('payouts')} onClick={() => setActiveTab('payouts')}>Payouts</button>
                    <button className={tabClass('giftcards')} onClick={() => setActiveTab('giftcards')}>Gift Cards</button>
                    <button className={tabClass('edwasomarkets')} onClick={() => setActiveTab('edwasomarkets')}>Edwaso Markets</button>
                    <button className={tabClass('live')} onClick={() => setActiveTab('live')}>Live Event</button>
                    <button className={tabClass('settings')} onClick={() => setActiveTab('settings')}>Settings</button>
                </div>
                <div>{renderContent()}</div>
            </div>
            {selectedApplication && (
                <ApplicationReviewModal
                    application={selectedApplication}
                    onClose={() => setSelectedApplication(null)}
                    onApprove={() => handleApplicationDecision(selectedApplication.id, 'approved')}
                    onReject={() => handleApplicationDecision(selectedApplication.id, 'rejected')}
                />
            )}
            {editingPartner && (editingPartner.role === 'vendor' || editingPartner.role === 'travel') && (
                <EditVendorModal vendor={editingPartner as Vendor | TravelPartner} onClose={handleCloseModal} onSave={handleSavePartner as (p: Vendor | TravelPartner) => void} />
            )}
            {editingPartner && editingPartner.role === 'workman' && (
                <EditWorkmanProfileModal professional={editingPartner as Professional} onClose={handleCloseModal} onSave={handleSavePartner as (p: Professional) => void} />
            )}
        </>
    );
};

export default AdminPage;
