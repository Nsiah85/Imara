import { UserProfile } from '../types';

const countryGreetings: Record<string, string> = {
  'Ghana': 'Akwaaba',
  'Nigeria': 'Ẹ káàbọ̀',
  'Kenya': 'Karibu',
  'Senegal': 'Teranga',
  'South Africa': 'Sawubona',
  'Ethiopia': 'Selam',
  'Ivory Coast': 'Bienvenue',
  'Cameroon': 'Bienvenue',
  'Rwanda': 'Murakaza neza',
  'Tanzania': 'Karibu',
  'Uganda': 'Kulaba',
  'Egypt': 'Marhaba',
  'Morocco': 'Marhaba',
};

/**
 * Returns a localized greeting based on the user's registered country.
 * Fallbacks to "Akwaaba" if country is not mapped.
 */
export const getLocalizedWelcome = (user?: UserProfile | null): string => {
  if (!user || !user.country) return 'Akwaaba';
  
  const greeting = countryGreetings[user.country];
  return greeting || 'Akwaaba';
};

/**
 * Returns a region-specific localized message if available.
 */
export const getRegionalFlavor = (user?: UserProfile | null): string => {
  if (!user) return 'Explore our continent.';
  
  const country = user.country;
  switch (country) {
    case 'Nigeria':
        return 'What’s buzzing in the 01?';
    case 'Ghana':
        return 'The gateway is open.';
    case 'Kenya':
        return 'Feel the heartbeat of the Rift.';
    default:
        return 'Your African legacy begins here.';
  }
};
