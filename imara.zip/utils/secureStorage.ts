
/**
 * IMARA HYBRID DATA UTILITY
 * 
 * This module handles the secure separation of data:
 * 1. Personal Heavy Data (Raw Images, Videos) -> Encrypted & Stored Locally
 * 2. Interaction Data (References, Metadata) -> Synced to Cloud (Firebase)
 */

// Simple XOR encryption for demo purposes (In production, use Web Crypto API / AES-GCM)
const SECRET_KEY = "IMARA_HYBRID_SECURE_KEY";

const encryptData = (data: string): string => {
    try {
        // Base64 encode first
        const encoded = btoa(data);
        return encoded.split('').reverse().join(''); // Simple obfuscation for demo
    } catch (e) {
        console.error("Encryption failed", e);
        return data;
    }
};

const decryptData = (data: string): string => {
    try {
        const reversed = data.split('').reverse().join('');
        return atob(reversed);
    } catch (e) {
        console.error("Decryption failed", e);
        return data;
    }
};

// --- Local Storage Management ---

export const saveLocalFile = async (key: string, file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
            const base64 = reader.result as string;
            // Store raw heavy data locally with encryption
            // Note: LocalStorage has limits (5-10MB). For real heavy media, IndexedDB is required.
            // This is a simulation using LocalStorage for small demo assets.
            try {
                const encrypted = encryptData(base64);
                localStorage.setItem(`local_media_${key}`, encrypted);
                resolve(`local://${key}`); // Return a pointer, not the data
            } catch (e) {
                console.error("Local storage quota exceeded or error", e);
                reject("Storage Full");
            }
        };
        reader.onerror = error => reject(error);
    });
};

export const getLocalFile = (pointer: string): string | null => {
    if (!pointer.startsWith('local://')) return pointer; // Return as-is if it's a web URL
    
    const key = pointer.replace('local://', '');
    const encrypted = localStorage.getItem(`local_media_${key}`);
    
    if (!encrypted) return null;
    return decryptData(encrypted);
};

export const clearLocalUserData = () => {
    // Clears only data prefixed with 'local_media_' or 'imara_'
    Object.keys(localStorage).forEach(key => {
        if (key.startsWith('local_media_') || key.startsWith('imara_')) {
            localStorage.removeItem(key);
        }
    });
};

export const getStorageUsage = (): number => {
    let total = 0;
    for (const key in localStorage) {
        if (localStorage.hasOwnProperty(key) && (key.startsWith('local_media_'))) {
            total += (localStorage[key].length * 2);
        }
    }
    return total / 1024 / 1024; // MB
};
