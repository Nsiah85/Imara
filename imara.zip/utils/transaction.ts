
/**
 * Generates a transaction ID in the format: PREFIX + Year(3) + VendorInitial + Sequence
 * Example: IMR024C001
 * 
 * @param vendorName The name of the vendor or provider
 * @param sequence The incremental number of the order
 * @param type 'order' or 'booking'
 */
export const generateTransactionId = (vendorName: string, sequence: number, type: 'order' | 'booking' = 'order'): string => {
    const prefix = type === 'order' ? 'IMR' : 'BKG';
    
    // Get last 3 digits of current year (e.g., 2024 -> 024)
    const yearFull = new Date().getFullYear().toString();
    const yearPart = yearFull.slice(1); 

    // Get last initial of vendor name
    const nameParts = vendorName.trim().split(' ');
    const lastWord = nameParts[nameParts.length - 1];
    const vendorInitial = lastWord ? lastWord[0].toUpperCase() : 'X';

    // Pad sequence to 3 digits
    const seq = sequence.toString().padStart(3, '0');

    return `${prefix}${yearPart}${vendorInitial}${seq}`;
};
