
/**
 * Downloads media with an Imara tag.
 * For images: Draws a watermark on a canvas.
 * For videos: Renames the file to include the tag (client-side encoding is too heavy).
 */
export const downloadMediaWithWatermark = async (url: string, type: 'image' | 'video', username: string) => {
    const tag = `IM%${username.replace(/\s+/g, '').toLowerCase()}`;
    const filename = `imara-${username.replace(/\s+/g, '')}-${Date.now()}.${type === 'image' ? 'png' : 'mp4'}`;

    try {
        if (type === 'image') {
            const img = new Image();
            img.crossOrigin = "anonymous";
            img.src = url;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                if (!ctx) return;

                canvas.width = img.width;
                canvas.height = img.height;

                // Draw Image
                ctx.drawImage(img, 0, 0);

                // Draw Watermark - Simple White Text, Light Font, No Background
                const fontSize = Math.max(18, img.width * 0.025); // Slightly smaller relative font
                ctx.font = `300 ${fontSize}px "Poppins", sans-serif`; // Light font weight (300)
                const textWidth = ctx.measureText(tag).width;
                const padding = fontSize;
                const x = img.width - textWidth - padding;
                const y = img.height - padding;

                // Optional: Minimal shadow for legibility on light backgrounds
                ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
                ctx.shadowBlur = 4;
                ctx.shadowOffsetX = 1;
                ctx.shadowOffsetY = 1;

                // Draw Text
                ctx.fillStyle = '#FFFFFF'; // White text
                ctx.fillText(tag, x, y);

                // Download
                const link = document.createElement('a');
                link.download = filename;
                link.href = canvas.toDataURL('image/png');
                link.click();
            };
            img.onerror = (err) => {
                console.error("Failed to load image for watermarking", err);
                // Fallback to direct download
                downloadDirect(url, filename);
            };
        } else {
            // For video, we download directly but with the tagged filename
            downloadDirect(url, filename);
        }
    } catch (e) {
        console.error("Download failed", e);
        alert("Could not download media.");
    }
};

const downloadDirect = async (url: string, filename: string) => {
    try {
        const response = await fetch(url);
        const blob = await response.blob();
        const blobUrl = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = blobUrl;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(blobUrl);
    } catch (e) {
        console.error("Direct download error", e);
        window.open(url, '_blank');
    }
};