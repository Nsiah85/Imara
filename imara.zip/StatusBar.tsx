// This file is deprecated. Please use components/gist/StatusBar.tsx instead.
