export const generateAIContent = async (prompt: string): Promise<string> => {
    try {
        const response = await fetch('/api/ai/generate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ prompt })
        });
        
        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.error || 'Failed to generate AI content');
        }
        
        const data = await response.json();
        return data.result;
    } catch (error) {
        console.error("AI Generation Error:", error);
        throw error;
    }
};
