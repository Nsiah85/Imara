import { db, doc, setDoc, addDoc, collection, serverTimestamp, getDoc, updateDoc } from '../firebase/firestore.ts';
import { uploadFile } from '../firebase/storage.ts';

// Save user docs
export const saveUserDocument = async (userId: string, folder: string, file: File, meta?: any) => {
    try {
        const url = await uploadFile(file, `users/${userId}/${folder}`);
        const docRef = await addDoc(collection(db, 'userDocs'), {
            userId,
            folder,
            fileName: file.name,
            url,
            meta: meta || {},
            timestamp: serverTimestamp()
        });
        return { id: docRef.id, url };
    } catch (e) {
        console.error("Error saving user document:", e);
        throw e;
    }
};

// Save general interactions (likes, saves, reports)
export const logUserInteraction = async (userId: string, targetId: string, action: 'like' | 'save' | 'comment' | 'report', extraData?: any) => {
    try {
        await addDoc(collection(db, 'interactions'), {
            userId,
            targetId,
            action,
            data: extraData || {},
            timestamp: serverTimestamp()
        });
    } catch (e) {
        console.error("Error logging interaction:", e);
    }
};

// Save Admin inputs/outputs (Audit Logs)
export const saveAdminAuditLog = async (adminId: string, targetId: string, action: string, metadata?: any) => {
    try {
        await addDoc(collection(db, 'adminLogs'), {
            adminId,
            targetId,
            action,
            metadata: metadata || {},
            timestamp: serverTimestamp()
        });
    } catch (e) {
        console.error("Error saving admin log:", e);
    }
};

// --- E-commerce & Funding ---
export const saveOrderDetails = async (userId: string, orderData: any) => {
    try {
         await addDoc(collection(db, 'orders'), {
            userId,
            ...orderData,
            createdAt: serverTimestamp()
         });
    } catch (e) {
         console.error("Error saving order:", e);
    }
};

export const updateImpactData = async (userId: string, impactDelta: { treesPlanted?: number, schoolDaysFunded?: number, artisansSupported?: number }) => {
     try {
         const ref = doc(db, 'user_impact', userId);
         const snap = await getDoc(ref);
         if (snap.exists()) {
             const data = snap.data();
             await updateDoc(ref, {
                 treesPlanted: (data.treesPlanted || 0) + (impactDelta.treesPlanted || 0),
                 schoolDaysFunded: (data.schoolDaysFunded || 0) + (impactDelta.schoolDaysFunded || 0),
                 artisansSupported: (data.artisansSupported || 0) + (impactDelta.artisansSupported || 0),
                 lastUpdated: serverTimestamp()
             });
         } else {
             await setDoc(ref, {
                 treesPlanted: impactDelta.treesPlanted || 0,
                 schoolDaysFunded: impactDelta.schoolDaysFunded || 0,
                 artisansSupported: impactDelta.artisansSupported || 0,
                 lastUpdated: serverTimestamp()
             });
         }
     } catch (e) {
         console.error("Error updating impact data:", e);
     }
};

// --- Messages ---
export const saveMessage = async (conversationId: string, messageData: any) => {
    try {
        await addDoc(collection(db, `conversations/${conversationId}/messages`), {
             ...messageData,
             timestamp: serverTimestamp()
        });
        // We should also update the conversation's "lastMessage" and "updatedAt"
        await setDoc(doc(db, 'conversations', conversationId), {
            lastMessage: messageData.text,
            updatedAt: serverTimestamp(),
            lastSenderId: messageData.senderId
        }, { merge: true });
    } catch (e) {
        console.error("Error saving message", e);
    }
};
