
// Re-exporting from data/mockData.ts to maintain compatibility if needed.
// In the future, please update imports to 'data/mockData.ts'.
export * from './data/mockData.ts';
