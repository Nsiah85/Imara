import type { 
    Product, Investment, Cause, Professional, VendorOrder, Conversation, 
    SubscriptionPlan, Vendor, PendingPayout, TravelPartner, TravelService, 
    UserProfile, Participant, JobListing, GiftCard, EdwasoMarket, GistPost, 
    GistComment, GistStatus, GistStatusItem, JobApplicant, LiveStream, 
    LiveComment, GistPostCreator, Review, BrandProfile, Sound, ImaraGift, 
    AdCampaign, UserOrder, CulturalImpactEntry, FestivalEdition 
} from '../types.ts';

export const mockSounds: Sound[] = [];
export const mockImaraGifts: ImaraGift[] = [];
export const mockCulturalImpactEntries: CulturalImpactEntry[] = [];
export const mockInvestments: Investment[] = [];
export const mockCauses: Cause[] = [];
export const mockFestivalEditions: FestivalEdition[] = [];
export const mockEdwasoMarkets: EdwasoMarket[] = [];
export const mockUsers: UserProfile[] = [];
export const mockProducts: Product[] = [];
export const mockVendors: Vendor[] = [];
export const mockTravelServices: TravelService[] = [];
export const mockConversations: Conversation[] = [];
export const mockGiftCards: GiftCard[] = [];
export const mockAdCampaigns: AdCampaign[] = [];
export const mockLiveStream: LiveStream = {
    id: "live_empty",
    host: { id: "empty", name: "none", role: "user", avatarUrl: "" },
    topic: "No Live Stream",
    viewers: 0,
    isLive: false,
    startedAt: new Date().toISOString(),
    likes: 0
};
export const mockGistPosts: GistPost[] = [];
export const mockGistStatuses: GistStatus[] = [];
export const mockJobListings: JobListing[] = [];
export const mockProfessionals: Professional[] = [];
export const mockTravelPartners: TravelPartner[] = [];
export const mockJobApplicants: JobApplicant[] = [];
export const mockBrandProfiles: BrandProfile[] = [];
export const mockUserOrders: UserOrder[] = [];
export const mockVendorOrders: VendorOrder[] = [];
export const mockPendingPayouts: PendingPayout[] = [];
export const mockVendorSubscriptionPlans: SubscriptionPlan[] = [];
export const mockWorkmanSubscriptionPlans: SubscriptionPlan[] = [];
export const mockReviews: Review[] = [];
export const mockAllUsersAndPartners: Participant[] = [];
