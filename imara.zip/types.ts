
import React from 'react';

export enum SustainabilityTag {
  HANDMADE = 'Handmade',
  FAIR_TRADE = 'Fair Trade',
  RECYCLED = 'Recycled',
  ORGANIC = 'Organic',
  LOCALLY_SOURCED = 'Locally Sourced',
  WOMEN_OWNED = 'Women Owned',
  ECO_FRIENDLY = 'Eco Friendly',
  HERITAGE_CRAFT = 'Heritage Craft'
}

export enum CulturalCategory {
  MUSIC = 'Music',
  VISUAL_ARTS = 'Visual Arts',
  FASHION = 'Fashion',
  STORYTELLING = 'Storytelling',
  INDIGENOUS = 'Indigenous Creativity'
}

export enum FestivalStatus {
  DORMANT = 'dormant',
  PRE_PRODUCTION = 'pre_production',
  ACTIVE = 'active',
  CONCLUDED = 'concluded'
}

// Admin Operational Models
export enum AdminRole {
  SUPER_ADMIN = 'Super Admin',
  OPERATIONS = 'Ops Manager',
  MODERATOR = 'Moderator',
  ANALYST = 'Impact Analyst'
}

export interface AuditLog {
  id: string;
  adminId: string;
  adminName: string;
  action: string;
  targetId: string;
  timestamp: string;
  metadata?: any;
}

export interface ImpactMetric {
  culturalReachIndex: number; // 0-100
  creatorLivelihoodGrowth: number; // %
  localVisibilityScore: number; // 0-100
  communityParticipation: number; // Total actions
}

export interface CulturalImpactEntry {
  id: string;
  artistName: string;
  country: string;
  region: string;
  category: CulturalCategory;
  impactStory: string;
  imageUrl: string;
  isFeatured: boolean;
  engagementCount: number;
}

export interface FestivalEdition {
  id: string;
  year: number;
  theme: string;
  hostCountry: string;
  status: FestivalStatus;
  narrativeHistory: string;
}

export enum ProfessionalIndustry {
  TECH = 'Tech',
  TRADES = 'Trades',
  HEALTHCARE = 'Healthcare',
  CREATIVE = 'Creative',
  TRANSPORT = 'Transport',
  FASHION_AND_MEDIA = 'Fashion & Media',
  ENGINEERING_AND_MANUFACTURING = 'Engineering & Manufacturing',
  PHOTOGRAPHY = 'Photography',
  DIGITAL_MEDIA = 'Digital Media',
  AUTOMOTIVE = 'Automotive',
  HOSPITALITY_AND_TOURISM = 'Hospitality & Tourism',
  EDUCATION = 'Education',
  AGRICULTURE = 'Agriculture',
  OTHER = 'Other'
}

export enum ServiceType {
  FLIGHT = 'Flights',
  HOTEL = 'Hotels',
  RIDE = 'Rides',
  MEAL = 'Meals',
  RESORT = 'Resorts',
  EXPERIENCE = 'Experiences',
  EVENT = 'Events'
}

export enum LanguageCode {
    EN = 'en',
    SW = 'sw',
    FR = 'fr',
    AR = 'ar',
    HA = 'ha',
    YO = 'yo',
    IG = 'ig',
    ZU = 'zu',
    XH = 'xh',
    ST = 'st',
    AM = 'am',
    OM = 'om',
    SO = 'so',
    MG = 'mg',
    SN = 'sn',
    PT = 'pt',
    DE = 'de',
    ES = 'es',
    ZH = 'zh',
    JA = 'ja',
    AK = 'ak',
    AF = 'af',
    LG = 'lg',
    RW = 'rw',
    RN = 'rn',
    TS = 'ts',
    WO = 'wo',
    BM = 'bm',
    FF = 'ff',
    LN = 'ln',
    TI = 'ti',
}

export enum ProductCategory {
  FASHION = 'Fashion',
  BEAUTY = 'Beauty',
  HOME_DECOR = 'Home Decor',
  AUTOMOTIVE = 'Automotive',
  FOODSTUFF = 'Foodstuff',
  FRUITS_VEGETABLES = 'Fruits & Vegetables',
  PROTEINS = 'Proteins',
  DRIVING_TEST = 'Driving Test',
  ELECTRONICS = 'Electronics',
  BOOKS = 'Books',
  HOME_APPLIANCES = 'Home Appliances',
  REAL_ESTATE = 'Real Estate',
  ART = 'Art & Collectibles'
}

export interface EdwasoMarket {
  id: string;
  name: string;
  country: string;
  region: string;
  workingHours?: string;
  voiceIntroUrl?: string; // Human touch
}

export interface Product {
  id: string;
  name: string;
  vendor: string;
  vendorId?: string;
  price: number;
  imageUrl: string;
  originCountry: string;
  originRegion?: string;
  sustainabilityTags: SustainabilityTag[];
  isVerified: boolean;
  trustScore: number; // 0-100
  impactPerPurchase: string;
  description: string;
  storySnippet?: string; // Story priority
  seenInToast?: boolean; // Social proof
  category: ProductCategory;
  marketId?: string;
  rating?: number;
  reviewsCount?: number;
  condition?: 'New' | 'Used';
}

export interface CartItem extends Product {
  quantity: number;
  reviewed?: boolean;
}

export interface Review {
  id: string;
  productId: string;
  vendorId: string;
  userId: string;
  userName: string;
  userAvatarUrl: string;
  rating: number;
  title: string;
  comment: string;
  voiceCommentUrl?: string; // Voice review support
  createdAt: string;
  isVerifiedPurchase: boolean;
}

export interface Investment {
  id: string;
  vendorName: string;
  title: string;
  description: string;
  goal: number;
  raised: number;
  imageUrl: string;
  videoUrl?: string;
  isTopPriority?: boolean;
}

export interface Cause {
  id: string;
  title: string;
  organization: string;
  description: string;
  imageUrl: string;
  goal?: number;
  raised?: number;
  isFeatured?: boolean;
}

export interface Professional {
  id: string;
  role: 'workman';
  name: string;
  email: string;
  industry: ProfessionalIndustry;
  professionalRole: string;
  location: string;
  skills: string[];
  profileImageUrl: string;
  coverImageUrl?: string;
  isVerified: boolean;
  trustScore: number;
  verificationStatus?: 'pending' | 'verified' | 'unverified' | 'rejected';
  wageRange: [number, number];
  wageType: 'hourly' | 'daily' | 'project';
  storeSlug: string;
  portfolioImageUrls?: string[];
  portfolioVideoUrls?: string[];
  subscriptionPlanId?: string;
}

export enum VendorType {
  ARTISAN = 'Artisan',
  MARKET_WOMAN = 'Market Woman',
  FARMER = 'Farmer',
  RESTAURANT = 'Restaurant / Chef',
  HOSPITALITY = 'Hospitality (Hotels/Stays)',
  AVIATION = 'Aviation (Airlines)',
  DIGITAL_CREATOR = 'Digital Creator',
  FASHION_DESIGNER = 'Fashion Designer',
  TECH_STORE = 'Tech Retailer',
  AUTO_DEALER = 'Auto Dealership',
  COSMETICS = 'Cosmetics',
  OTHER = 'Other'
}

export interface Vendor {
    id: string;
    role: 'vendor';
    fullName: string;
    brandName: string;
    email: string;
    country: string;
    story: string;
    storeSlug: string;
    brandLogoUrl?: string;
    coverImageUrl?: string;
    subscriptionPlanId?: string;
    vendorType: VendorType;
    marketId?: string;
    isVerified: boolean;
    trustScore: number;
    verificationStatus?: 'pending' | 'verified' | 'unverified' | 'rejected';
}

export interface TravelPartner {
  id: string;
  role: 'travel';
  brandName: string;
  serviceTypes: ServiceType[];
  email: string;
  country: string;
  storeSlug: string;
  brandLogoUrl?: string;
  subscriptionPlanId?: string;
  isVerified: boolean;
  trustScore: number;
  verificationStatus?: 'pending' | 'verified' | 'unverified' | 'rejected';
}

export type Partner = Vendor | Professional | TravelPartner;

export interface TravelService {
  id: string;
  type: ServiceType;
  providerName: string;
  providerId?: string;
  title: string;
  location: string;
  price: number;
  priceUnit: 'night' | 'ticket' | 'person' | 'ride';
  imageUrl: string;
  rating: number;
  description: string;
  socialProofLabel?: string; // "12 people near you booked this"
  isAvailableNow?: boolean;
  amenities?: string[];
  classes?: string[];
}

// Updated UserOrder for Lifecycle Management
export type OrderStatus = 'pending' | 'paid' | 'processing' | 'shipped' | 'delivered' | 'disputed' | 'refunded';

export interface UserOrder {
    id: string;
    orderId: string;
    date: string;
    items: CartItem[];
    total: number;
    status?: OrderStatus; // Added status
    trackingCode?: string; // Added tracking
    shippingAddress?: ShippingAddress; // Ensure shipping is available
    commissionAmount?: number;
}

export interface VendorOrder {
  id: string;
  orderId: string;
  vendorId: string;
  items: CartItem[];
  shippingDetails: ShippingAddress;
  total: number;
  status: OrderStatus; // Updated type
  refundReason?: string;
  refundComment?: string;
}

export interface Participant {
    id: string;
    name: string;
    avatarUrl: string;
    role?: string;
    isOnline?: boolean;
    bio?: string;
    profileLink?: string;
    isVerified?: boolean;
    trustScore?: number;
}

export type MessageContent = 
  | { type: 'text'; text: string }
  | { type: 'image'; imageUrl: string }
  | { type: 'voice'; audioUrl: string; duration: number }
  | { type: 'document'; fileUrl: string; fileName: string; fileSize: string }
  | { type: 'test_invite'; testAttemptId: string; jobTitle: string }
  | { type: 'notification'; text: string; link?: string }
  | { type: 'file'; fileUrl: string; fileName: string };

export interface DirectMessage {
    id: string;
    senderId: 'currentUser' | string;
    content: MessageContent;
    timestamp: string;
}

export interface ConversationMeta {
    isArchived?: boolean;
    isHidden?: boolean;
    isUnread?: boolean;
    isPinned?: boolean;
    isLocked?: boolean;
}

export interface DirectConversation extends ConversationMeta {
    id: string;
    type: 'direct';
    participant: Participant;
    messages: DirectMessage[];
}

export interface GroupConversation extends ConversationMeta {
    id: string;
    type: 'group';
    groupName: string;
    groupAvatarUrl: string;
    participants: Participant[];
    messages: DirectMessage[];
    adminIds: string[];
    inviteLink?: string;
}

export type Conversation = DirectConversation | GroupConversation;

export interface ShippingAddress {
    fullName: string;
    addressLine1: string;
    city: string;
    country: string;
    postalCode: string;
    email: string;
}

export interface ShippingMethod {
    id: string;
    name: string;
    price: number;
    estimatedDelivery: string;
}

export interface DeliveryDetails {
    date: string;
    timeSlot: string;
}

export interface Todo {
    id: string;
    text: string;
    completed: boolean;
}

export interface PartnerApplication {
    id: string;
    status: 'pending' | 'approved' | 'rejected';
    role: 'vendor' | 'workman' | 'travel';
    fullName: string;
    email: string;
    password?: string;
    country: string;
    submittedAt: string;
    brandName?: string;
    story?: string;
    industry?: ProfessionalIndustry;
    skills?: string;
    serviceTypes?: ServiceType[];
    vendorType?: VendorType;
    marketId?: string;
    companyLogoUrl?: string;
    coverImageUrl?: string;
}

export interface PaymentItem {
    id: string;
    type: 'investment' | 'donation';
    title: string;
    recipient: string;
    imageUrl: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}

export interface GiftCard {
  code: string;
  type: 'fixed' | 'percentage';
  value: number;
  description: string;
  expiryDate: string;
  isActive: boolean;
}

export interface ImpactData {
    treesPlanted: number;
    schoolDaysFunded: number;
    artisansSupported: number;
}

export interface MonetizationProfile {
    torts: number; // Replaced points
    tokens: number; // Tokens = torts / 100
    level: 'Starter' | 'Active' | 'Creator' | 'Premium Provider';
    totalEarnings: number;
    pendingPayout: number;
    earningsHistory: { date: string; source: string; amount: number; torts?: number }[];
}

export interface GuardianDetails {
    name: string;
    email: string;
    phone: string;
}

export interface PrivacyConsent {
    hasAcceptedTerms: boolean;
    hasAcceptedPrivacyPolicy: boolean;
    acceptedAt: string;
    policyVersion: string;
}

export interface MonkixCISettings {
    enabled: boolean;
    mode: 'observation' | 'suggestions' | 'semi-autonomous' | 'full';
    permissions: {
        autoPost: boolean;
        autoEngage: boolean;
        suggestPosts: boolean;
        maintainPresence: boolean;
    };
    allowedTopics: string[];
    restrictedActions: string[];
    visibility: 'private' | 'public' | 'followers_only';
    lastMemoryWipe?: string;
    consentGiven: boolean;
    consentDate?: string;
}

export interface MonkixCIProfile {
    id: string; // same as userId
    userId: string;
    usernameMonkixCI: string;
    learningStatus: 'calibrating' | 'active' | 'paused';
    creationDate: string;
    healthScore: number;
    toxicityRisk: number;
}

export interface MonkixCIDashboardData {
    engagementHabits: string[];
    communicationTone: string;
    toxicityRiskScore: number;
    spamLikeBehaviorScore: number;
    emotionalPostingTrends: string;
    reputationPatterns: string;
}

export interface SyncSettings {
    syncMedia: boolean;
    syncChats: boolean;
}

export interface UserProfile {
    id: string;
    fullName: string;
    nativeName?: string;
    email: string;
    dateOfBirth?: string;
    guardianDetails?: GuardianDetails;
    country: string;
    region?: string;
    profileImageUrl: string;
    role?: 'user' | 'admin' | 'vendor' | 'workman' | 'travel';
    isVerified?: boolean;
    verificationStatus?: 'pending' | 'verified' | 'unverified' | 'rejected';
    trustScore?: number;
    accountFlagged?: boolean;
    bio?: string;
    giftCards?: GiftCard[];
    twoFactorEnabled?: boolean;
    followingIds?: string[];
    followerIds?: string[];
    savedPostIds?: string[];
    monkixSettings?: MonkixCISettings;
    contactIds?: string[];
    socialMediaLinks?: SocialMediaLinks;
    website?: string;
    subscriptionPlanId?: string;
    showNativeName?: boolean;
    profileVisibility?: 'public' | 'followers_only';
    monetization?: MonetizationProfile;
    privacyConsent?: PrivacyConsent;
    syncSettings?: SyncSettings;
    preferences?: {
        reflectiveFont?: boolean;
    };
    coverImageUrl?: string;
}

export interface ShopProfile {
    brandName: string;
    story: string;
    logoUrl: string;
    bannerUrl: string;
}

export interface SubscriptionPlan {
    id: string;
    name: string;
    price: number;
    billingCycle: 'monthly' | 'yearly';
    features: string[];
    isFeatured?: boolean;
    type: 'vendor' | 'workman';
    tierLevel: 'Free' | 'Pro' | 'Business';
}

export interface PendingPayout {
    id: string;
    orderId: string;
    vendorName: string;
    amount: number;
    date: string;
}

export interface Booking {
    id: string;
    userId: string;
    serviceId: string;
    serviceTitle: string;
    serviceType: ServiceType;
    providerName: string;
    bookingDate: string;
    startDate?: string;
    endDate?: string;
    destination?: string;
    guests: number;
    requests: string;
    rated?: boolean;
    status: 'confirmed' | 'cancelled';
}

export interface DrivingTestBookingDetails {
    name: string;
    email: string;
    phone: string;
    locationId: string;
    vehicleTypeId: string;
    identificationUrl: string;
    personImageUrl: string;
    policyAccepted: boolean;
}

export interface Rating {
    id: string;
    userId: string;
    serviceId: string;
    bookingId: string;
    rating: number;
    comment?: string;
    ratedAt: string;
}

export interface JobListing {
  id: string;
  title: string;
  companyName: string;
  companyLogoUrl: string;
  location: string;
  industry: ProfessionalIndustry;
  jobType: 'Full-time' | 'Part-time' | 'Contract' | 'Freelance';
  salaryRange?: [number, number];
  salaryType?: 'annual' | 'monthly' | 'hourly';
  description: string;
  requirements: string[];
  postedDate: string;
}

export type ShowcaseItem = (Product | Professional | JobListing | TravelService) & { 
    itemType: 'product' | 'professional' | 'job' | 'service' 
};

export interface SocialMediaLinks {
  facebook?: string;
  x?: string;
  instagram?: string;
  tiktok?: string;
  linkedin?: string;
  website?: string;
}

export interface Sound {
  id: string;
  title: string;
  artist: string;
  url: string;
  duration: number;
}

export interface BrandProfile {
    id: string;
    name: string;
    avatarUrl: string;
    profileLink: string;
    role: 'admin';
    isVerified: boolean;
    coverImageUrl?: string;
    bio?: string;
}

export interface GistPostCreator extends Omit<BrandProfile, 'role'> {
    role: 'user' | 'partner' | 'admin';
}

export interface GistComment {
    id: string;
    author: {
        name: string;
        avatarUrl: string;
    };
    text: string;
    timestamp: string;
    replies?: GistComment[];
}

export interface ImaraGift {
    id: string;
    name: string;
    cost: number;
    iconUrl: string;
    animationUrl?: string; 
    type: 'emoji' | 'premium' | 'brand' | 'seasonal';
}

export interface AdCampaign {
    id: string;
    advertiserName: string;
    title: string;
    content: string;
    mediaUrl: string;
    targetRegions: string[];
    budget: number;
    clicks: number;
    impressions: number;
    status: 'active' | 'paused' | 'ended';
    adLink?: string;
    adCtaText?: string;
}

export interface GistPost {
    id: string;
    creator: GistPostCreator;
    timestamp: string;
    isSponsored?: boolean;
    isMonkixCIAssisted?: boolean;
    content: {
        text: string;
        translatedText?: string;
        imageUrl?: string;
        videoUrl?: string;
        gifUrl?: string;
        sound?: Sound;
        sentimentTag?: string;
        type?: 'standard' | 'product_card' | 'booking_card' | 'sponsored_ad' | 'donor_campaign' | 'impact_story' | 'poll' | 'q&a' | 'testimonial' | 'quote' | 'document' | 'gift_celebration' | 'cultural_snap';
        productId?: string;
        serviceId?: string;
        causeId?: string;
        pollOptions?: { id: string; option: string; votes: number; color?: string }[];
        pollDuration?: string;
        question?: string;
        quoteAuthor?: string;
        documentUrl?: string;
        documentName?: string;
        giftData?: {
            giftName: string;
            giftIcon: string;
            senderName: string;
            recipientName: string;
        };
        impactSnap?: CulturalImpactEntry;
        
        answer?: { text: string; author: GistPostCreator };
        testimonial?: { quote: string; authorName: string; authorRole?: string };
        
        filterName?: string; 
        overlayText?: string;
        backgroundColor?: string; 
        fontFamily?: string;
        gradient?: string;
        
        adCtaText?: string;
        adLink?: string;
    };
    languageCode?: LanguageCode;
    tags: string[]; 
    engagement: {
        likes: number;
        commentsCount: number;
        shares: number;
        saves: number;
        rating: number;
        ratingCount: number;
    };
    reposts?: number;
    viralScore?: number;
    comments: GistComment[];
    originalPostId?: string; 
    likedByMe?: boolean;
    userRating?: number;
    scheduledFor?: string; 
    status?: 'published' | 'scheduled' | 'draft';
}

export type GistStatusItem = 
  | { id: string; type: 'image'; url: string; duration: number; soundUrl?: string; }
  | { id: string; type: 'video'; url: string; duration: number; soundUrl?: string; }
  | { id: string; type: 'gif'; url: string; duration: number; soundUrl?: string; }
  | { id: string; type: 'text'; text: string; backgroundColor: string; gradient?: string; font: string; duration: number; soundUrl?: string; };

export interface GistStatus {
    id: string;
    creator: GistPostCreator;
    items: GistStatusItem[];
    timestamp: string;
}

export interface GistDraft {
    id: string;
    content: Partial<GistPost['content']>;
    lastModified: string;
}

export interface JobApplicant {
    id: string;
    jobListingId: string;
    professionalId: string;
    professionalName: string;
    professionalAvatar: string;
    status: 'applied' | 'test_invited' | 'test_completed' | 'test_passed' | 'test_failed' | 'interviewing' | 'rejected' | 'hired';
    appliedDate: string;
    cvUrl?: string;
    coverLetter?: string;
    otherDocuments?: { name: string; url: string }[];
}

export interface PreInterviewTest {
    id: string;
    jobListingId: string;
    title: string;
    questions: TestQuestion[];
    timeLimitMinutes: number;
    useCameraMonitoring: boolean;
    useMicrophoneMonitoring: boolean;
    passingScore: number;
}

export interface TestQuestion {
    id: string;
    type: 'mcq' | 'short_answer' | 'situational';
    questionText: string;
    options?: string[];
    correctAnswer?: string;
}

export type ApplicantAnswer = {
    questionId: string;
    answer: string;
};

export interface ApplicantTestAttempt {
    id: string;
    applicantId: string;
    testId: string;
    status: 'invited' | 'started' | 'completed' | 'graded';
    startTime?: string;
    endTime?: string;
    answers: ApplicantAnswer[];
    score?: number;
    isCheatingDetected?: boolean;
}

export interface LiveComment {
    id: string;
    authorName: string;
    authorAvatar: string;
    text: string;
}

export interface LiveStream {
    id: string;
    host: Partner;
    title: string;
    featuredProducts: Product[];
    comments: LiveComment[];
    followers: number;
    rating: number;
    backgroundMusic: { title: string; artist: string; url: string }[];
}

export interface AdminLiveEventSettings {
    isActive: boolean;
    eventName: string;
    bannerText: string;
    startTime: string;
    durationMinutes: number;
}

export interface TrendingItem {
    id: string;
    title: string;
    category: string;
    metric: string; 
    type: 'sound' | 'product' | 'script' | 'video';
    imageUrl?: string;
}
