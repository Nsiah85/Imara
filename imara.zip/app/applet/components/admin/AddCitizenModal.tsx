import React, { useState } from 'react';
import type { UserProfile } from '../../types.ts';
import Button from '../ui/Button.tsx';
import { XIcon } from '../icons/Icons.tsx';

interface AddCitizenModalProps {
    onClose: () => void;
    onAdd: (citizen: UserProfile) => void;
}

const AddCitizenModal: React.FC<AddCitizenModalProps> = ({ onClose, onAdd }) => {
    const [fullName, setFullName] = useState('');
    const [email, setEmail] = useState('');
    const [role, setRole] = useState<'user' | 'admin'>('user');
    const [country, setCountry] = useState('Ghana');
    const [region, setRegion] = useState('Accra');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const newCitizen: UserProfile = {
            id: crypto.randomUUID(),
            fullName,
            email,
            role,
            country,
            region,
        };
        onAdd(newCitizen);
    };

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
            <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 max-w-md w-full relative shadow-2xl">
                <button onClick={onClose} className="absolute top-4 right-4 p-2 text-gray-500 hover:text-gray-900 dark:hover:text-white transition-colors cursor-pointer">
                    <XIcon className="w-5 h-5" />
                </button>
                <h3 className="text-2xl font-bold mb-6 text-brand-navy-dark dark:text-white">Add New Citizen</h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium mb-1 dark:text-gray-300">Full Name</label>
                        <input type="text" required value={fullName} onChange={e => setFullName(e.target.value)} className="w-full p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 dark:text-white focus:ring-2 focus:ring-brand-gold outline-none" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1 dark:text-gray-300">Email Address</label>
                        <input type="email" required value={email} onChange={e => setEmail(e.target.value)} className="w-full p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 dark:text-white focus:ring-2 focus:ring-brand-gold outline-none" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1 dark:text-gray-300">Role</label>
                        <select value={role} onChange={e => setRole(e.target.value as any)} className="w-full p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 dark:text-white focus:ring-2 focus:ring-brand-gold outline-none">
                            <option value="user">User</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium mb-1 dark:text-gray-300">Country</label>
                            <input type="text" required value={country} onChange={e => setCountry(e.target.value)} className="w-full p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 dark:text-white focus:ring-2 focus:ring-brand-gold outline-none" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1 dark:text-gray-300">Region</label>
                            <input type="text" required value={region} onChange={e => setRegion(e.target.value)} className="w-full p-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 dark:text-white focus:ring-2 focus:ring-brand-gold outline-none" />
                        </div>
                    </div>
                    <div className="pt-4">
                        <Button type="submit" className="w-full justify-center">Create Citizen</Button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddCitizenModal;
