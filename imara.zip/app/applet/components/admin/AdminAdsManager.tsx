import React from 'react';
import Button from '../ui/Button.tsx';

const AdminAdsManager: React.FC = () => {
    return (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-[40px] border border-gray-100 dark:border-gray-700 shadow-sm animate-fade-in text-center">
            <h3 className="text-2xl font-display font-black text-brand-navy-dark dark:text-white uppercase mb-4 tracking-tight">Ads & Growth Management</h3>
            <p className="text-gray-500 mb-8 max-w-lg mx-auto">Manage platform-wide advertising campaigns, sponsorships, and growth metrics.</p>
            <div className="p-8 bg-gray-50 dark:bg-gray-900 rounded-3xl">
                <p className="text-sm font-bold text-gray-500">Ad Management Module Active</p>
                <div className="mt-8 flex justify-center gap-4">
                     <Button variant="outline">View Active Campaigns</Button>
                     <Button className="!bg-brand-gold !text-brand-navy-dark">Create Ad Slot</Button>
                </div>
            </div>
        </div>
    );
};

export default AdminAdsManager;
