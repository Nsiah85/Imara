
import { useState, useEffect } from 'react';
import { GoogleGenAI, Type } from '@google/genai';
import { mockProducts, mockProfessionals, mockTravelServices } from '../data/mockData';
import type { UserProfile, ShowcaseItem } from '../types';

type RecommendedItemStub = {
    id: string;
    itemType: 'product' | 'professional' | 'service';
};

export function usePersonalizedRecommendations(user: UserProfile | null) {
    const [recommendations, setRecommendations] = useState<ShowcaseItem[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        if (!user) {
            setIsLoading(false);
            return;
        }

        const generateRecommendations = async () => {
            setIsLoading(true);
            setError(null);

            try {
                 if (!process.env.API_KEY) {
                    throw new Error("API key is not configured.");
                }
                const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
                
                const productsForPrompt = mockProducts.slice(0, 20);
                const professionalsForPrompt = mockProfessionals.slice(0, 10);
                const servicesForPrompt = mockTravelServices;

                const prompt = `You are the Imara Cultural Discovery Engine. Your task is to select 8 diverse items for user: ${user.fullName} in ${user.country}.

User Preferences: Focus on verified cultural authenticity and trust.

Available Data:
- Products: ${JSON.stringify(productsForPrompt.map(({id, name, originCountry, trustScore, sustainabilityTags}) => ({id, name, originCountry, trustScore, tags: sustainabilityTags})))}
- Professionals: ${JSON.stringify(professionalsForPrompt.map(({id, name, location, industry, trustScore}) => ({id, name, location, industry, trustScore})))}
- Services: ${JSON.stringify(servicesForPrompt.map(({id, title, location, type}) => ({id, title, location, type})))}

Ranking Rules:
1. Trust Score > 90 must be prioritized.
2. Items from ${user.country} should be at the top.
3. Include at least 1 'Heritage Craft' or 'Handmade' product.
4. Return your selection as a valid JSON array of objects: { "id": string, "itemType": "product" | "professional" | "service" }
`;

                const responseSchema = {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            id: { type: Type.STRING },
                            itemType: { type: Type.STRING },
                        },
                        required: ['id', 'itemType'],
                    }
                };
                
                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-flash',
                    contents: prompt,
                    config: {
                        responseMimeType: "application/json",
                        responseSchema,
                    },
                });

                const stubs: RecommendedItemStub[] = JSON.parse(response.text);

                const fullItems: ShowcaseItem[] = stubs.map(stub => {
                    let foundItem;
                    if (stub.itemType === 'product') {
                        foundItem = mockProducts.find(p => p.id === stub.id);
                    } else if (stub.itemType === 'professional') {
                        foundItem = mockProfessionals.find(p => p.id === stub.id);
                    } else if (stub.itemType === 'service') {
                        foundItem = mockTravelServices.find(s => s.id === stub.id);
                    }
                    return foundItem ? { ...foundItem, itemType: stub.itemType } as ShowcaseItem : null;
                }).filter((item): item is ShowcaseItem => item !== null);

                setRecommendations(fullItems);

            } catch (e) {
                console.error("AI recommendations error:", e);
                setError("Discovery engine offline.");
                setRecommendations([]);
            } finally {
                setIsLoading(false);
            }
        };

        generateRecommendations();

    }, [user]);

    return { recommendations, isLoading, error };
}
