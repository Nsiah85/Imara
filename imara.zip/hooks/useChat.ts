
import { useState } from 'react';
import type { ChatMessage } from '../types.ts';
import { useLanguage } from '../contexts/LanguageContext.tsx';

const SYSTEM_INSTRUCTION = `You are Monkix AI, an expert shopping assistant and cultural guide for the Imara platform.
Your mission is to help users "Shop Smarter This Season".

Key Responsibilities:
1. **Deep Research**: When a user asks about a product type (e.g., "Kente cloth"), do not just list items. Explain the history, quality markers, and price ranges.
2. **Deal Finder**: Actively suggest the best deals from the ShopHub. If a user wants "shoes", prioritize discounted items or high-value bundles from AfroMall.
3. **Gift Guru**: Recommend personalized gifts based on the user's description of the recipient (e.g., "gift for my mother who loves cooking"). Suggest specific items from Edwaso or AfroMall.
4. **Platform Guide**:
    - **AfroMall**: Premium goods, fashion, tech.
    - **Edwaso**: Local foodstuff, bulk buying.
    - **Automotive**: Cars, parts, driving tests.
    - **FeelAfro**: Travel bookings, experiences.
    - **AfroTalents**: Hire professionals.
    - **Invest**: Micro-funding and donations.

Tone: Friendly, knowledgeable, Afro-centric, and helpful. Always try to close with a link or a call to action to visit a specific Hub page.

If a user has a complaint, apologize sincerely and state that you have forwarded it to the human support team. Do not try to resolve complex billing or order disputes yourself.`;

export function useChat() {
    const { t } = useLanguage();
    const [messages, setMessages] = useState<ChatMessage[]>([
        {
            role: 'model',
            content: "Akwaaba! I'm Monkix AI. I can help you shop smarter, find the best deals, or discover amazing African talent. What are you looking for today?",
        },
    ]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const getPosition = (): Promise<{ latitude: number; longitude: number } | null> => {
        return new Promise((resolve) => {
            if (!navigator.geolocation) {
                resolve(null);
                return;
            }
            navigator.geolocation.getCurrentPosition(
                (pos) => resolve({ latitude: pos.coords.latitude, longitude: pos.coords.longitude }),
                () => resolve(null),
                { timeout: 5000 }
            );
        });
    };

    const sendMessage = async (userMessage: string, attachment?: File | null, tool?: 'search' | 'maps') => {
        setIsLoading(true);
        setError(null);
        
        const newMessage: ChatMessage = { role: 'user', content: userMessage };
        setMessages(prev => [...prev, newMessage]);
        
        // Add empty model message for streaming/loading UX
        setMessages(prev => [...prev, { role: 'model', content: '' }]);

        try {
            let location = undefined;
            if (tool === 'maps') {
                location = await getPosition();
            }

            const history = messages.slice(1, -1).map(m => ({
                role: m.role,
                parts: [{ text: m.content }],
            }));
            
            const response = await fetch('/api/ai/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    messages: history, 
                    userMessage, 
                    tool, 
                    location,
                    systemInstruction: SYSTEM_INSTRUCTION
                })
            });

            if (!response.ok) {
                 throw new Error(`Server returned ${response.status}`);
            }

            const data = await response.json();
            
            let finalText = data.text;
            if (data.grounding && data.grounding.length > 0) {
                 const isMaps = tool === 'maps';
                 const links = data.grounding
                        .map((c: any) => {
                            if (isMaps && c.maps?.uri) return `- [${c.maps.title || 'Location'}](${c.maps.uri})`;
                            if (!isMaps && c.web?.uri) return `- [${c.web.title}](${c.web.uri})`;
                            return '';
                        })
                        .filter(Boolean);
                if (links.length > 0) {
                     finalText += "\n\nSources/Locations:\n" + links.join('\n');
                }
            }
            setMessages(prev => [...prev.slice(0, -1), { role: 'model', content: finalText }]);

        } catch (e) {
            const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
            console.error("Error sending message:", e);
            setError(errorMessage);
            setMessages(prev => [...prev.slice(0, -1), { role: 'model', content: `Oops, something went wrong. Please try again.` }]);
        } finally {
            setIsLoading(false);
        }
    };

    return { messages, isLoading, error, sendMessage };
}
