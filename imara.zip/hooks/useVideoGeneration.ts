
import { useState } from 'react';
import { GoogleGenAI } from '@google/genai';

interface VideoGenerationResult {
  videoUrl: string | null;
  isLoading: boolean;
  error: string | null;
  generateVideo: (prompt: string, aspectRatio?: '16:9' | '9:16') => Promise<void>;
}

export function useVideoGeneration(): VideoGenerationResult {
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generateVideo = async (prompt: string, aspectRatio: '16:9' | '9:16' = '9:16') => {
    if (!process.env.API_KEY) {
      setError("API Key not configured.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setVideoUrl(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: `Create a high-quality, cinematic promotional video for the following description. Style: Professional, vibrant, African aesthetic. Prompt: ${prompt}`,
        config: {
          numberOfVideos: 1,
          resolution: '720p', // fast-generate-preview only supports 720p or 1080p, check docs.
          aspectRatio: aspectRatio, 
        }
      });

      // Poll for completion
      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 5000)); // Check every 5 seconds
        operation = await ai.operations.getVideosOperation({ operation: operation });
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;

      if (downloadLink) {
          // In a real app with proper proxying, we might need to fetch the blob.
          // For this demo/preview, we append the key if needed or use the direct link if accessible.
          // The docs say "You must append an API key when fetching from the download link".
          const authenticatedLink = `${downloadLink}&key=${process.env.API_KEY}`;
          setVideoUrl(authenticatedLink);
      } else {
          setError("Video generation completed but no URL was returned.");
      }

    } catch (e) {
      console.error("Video generation failed:", e);
      setError(e instanceof Error ? e.message : "An unknown error occurred during video generation.");
    } finally {
      setIsLoading(false);
    }
  };

  return { videoUrl, isLoading, error, generateVideo };
}
