
import { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { useSecurity } from '../contexts/SecurityContext';

export function useContentSafety() {
    const { analyzeTextForFraud, isActionAllowed, reportSuspiciousActivity } = useSecurity();
    const [isSafe, setIsSafe] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const checkSafety = async (content: string): Promise<boolean> => {
        // Check if user is allowed to perform this action based on risk score
        if (!isActionAllowed(30)) { // 30 is a weight for posting content
            setError("Your account is restricted from posting due to suspicious activity.");
            return false;
        }

        if (!process.env.API_KEY || !content.trim()) return true;

        try {
            // First check for specific fraud patterns
            const fraudResult = await analyzeTextForFraud(content);
            if (!fraudResult.safe) {
                setIsSafe(false);
                setError(fraudResult.reason || "Content flagged as potential fraud.");
                reportSuspiciousActivity(20); // Increase risk score
                return false;
            }

            // Then check general safety (hate speech, etc.)
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const model = "gemini-2.5-flash";
            
            const prompt = `Classify the following text/content for a social media app. Is it safe? 
            Rules: No hate speech, harassment, explicit violence, illegal acts, or scam keywords (e.g. 'cashapp flip', 'send crypto').
            Content: "${content}"
            Return ONLY JSON: { "safe": boolean, "reason": "string" }`;

            const response = await ai.models.generateContent({
                model,
                contents: prompt,
                config: { responseMimeType: "application/json" }
            });

            const result = JSON.parse(response.text || '{}');
            setIsSafe(result.safe);
            if (!result.safe) {
                setError(result.reason);
                reportSuspiciousActivity(10);
            }
            return result.safe;

        } catch (e) {
            console.error("Safety check failed", e);
            return true;
        }
    };

    return { checkSafety, isSafe, error };
}
