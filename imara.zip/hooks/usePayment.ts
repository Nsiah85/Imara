
import { useState, useCallback } from 'react';
import { useCurrency } from '../contexts/CurrencyContext';
import { useAuth } from '../contexts/AuthContext';
import { useMonetization } from '../contexts/MonetizationContext';

interface PaymentConfig {
    amount: number; // Base amount in USD
    email: string;
    metadata: {
        type: 'order' | 'donation' | 'investment' | 'subscription';
        itemId?: string;
        vendorId?: string;
        description: string;
    };
    onSuccess: (reference: string) => void;
    onCancel?: () => void;
}

export function usePayment() {
    const { currency } = useCurrency();
    const { user } = useAuth();
    const { addEngagement } = useMonetization();
    const [isProcessing, setIsProcessing] = useState(false);

    // Load admin configured keys
    const getGatewayConfig = () => {
        try {
            const stored = localStorage.getItem('imara_payment_gateway_config');
            return stored ? JSON.parse(stored) : null;
        } catch {
            return null;
        }
    };

    const getLocalAmount = (usdAmount: number) => {
        // Simple conversion for demo
        const rates: Record<string, number> = { GHS: 15, NGN: 1500, KES: 130, ZAR: 19, USD: 1 };
        const rate = rates[currency] || 1;
        return Math.round(usdAmount * rate * 100);
    };

    const initializePayment = useCallback((config: PaymentConfig) => {
        setIsProcessing(true);
        const gatewayConfig = getGatewayConfig();
        // Use admin configured public key or fallback
        const publicKey = gatewayConfig?.paystackPublicKey || 'pk_test_xxxxxxxxxxxxxxxxxxxxxxxx';

        // Simulate Paystack script interaction
        const handler = (window as any).PaystackPop?.setup({
            key: publicKey,
            email: config.email,
            amount: getLocalAmount(config.amount),
            currency: currency === 'USD' ? 'GHS' : currency,
            metadata: {
                ...config.metadata,
                custom_fields: [
                    { display_name: "User ID", variable_name: "user_id", value: user?.id || 'guest' },
                    { display_name: "Platform", variable_name: "platform", value: "Imara" }
                ]
            },
            callback: (response: any) => {
                setIsProcessing(false);
                if (config.metadata.type === 'order' || config.metadata.type === 'investment') {
                    addEngagement('commerce_sale', { 
                        targetUserId: config.metadata.vendorId || 'platform',
                        amount: config.amount 
                    });
                }
                config.onSuccess(response.reference);
            },
            onClose: () => {
                setIsProcessing(false);
                if (config.onCancel) config.onCancel();
            }
        });

        if (handler) {
            handler.openIframe();
        } else {
            // Mock success if Paystack script isn't loaded
            setTimeout(() => {
                const ref = `IMR-REF-${Math.random().toString(36).substring(7).toUpperCase()}`;
                config.onSuccess(ref);
                setIsProcessing(false);
            }, 1500);
        }
    }, [currency, user, addEngagement]);

    return { initializePayment, isProcessing };
}
