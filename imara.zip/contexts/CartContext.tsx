
import React, { createContext, useContext, useState, useEffect } from 'react';
import type { Product, CartItem, TravelService } from '../types.ts';
import { ServiceType, ProductCategory } from '../types.ts';

interface CartContextType {
  cartItems: CartItem[];
  addToCart: (item: Product | TravelService) => void;
  updateQuantity: (productId: string, newQuantity: number) => void;
  removeFromCart: (productId: string) => void;
  totalItems: number;
  subtotal: number;
  clearCart: () => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  useEffect(() => {
    try {
      const storedCart = localStorage.getItem('imara_cart');
      if (storedCart) {
        setCartItems(JSON.parse(storedCart));
      }
    } catch (error) {
      console.error("Failed to load cart from localStorage", error);
      setCartItems([]);
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('imara_cart', JSON.stringify(cartItems));
    } catch (error) {
      console.error("Failed to save cart to localStorage", error);
    }
  }, [cartItems]);

  const addToCart = (item: Product | TravelService) => {
    let product: Product;

    // Type guard to check if it's a TravelService of type Meal
    if ('providerName' in item && item.type === ServiceType.MEAL) {
        // Convert TravelService (Meal) to a Product-like object
        product = {
            id: item.id,
            name: item.title,
            vendor: item.providerName,
            price: item.price,
            imageUrl: item.imageUrl,
            originCountry: item.location,
            sustainabilityTags: [],
            isVerified: true,
            /* FIX: Adding required trustScore property to satisfy Product interface */
            trustScore: 100,
            impactPerPurchase: 'Supports local cuisine',
            description: item.description,
            category: ProductCategory.FOODSTUFF,
        };
    } else if ('vendor' in item) {
        product = item as Product;
    } else {
        console.error("Item cannot be added to cart:", item);
        return;
    }

    setCartItems(prevItems => {
      const existingItem = prevItems.find(i => i.id === product.id);
      if (existingItem) {
        return prevItems.map(i =>
          i.id === product.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prevItems, { ...product, quantity: 1 }];
    });
  };

  const updateQuantity = (productId: string, newQuantity: number) => {
    setCartItems(prevItems => {
      if (newQuantity <= 0) {
        return prevItems.filter(item => item.id !== productId);
      }
      return prevItems.map(item =>
        item.id === productId ? { ...item, quantity: newQuantity } : item
      );
    });
  };

  const removeFromCart = (productId: string) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== productId));
  };
  
  const clearCart = () => {
    setCartItems([]);
  }

  const totalItems = cartItems.reduce((total, item) => total + item.quantity, 0);
  const subtotal = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);

  return (
    <CartContext.Provider value={{ cartItems, addToCart, updateQuantity, removeFromCart, totalItems, subtotal, clearCart }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = (): CartContextType => {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
