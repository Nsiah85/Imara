
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { clearLocalUserData, getStorageUsage } from '../utils/secureStorage';
import type { PrivacyConsent, SyncSettings } from '../types';

interface PrivacyContextType {
    hasConsented: boolean;
    consentData: PrivacyConsent | undefined;
    syncSettings: SyncSettings;
    acceptTerms: () => void;
    updateSyncSettings: (settings: SyncSettings) => void;
    purgeLocalData: () => void;
    storageUsageMB: number;
    requestDataExport: () => void;
}

const CURRENT_POLICY_VERSION = "1.0";

const PrivacyContext = createContext<PrivacyContextType | undefined>(undefined);

export const PrivacyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { user, updateUser } = useAuth();
    const [storageUsageMB, setStorageUsageMB] = useState(0);

    // Initial State derived from User Profile
    const [consentData, setConsentData] = useState<PrivacyConsent | undefined>(user?.privacyConsent);
    const [syncSettings, setSyncSettings] = useState<SyncSettings>(user?.syncSettings || { syncMedia: false, syncChats: true });

    useEffect(() => {
        if (user) {
            setConsentData(user.privacyConsent);
            setSyncSettings(user.syncSettings || { syncMedia: false, syncChats: true });
        }
        // Calculate storage usage
        setStorageUsageMB(getStorageUsage());
    }, [user]);

    const hasConsented = React.useMemo(() => {
        return consentData?.hasAcceptedTerms && 
               consentData?.hasAcceptedPrivacyPolicy && 
               consentData?.policyVersion === CURRENT_POLICY_VERSION;
    }, [consentData]);

    const acceptTerms = () => {
        const newConsent: PrivacyConsent = {
            hasAcceptedTerms: true,
            hasAcceptedPrivacyPolicy: true,
            acceptedAt: new Date().toISOString(),
            policyVersion: CURRENT_POLICY_VERSION
        };
        
        setConsentData(newConsent);
        
        // Sync to "Cloud" (Update User Profile)
        updateUser({ privacyConsent: newConsent });
    };

    const updateSyncSettings = (newSettings: SyncSettings) => {
        setSyncSettings(newSettings);
        updateUser({ syncSettings: newSettings });
    };

    const purgeLocalData = () => {
        clearLocalUserData();
        setStorageUsageMB(0);
        alert("Local data cleared successfully. Some content may need to be re-downloaded.");
    };

    const requestDataExport = () => {
        // Mock Export
        alert("Your data export request has been queued. You will receive an email with a secure download link within 24 hours.");
    };

    return (
        <PrivacyContext.Provider value={{
            hasConsented: !!hasConsented,
            consentData,
            syncSettings,
            acceptTerms,
            updateSyncSettings,
            purgeLocalData,
            storageUsageMB,
            requestDataExport
        }}>
            {children}
        </PrivacyContext.Provider>
    );
};

export const usePrivacy = () => {
    const context = useContext(PrivacyContext);
    if (context === undefined) {
        throw new Error('usePrivacy must be used within a PrivacyProvider');
    }
    return context;
};
