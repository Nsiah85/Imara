
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { GoogleGenAI } from '@google/genai';
import { useAuth } from './AuthContext';

interface SecurityContextType {
  riskScore: number;
  isDeviceTrusted: boolean;
  verifyImageConsistency: (file: File, type: 'face' | 'product') => Promise<{ safe: boolean; reason?: string }>;
  analyzeTextForFraud: (text: string) => Promise<{ safe: boolean; reason?: string }>;
  registerDevice: () => void;
  reportSuspiciousActivity: (weight: number) => void;
  isActionAllowed: (actionWeight: number) => boolean;
}

const SecurityContext = createContext<SecurityContextType | undefined>(undefined);

export const SecurityProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [riskScore, setRiskScore] = useState(0);
  const [isDeviceTrusted, setIsDeviceTrusted] = useState(true); // Default true for demo flow

  // 2. Identity Lock System
  const registerDevice = useCallback(() => {
    const fingerPrint = `${navigator.userAgent}-${window.screen.width}x${window.screen.height}-${Intl.DateTimeFormat().resolvedOptions().timeZone}`;
    const hashed = btoa(fingerPrint); // Simple hash for demo
    
    const storedHash = localStorage.getItem(`imara_trusted_device_${user?.id}`);
    
    if (storedHash && storedHash !== hashed) {
        setIsDeviceTrusted(false);
        // In a real app, trigger 2FA here
        alert("New device detected. Identity Lock active. Please verify via email (Simulated).");
        setIsDeviceTrusted(true); // Auto-resolve for demo
    } else {
        localStorage.setItem(`imara_trusted_device_${user?.id}`, hashed);
        setIsDeviceTrusted(true);
    }
  }, [user]);

  // 3. AI Behavior Risk Model - Decay
  useEffect(() => {
    const interval = setInterval(() => {
        setRiskScore(prev => Math.max(0, prev - 5)); // Decay risk score over time
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  const reportSuspiciousActivity = (weight: number) => {
      setRiskScore(prev => {
          const newScore = prev + weight;
          if (newScore > 80) console.warn("High Risk User Activity Detected");
          return newScore;
      });
  };

  const isActionAllowed = (actionWeight: number) => {
      // If user is already risky, block high-weight actions
      if (riskScore > 70 && actionWeight > 20) return false;
      return true;
  };

  // 1 & 4. AI Face Consistency & Marketplace Fraud Filters
  const verifyImageConsistency = async (file: File, type: 'face' | 'product'): Promise<{ safe: boolean; reason?: string }> => {
    if (!process.env.API_KEY) return { safe: true }; // Bypass if no key
    
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
        const model = "gemini-2.5-flash";

        const base64Data = await new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result?.toString().split(',')[1] || '');
            reader.readAsDataURL(file);
        });

        const prompt = type === 'face' 
            ? `Analyze this profile photo for a verified professional platform. 
               Check for: 
               1. Artificial/Stock Photo look (watermarks, overly perfect studio lighting).
               2. Celebrity impersonation.
               3. Deepfake artifacts.
               Return JSON: { "isReal": boolean, "reason": "string" }`
            : `Analyze this product image for an e-commerce marketplace.
               Check for:
               1. Watermarks from Alibaba, AliExpress, Amazon, or Temu.
               2. Text overlays indicating dropshipping.
               3. Counterfeit branding logos.
               Return JSON: { "isAuthentic": boolean, "reason": "string" }`;

        const response = await ai.models.generateContent({
            model,
            contents: [
                { inlineData: { mimeType: file.type, data: base64Data } },
                { text: prompt }
            ],
            config: { responseMimeType: "application/json" }
        });

        const result = JSON.parse(response.text || '{}');
        
        if (type === 'face') {
            return result.isReal ? { safe: true } : { safe: false, reason: result.reason || "Image flagged as potential impersonation or stock photo." };
        } else {
            return result.isAuthentic ? { safe: true } : { safe: false, reason: result.reason || "Image flagged for potential trademark/authenticity issues." };
        }

    } catch (e) {
        console.error("AI Verification Failed", e);
        return { safe: true }; // Fail open for UX in demo
    }
  };

  // 5. Text Fraud Scan
  const analyzeTextForFraud = async (text: string): Promise<{ safe: boolean; reason?: string }> => {
      if (!text.trim() || !process.env.API_KEY) return { safe: true };

      try {
          const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
          const model = "gemini-2.5-flash";
          const response = await ai.models.generateContent({
              model,
              contents: `Analyze text for fraud/scams on a marketplace app.
              Flags: "Cashapp only", "send code", "crypto investment", "password", "bank details".
              Text: "${text}"
              Return JSON: { "safe": boolean, "reason": "string" }`,
              config: { responseMimeType: "application/json" }
          });
          
          return JSON.parse(response.text || '{ "safe": true }');
      } catch (e) {
          return { safe: true };
      }
  };

  return (
    <SecurityContext.Provider value={{ 
        riskScore, 
        isDeviceTrusted, 
        verifyImageConsistency, 
        analyzeTextForFraud,
        registerDevice,
        reportSuspiciousActivity,
        isActionAllowed
    }}>
      {children}
    </SecurityContext.Provider>
  );
};

export const useSecurity = () => {
  const context = useContext(SecurityContext);
  if (context === undefined) {
    throw new Error('useSecurity must be used within a SecurityProvider');
  }
  return context;
};
