
import React, { createContext, useContext, useState, useMemo, useEffect, useCallback } from 'react';
import { LanguageCode } from '../types';

// Main translation object, providing key UI translations for an expanded list of languages.
const translations = {
  en: {
    general: { search: 'Search', viewAll: 'View All', back: 'Back', by: 'by', cancel: 'Cancel' },
    nav: { home: 'Toast', shopHub: 'ShopHub', findTalent: 'AfroTalents', invest: 'Impact', messages: 'Gossip' },
    mobileNav: { hub: 'Hubs', cart: 'Cart', account: 'Account', login: 'Login', invest: 'Impact' },
    toast: { onboarding: { title: 'Akwaaba to Imara.', subtitle: 'Share your voice, discover authentic culture, and empower communities.', cta: 'What %Moment' }, comment: 'Comment', share: 'Share', save: 'Save', translate: 'Translate', showOriginal: 'Show Original', sponsored: 'Sponsored', commentsTitle: 'Comments' },
    home: { hero: { title: 'Commerce in Unity, Pride in Strength', subtitle: 'Discover authentic goods, have the best travel experience, hire Talents, ride with African motor dealerships, and empower Africa’s communities all in this Extension', exploreMarketplace: 'Explore the ShopHub', empowerCommunities: 'Empower with Impact' }, featuredShopHub: { title: 'Featured from ShopHub' }, impact: { artisans: 'Artisans & Talents Supported', invested: 'Invested in Partner Businesses', communities: 'Communities Influenced' } },
    shop: { title: 'AfroMall', subtitle: 'Discover authentic, handcrafted goods from verified artisans across the continent.', searchPlaceholder: 'Search for products, artisans, or materials...', sortBy: 'Sort by', sort: { relevance: 'Relevance', priceAsc: 'Price: Low to High', priceDesc: 'Price: High to Low', nameAsc: 'Name: A-Z' }, filters: { sustainability: 'Sustainability', origin: 'Origin Country' }, noProductsFound: 'No Products Found', noProductsMessage: 'Try adjusting your search or filters to find more items.' },
    product: { yourImpact: 'Your Impact', addedToCart: 'Added to Cart!', addToCart: 'Add to Cart', messageVendor: 'Contact Dealer', youMightLike: 'You Might Also Like' },
    invest: { title: 'Make an Impact', subtitle: 'Your support creates ripples of change. Support entrepreneurs or donate to causes that empower communities.', tabs: { invest: 'Invest', donate: 'Donate' } },
    account: { loginPrompt: { title: 'Please log in to view your account.', button: 'Log In or Sign Up' }, title: 'My Account', welcome: 'Akwaaba, {{name}}!', editProfile: 'Edit Profile', logout: 'Log Out', rateExperience: { title: 'Rate Your Experience', completedOn: 'Completed on {{date}}', button: 'Rate Now' }, orderHistory: { title: 'Order History' }, orderDetails: { id: 'Order #{{id}}' }, myDetails: { title: 'My Details', name: 'Full Name', email: 'Email', country: 'Country' }, wishlist: { title: 'My Wishlist', description: 'View and manage your saved items.' }, language: { title: 'Language Settings' } },
    checkout: { review: { title: 'Review Your Order', shippingTo: 'Shipping To', deliveryTitle: 'Scheduled Delivery', deliveryDate: 'Date', deliveryTime: 'Time Slot', paymentMethod: 'Payment Method', orderSummary: 'Order Summary', button: 'Place Order' }, delivery: { title: 'Schedule Your Delivery', subtitle: 'This service is available for local orders. Choose a convenient date and time.', dateLabel: 'Delivery Date', timeLabel: 'Delivery Time Slot', button: 'Continue to Payment' } },
    findTalent: { title: 'AfroTalents', subtitle: 'Find and hire verified, skilled professionals across various industries for your next project.', filters: { searchPlaceholder: 'Search by name, role, or skills...', sortBy: 'Sort by', sort: { relevance: 'Relevance', name: 'Name: A-Z', rate: 'Rate: Low to High' }, industry: 'Filter by Industry' }, cta: { title: 'Are you a skilled professional?', subtitle: 'Join our network to connect with clients, showcase your portfolio, and grow your business.', button: 'Join as a Professional' }, noProfessionalsFound: 'No Professionals Found' },
    shopHub: { title: 'Akwaaba to the ShopHub', subtitle: 'Explore our diverse marketplaces, each designed to connect you with the best of Africa.', afroMall: { title: 'AfroMall', description: 'Shop for authentic fashion, beauty, and home decor from verified artisans.' }, feelAfro: { title: 'FeelAfro', description: 'Book flights, hotels, and unique travel experiences across the continent.' }, automotive: { title: 'Automotive', description: 'Buy vehicles from trusted African dealerships and book driving tests.' }, edwaso: { title: 'Edwaso', description: 'Get fresh, local produce and foodstuffs directly from farmers and market women.' }, investHub: { title: 'Impact Hub', description: 'Micro-invest in partner businesses or donate to community causes.', guide: '/invest' } },
    feelAfro: { title: 'FeelAfro Travel & Leisure', subtitle: 'Discover and book unforgettable experiences across the continent.', filters: { searchPlaceholder: 'Search for flights, hotels, cities...', priceRange: 'Price Range', rating: 'Minimum Rating', anyRating: 'Any', serviceType: 'Service Type', amenities: 'Amenities', flightClass: 'Flight Class', reset: 'Reset Filters' }, noServicesFound: 'No Services Found', noServicesMessage: 'Try adjusting your search filters to find more experiences.' },
    service: { notFound: 'Service Not Found', bookNow: 'Book Now', messageProvider: 'Message Provider', similarExperiences: 'Similar Experiences' },
    auth: { login: { button: 'Log In', title: 'Akwaaba!' }, signup: { button: 'Sign Up', title: 'Join Imara', selectionTitle: 'How would you like to join us?', customer: { title: 'As a Consumer/User', subtitle: 'Shop, invest, and track your impact.' }, partner: { title: 'As a Partner', subtitle: 'Sell products or offer your professional services.', vendorButton: 'Join as a Vendor', workerButton: 'Join as a Professional' } } },
    automotive: { bookTest: { title: 'Ready for Your Driving Test?', subtitle: 'Secure your spot by making a down payment. Our team will contact you to schedule the date.', button: 'Book a Driving Test' }, modal: { title: 'Book Your Driving Test', subtitle: 'Please fill out your details below. A non-refundable down payment of {{amount}} is required to secure your booking.', name: 'Full Name', email: 'Email', phone: 'Phone Number', vehicleType: 'Vehicle Type for Test', submit: 'Pay and Confirm' } },
    edwaso: { title: 'Edwaso Market', subtitle: 'Fresh foodstuffs, fruits, and vegetables direct from local farmers and market women.', filters: { searchPlaceholder: 'Search for yams, tomatoes, fish...' }, noProductsFound: 'No Products Found', noProductsMessage: 'Try a different search or check another market.' },
    ai: { greeting: "Akwaaba! How can I help you explore African products, services, or talent today?" }
  },
  ak: {
    general: { search: 'Hwehwɛ', viewAll: 'Hwɛ Ne Nyinaa', back: 'San Akyire', by: 'efiri', cancel: 'Gyae' },
    nav: { home: 'Toast', shopHub: 'Dwadibea', findTalent: 'AfroTalents', invest: 'Nkɛntɛnsoɔ', messages: 'Nkomɔ' },
    mobileNav: { hub: 'Ndwuma', cart: 'Kɛntɛn', account: 'Akonta', login: 'Kɔ mu' },
    home: { hero: { title: 'Dwadie wɔ Baakoyɛ mu, Ahomasoɔ wɔ Tumi mu', subtitle: 'Hwehwɛ nnoɔma ankasa, nya akwantuo osuahu pa, fa Adwumfoɔ, na hyɛ Abibiman mpɔtam den', exploreMarketplace: 'Hwehwɛ Dwadibea mu', empowerCommunities: 'Hyɛ Asetena mu den' } },
    shop: { title: 'AfroMall', subtitle: 'Tɔ nsaano adwuma ankasa firi adwumfoɔ a wɔagye wɔn atom wɔ abibiman mu.' },
    product: { yourImpact: 'Wo Nkɛntɛnsoɔ', addedToCart: 'Wɔde aka Kɛntɛn ho!', addToCart: 'Fa Kɔ Kɛntɛn mu', messageVendor: 'Kasa kyerɛ ɔtɔnfoɔ' },
    invest: { title: 'Yɛ Sika hyɛ mu', subtitle: 'Wo mmoa de nsakraeɛ kɛseɛ ba. Fa sika hyɛ nnwuma mu anaa boa nnɛɛma a ɛhyɛ mpɔtam den.' },
    auth: { login: { button: 'Kɔ mu', title: 'Akwaaba!' }, signup: { button: 'Yɛ Akonta Foforɔ', title: 'Bɛka Imara ho' } }
  },
  fr: {
    general: { search: 'Rechercher', viewAll: 'Voir Tout', back: 'Retour', by: 'par', cancel: 'Annuler' },
    nav: { home: 'Toast', shopHub: 'ShopHub', findTalent: 'AfroTalents', invest: 'Impact', messages: 'Gossip' },
    mobileNav: { hub: 'Hubs', cart: 'Panier', account: 'Compte', login: 'Connexion' },
    home: { hero: { title: 'Commerce en Unité, Fierté en Force', subtitle: 'Découvrez des produits authentiques, vivez la meilleure expérience de voyage, engagez des talents et renforcez les communautés africaines.', exploreMarketplace: 'Explorer le ShopHub', empowerCommunities: 'Soutenir un Investissement' } },
    shop: { title: 'AfroMall', subtitle: "Découvrez des produits authentiques, faits à la main par des artisans vérifiés à travers le continent." },
    product: { yourImpact: 'Votre Impact', addedToCart: 'Ajouté au panier !', addToCart: 'Ajouter au panier', messageVendor: 'Contacter le vendeur' },
    invest: { title: 'Investir', subtitle: 'Votre soutien crée des ondes de changement. Investissez dans des entrepreneurs ou faites un don à des causes.' },
    auth: { login: { button: 'Se connecter', title: 'Akwaaba!' }, signup: { button: 'S\'inscrire', title: 'Rejoindre Imara' } }
  },
  sw: {
    general: { search: 'Tafuta', viewAll: 'Tazama Zote', back: 'Rudi', by: 'na', cancel: 'Ghairi' },
    nav: { home: 'Toast', shopHub: 'Sokoni', findTalent: 'AfroTalents', invest: 'Ushawishi', messages: 'Gossip' },
    mobileNav: { hub: 'Vituo', cart: 'Gari', account: 'Akaunti', login: 'Ingia' },
    home: { hero: { title: 'Biashara kwa Umoja, Fahari kwa Nguvu', subtitle: 'Gundua bidhaa halisi, pata uzoefu bora wa usafiri, ajiri Vipaji, na uwezeshe jamii za Afrika.', exploreMarketplace: 'Gundua Sokoni', empowerCommunities: 'Wekeza Sasa' } },
    shop: { title: 'AfroMall', subtitle: 'Gundua bidhaa halisi, zilizotengenezwa kwa mikono na mafundi waliothibitishwa kote barani.' },
    product: { yourImpact: 'Mchango Wako', addedToCart: 'Imeongezwa!', addToCart: 'Weka Kwenye Gari', messageVendor: 'Tuma ujumbe kwa muuzaji' },
    invest: { title: 'Wekeza', subtitle: 'Msaada wako unaleta mabadiliko. Wekeza kwa wajasiriamali au changia mashirika yanayowezesha jamii.' },
    auth: { login: { button: 'Ingia', title: 'Akwaaba!' }, signup: { button: 'Jisajili', title: 'Jiunge na Imara' } }
  },
  ar: {
    general: { search: 'بحث', viewAll: 'مشاهدة الكل', back: 'رجوع', by: 'بواسطة', cancel: 'إلغاء' },
    nav: { home: 'توست', shopHub: 'مركز التسوق', findTalent: 'مواهب أفرو', invest: 'التأثير', messages: 'دردشة' },
    mobileNav: { hub: 'المراكز', cart: 'السلة', account: 'الحساب', login: 'دخول' },
    home: { hero: { title: 'تجارة في وحدة، فخر في قوة', subtitle: 'اكتشف السلع الأصيلة، عش أفضل تجربة سفر، وظف المواهب، وادعم مجتمعات أفريقيا.', exploreMarketplace: 'استكشف مركز التسوق', empowerCommunities: 'ادعم باستثمار' } },
    shop: { title: 'أفرو مول', subtitle: 'اكتشف السلع الأصيلة المصنوعة يدوياً من حرفيين معتمدين في جميع أنحاء القارة.' },
    product: { yourImpact: 'تأثيرك', addedToCart: 'أضيف إلى السلة!', addToCart: 'أضف إلى السلة', messageVendor: 'راسل البائع' },
    invest: { title: 'استثمر', subtitle: 'دعمك يخلق موجات من التغيير. استثمر في رواد الأعمال أو تبرع لقضايا تمكن المجتمعات.' },
    auth: { login: { button: 'تسجيل الدخول', title: 'أهلاً بعودتك' }, signup: { button: 'إنشاء حساب', title: 'انضم إلى إمارا' } }
  },
  ha: {
    general: { search: 'Bincika', viewAll: 'Duba Duka', back: 'Baya', by: 'daga', cancel: 'Soke' },
    nav: { home: 'Toast', shopHub: 'Kasuwa', findTalent: 'AfroTalents', invest: 'Tasiri', messages: 'Hira' },
    mobileNav: { hub: 'Cibiyoyi', cart: 'Keke', account: 'Asusu', login: 'Shiga' },
    home: { hero: { title: 'Ciniki cikin Haɗin Kai, Alfahari cikin Ƙarfi', subtitle: 'Gano kayayyaki na asali, sami mafi kyawun tafiye-tafiye, ɗauki hayar Masu Hazaka, da ƙarfafa al\'ummomin Afirka.', exploreMarketplace: 'Bincika Kasuwa', empowerCommunities: 'Zuba Jari' } },
    shop: { title: 'AfroMall', subtitle: 'Gano kayayyaki na asali, da aka yi da hannu daga masu sana\'a da aka tabbatar a fadin nahiyar.' },
    product: { yourImpact: 'Taimakon Ka', addedToCart: 'An ƙara!', addToCart: 'Sanya a Keke', messageVendor: 'Aika sako ga mai siyarwa' },
    invest: { title: 'Zuba Jari', subtitle: 'Taimakon ku yana haifar da canji. Zuba jari a cikin \'yan kasuwa ko ba da gudummawa ga ayyukan da ke ƙarfafa al\'ummomi.' },
    auth: { login: { button: 'Shiga', title: 'Akwaaba!' }, signup: { button: 'Bude Asusu', title: 'Shiga Imara' } }
  },
  yo: {
    general: { search: 'Wáà', viewAll: 'Wo Gbogbo Rẹ̀', back: 'Padà', by: 'lati ọwọ', cancel: 'Fagilee' },
    nav: { home: 'Toast', shopHub: 'Ọjà', findTalent: 'AfroTalents', invest: 'Ipa', messages: 'Ọrọ' },
    mobileNav: { hub: 'Àwọn Ibùdó', cart: 'Agbọ̀n', account: 'Àkọọ́lẹ̀', login: 'Wọlé' },
    home: { hero: { title: 'Ìṣòwò ní Ìṣọ̀kan, Ìgbéraga ní Agbára', subtitle: 'Ṣawari awọn ọja gidi, ni iriri irin-ajo ti o dara julọ, bẹwẹ Awọn Talent, ki o si fun awọn agbegbe Afirika ni agbara.', exploreMarketplace: 'Ṣawari Ọjà', empowerCommunities: 'Ṣe Idoko-owo' } },
    shop: { title: 'AfroMall', subtitle: 'Ṣawari awọn ọja oníṣe ọwọ́ gidi lati ọdọ awọn oníṣẹ́ ọnà ti a fọwọsi ni gbogbo ilẹ Afirika.' },
    product: { yourImpact: 'Ipa Rẹ', addedToCart: 'A ti fikun!', addToCart: 'Fi sí Agbọ̀n', messageVendor: 'Fiṣẹ ranṣẹ si olùtajà' },
    invest: { title: 'Ṣe Idoko-owo', subtitle: 'Atilẹyin rẹ n ṣẹda awọn iyipada. Ṣe idoko-owo ninu awọn oniṣowo tabi ṣetọrẹ si awọn idi ti o fun awọn agbegbe ni agbara.' },
    auth: { login: { button: 'Wọlé', title: 'Akwaaba!' }, signup: { button: 'Forukọsilẹ', title: 'Darapọ mọ Imara' } }
  },
  zu: {
    general: { search: 'Sesha', viewAll: 'Buka Konke', back: 'Emuva', by: 'ngu', cancel: 'Khansela' },
    nav: { home: 'Toast', shopHub: 'Indawo Yezitolo', findTalent: 'AfroTalents', invest: 'Umthelela', messages: 'Izingxoxo' },
    mobileNav: { hub: 'Amahabhu', cart: 'Inqola', account: 'I-akhawunti', login: 'Ngena' },
    home: { hero: { title: 'Ukuhweba Ngobunye, Ukuziqhenya Ngamandla', subtitle: 'Thola izimpahla zangempela, ube nokuhlangenwe nakho okungcono kakhulu kokuvakasha, qasha Amathalente, futhi unikeze amandla imiphakathi yase-Afrika.', exploreMarketplace: 'Hlola Indawo Yezitolo', empowerCommunities: 'Tshala Imali' } },
    shop: { title: 'AfroMall', subtitle: 'Thola izimpahla zangempela, ezenziwe ngezandla ezivela kubaculi abaqinisekisiwe kulo lonke izwekazi.' },
    product: { yourImpact: 'Umthelela Wakho', addedToCart: 'Kungeziwe!', addToCart: 'Faka Enqoleni', messageVendor: 'Thumela umyalezo kumdayisi' },
    invest: { title: 'Tshala Imali', subtitle: 'Ukwesekwa kwakho kudala amagagasi oshintsho. Tshala imali kosomabhizinisi noma unikele ezinhlosweni ezinikeza amandla imiphakathi.' },
    auth: { login: { button: 'Ngena', title: 'Akwaaba!' }, signup: { button: 'Bhalisa', title: 'Joyina i-Imara' } }
  }
};

interface Language {
    code: LanguageCode;
    name: string;
}

// Full list of languages supported
const languages: Language[] = [
    { code: LanguageCode.EN, name: 'English' },
    { code: LanguageCode.AK, name: 'Akan (Twi)' },
    { code: LanguageCode.FR, name: 'Français' },
    { code: LanguageCode.SW, name: 'Kiswahili' },
    { code: LanguageCode.AR, name: 'العربية' },
    { code: LanguageCode.HA, name: 'Hausa' },
    { code: LanguageCode.YO, name: 'Yorùbá' },
    { code: LanguageCode.ZU, name: 'isiZulu' },
];

// Helper to get nested value from object by string path
// Falls back to English if the key is not found in the current language
const get = (obj: any, path: string, fallbackLangObj: any) => {
  const keys = path.split('.');
  let current = obj;
  for (const key of keys) {
      if (current && typeof current === 'object' && key in current) {
          current = current[key];
      } else {
          // Key not found in current language, try fallback
          let fallbackCurrent = fallbackLangObj;
          for (const fallbackKey of keys) {
              if (fallbackCurrent && typeof fallbackCurrent === 'object' && fallbackKey in fallbackCurrent) {
                  fallbackCurrent = fallbackCurrent[fallbackKey];
              } else {
                  return path; // Return key if not found in fallback either
              }
          }
          return fallbackCurrent;
      }
  }
  return current;
};


interface LanguageContextType {
  language: LanguageCode;
  setLanguage: (language: LanguageCode) => void;
  t: (key: string, options?: { [key: string]: string | number }) => string;
  languages: Language[];
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<LanguageCode>(() => {
    try {
        const storedLang = localStorage.getItem('imara_language');
        if (storedLang && Object.values(LanguageCode).includes(storedLang as LanguageCode)) {
            return storedLang as LanguageCode;
        }
        return LanguageCode.EN;
    } catch {
        return LanguageCode.EN;
    }
  });

  useEffect(() => {
    try {
        localStorage.setItem('imara_language', language);
    } catch (error) {
        console.error("Failed to save language to localStorage", error);
    }
  }, [language]);

  const t = useCallback((key: string, options?: { [key: string]: string | number }): string => {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    let translation = get(translations[language], key, translations.en);

    if (typeof translation !== 'string') {
        // Fallback for missing parent keys
        const enTranslation = get(translations.en, key, translations.en);
        if(typeof enTranslation === 'string') {
            translation = enTranslation;
        } else {
            console.warn(`Translation for key '${key}' not found in '${language}' or fallback 'en'.`);
            return key;
        }
    }

    if (options) {
        Object.keys(options).forEach(optKey => {
            translation = translation.replace(new RegExp(`{{${optKey}}}`, 'g'), String(options[optKey]));
        });
    }
    return translation;
  }, [language]);
  
  const value = useMemo(() => ({ language, setLanguage, t, languages }), [language, t]);

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
