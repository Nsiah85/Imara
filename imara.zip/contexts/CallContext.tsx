import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import type { Participant } from '../types';

type CallType = 'voice' | 'video';
type CallStatus = 'ringing' | 'connected' | 'ended';

interface CallState {
    isActive: boolean;
    isMinimized: boolean;
    participant: Participant | null;
    type: CallType;
    status: CallStatus;
    duration: number;
    isMuted: boolean;
    isCameraOff: boolean;
}

interface CallContextType extends CallState {
    startCall: (participant: Participant, type: CallType) => void;
    endCall: () => void;
    toggleMinimize: () => void;
    toggleMute: () => void;
    toggleCamera: () => void;
    maximize: () => void;
}

const CallContext = createContext<CallContextType | undefined>(undefined);

export const CallProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [state, setState] = useState<CallState>({
        isActive: false,
        isMinimized: false,
        participant: null,
        type: 'voice',
        status: 'ended',
        duration: 0,
        isMuted: false,
        isCameraOff: false,
    });

    const startCall = useCallback((participant: Participant, type: CallType) => {
        setState({
            isActive: true,
            isMinimized: false,
            participant,
            type,
            status: 'ringing',
            duration: 0,
            isMuted: false,
            isCameraOff: false,
        });

        // Simulate connection
        setTimeout(() => {
            setState(prev => prev.isActive ? { ...prev, status: 'connected' } : prev);
        }, 3000);
    }, []);

    const endCall = useCallback(() => {
        setState(prev => ({ ...prev, isActive: false, status: 'ended', duration: 0 }));
    }, []);

    const toggleMinimize = useCallback(() => {
        setState(prev => ({ ...prev, isMinimized: !prev.isMinimized }));
    }, []);

    const maximize = useCallback(() => {
        setState(prev => ({ ...prev, isMinimized: false }));
    }, []);

    const toggleMute = useCallback(() => {
        setState(prev => ({ ...prev, isMuted: !prev.isMuted }));
    }, []);

    const toggleCamera = useCallback(() => {
        setState(prev => ({ ...prev, isCameraOff: !prev.isCameraOff }));
    }, []);

    // Timer effect
    React.useEffect(() => {
        let interval: number | null = null;
        if (state.isActive && state.status === 'connected') {
            interval = window.setInterval(() => {
                setState(prev => ({ ...prev, duration: prev.duration + 1 }));
            }, 1000);
        }
        return () => {
            if (interval) clearInterval(interval);
        };
    }, [state.isActive, state.status]);

    return (
        <CallContext.Provider value={{ ...state, startCall, endCall, toggleMinimize, toggleMute, toggleCamera, maximize }}>
            {children}
        </CallContext.Provider>
    );
};

export const useCall = () => {
    const context = useContext(CallContext);
    if (context === undefined) {
        throw new Error('useCall must be used within a CallProvider');
    }
    return context;
};