import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { Product } from '../types';
import { useAuth } from './AuthContext';

interface WishlistContextType {
  wishlistItems: Product[];
  addToWishlist: (product: Product) => void;
  removeFromWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;
}

const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

export const WishlistProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [wishlistItems, setWishlistItems] = useState<Product[]>([]);

  const getStorageKey = useCallback(() => {
    return user ? `imara_wishlist_${user.id}` : null;
  }, [user]);

  // Load wishlist from localStorage when user changes
  useEffect(() => {
    const storageKey = getStorageKey();
    if (!storageKey) {
      setWishlistItems([]); // Clear wishlist if no user
      return;
    }
    try {
      const storedWishlist = localStorage.getItem(storageKey);
      if (storedWishlist) {
        setWishlistItems(JSON.parse(storedWishlist));
      } else {
        setWishlistItems([]);
      }
    } catch (error) {
      console.error("Failed to load wishlist from localStorage", error);
      setWishlistItems([]);
    }
  }, [user, getStorageKey]);

  // Listen for changes in other tabs
  useEffect(() => {
    const handleStorageChange = (event: StorageEvent) => {
      const storageKey = getStorageKey();
      if (storageKey && event.key === storageKey) {
        try {
          setWishlistItems(JSON.parse(event.newValue || '[]'));
        } catch (error) {
          console.error("Failed to parse wishlist from storage event", error);
        }
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [getStorageKey]);

  // Save wishlist to localStorage when it changes
  useEffect(() => {
    const storageKey = getStorageKey();
    if (storageKey) {
      try {
        localStorage.setItem(storageKey, JSON.stringify(wishlistItems));
      } catch (error) {
        console.error("Failed to save wishlist to localStorage", error);
      }
    }
  }, [wishlistItems, getStorageKey]);

  const addToWishlist = (product: Product) => {
    if (!user) return; // Only allow logged-in users to add
    setWishlistItems(prevItems => {
      if (prevItems.some(item => item.id === product.id)) {
        return prevItems; // Already in wishlist
      }
      return [...prevItems, product];
    });
  };

  const removeFromWishlist = (productId: string) => {
    if (!user) return;
    setWishlistItems(prevItems => prevItems.filter(item => item.id !== productId));
  };

  const isInWishlist = (productId: string): boolean => {
    return wishlistItems.some(item => item.id === productId);
  };

  return (
    <WishlistContext.Provider value={{ wishlistItems, addToWishlist, removeFromWishlist, isInWishlist }}>
      {children}
    </WishlistContext.Provider>
  );
};

export const useWishlist = (): WishlistContextType => {
  const context = useContext(WishlistContext);
  if (context === undefined) {
    throw new Error('useWishlist must be used within a WishlistProvider');
  }
  return context;
};