
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useAuth } from './AuthContext';
import type { MonetizationProfile, UserProfile } from '../types';

interface MonetizationContextType {
    profile: MonetizationProfile;
    cis: number; // Creator Impact Score
    minRedeemThresholdTokens: number;
    getLevelProgress: () => number;
    addEngagement: (type: EarningAction, metadata: { targetUserId: string; postId?: string; amount?: number }) => void;
    redeemPoints: (amountTts: number, type: 'shop' | 'momo') => Promise<boolean>;
    payoutRequests: PayoutRequest[];
    payoutHistory: PayoutHistory[];
    adminStats: AdminStats;
    requestPayout: (amount: number) => Promise<{success: boolean; message: string}>;
    // Admin Controls
    updateSystemRates: (rates: Partial<EarningRates>) => void;
    handlePayoutAction: (id: string, action: 'approve' | 'reject') => void;
    adjustCIS: (userId: string, newScore: number) => void;
}

export type EarningAction = 'like_received' | 'comment_received' | 'share_received' | 'save_received' | 'view_qualified' | 'commerce_sale' | 'engagement_given';

interface EarningRates {
    like: number;
    comment: number;
    share: number;
    save: number;
    view: number;
    commerce: number;
    givenCap: number; // Daily cap for "engagement given"
}

interface PayoutRequest {
    id: string;
    userId: string;
    userName: string;
    amount: number;
    timestamp: string;
    status: 'pending' | 'approved' | 'rejected';
    fraudFlag: boolean;
}

interface PayoutHistory {
    id: string;
    amount: number;
    date: string;
    method: string;
}

interface AdminStats {
    totalPlatformEarnings: number;
    payoutLiability: number;
    fraudFlaggedPercent: number;
    commerceRevenueShare: number;
}

const MonetizationContext = createContext<MonetizationContextType | undefined>(undefined);

export const MonetizationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { user, updateUser } = useAuth();
    const [profile, setProfile] = useState<MonetizationProfile>(user?.monetization || {
        torts: 0,
        tokens: 0,
        level: 'Starter',
        totalEarnings: 0,
        pendingPayout: 0,
        earningsHistory: []
    });

    const [rates] = useState<EarningRates>({
        like: 5, comment: 15, share: 25, save: 30, view: 1, commerce: 100, givenCap: 50
    });

    const minRedeemThresholdTokens = 50; // $0.50 equivalent

    // --- FRAUD DETECTION UTILS ---
    const detectLoop = (targetId: string) => {
        const history = profile.earningsHistory.slice(0, 10);
        const interactions = history.filter(h => h.source.includes(targetId));
        return interactions.length > 3; 
    };

    // --- LEVEL PROGRESS ---
    const getLevelProgress = useCallback(() => {
        const torts = profile.torts;
        if (torts < 5000) return (torts / 5000) * 100;
        if (torts < 20000) return ((torts - 5000) / 15000) * 100;
        if (torts < 100000) return ((torts - 20000) / 80000) * 100;
        return 100;
    }, [profile.torts]);

    // Update level based on Torts
    useEffect(() => {
        let newLevel: MonetizationProfile['level'] = 'Starter';
        if (profile.torts >= 100000) newLevel = 'Premium Provider';
        else if (profile.torts >= 20000) newLevel = 'Creator';
        else if (profile.torts >= 5000) newLevel = 'Active';

        if (newLevel !== profile.level) {
            setProfile(prev => ({ ...prev, level: newLevel }));
        }
    }, [profile.torts, profile.level]);

    // --- CIS CALCULATION ---
    const calculateCIS = (u: UserProfile | null) => {
        if (!u) return 1.0;
        let score = 1.0;
        if (u.isVerified) score += 0.5;
        if (u.trustScore && u.trustScore > 90) score += 0.3;
        if (u.accountFlagged) score -= 0.5;
        return Math.max(0.5, Math.min(2.0, score));
    };

    const cis = React.useMemo(() => calculateCIS(user), [user]);

    // --- REDEEM LOGIC ---
    const redeemPoints = async (amountTts: number, type: 'shop' | 'momo'): Promise<boolean> => {
        if (profile.torts < amountTts) return false;

        // Mock network delay
        await new Promise(resolve => setTimeout(resolve, 1000));

        const updatedProfile: MonetizationProfile = {
            ...profile,
            torts: profile.torts - amountTts,
            tokens: Math.floor((profile.torts - amountTts) / 100),
            earningsHistory: [{
                date: new Date().toISOString(),
                source: `REDEEMED: ${type === 'shop' ? 'Gift Card' : 'Momo Payout'}`,
                amount: -(amountTts * 0.001),
                torts: -amountTts
            }, ...profile.earningsHistory].slice(0, 100)
        };

        setProfile(updatedProfile);
        updateUser({ monetization: updatedProfile });
        return true;
    };

    // --- CORE EARNING LOGIC ---
    const addEngagement = useCallback((type: EarningAction, metadata: { targetUserId: string; postId?: string; amount?: number }) => {
        if (!user || user.id === metadata.targetUserId) return;

        if (detectLoop(metadata.targetUserId)) {
            console.warn("Engagement Loop Detected - Nullifying Value");
            return;
        }

        let baseTorts = 0;
        switch (type) {
            case 'like_received': baseTorts = rates.like; break;
            case 'comment_received': baseTorts = rates.comment; break;
            case 'share_received': baseTorts = rates.share; break;
            case 'save_received': baseTorts = rates.save; break;
            case 'view_qualified': baseTorts = rates.view; break;
            case 'commerce_sale': baseTorts = (metadata.amount || 0) * 10; break; 
            case 'engagement_given': baseTorts = 0.5; break;
        }

        const earned = Math.round(baseTorts * cis);
        const earningValue = earned * 0.001;

        const newEntry = {
            date: new Date().toISOString(),
            source: `${type.toUpperCase()} from ${metadata.targetUserId}`,
            amount: earningValue,
            torts: earned
        };

        const updatedProfile: MonetizationProfile = {
            ...profile,
            torts: profile.torts + earned,
            tokens: Math.floor((profile.torts + earned) / 100),
            totalEarnings: profile.totalEarnings + earningValue,
            pendingPayout: profile.pendingPayout + earningValue,
            earningsHistory: [newEntry, ...profile.earningsHistory].slice(0, 100)
        };

        setProfile(updatedProfile);
        updateUser({ monetization: updatedProfile });
    }, [user, profile, rates, cis, updateUser]);

    return (
        <MonetizationContext.Provider value={{
            profile,
            cis,
            minRedeemThresholdTokens,
            getLevelProgress,
            addEngagement,
            redeemPoints,
            payoutRequests: [], 
            payoutHistory: [],
            adminStats: { totalPlatformEarnings: 154200, payoutLiability: 12400, fraudFlaggedPercent: 2.4, commerceRevenueShare: 45000 },
            requestPayout: async () => ({ success: true, message: "Request received" }),
            updateSystemRates: () => {},
            handlePayoutAction: () => {},
            adjustCIS: () => {}
        }}>
            {children}
        </MonetizationContext.Provider>
    );
};

export const useMonetization = () => {
    const context = useContext(MonetizationContext);
    if (!context) throw new Error('useMonetization must be used within MonetizationProvider');
    return context;
};
