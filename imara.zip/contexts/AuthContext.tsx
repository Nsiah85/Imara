
import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import type { UserProfile, GuardianDetails, Conversation } from '../types.ts';
import { 
    onAuthStateChangedListener, signOutUser, 
    createAuthUserWithEmailAndPassword, signInAuthUserWithEmailAndPassword,
    signInWithGoogle
} from '../firebase/auth.ts';
import { db, doc, getDoc, setDoc } from '../firebase/firestore.ts';

interface AuthContextType {
  user: UserProfile | null;
  isLoading: boolean;
  unreadGossipCount: number;
  login: (email: string, password?: string, details?: { fullName: string; country: string; region?: string; dateOfBirth?: string; guardianDetails?: GuardianDetails; role?: string; isVerified?: boolean; }) => Promise<UserProfile | null>;
  loginWithGoogleProvider: () => Promise<UserProfile | null>;
  logout: () => Promise<void>;
  updateUser: (updatedData: Partial<UserProfile>) => void;
  refreshGossipCount: () => void;
  savePost: (postId: string) => void;
  unsavePost: (postId: string) => void;
  isPostSaved: (postId: string) => boolean;
  followUser: (userIdToFollow: string) => void;
  unfollowUser: (userIdToUnfollow: string) => void;
  isFollowing: (userId: string) => boolean;
  addContact: (contactId: string) => void;
  removeContact: (contactId: string) => void;
  isContact: (contactId: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [unreadGossipCount, setUnreadGossipCount] = useState(0);

  // Helper to calculate unread messages from LocalStorage (can move to realtime later)
  const calculateUnread = (userId: string) => {
    try {
        const key = `imara_chats_${userId}`;
        const stored = localStorage.getItem(key);
        if (stored) {
            const chats: Conversation[] = JSON.parse(stored);
            const count = chats.filter(c => c.isUnread).length;
            setUnreadGossipCount(count);
        } else {
            setUnreadGossipCount(0);
        }
    } catch (e) {
        console.error("Failed to calculate unread gossip", e);
        setUnreadGossipCount(0);
    }
  };

  const refreshGossipCount = useCallback(() => {
      if (user) {
          calculateUnread(user.id);
      } else {
          setUnreadGossipCount(0);
      }
  }, [user]);

  useEffect(() => {
    const unsubscribe = onAuthStateChangedListener(async (firebaseUser) => {
      if (firebaseUser) {
        const userDocRef = doc(db, 'users', firebaseUser.uid);
        const userSnapshot = await getDoc(userDocRef);
        if (userSnapshot.exists()) {
          const userData = userSnapshot.data() as UserProfile;
          setUser({ ...userData, id: firebaseUser.uid });
          calculateUnread(firebaseUser.uid);
        } else {
            // User authenticated but no document yet, handle pending setups
            setUser(null);
        }
      } else {
        setUser(null);
        setUnreadGossipCount(0);
      }
      setIsLoading(false);
    });

    return unsubscribe;
  }, []);

  // Re-calculate when user changes
  useEffect(() => {
      refreshGossipCount();
  }, [user, refreshGossipCount]);

  const checkIntegrity = (email: string): { safe: boolean; reason?: string } => {
      const suspiciousDomains = ['tempmail.com', '10minutemail.com'];
      const domain = email.split('@')[1];
      if (suspiciousDomains.includes(domain)) {
          return { safe: false, reason: "Disposable email addresses are not permitted." };
      }
      return { safe: true };
  };

  const loginWithGoogleProvider = async (): Promise<UserProfile | null> => {
      setIsLoading(true);
      try {
          const result = await signInWithGoogle();
          const { user: firebaseUser } = result;
          
          const userDocRef = doc(db, 'users', firebaseUser.uid);
          const userSnapshot = await getDoc(userDocRef);
          
          let mergedProfile: UserProfile;
          if (!userSnapshot.exists()) {
             mergedProfile = {
                 id: firebaseUser.uid,
                 email: firebaseUser.email || '',
                 fullName: firebaseUser.displayName || 'Google User',
                 nativeName: '',
                 country: 'Ghana', 
                 region: '',
                 profileImageUrl: firebaseUser.photoURL || '',
                 role: 'user',
                 isVerified: false,
                 verificationStatus: 'unverified',
                 trustScore: 50,
                 accountFlagged: false,
                 twoFactorEnabled: false,
                 createdAt: new Date().toISOString(),
                 updatedAt: new Date().toISOString()
             };
             await setDoc(userDocRef, mergedProfile);
          } else {
             mergedProfile = userSnapshot.data() as UserProfile;
          }
          
          setUser(mergedProfile);
          localStorage.setItem('imara_user', JSON.stringify(mergedProfile));
          return mergedProfile;
      } catch (error) {
          console.error("Google Auth Failed", error);
          return null;
      } finally {
          setIsLoading(false);
      }
  };

  const login = async (email: string, password?: string, details?: { fullName: string; country: string; region?: string; dateOfBirth?: string; guardianDetails?: GuardianDetails; role?: string; isVerified?: boolean; }): Promise<UserProfile | null> => {
    const integrityCheck = checkIntegrity(email);
    if (!integrityCheck.safe) {
        alert(`Account creation blocked: ${integrityCheck.reason}`);
        return null;
    }

    if (!email || !password) return null;
    
    try {
        let result;
        const isSignupRequest = !!details;

        if (isSignupRequest) {
            result = await createAuthUserWithEmailAndPassword(email, password);
        } else {
            result = await signInAuthUserWithEmailAndPassword(email, password);
        }

        const { user: firebaseUser } = result;
        const userDocRef = doc(db, 'users', firebaseUser.uid);
        const userSnapshot = await getDoc(userDocRef);

        let mergedProfile: UserProfile;
        
        if (!userSnapshot.exists()) {
            const isAdmin = email.toLowerCase() === 'admin@imara.com';
            const userRole = details?.role ? (details.role as any) : (isAdmin ? 'admin' : 'user');
            const isVerif = details?.isVerified !== undefined ? details.isVerified : isAdmin;
            mergedProfile = {
                id: firebaseUser.uid,
                email: email,
                fullName: details?.fullName || (isAdmin ? 'Admin User' : 'New User'),
                nativeName: '',
                country: details?.country || 'Ghana',
                region: details?.region || '',
                ...(details?.dateOfBirth ? { dateOfBirth: details.dateOfBirth } : {}),
                ...(details?.guardianDetails ? { guardianDetails: details.guardianDetails } : {}),
                profileImageUrl: '',
                role: userRole,
                isVerified: isVerif,
                verificationStatus: isVerif ? 'verified' : 'unverified',
                trustScore: 50,
                accountFlagged: false,
                twoFactorEnabled: false,
                followingIds: [],
                followerIds: [],
                savedPostIds: [],
                contactIds: [],
                socialMediaLinks: {},
                website: '',
                showNativeName: false,
                profileVisibility: 'public',
                privacyConsent: {
                    hasAcceptedTerms: false,
                    hasAcceptedPrivacyPolicy: false,
                    acceptedAt: '',
                    policyVersion: ''
                },
                syncSettings: {
                    syncMedia: false,
                    syncChats: true
                }
            };
            await setDoc(userDocRef, mergedProfile);
            if (details) sessionStorage.setItem('imara_is_new_user', 'true');
        } else {
            mergedProfile = { ...userSnapshot.data() as UserProfile, id: firebaseUser.uid };
        }
        
        setUser(mergedProfile);
        return mergedProfile;
    } catch (error: any) {
        console.error("Login/Signup failed", error);
        if (error.message?.includes('auth/firebase-app-check-token-is-invalid') || (error.code === 'auth/firebase-app-check-token-is-invalid')) {
            alert("App Check Configuration Notice:\nYour Firebase project has 'Enforce App Check' enabled for Authentication, but no Recaptcha Site Key was provided. Please disable this enforcement in your Firebase console, or add VITE_RECAPTCHA_SITE_KEY to your env.");
        } else {
            alert(`Authentication Error: ${error.message || String(error)}`);
        }
        return null;
    }
  };

  const logout = async () => {
    try {
      await signOutUser();
      setUser(null);
      setUnreadGossipCount(0);
    } catch (error) {
      console.error("Failed to logout", error);
    }
  };

  const updateUser = async (updatedData: Partial<UserProfile>) => {
    if (!user) return;
    const updatedUser = { ...user, ...updatedData };
    setUser(updatedUser);
    try {
      await setDoc(doc(db, 'users', user.id), updatedUser, { merge: true });
    } catch (error) {
      console.error("Failed to update user in Firestore", error);
    }
  };

  const savePost = (postId: string) => {
    if (!user) return;
    updateUser({ savedPostIds: [...(user.savedPostIds || []), postId] });
  };
  
  const unsavePost = (postId: string) => {
    if (!user) return;
    updateUser({ savedPostIds: (user.savedPostIds || []).filter(id => id !== postId) });
  };

  const isPostSaved = (postId: string) => {
    return user?.savedPostIds?.includes(postId) || false;
  };

  const followUser = (userIdToFollow: string) => {
    if (!user || (user.followingIds || []).includes(userIdToFollow)) return;
    updateUser({ followingIds: [...(user.followingIds || []), userIdToFollow] });
  };

  const unfollowUser = (userIdToUnfollow: string) => {
      if (!user) return;
      updateUser({ followingIds: (user.followingIds || []).filter(id => id !== userIdToUnfollow) });
  };

  const isFollowing = (userId: string) => {
      return user?.followingIds?.includes(userId) || false;
  };

  const addContact = (contactId: string) => {
    if (!user || (user.contactIds || []).includes(contactId)) return;
    updateUser({ contactIds: [...(user.contactIds || []), contactId] });
  };

  const removeContact = (contactId: string) => {
    if (!user) return;
    updateUser({ contactIds: (user.contactIds || []).filter(id => id !== contactId) });
  };

  const isContact = (contactId: string) => {
    return user?.contactIds?.includes(contactId) || false;
  };
  
  const value = useMemo(() => ({ 
      user, 
      isLoading, 
      unreadGossipCount, 
      login, 
      loginWithGoogleProvider,
      logout, 
      updateUser, 
      refreshGossipCount,
      savePost, 
      unsavePost, 
      isPostSaved, 
      followUser, 
      unfollowUser, 
      isFollowing, 
      addContact, 
      removeContact, 
      isContact 
    }), [user, isLoading, unreadGossipCount, refreshGossipCount]);

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

