import React, { createContext, useContext, useState, useMemo, useEffect, useCallback } from 'react';
import { useAuth } from './AuthContext.tsx';
import { getCurrencyForCountry } from '../utils/currency.ts';

interface CurrencyContextType {
  currency: string;
  setCurrency: (currency: string) => void;
  formatCurrency: (amount: number, options?: Intl.NumberFormatOptions) => string;
  supportedCurrencies: string[];
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

const BASE_CURRENCY = 'USD';

const exchangeRates: { [key: string]: number } = {
    USD: 1,
    GHS: 15.00,
    NGN: 1480.00,
    KES: 130.00,
    ZAR: 18.50,
    EUR: 0.92,
    GBP: 0.79,
    CAD: 1.36,
    XOF: 605.00, // CFA Franc (Senegal, etc.)
    XAF: 605.00, // CFA Franc (Cameroon, etc.)
    UGX: 3750.00, // Ugandan Shilling
    TZS: 2580.00, // Tanzanian Shilling
    RWF: 1300.00, // Rwandan Franc
    BIF: 2850.00, // Burundian Franc
    ETB: 57.00, // Ethiopian Birr
    AOA: 830.00, // Angolan Kwanza
    BWP: 13.50, // Botswana Pula
    CDF: 2800.00, // Congolese Franc
    ZMW: 25.50, // Zambian Kwacha
    MZN: 63.50, // Mozambican Metical
};

const supportedCurrencies = Object.keys(exchangeRates);

export const CurrencyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [currency, setCurrency] = useState<string>(BASE_CURRENCY);

  useEffect(() => {
    // Set default currency based on user's country for personalization
    if (user?.country) {
        const userCurrency = getCurrencyForCountry(user.country);
        if (supportedCurrencies.includes(userCurrency)) {
            setCurrency(userCurrency);
        } else {
             setCurrency(BASE_CURRENCY);
        }
    } else {
        // Default for guests. Could be based on browser locale in a real app.
        setCurrency(BASE_CURRENCY);
    }
  }, [user]);

  const formatCurrency = useCallback((amountInBaseCurrency: number, options?: Intl.NumberFormatOptions) => {
    const rate = exchangeRates[currency] || 1;
    const convertedAmount = amountInBaseCurrency * rate;
    try {
        const primaryOptions: Intl.NumberFormatOptions = {
            style: 'currency',
            currency,
            ...options,
        };
        return new Intl.NumberFormat(undefined, primaryOptions).format(convertedAmount);
    } catch (e) {
        // Fallback for unsupported currencies in Intl.NumberFormat
        console.warn(`Currency formatting for ${currency} is not widely supported. Using symbol instead.`);
        const fallbackOptions: Intl.NumberFormatOptions = {
            style: 'currency',
            currency: 'USD', 
            ...options
        };
        const formattedAmount = new Intl.NumberFormat(undefined, fallbackOptions).format(convertedAmount);
        return formattedAmount.replace('$', `${currency} `);
    }
  }, [currency]);

  const value = {
    currency,
    setCurrency,
    formatCurrency,
    supportedCurrencies,
  };

  return (
    <CurrencyContext.Provider value={value}>
      {children}
    </CurrencyContext.Provider>
  );
};

export const useCurrency = (): CurrencyContextType => {
  const context = useContext(CurrencyContext);
  if (context === undefined) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
};