
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { mockUserOrders, mockGiftCards, mockUsers } from '../data/mockData.ts';

// Types for the Sync Engine
type SyncStatus = 'synced' | 'pending' | 'error';

interface SyncItem {
    id: string;
    collection: string;
    docId: string;
    data: any;
    action: 'create' | 'update' | 'delete';
    timestamp: number;
    status: SyncStatus;
    retryCount: number;
}

interface DataSyncContextType {
    syncState: 'online' | 'offline' | 'syncing';
    pendingChanges: number;
    saveData: (collection: string, docId: string, data: any, action?: 'create' | 'update' | 'delete') => Promise<void>;
    getData: (collection: string) => any;
    forceSync: () => Promise<void>;
}

const DataSyncContext = createContext<DataSyncContextType | undefined>(undefined);

const SYNC_QUEUE_KEY = 'imara_sync_queue';

// Mapping collections to localStorage keys for persistence
const COLLECTION_MAP: Record<string, string> = {
    'orders': 'imara_orders',
    'users': 'imara_all_users',
    'gifts': 'imara_admin_gift_cards',
    'system/payments': 'imara_payment_gateway_config',
    'system/delivery': 'imara_delivery_config',
    'system/platform': 'imara_system_config',
    'system/whatsapp': 'imara_whatsapp_config',
    'system/governance': 'imara_package_governance',
    'system/live': 'imara_live_event'
};

export const DataSyncProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [queue, setQueue] = useState<SyncItem[]>([]);
    const [syncState, setSyncState] = useState<'online' | 'offline' | 'syncing'>('online');
    
    // 1. Load Queue on Mount
    useEffect(() => {
        const storedQueue = localStorage.getItem(SYNC_QUEUE_KEY);
        if (storedQueue) {
            setQueue(JSON.parse(storedQueue));
        }
        
        const handleOnline = () => setSyncState('online');
        const handleOffline = () => setSyncState('offline');
        
        window.addEventListener('online', handleOnline);
        window.addEventListener('offline', handleOffline);
        
        return () => {
            window.removeEventListener('online', handleOnline);
            window.removeEventListener('offline', handleOffline);
        };
    }, []);

    // 2. Persist Queue when it changes
    useEffect(() => {
        localStorage.setItem(SYNC_QUEUE_KEY, JSON.stringify(queue));
    }, [queue]);

    // Helper to persist data to local storage synchronously (Write-Ahead)
    const persistToLocal = (collection: string, docId: string, data: any, action: string) => {
        const storageKey = COLLECTION_MAP[collection] || `imara_${collection}`;
        
        try {
            const currentStr = localStorage.getItem(storageKey);
            
            // Scenario A: Single Object (Configs) - e.g., 'system/payments'
            if (collection.startsWith('system/')) {
                const currentObj = currentStr ? JSON.parse(currentStr) : {};
                const newObj = { ...currentObj, ...data };
                localStorage.setItem(storageKey, JSON.stringify(newObj));
                console.log(`[DataSync] Updated config ${storageKey}`);
                return;
            }

            // Scenario B: Arrays (Orders, Users, Gifts)
            let items = currentStr ? JSON.parse(currentStr) : [];
            
            // Initialize from mocks if empty and it's a known collection
            if (items.length === 0) {
                if (collection === 'orders') items = [...mockUserOrders];
                if (collection === 'gifts') items = [...mockGiftCards];
                if (collection === 'users') items = [...mockUsers];
            }

            if (action === 'delete') {
                items = items.filter((item: any) => (item.id || item.code) !== docId);
            } else {
                const index = items.findIndex((item: any) => (item.id || item.code) === docId);
                if (index >= 0) {
                    // Update existing
                    items[index] = { ...items[index], ...data };
                } else {
                    // Create new
                    items.push({ ...data, id: docId });
                }
            }
            
            localStorage.setItem(storageKey, JSON.stringify(items));
            console.log(`[DataSync] Updated collection ${collection}, count: ${items.length}`);

        } catch (e) {
            console.error(`[Sync] Failed to persist locally to ${storageKey}`, e);
        }
    };

    // 3. The Core Save Function
    const saveData = useCallback(async (collection: string, docId: string, data: any, action: 'create' | 'update' | 'delete' = 'update') => {
        // 1. Optimistic Local Update
        persistToLocal(collection, docId, data, action);

        // 2. Queue for Cloud Sync
        const newItem: SyncItem = {
            id: crypto.randomUUID(),
            collection,
            docId,
            data,
            action,
            timestamp: Date.now(),
            status: 'pending',
            retryCount: 0
        };

        setQueue(prev => [...prev, newItem]);
        
        // 3. Trigger Cloud Sync immediately if online (Simulation)
        if (navigator.onLine) {
            processQueueItem(newItem);
        }
    }, []);

    // 4. Helper to get data synchronously
    const getData = useCallback((collection: string) => {
        const storageKey = COLLECTION_MAP[collection] || `imara_${collection}`;
        const str = localStorage.getItem(storageKey);
        return str ? JSON.parse(str) : null;
    }, []);

    // 5. Process a single item (Mock Cloud Sync)
    const processQueueItem = async (item: SyncItem) => {
        setSyncState('syncing');
        try {
            // SIMULATION: In a real app, this calls Firebase/Firestore
            // await setDoc(doc(db, item.collection, item.docId), item.data, { merge: true });
            
            await new Promise(resolve => setTimeout(resolve, 800)); // Network delay simulation
            
            setQueue(prev => prev.filter(i => i.id !== item.id));
            setSyncState('online');
            
        } catch (error) {
            console.error(`[Sync] Failed to sync ${item.collection}/${item.docId}`, error);
            setSyncState('online');
            setQueue(prev => prev.map(i => 
                i.id === item.id ? { ...i, retryCount: i.retryCount + 1, status: 'error' } : i
            ));
        }
    };

    // 6. Background Sync Loop
    useEffect(() => {
        const interval = setInterval(() => {
            if (navigator.onLine && queue.length > 0 && syncState !== 'syncing') {
                const nextItem = queue[0];
                processQueueItem(nextItem);
            }
        }, 5000); 
        return () => clearInterval(interval);
    }, [queue, syncState]);

    const forceSync = async () => {
        if (queue.length === 0) return;
        setSyncState('syncing');
        for (const item of queue) {
            await processQueueItem(item);
        }
    };

    return (
        <DataSyncContext.Provider value={{
            syncState,
            pendingChanges: queue.length,
            saveData,
            getData,
            forceSync
        }}>
            {children}
        </DataSyncContext.Provider>
    );
};

export const useDataSync = () => {
    const context = useContext(DataSyncContext);
    if (context === undefined) {
        throw new Error('useDataSync must be used within a DataSyncProvider');
    }
    return context;
};
